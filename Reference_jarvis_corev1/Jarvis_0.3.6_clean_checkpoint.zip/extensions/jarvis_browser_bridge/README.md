# Jarvis Browser Bridge

This Manifest V3 extension gives Jarvis structured access to the user's normal Chromium browser without synthetic mouse/keyboard input.

## Development install

1. Start Jarvis first.
2. In Microsoft Edge open `edge://extensions` (or in Chrome open `chrome://extensions`).
3. Enable **Developer mode**.
4. Choose **Load unpacked**.
5. Select this folder: `extensions/jarvis_browser_bridge`.
6. Leave the extension enabled. It reconnects to the loopback Jarvis core automatically.

The extension requests access to webpages because Jarvis needs to read visible page structure and interact with page elements. Password values are never exposed. Browser-internal pages such as `edge://` / `chrome://` are intentionally unsupported.

## 0.3.1 structural controls

The 0.3.1 bridge advertises its supported operations to the Jarvis core and adds persistent media targeting plus structural controls for volume, mute/unmute, seek, restart, playback speed, and video fullscreen. Common tab switching and page scrolling remain browser-API/DOM operations; no synthetic desktop input is used.

When testing an unpacked extension after updating these files, click **Reload** once in `edge://extensions` / `chrome://extensions` so the service worker and content script use the new bridge version.

## 0.3.1 repair1 verification behavior

The repair1 bridge verifies the resulting media state before the core accepts success. It prefers YouTube's main structural video, verifies volume/mute/seek/rate/playback changes, restarts from the beginning with playback resumed, and uses a reversible Jarvis immersive + Chromium window-fullscreen fallback when native fullscreen entry is blocked by browser user-gesture requirements. Reload the unpacked extension once after installing this repair.
