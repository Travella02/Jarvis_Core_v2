'use strict';

const path = require('node:path');
const packageDocument = require('./package.json');
const {
  createPackagerIgnore,
  productionDependencyNames,
} = require('./scripts/packaging_scope.cjs');
const {
  installWindowsPackagerDiagnostics,
} = require('./scripts/windows_packager_diagnostics.cjs');

installWindowsPackagerDiagnostics({projectRoot: __dirname});
const productionDependencies = productionDependencyNames(packageDocument);

module.exports = {
  packagerConfig: {
    asar: true,
    name: 'JarvisRealTime',
    executableName: 'JarvisRealTime',
    icon: path.join(__dirname, 'apps', 'desktop', 'electron', 'assets', 'icon'),
    ignore: createPackagerIgnore(packageDocument),
    overwrite: true,
    // Use Electron Packager's standard temporary staging. repair5 replaces
    // only the unreliable archive extractor and leaves the normal final move intact.
    // With no production Node dependencies, bypass npm pruning and reject the
    // entire development node_modules tree at the copy filter.
    prune: productionDependencies.length > 0,
    // Electron copies two files instead of traversing thousands of Python
    // runtime files. Jarvis verifies and extracts this bundle on first launch.
    extraResource: [
      path.join(__dirname, 'build', 'runtime_bundle.zip'),
      path.join(__dirname, 'build', 'runtime_bundle-manifest.json'),
    ],
    // Preserved for a later signed/branding build. repair4 deliberately skips
    // Electron Packager's executable resource editor while isolating the stall.
    win32metadata: {
      CompanyName: 'Jarvis Real Time',
      FileDescription: 'Jarvis Real Time Desktop Alpha',
      OriginalFilename: 'JarvisRealTime.exe',
      ProductName: 'Jarvis Real Time',
      InternalName: 'JarvisRealTime',
    },
  },
  rebuildConfig: {},
  makers: [
    {
      name: '@electron-forge/maker-squirrel',
      config: {
        name: 'JarvisRealTime',
        authors: 'Tanner Yarman',
        description: 'Jarvis Real Time Desktop Alpha',
        setupExe: 'Jarvis_Real_Time_Setup.exe',
        setupIcon: path.join(__dirname, 'apps', 'desktop', 'electron', 'assets', 'icon.ico'),
        createDesktopShortcut: true,
        createStartMenuShortcut: true,
        shortcutName: 'Jarvis Real Time',
        noMsi: true,
      },
    },
    {
      name: '@electron-forge/maker-zip',
      platforms: ['win32'],
    },
  ],
};
