# 0.3.3 — Runtime Reliability

## Goal

Make Jarvis start reliably with a self-managed runtime on a fresh or stale development checkout without asking the user to install internal Python packages, while keeping installed builds self-contained and making local API cost reporting distinguish cheap text/Luna work from Realtime audio work.

## What changed

- The desktop now performs a private runtime preflight before starting the local core in development mode.
- If `.venv` is missing, the development launcher creates it with Python 3.12; if required modules are missing, it runs Jarvis's own dependency bootstrap automatically instead of failing later with a Browser Bridge 404/WebSocket symptom.
- The required runtime set remains `fastapi`, `httpx`, `uvicorn`, and `websockets`, sourced from the project dependency contract.
- Installed builds continue to use the checksum-verified bundled private Python runtime. Before reusing an extracted runtime, Jarvis now verifies that the runtime can actually import FastAPI, HTTPX, Uvicorn, WebSockets, Jarvis, and the core app; a damaged/incomplete runtime is re-extracted from the verified bundle.
- Web Intelligence, Browser Control planning, and Connected Actions planning now record their Responses/Luna usage through text-model pricing instead of the Realtime audio pricing lane.
- Usage records now carry `provider` and `purpose` attribution, and summaries expose tracked paid-call counts plus provider/purpose call totals.
- The Insights cost panel shows tracked paid calls, text/Luna calls, and Realtime calls separately.
- No aggressive model-routing, context-reduction, or intelligence-reduction optimization is included. This release improves reliability and measurement first.
- Account Foundation remains local-first; Cloud Sync moves to 0.3.4.

## User-facing setup contract

Normal users should never install Python, `websockets`, FastAPI, Uvicorn, or other internal dependencies manually. Installed Jarvis builds own their runtime. External services should require only ordinary user authorization such as sign-in, OAuth consent, or OS/browser permission prompts.

## Compatibility

- Requires accepted `0.3.2 — Account Foundation`.
- Existing `.env`, account data, memory, tasks, browser state, logs, and local data are preserved.
- Browser Control behavior is not intentionally changed by this release.
