# 0.3.5 — Billing & Entitlements

**Date:** 2026-09-01  
**Required previous version:** 0.3.4  
**Status:** Candidate for live acceptance

## Purpose

0.3.5 establishes the Cloud-authoritative commercial boundary for Jarvis. The desktop is treated as potentially hostile: local UI state, cached entitlements, plan labels, local databases, environment variables, and request bodies are never financial authority for ORVEX-funded provider work.

## What changed

- Added a configuration-driven capability/plan catalog. Feature code uses stable capability keys rather than hardcoded customer tier names.
- Classifies entitlements as `cloud_authoritative` or `local_advisory`. Catalog validation rejects attempts to make a purely local capability securely tier-exclusive without a real Cloud boundary.
- Added a separate authoritative Billing SQLite store for plan state, billing periods, monthly included allowance, purchased top-ups, reservations, provider evidence, payment events, and durable Realtime state.
- Monthly included allowance spends before purchased top-ups. Monthly allowance does not roll over; purchased top-ups persist until consumed.
- Added reserve → atomic execute claim → provider execution → authoritative evidence → settle lifecycle. Ambiguous provider outcomes become `uncertain` and keep authorization held for reconciliation rather than automatically refunding.
- Added idempotency and concurrent replay protection so the same provider operation cannot execute twice under overlap.
- Added versioned metering/pricing configuration. Billing consumes normalized units rather than provider-specific pricing logic, and model/pricing-profile mismatches fail closed.
- Added narrow Cloud provider operations for hosted reasoning, Web Intelligence, wake transcription, ElevenLabs speech, Connected Actions planning, Browser planning, and Realtime control. The desktop cannot choose provider, model, pricing revision, reservation amount, actual cost, tools, or arbitrary schemas.
- Hosted wake transcription derives WAV duration server-side. Hosted ElevenLabs settlement requires provider-native character evidence; missing evidence is treated as uncertain.
- Hosted customer mode no longer requires or honors customer OpenAI/ElevenLabs credentials as a subscription bypass. Direct-provider configuration is development-only.
- Added secure hosted Realtime control: direct WebRTC audio media, no hosted OpenAI data channel in the browser, opaque `rts_...` IDs client-side, private provider call IDs Cloud-side, Cloud sideband/hangup, durable active-call state, bounded reservation, fail-closed control loss, and startup recovery.
- Strengthened account/device authority. Cloud generates canonical account/tenant identity, authoritative device limits come from plan configuration, and Cloud Sync verifies `cloud_sync.tasks` on Cloud independently of desktop caches.
- Added server-owned payment product catalog/coordinator with verified/idempotent/ordered event handling. Customer requests can name only an allowed product ID; price, allowance grant, plan target, and redirects remain server-owned.
- Added sanitized Account usage state: plan/subscription state, monthly usage percentage, renewal/reset date, device allowance, and neutral additional-usage availability. Internal provider economics, margins, reservation IDs, and raw cost units are not exposed.
- Promoted candidate release metadata and active UI/Browser Bridge surfaces to 0.3.5.

## Security guarantees targeted by this candidate

- Zero/insufficient authoritative balance rejects metered work before provider traffic.
- A top-up balance does not unlock a capability the authoritative plan does not grant.
- Forged/replayed local entitlement snapshots do not authorize Cloud work.
- Client-supplied account/tenant/plan/provider/model/cost fields do not become authority.
- Concurrent idempotency replay reaches the provider at most once.
- Worst-case exposure is fully reserved or the request is rejected; it is never clipped down and executed.
- Ambiguous provider failures retain held authorization pending reconciliation.
- Hosted ORVEX provider secrets and private Realtime provider IDs remain Cloud-side.
- Realtime loses trusted control by failing closed and requesting authoritative hangup.
- Payment events must be provider-adapter verified, bound to a server-created checkout, idempotent, and ordered.

## Important limitations / intentionally deferred production work

- There is **no real production payment processor connected in 0.3.5**. Development checkout/top-up simulation is test-only and must not be presented as customer production checkout.
- Final commercial plan names, prices, included usage, device limits, and capability matrix are not invented by this release. Development catalogs contain synthetic test fixtures only.
- Hosted OpenAI TTS remains outside the authoritative hosted settlement lane; hosted speech uses the configured ElevenLabs path when enabled.
- Realtime provider mocks and regressions are not a substitute for live OpenAI failure testing. Sideband attachment, authoritative hangup, crash/restart recovery, actual provider billing evidence, and maximum-window enforcement still require live validation before external production rollout.
- Purely local capabilities cannot honestly be marketed as unhackable paid-only features until they gain a Cloud-authoritative value boundary.
- Production Cloud deployment still requires TLS, secret management, abuse/rate controls, operational reconciliation tooling, monitoring, backup/migrations, and real payment-webhook security.

## Compatibility / preserved data

The patch does not replace `.env`, OAuth tokens, provider credentials, user databases, memories, voice profiles, browser state, logs, Git history, or unrelated user data. Existing 0.3.4 account and Cloud Sync data remain in their existing per-user namespaces; new authoritative billing state uses its own store.

## Automated validation before packaging

The reconstruction was validated in deterministic groups because the broad Python suite exceeds the execution window. Security-focused Billing/provider/Realtime/payment tests passed, existing account/cloud/browser/memory/runtime groups passed, Computer Actions/Game Mode pytest coverage passed, and all Speaker Recognition cases were exercised in bounded groups. `npm run desktop:check` passed. The full Node suite is expected to pass all product behavior tests; four historical Electron packaging tests may remain blocked in this artifact workspace if `@electron/packager` cannot be completely restored by npm.

## Rollback

The installer creates a timestamped backup of each replaced file before applying 0.3.5. If live acceptance fails, stop Jarvis and restore those files from the installer-reported backup directory. New billing database files should be retained for investigation unless a rollback specifically requires their removal; never delete existing account/user data as part of source rollback.
