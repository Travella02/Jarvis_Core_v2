# 0.2.3-repair2 — Calendar Routing

## Summary

This live-acceptance repair makes Calendar actions own the entire turn from recognition through spoken confirmation, while grounding relative dates in the user's local calendar day.

## What changed

- **No contradictory capability disclaimer:** A Calendar request can no longer fall through to ordinary Realtime while the same Connected Action is already running. Jarvis will not say “I can’t schedule that” immediately before showing a real Calendar proposal.
- **Duplicate turn coalescing:** If Realtime emits more than one completion event for the same utterance, every duplicate shares the same in-flight Google action result instead of starting a separate reasoning path.
- **One grounded spoken result:** Existing Connected Action speech deduplication combines with request coalescing so the user hears one answer owned by the action system.
- **Local-date grounding:** Luna now receives the user's CURRENT LOCAL TIME and CURRENT LOCAL DATE in addition to UTC time and timezone.
- **Midnight safety:** Direct Calendar create/update proposals containing “today” or “tomorrow” are deterministically anchored to the user's local date before confirmation, while preserving the requested local time and duration.
- **Architecture preserved:** Realtime remains speech-only; Luna and the Connected Actions layer remain responsible for Google Calendar interpretation and execution.

## Regression coverage

Added tests cover:

- duplicate provider completion events reusing the same Connected Action promise,
- removal of the old in-flight fall-through path,
- explicit local date/time context in the Luna planner input,
- deterministic Denver “tomorrow” resolution when UTC has already advanced to the next date.
