# 0.2.2 — Action Speed Testing

## Apply

After extracting the update ZIP directly into the current Jarvis project root:

```powershell
py -3.12 apply_0_2_2_patch.py
npm run desktop
```

## Acceptance flow

### 1. Baseline draft latency

Say:

> Draft an email to Tanner asking how he's doing.

Expected:
- Jarvis resolves Tanner safely and creates a real Gmail draft.
- The structured email preview appears exactly as it did in accepted 0.2.1.
- Jarvis asks once whether to send it.
- Connected Apps shows a numeric **Last action** latency rather than `—`.

### 2. Same-session recipient fast path

Without restarting Jarvis, create another new draft to Tanner.

Expected:
- Recipient resolution still selects the same trusted address.
- The second same-name action should generally feel faster because the just-resolved recipient can be reused from the short session cache.
- No ambiguity or safety behavior changes.

### 3. Draft edit

Say:

> Make the message a little friendlier.

Then:

> Change the subject to Today.

Expected:
- Both edits update the same exact Gmail draft.
- The email preview updates normally.
- No extra confirmation is requested merely to save an edit.
- The actions should return faster than 0.2.1 because Jarvis does not spend a second Luna call writing a deterministic completion message.

### 4. Natural send confirmation

Say:

> Perfect, thanks, Jarvis. Go ahead and send it.

Expected:
- The exact reviewed draft sends once on the first confirmation.
- Jarvis does not ask a second time.
- The result changes to `EMAIL SENT`.
- Connected Apps updates **Last action** latency.

### 5. Gmail search concurrency

Ask:

> Summarize my five most recent unread emails.

Expected:
- Gmail results and ordering are correct.
- Luna still writes the useful summary because this is a reasoning/summarization task.
- The Gmail fetch stage should feel noticeably quicker when several messages need metadata.

### 6. Calendar write regression

Ask Jarvis to create a disposable calendar event.

Expected:
- Jarvis proposes the event and waits for explicit confirmation.
- Confirmation creates the provider event exactly once.
- The confirmation/result phrasing returns without an unnecessary response-writer model round trip.

### 7. Safety regression

With a fresh pending draft, say:

> Perfect, thanks, Jarvis. Don't send it.

Expected:
- Nothing is sent.
- The draft remains saved.
- Speed changes do not weaken confirmation/cancellation rules.

### 8. Non-action regression

Ask:

> Explain thermodynamics.

Expected:
- Connected Actions does not intercept the request.
- Normal conversation, memory, response modes, interruption, wake/sleep, and Fullscreen behavior remain unchanged.

## Automated validation

```powershell
py -3.12 -m unittest discover -s tests -p "test_*.py"
npm run desktop:check
npm run desktop:test
```


## Repair1 acceptance additions

After applying `0.2.2-repair1 — Gmail Polish`, also verify:

1. A pending reviewed draft sends on the first explicit phrase `Perfect, thanks, Jarvis. Go ahead and send it.` even if speech recognition imperfectly transcribes the assistant vocative.
2. Negative/uncertain phrasing never sends.
3. `Show me the email from Google Cloud.` opens the matching thread and displays a structured Gmail-style card with the actual body when available.
4. Requests for multiple emails display a stack of Gmail-style cards while retaining the fast metadata-search path.
5. Fullscreen preserves those read-email cards.
