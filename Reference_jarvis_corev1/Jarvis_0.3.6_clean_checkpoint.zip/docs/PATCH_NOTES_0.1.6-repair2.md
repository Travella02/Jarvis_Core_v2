# 0.1.6-repair2 — Natural Identity & Silent Sleep

This acceptance repair makes speaker recognition conversationally useful before and after enrollment, opens Voice Profiles when the user accepts an enrollment offer, and closes clear sleep sign-offs locally before the model can emit a stray acknowledgement.

## Natural identity answers

- Direct identity questions use the local speaker result already resolved before `response.create`.
- A confident match receives one short human answer, such as **“Yes, sir—you’re Tanner.”**
- Likely matches remain explicitly uncertain in one concise sentence.
- Technical details about confidence, local matching, attribution, privacy, and voiceprints are omitted unless the user asks how recognition works.
- The behavior is generalized for arbitrary tenant-scoped people and names; current project names are test fixtures only.

## Enrollment offer for unknown voices

- If no voice matches confidently and the user asks who they are, Jarvis says the voice is not recognized yet and offers to create a Voice Profile.
- Jarvis no longer claims that voice identification is unavailable or that he lacks access to the feature.
- A clear affirmative reply opens **Memory → Voice profiles** locally without another model round trip.
- The enrollment page requires the user to choose the correct person, confirm consent, and upload or record samples.
- A declined or expired offer does not interfere with later conversation.

## Deterministic silent sleep

- Clear phrases such as **“That’s all”**, **“That’s it”**, **“Go to sleep”**, and polite variants are handled locally from the final transcript.
- The sleep path runs before any `response.create` request.
- Pending response audio, output buffers, and input buffers are cleared immediately.
- No hidden text, spoken “Got it,” or closing assistant memory is created.
- Ambiguous conversational endings can still use the existing model sleep tool as a fallback.

## Validation

- 250 Python tests passed.
- 63 Node tests passed.
- JavaScript and Python syntax checks passed.
- Doctor and core diagnostics passed.
- Desktop-runtime staging passed.
- Private `.env` preservation verified.
