# Testing Guide — 0.1.1 Total Recall

## Apply

Extract the update ZIP directly into the Jarvis project root, approve replacing and merging files, then run:

```powershell
py -3.12 apply_0_1_1_patch.py
```

## Start development Jarvis

You do not need to rebuild or reinstall the Windows application for normal testing:

```powershell
npm run desktop
```

## Acceptance test

1. Open the new **Memory** workspace.
2. Enter: `I'm eating chicken Alfredo.` in **Tell Jarvis something**.
3. Confirm a timestamped event appears under `Activities/Food`.
4. Enter: `I created a new business called ORVEX.`
5. Confirm Jarvis creates the `Work/Businesses` category and an `ORVEX` entity.
6. Search `ORVEX`; confirm the exact statement, source, actor, and timestamp are shown.
7. Set the date filter to today; confirm only today’s events remain.
8. Wake Jarvis naturally and have one voice conversation.
9. Return to Memory and confirm the exact voice turn and Jarvis response appear.
10. Close Jarvis, reopen it, and confirm the memories remain.
11. Tell Jarvis the same preference twice on separate turns. Confirm both events remain while the organized fact count does not create two independent duplicate facts.
12. Run **Safe consolidation**. Confirm distinct events remain and only exact duplicates are eligible to merge.
13. Ask Jarvis about a fact recorded before the current session; confirm the new Realtime session can recall it.

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m pytest -q tests
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Expected local data

Development mode normally stores memory at:

```text
data\memory\jarvis_memory.sqlite3
```

Installed mode stores it beneath Jarvis’s per-user data directory. Do not commit the database.

## Cost note

Ordinary Realtime input transcription is enabled so exact voice turns can be stored. This adds transcription usage. Set the following to disable that capture while keeping typed/manual memory:

```text
JARVIS_MEMORY_TRANSCRIPTION_ENABLED=false
```
