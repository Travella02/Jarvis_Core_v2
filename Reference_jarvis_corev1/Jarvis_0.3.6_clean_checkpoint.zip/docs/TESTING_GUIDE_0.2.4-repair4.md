# 0.2.4-repair4 — Task Follow-up Grounding live test

## 1. Reproduce the exact focus-switch case

Have an undated task such as:

> Finish the ORVEX website

Then create a reminder-only task:

> Remind me tomorrow at 2 PM to call Tanner.

Ask:

> Is there anything I need to do tomorrow?

Expected: Jarvis names `Call Tanner` as the tomorrow task.

Immediately ask only:

> What time?

Expected: Jarvis stays in Tasks and answers naturally from the authoritative reminder record, for example:

> Call Tanner is set for 2 PM tomorrow.

It must not say that no time is scheduled and must not fall back to generic Realtime advice.

## 2. Explicit reminder wording

Ask:

> When will you remind me?

Expected: Jarvis names the active task and reminder time.

## 3. Unscheduled truthfulness

Focus an undated/unreminded task and ask:

> When?

Expected: Jarvis says there is no time set for that task. It must not invent one.

## 4. Current-time isolation

While task context is still recent, ask:

> What time is it?

Expected: this remains a normal clock question. The task-attribute continuation rule must not reinterpret it as a task schedule question.

## 5. Focus switching

Return to a different task, then ask a short metadata follow-up.

Expected: Jarvis answers from the newly focused task, not the previous project/task. Old ORVEX website context must not leak into the Call Tanner reminder or vice versa.

## Acceptance criteria

- “What time?” after a single grounded scheduled task answers the actual task/reminder time.
- No additional Luna planning call is required for a simple structured metadata lookup.
- No Realtime capability/knowledge fallback while grounded task metadata exists.
- Timezone conversion matches the task/user local time.
- A genuinely unscheduled task produces a truthful no-time response.
- Existing contextual project reasoning, task cards, reminder delivery, Gmail, and Calendar behavior remain intact.
