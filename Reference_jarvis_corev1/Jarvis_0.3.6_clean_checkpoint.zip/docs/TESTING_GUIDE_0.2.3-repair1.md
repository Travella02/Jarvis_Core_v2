# 0.2.3-repair1 — Calendar Follow-through Testing Guide

## Before testing

1. Close Jarvis.
2. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root.
3. Run `py -3.12 apply_0_2_3_repair1_patch.py`.
4. Start Jarvis with `npm run desktop`.

No new Google permission is required for this repair.

## Test 1 — Natural empty-calendar response

Ask:

> What do I have on my calendar tomorrow?

If tomorrow is empty, Jarvis should say something natural such as:

> You don’t have anything on your calendar tomorrow.

He should not say “Your calendar is clear for that time.”

## Test 2 — Duration change remains a proposal

Use an existing one-hour meeting, then say:

> Make it 30 minutes instead of an hour.

Expected:

- The Calendar card changes to a 30-minute end time.
- The card remains `Ready to update · Not changed` until confirmation.
- Jarvis does **not** claim the Google Calendar event is already changed.
- Jarvis asks naturally whether to apply the update.

Do not confirm yet.

## Test 3 — Chain another edit before confirming

Immediately say:

> Add Austin too.

Expected:

- The same pending Calendar action is revised rather than replaced by a second action.
- The preview still shows the 30-minute duration.
- The existing attendee remains.
- Austin is added to the attendee list after contact/email resolution.
- Jarvis asks once whether to update the meeting.

Then say:

> Perfect, update it.

Verify in Google Calendar that the real event is now 30 minutes long and includes both attendees.

## Test 4 — Regression checks

Repeat the previously successful behaviors:

- schedule into a conflict and verify Jarvis warns before the write,
- cancel/remove an event and verify confirmation is still required,
- move an event and verify the exact event is updated,
- let a pending Calendar action survive sleep/wake and confirm it afterward.

## Acceptance

Accept `0.2.3` only when the pending proposal accumulates both the duration and attendee changes, the final Google event matches the preview after confirmation, and Jarvis’s spoken wording does not claim an unconfirmed change is already complete.
