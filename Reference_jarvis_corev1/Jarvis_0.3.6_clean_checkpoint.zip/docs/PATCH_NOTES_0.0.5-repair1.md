# 0.0.5 — Electron Shell Repair 1

## Summary

Repairs a Windows installation failure where a semantically unchanged `.gitignore` was rejected because its checkout used CRLF line endings instead of LF.

## Changes

- Canonicalizes line endings only for source-text baseline comparison.
- Keeps release payload checksums byte-exact.
- Keeps binary validation byte-exact.
- Explicitly pins `.gitignore` and `.gitattributes` to LF in Git.
- Preserves conflict detection for genuine local edits.
- Adds recruiter-friendly issue record `ISSUE-022`.

## Safety

The failed original installer stopped before copying the Electron Shell payload and restored any temporary changes. This repair still verifies the accepted `0.0.4` baseline, backs up replaced files, preserves `.env`, validates the Python environment, installs npm dependencies, and rolls back on failure.
