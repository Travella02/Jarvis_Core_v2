# Testing Guide — 0.0.5 Repair 10

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Wake latency acceptance

1. Launch with `npm run desktop` and wait until the local wake listener is ready.
2. Say **“Jarvis.”** ten times across separate sleep cycles.
3. Compare the perceived delay from the end of the word to Cedar’s acknowledgement.
4. Say **“Jarvis, tell me a short joke.”** five times.
5. Confirm the full request remains intact and produces exactly one response.
6. Remain silent for at least one minute and confirm false waking does not return.
7. Make ordinary room noise and confirm it is rejected before wake transcription where possible.

The target is a noticeably faster wake than Repair 9 without reintroducing false wakes or duplicate opening turns. Cloud transcription and WebRTC still impose network latency, so the result will not be literally instant.

## Window acceptance

1. Quit Jarvis completely.
2. Relaunch with multiple monitors connected.
3. Confirm the whole window appears on one monitor and is comfortably smaller than that monitor’s work area.
4. Move the window to another display, resize it to a normal size, quit, and relaunch.
5. Confirm valid saved bounds restore on that single display.
6. Deliberately make the window very large, quit, and relaunch.
7. Confirm the oversized state is reset to a conservative single-display size.
8. Use tray **Reset window size** and confirm Jarvis returns to the centered primary-display size.
