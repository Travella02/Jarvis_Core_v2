# Testing Guide — 0.1.2-repair1 Voice Memory Navigation

## Start

Close Jarvis, apply the repair, then launch the development app:

```powershell
py -3.12 apply_0_1_2_repair1_patch.py
npm run desktop
```

A Windows reinstall is not required for this acceptance test.

## Visual navigation tests

1. Wake Jarvis and say: “Jarvis, show me everything about ORVEX.”
   - Memory Explorer should open automatically.
   - If ORVEX exists as an entity, its entity and relationship detail should open.
   - Jarvis may also give a brief spoken summary.
2. Say: “Show me what I told you yesterday.”
   - Memory Explorer should open to the timeline with the full natural-language query applied.
3. Type: “Open my memories.”
   - Memory Explorer should open without inventing a search term.
4. Say: “Show me what Kenleigh said about the business.”
   - The timeline should open rather than incorrectly treating “the business” as an exact entity page.
5. Ask: “What do you know about ORVEX?”
   - Jarvis should answer verbally and should not move away from the current workspace.
6. Ask: “Show me a picture of a spaceship.”
   - Memory Explorer should not open.

## Regression checks

- Ordinary voice and typed conversation still appears once in chat.
- Memory capture, timeline filters, entity pages, corrections, undo, summary, and export still work.
- “That’s all” still uses the silent model-confirmed sleep flow.
- Close and reopen Jarvis; saved memory remains available.
