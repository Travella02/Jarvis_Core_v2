# 0.0.4 — Cost Control

## Summary

`0.0.4 — Cost Control` makes Jarvis cheaper and safer to develop. It adds a free local simulation path, server-authoritative usage accounting, configurable response modes, budget warnings and hard stops, and Realtime context limits designed to reduce repeated input cost.

## Added

- **Local simulation — free** mode for wake, transcript, timers, typed turns, interruption, idle sleep, and lifecycle testing without opening an OpenAI session.
- **Test**, **Normal**, and **Full** response modes.
- Optional automatic sleep after one Test-mode response.
- Response-level, session, daily, monthly, audio, text/context, and cached-savings cost displays.
- Crash-safe local usage ledger at `data/realtime_usage.jsonl`.
- Provider response-ID deduplication so repeated `response.done` events do not inflate totals.
- Session, daily, and monthly warning and hard budget thresholds.
- Server-side refusal of new live sessions when the daily or monthly hard limit has already been reached.
- Realtime context truncation with a configurable token limit and retention ratio.
- Recruiter-friendly issue records for paid UI regression testing and browser-only cost drift.

## Changed

- Cost calculation moved from browser `localStorage` to the local Python core.
- Pricing is centralized in a versioned profile rather than duplicated across the UI.
- Test mode limits each response to a short sentence and caps maximum output tokens.
- Normal mode keeps simple spoken answers concise.
- Full mode remains available when detail is appropriate.
- The usage panel explicitly labels values as estimates and keeps the OpenAI billing dashboard as the final account record.

## Privacy and security

The usage ledger stores only timestamps, response/session identifiers, model/mode labels, token counts, and calculated costs. It does not store transcript text, raw audio, API keys, raw SDP, Authorization headers, or ephemeral media credentials.

## Default safeguards

```text
Session warning:  $0.10
Session hard stop: $0.25
Daily warning:    $0.50
Daily hard stop:   $1.00
Monthly warning:  $5.00
Monthly hard stop: $10.00
```

Set a threshold to `0` in `.env` to disable that threshold.

## Validation

The release is validated with the complete automated suite, JavaScript syntax checking, doctor, secret-safe diagnostic, installer rollback/rerun checks, and `.env` preservation. Automated tests never create a paid OpenAI session.
