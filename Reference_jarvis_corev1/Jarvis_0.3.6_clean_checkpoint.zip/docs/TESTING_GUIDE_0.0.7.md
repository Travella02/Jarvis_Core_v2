# Testing Guide — 0.0.7 Voice Lifecycle

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Launch with `npm run desktop`.
2. Select **Fast** wake profile.
3. Test “Jarvis” five times and confirm one acknowledgement per wake.
4. Test “Jarvis, tell me a short joke” five times and confirm one request and one answer.
5. While awake, say “That’s all, Jarvis.”
6. Confirm Cedar audibly says **“Of course, sir.”**
7. Confirm Jarvis closes the Realtime session only after the audible sign-off finishes.
8. Confirm the wake listener resumes and Jarvis can wake again.
9. Repeat with “You can go back to sleep now.”
10. Verify the three sleep timing metrics update.
11. Switch to Balanced and Strict once each and confirm they still wake without false duplicate turns.
12. Close the desktop window and confirm Electron and Python both end.

## Acceptance boundary

Commit only after the audible sign-off works reliably without duplicate speech, clipped audio, a stuck session, or a delayed wake-listener restart.
