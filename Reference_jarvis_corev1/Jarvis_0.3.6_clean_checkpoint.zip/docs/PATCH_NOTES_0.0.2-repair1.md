# 0.0.2 — Voice Control Repair 1

**Corrects duplicate typed-message rendering and restores provider-default end-of-turn detection while retaining optional semantic tuning.**

- **Repair date:** 2026-07-26
- **Required installed version:** `0.0.2`
- **Installed version after repair:** `0.0.2`
- **Repository:** `Jarvis_Real_Time`

## User-visible corrections

- A typed message now appears exactly once in the conversation panel.
- The client still renders typed input immediately, then reconciles the provider's authoritative echo into that same bubble.
- Rapid submit re-entry is blocked during the send action.
- Turn detection now defaults to **Provider default (recommended)** instead of forcing low semantic VAD.
- Optional semantic profiles remain available in the Voice Lab: auto, low, medium, and high.
- The old low-VAD browser default is intentionally not migrated; Cedar and audio-device preferences are preserved.

## Technical changes

- Added a bounded pending typed-message queue and provider-echo reconciliation path.
- Added rollback of the optimistic bubble when a typed send fails.
- Added a submit lock to prevent overlapping UI submissions.
- Replaced eagerness-only configuration with `JARVIS_TURN_DETECTION_PROFILE`.
- The `provider_default` profile omits `audio.input.turn_detection` from the session payload so OpenAI applies its supported default.
- Explicit semantic profiles compile to `semantic_vad` with the selected eagerness and automatic response/interruption enabled.
- Updated health, diagnostics, local API validation, and the browser client to use the turn-detection profile contract.

## Issue records added

- `issues/ISSUE_009_TYPED_MESSAGE_ECHO_DUPLICATION.md`
- `issues/ISSUE_010_FORCED_LOW_SEMANTIC_VAD_DELAY.md`

Both records include the symptom, root cause, investigation, repair, regression evidence, engineering lesson, and recruiter talking point.

## Existing `.env` behavior

The repair preserves `.env` byte-for-byte. The new default does not rely on the old `JARVIS_VAD_EAGERNESS` variable. To make a semantic profile persistent across browser resets, add one of these locally:

```text
JARVIS_TURN_DETECTION_PROFILE=semantic_auto
JARVIS_TURN_DETECTION_PROFILE=semantic_low
JARVIS_TURN_DETECTION_PROFILE=semantic_medium
JARVIS_TURN_DETECTION_PROFILE=semantic_high
```

For the recommended provider-managed behavior, omit the setting or use:

```text
JARVIS_TURN_DETECTION_PROFILE=provider_default
```

Never commit `.env`.

## Compatibility

- Requires the installed `0.0.2 — Voice Control` update.
- Keeps version `0.0.2` because this is a repair during live acceptance, not a new capability milestone.
- Preserves the API key, virtual environment, Git history, data, logs, and patch backups.
- No paid provider call is made by automated tests.

## Rollback

The installer creates a timestamped backup under:

```text
.patch_backups/0.0.2-repair1_<timestamp>/
```

If validation fails, files are restored automatically. For a manual rollback, stop Jarvis and copy the timestamped backup contents to their project-relative locations.

## Validation before delivery

- `python -m unittest discover -s tests -v` — **46 tests passed**.
- JavaScript syntax validation passed.
- Doctor and safe diagnostic passed.
- Installer succeeded against the exact `0.0.2` baseline.
- A second installer run changed zero files.
- A configured ignored `.env` remained byte-for-byte unchanged.
