# 0.3.0-repair8 — First-Party Freshness & Fast Browser Control

This repair addresses the remaining live-test gaps in Web Intelligence freshness, explicit website-search behavior, Browser Control latency, and card readability.

- Recency-sensitive Web Intelligence queries now identify strong first-party domains from the grounded first pass and constrain the chronology-verification pass with Responses API web-search `allowed_domains` when it is safe to do so.
- The freshness challenge explicitly searches for newer items than the preliminary candidate and checks the newest official listing/index entries before Jarvis is allowed to say that an older result is still the latest.
- Simple browser commands can bypass Luna's multi-step planner when no reasoning is needed.
- “Open a new tab and search YouTube for …” now opens YouTube's own search results directly instead of translating the request into a Google `site:youtube.com` search.
- Fast new-tab/site-search/back/forward/refresh actions return as soon as the browser mutation is accepted; autonomous browser work still keeps normal load settling before Luna reasons from the resulting page.
- The Browser Bridge no longer performs a redundant long post-click load wait on top of the core's own post-action settling loop.
- Web Intelligence cards now have a clear topic heading, larger answer text, larger fullscreen typography, and more readable source cards.

VERSION and release metadata remain unchanged until 0.3.0 live acceptance passes.
