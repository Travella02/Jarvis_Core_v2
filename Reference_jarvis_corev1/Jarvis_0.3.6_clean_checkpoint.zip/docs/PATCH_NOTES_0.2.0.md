# 0.2.0 — Connected Actions

Jarvis can now connect to Google through OAuth and use Gmail and Google Calendar without asking users to paste personal API keys.

## Model routing

- OpenAI Realtime remains the live voice interface only: microphone conversation, interruption, and speaking a prepared result.
- `gpt-5.6-luna` performs connected-action interpretation, argument extraction, confirmation planning, tool selection, and the final grounded response text.
- Ordinary non-action conversation continues through the existing Realtime flow and does not invoke the action planner.

## Google connection

- A new **Controls → Connected apps** panel starts and monitors Google OAuth.
- OAuth uses a loopback redirect and PKCE.
- Refresh and access tokens are protected with Windows DPAPI in the packaged Windows app.
- Disconnecting removes the local token and makes a best-effort Google revocation request.

## Gmail

- Search and summarize messages.
- Create an email draft without sending it.
- Sending a prepared draft requires a separate explicit instruction such as “Send it.”
- Jarvis never reports a sent message until Gmail confirms it.

## Google Calendar

- Read upcoming events and date ranges.
- Create, update, and delete events only after a separate confirmation.
- Ambiguous event matches produce a clarification instead of a guess.

## Safety and auditability

- Every connected action is recorded in a local SQLite audit ledger with actor, operation, arguments, state, timestamps, result, and errors.
- External writes move through `pending_confirmation`, then `completed`, `cancelled`, or `failed`.
- Read actions can execute immediately; email drafts remain unsent until explicitly approved.
- Jarvis's capability registry updates from the actual Google configuration and connection state.

## Cost control

The action planner is called only for requests that look like Gmail or Calendar work, or for a confirmation tied to a pending action. Luna usage is recorded in the existing local usage ledger. Realtime does not redo the reasoning; it speaks the concise text Luna prepared.
