# Testing Guide — 0.0.7 Silent Sleep Repair

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Start Jarvis with `npm run desktop`.
2. Wake Jarvis and have one normal spoken exchange.
3. Say **“That’s all, Jarvis.”**
4. Confirm Jarvis returns to Sleeping without speaking or adding a Jarvis sign-off bubble.
5. Repeat with **“Go back to sleep, Jarvis.”** and **“Thanks, that’s everything.”**
6. Confirm the session closes once, no partial `Of course` text appears, and no duplicate wake starts occur.
7. Wake Jarvis again immediately and confirm the Fast wake profile still works.
8. Confirm the Usage panel does not add a dedicated sign-off response.
