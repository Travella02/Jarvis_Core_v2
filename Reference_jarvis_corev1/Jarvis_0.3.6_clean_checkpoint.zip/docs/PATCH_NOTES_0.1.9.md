# 0.1.9 — Context Intelligence

Jarvis now resolves each question against the local memory graph before answering, so durable memory is used by meaning and conversation context rather than exact wording alone.

## What changed

- Added a local query-specific context resolver that ranks current facts, open proactive items, and source events by subject match, semantic overlap, recency, confidence, current session, and lifecycle state.
- Added conservative reference resolution for phrases such as “the business,” “that company,” “the project,” “my fiancée,” and similar relationship or entity references.
- Recent same-session entities are preferred for follow-up references, while persistent entity profiles allow context to carry across restarts and later sessions.
- Clarification-first ambiguity handling now produces one short question when entities are closely matched instead of making an ungrounded guess.
- Current facts always outrank historical evidence. Completed, dismissed, superseded, outdated, incorrect, and forgotten records are excluded from current answers unless the user explicitly asks for history.
- Source questions such as “How do you know?” and “When did I tell you?” receive evidence with the remembered speaker, time, source, and direct-versus-inferred distinction.
- Open-work questions retrieve only current goals, decisions, commitments, and pending proactive items connected to the resolved subject.
- Every ordinary voice, wake-voice, and typed turn receives local query-specific context before the single Realtime response is created.
- Detailed low-cost written answers use the same resolved memory package as the spoken summary.
- Non-owner speakers receive conservative memory filtering so unrelated private owner memories are not placed into their response context.

## Architecture

`jarvis.memory.context.ContextIntelligence` is a deterministic local retrieval layer. It does not mutate memory and does not call an AI model. It produces an auditable resolution package containing:

- resolved subject and confidence,
- ambiguity alternatives and one clarification question,
- current facts,
- relevant open proactive work,
- exact source events,
- source/history intent flags,
- a bounded model-context rendering.

The desktop requests this package through the trusted loopback-only `/api/memory/context/resolve` endpoint and attaches it to the current Realtime turn. The separate detailed-text path calls the same service directly, keeping speech and written answers aligned.

## Safety and privacy

- No memory is invented when retrieval returns no relevant evidence.
- Generic references are not silently resolved when two subjects are similarly plausible.
- Historical records remain available for explicit history questions but are never represented as current truth.
- Query-specific retrieval does not change or delete the exact event ledger.
- Private owner memory is not supplied to a different recognized speaker unless it belongs to that speaker or is explicitly shared.

## Validation

Automated coverage verifies unique and ambiguous business references, same-session follow-ups, relationship references, source explanations, lifecycle-aware current versus historical truth, non-owner privacy boundaries, the trusted context endpoint, detailed-answer grounding, and desktop turn integration.
