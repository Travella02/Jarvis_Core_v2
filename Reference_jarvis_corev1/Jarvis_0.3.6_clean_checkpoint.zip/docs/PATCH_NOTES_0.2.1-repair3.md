# 0.2.1-repair3 — Email Review

Fixes two live 0.2.1 acceptance issues found after repair2: a natural first send confirmation such as “Yes, please go ahead and send it” could be treated as a fresh planning turn instead of confirming the already-reviewed draft, and fullscreen converted the structured email preview back into plain text.

## Changes

- Pending external-write confirmation now accepts natural compound approval phrases such as `Yes, please go ahead and send it`, `Yes, go ahead and send it`, `Please go ahead and send it`, and `Go ahead and send it`.
- Those phrases execute the already-pending exact Gmail draft directly; Luna is not asked to re-plan the send and Jarvis does not ask for a second confirmation.
- Existing short confirmations (`Yes`, `Yes, please`, `Send it`, `Yes, send it, please`) remain supported.
- Cancellation remains disjoint from approval; `Cancel it` still cancels instead of sending.
- The fullscreen reader now recognizes structured Gmail previews and clones the same email card into fullscreen rather than flattening it into raw text.
- Fullscreen Gmail review preserves the draft/sent status, From, To, Cc/Bcc, Subject, and exact message body with a larger email-reading layout.
- Ordinary non-email fullscreen answers keep the existing plain reader behavior.
- The fullscreen title now identifies the email state as `Email draft` or `Email sent` when appropriate.

## Safety boundary

Sending remains an external write and still requires a separate explicit confirmation after the draft is shown. This repair broadens only the natural-language forms that count as that explicit approval; it does not weaken the confirmation requirement or infer approval from ambiguous text.

## Primary regression

1. Create a disposable Gmail draft and review the displayed email card.
2. Say:

> Yes, please go ahead and send it.

Expected: the exact reviewed draft sends once on that first confirmation, with no repeated “Would you like me to send it?” prompt.

3. Create another disposable draft, open **Fullscreen**, and verify the fullscreen view still looks like the structured email card rather than raw `From:/To:/Subject:` text.

## Apply it

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair3_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```
