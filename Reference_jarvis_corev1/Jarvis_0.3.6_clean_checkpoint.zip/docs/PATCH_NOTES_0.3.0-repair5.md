# 0.3.0-repair5 — Durable Browser Planning

This repair keeps the working Browser Bridge, DOM/tab executor, Game Mode boundary, and interruption behavior intact while hardening the autonomous browser-planning loop discovered during live acceptance.

## Fixed

- Browser tasks no longer abort immediately when a Luna structured planning response is incomplete or temporarily unparsable after an earlier browser step succeeded.
- Browser planner now detects incomplete Responses output/refusals and retries the private planning iteration with a larger output budget without replaying browser side effects.
- Planner retry usage is accumulated for accurate cost accounting.
- Recoverable research dead ends now prefer the strongest exact grounded URL already observed before searching again.
- Site-scoped research recovery selects a domain by semantic match to the user’s goal instead of lexicographic URL order.
- Recovery URLs are de-duplicated so the agent cannot repeatedly navigate to the same failed route.

## Safety preserved

- No synthetic mouse/keyboard input was added.
- Game Mode remains unchanged and continues to protect game processes.
- Navigation is still restricted to exact user-supplied or browser-observed grounded URLs.
- Brand/domain words alone do not authorize invented URLs.
- Credential/payment field protections and external-commit confirmations are unchanged.
- Browser interruption cancellation remains authoritative.

## Live acceptance focus

Retest both:

1. `Search for Rocket League's latest update.` — the visible search must complete without a malformed-planner error.
2. `Find the latest RTX 5080 driver on NVIDIA's official site, open it, and tell me what changed.` — Jarvis should autonomously continue from search results into a grounded official result instead of giving up.
