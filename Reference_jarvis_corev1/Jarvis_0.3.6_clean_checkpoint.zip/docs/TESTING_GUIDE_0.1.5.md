# 0.1.5 — Identity Foundations Testing Guide

## Acceptance flow — canonical identity

1. Start Jarvis and say: `Kenly Yarman is my fiancée.`
2. Say: `The meeting was moved to seven.`
3. Correct attribution: `Ken Lee said that, not me.`
4. Clarify identity: `Kenleigh is the proper spelling. Kenleigh, Kenly, Ken Lee, and Kenley are all the same person. Kenleigh is my fiancée.`
5. Open **Memory → People & identities**.

Expected result:

- One active profile named **Kenleigh Yarman**.
- Relationship to Tanner: **fiancée**.
- Aliases include Kenly Yarman, Kenly, Ken Lee, Kenley, and Kenleigh.
- The meeting event appears in Kenleigh’s attributed timeline.
- Attribution history preserves Tanner as the previous actor and the correction as evidence.
- No separate active Kenly or Ken Lee profile remains.
- Restarting Jarvis preserves the result.

## Identity control acceptance flow

Open the Kenleigh profile and verify every button opens an in-app form:

- **Edit relationship / role** — change a field, save, reopen, and confirm persistence.
- **Set privacy boundary** — change access scope or retention and confirm persistence.
- **Add alias** — add a disposable alias and confirm it appears.
- **Set memory permission** — add or update a scope and access level.
- **Merge duplicate person** — select a disposable duplicate, confirm, and verify the source disappears while evidence remains.
- Use **Undo latest reversible change** and confirm the latest reversible identity operation is restored.

## Expected safety behavior

- Tanner’s owner boundary cannot be downgraded.
- A similar-looking name is not merged without explicit confirmation.
- Canonical rename preserves old names as aliases.
- Identity merges retain event provenance and current speaker attribution.
- Voice and face rows remain `not_enrolled`; no raw biometric template is exposed.

## Validation baseline

The repair installer expects 242 Python tests and 55 Node tests to pass.
