# 0.3.6-repair11 — Conversation Continuity live testing

## Test 1 — transient Unknown clarification continuity

1. Wake Jarvis.
2. Say: `Draft an email to Tanner.`
3. After Jarvis asks what the email should say, answer: `Say hi.`
4. Repeat if speaker recognition happens to label the second utterance `Unknown speaker`.

**Pass:** Jarvis creates/updates the draft instead of saying it lost the action context.

## Test 2 — known speaker isolation

Start a Connected Action clarification as one positively recognized person. Have a different positively recognized person answer the clarification.

**Pass:** Jarvis does not silently inherit the first person's action session.

## Test 3 — Unknown cannot execute attributed pending action

Create a draft as a positively recognized speaker, then make the final `send it`/`yes` decision while the turn is attributed as Unknown.

**Pass:** Jarvis does not send. It asks for the original speaker or on-screen controls.

## Test 4 — trusted permission voice quarantine

Trigger any permission set to Always ask. While the native permission dialog is open, speak `yes`, `cancel it`, and an unrelated command.

**Pass:** none of the speech appears in chat, changes the action, approves/denies it, queues another command, or triggers a Jarvis response. Only the trusted Allow/Cancel controls decide.

## Test 5 — Fullscreen regression check

Create an email draft and click both the top `Fullscreen` control and the bottom `ANSWER CONTINUES — OPEN FULLSCREEN` control.

**Pass:** each opens the structured card in the fullscreen reader with the full draft visible.
