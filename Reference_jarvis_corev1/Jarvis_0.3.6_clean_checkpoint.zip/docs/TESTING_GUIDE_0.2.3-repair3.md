# Testing Guide — 0.2.3-repair3 Calendar Confirmation

## Install

1. Close Jarvis.
2. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root and allow overwrite/merge.
3. Run:

```powershell
py -3.12 apply_0_2_3_repair3_patch.py
```

4. Start Jarvis:

```powershell
npm run desktop
```

No Google reconnect is required.

## Primary live test — spoken/display time agreement

Say:

> Can you schedule a meeting with Tanner for tomorrow at 3 PM?

Expected:

- Jarvis says **3 PM**, not a UTC-converted value such as 9 PM.
- The Calendar card also shows **3:00 PM** in the user's local timezone.
- “Tomorrow” resolves from the user's local desktop date.
- The event remains a proposal until confirmed.

## Confirmation test

Say:

> Yes, go ahead and add it.

Expected:

- Jarvis creates the exact reviewed event immediately.
- Jarvis does **not** ask “Want me to add it?” a second time.
- Google Calendar contains one event, not a duplicate.

## Follow-up regression

Repeat the chained edit flow:

> Make it 30 minutes instead of an hour.

Then:

> Add Austin too.

Then confirm once. Verify the final Google event preserves all accumulated changes.
