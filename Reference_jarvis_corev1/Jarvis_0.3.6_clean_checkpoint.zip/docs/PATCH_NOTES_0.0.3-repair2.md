# 0.0.3 — Wake Handoff Repair

## Summary

Repairs two live-acceptance defects in `0.0.3 — Wake Detection`: the opening request after the wake keyword was not reaching the Realtime session, and Jarvis-speaking duration was not increasing even while remote audio was audible.

## Fixed

- Wake recognition no longer stops on the first interim result containing `Jarvis`.
- The listener captures the complete utterance using final-result detection plus a short bounded quiet window.
- The opening request remains queued until the WebRTC data channel is open.
- Failed early dispatch attempts retry briefly instead of clearing the prompt.
- Jarvis-speaking time now starts and stops from actual remote WebRTC audio energy.
- A short silence threshold prevents tiny audio gaps from splitting one response into many fragments.
- Active speaking segments finalize safely during interruption and connection cleanup.

## Issue records

- `issues/ISSUE_012_WAKE_REQUEST_DROPPED.md`
- `issues/ISSUE_013_JARVIS_SPEAKING_TIMER.md`

## Versioning

The project version remains `0.0.3` because this repairs the unaccepted Wake Detection update rather than beginning `0.0.4`.
