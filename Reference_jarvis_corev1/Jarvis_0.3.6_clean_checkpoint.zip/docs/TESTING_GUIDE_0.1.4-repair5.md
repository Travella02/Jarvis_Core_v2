# 0.1.4-repair5 — Audio Resume Testing Guide

## Automated validation

The patch installer runs:

- 229 Python tests
- 50 Node tests
- Desktop JavaScript syntax checks
- Doctor diagnostics
- Core diagnostics
- Desktop-runtime staging
- Private `.env` preservation verification

## Live interruption acceptance

1. Start Jarvis with `npm run desktop`.
2. Ask a question that produces a multi-sentence spoken response.
3. Interrupt Jarvis while Cedar is speaking and ask a new question or provide a correction.
4. Confirm the old bubble is marked **Interrupted by user**.
5. Confirm no additional old-response text appears after the interruption.
6. Confirm the new response appears once in chat and Cedar speaks it aloud.
7. Repeat the interruption at least twice in the same awake session.
8. Confirm no reconnect or manual Wake/Sleep cycle is needed.

## Proactive-memory regression

1. State a follow-up commitment.
2. Correct the name naturally, such as “I actually meant Kyver.”
3. Confirm proactive memory updates automatically without pressing **Refresh locally**.
4. Confirm the corrected response is spoken after interrupting Jarvis’s acknowledgement.
5. Restart Jarvis and confirm the corrected commitment remains current.
