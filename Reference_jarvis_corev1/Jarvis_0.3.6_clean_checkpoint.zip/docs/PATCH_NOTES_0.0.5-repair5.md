# 0.0.5 — Electron Shell Repair 5

## Summary

The first native Electron launch proved that the desktop window and Python core were working, but Electron's browser speech-recognition path entered a rapid network-error restart loop. This repair replaces Electron wake and lifecycle recognition with a local Windows speech-recognition subprocess managed by the Electron main process.

## Changes

- Added `apps/desktop/electron/windows-speech-listener.ps1` using the installed Windows `System.Speech` recognizer.
- Added Electron process supervision, restart handling, structured JSON messages, and clean shutdown for the local listener.
- Added a narrow preload IPC bridge for local recognized phrases; no filesystem, environment, or process APIs are exposed to the renderer.
- Electron now uses the local recognizer for:
  - Natural wake phrases containing “Jarvis”.
  - Complete opening requests after the wake keyword.
  - Wake-only acknowledgements.
  - Spoken sleep commands while awake.
- The browser `SpeechRecognition` implementation remains only as a non-Electron fallback.
- Locally recognized ordinary voice turns can replace the cost-conscious `Voice input` placeholder when timing permits.
- Added packaged-app `asarUnpack` handling so PowerShell can execute the local listener script.

## Privacy and cost

- The local recognizer uses the Windows in-process speech engine and the default Windows microphone.
- No OpenAI Realtime session is created while Jarvis is sleeping.
- Wake and sleep phrase recognition does not add OpenAI API usage.
- Raw audio is not written to project logs or the issue portfolio.

## Known boundary

The local Windows listener currently follows the operating system's default recording device. The Realtime conversation can still use the microphone selected in the Jarvis interface. Device unification can be added later if live testing shows this distinction matters.
