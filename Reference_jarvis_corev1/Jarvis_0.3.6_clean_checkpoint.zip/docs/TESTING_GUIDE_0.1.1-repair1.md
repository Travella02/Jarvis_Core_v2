# Testing Guide — 0.1.1-repair1 Conversation Continuity

## Apply

Extract the update directly into the project root, approve replacement/merge, then run:

```powershell
py -3.12 apply_0_1_1_repair1_patch.py
npm run desktop
```

## Transcript acceptance

1. Wake Jarvis and say: `Tell me a joke.`
2. Confirm one user bubble resolves to the real transcript.
3. Confirm no extra `Voice input` bubble remains.
4. Confirm the sentence beginning `Personal assistant conversation. Preserve names...` never appears.
5. Say another short phrase immediately after Jarvis finishes and confirm it updates the correct bubble.
6. Open Memory and confirm only genuine user speech was stored.

A turn whose provider transcript genuinely never arrives may become `Voice message` after about 2.5 seconds. It should not create a second bubble if a late transcript arrives before the next turn.

## Response acceptance

1. Leave response mode on Normal.
2. Ask for an answer long enough to require several sentences, such as a clear explanation of how Jarvis memory is organized.
3. Confirm Jarvis finishes the final sentence in both audio and transcript.
4. Confirm simple questions remain concise.
5. Switch to Test mode and confirm answers remain intentionally very short.

## Persistence check

Close and reopen the development app, ask what was previously discussed, and confirm Total Recall still retrieves the earlier real memories without the suppressed internal guidance text.
