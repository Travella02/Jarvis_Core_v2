# 0.2.3-repair3 — Calendar Confirmation

## Summary

This live-acceptance repair keeps Calendar proposals grounded to one local wall-clock truth and accepts natural approval phrases such as “Yes, go ahead and add it” without asking twice.

## What changed

- **Spoken time now matches the event card:** Calendar create/update proposals are canonicalized into the event timezone before the confirmation sentence and structured preview are produced. Jarvis should never say 9 PM while the reviewed card says 3 PM for the same action.
- **Browser-local date anchor:** Connected Actions now receives the desktop/browser local timestamp in addition to the IANA timezone. Relative requests such as “today” and “tomorrow” are anchored from the user's actual local calendar date instead of depending only on the backend host clock.
- **Relative-date hardening expanded:** The same local-date correction now applies to Calendar reads, free/busy windows, smart scheduling, creates, and updates—not only fixed writes.
- **Natural Calendar confirmation:** “Yes, go ahead and add it”, “add it”, “apply it”, and equivalent explicit Calendar approvals are recognized as confirmation of the already-reviewed pending action.
- **One confirmation, one write:** A valid natural confirmation executes the exact pending Calendar action immediately and cannot fall back into Luna planning just to ask the same confirmation again.
- **Safety preserved:** Generic praise or conversational filler still cannot create/change Calendar data by itself. An explicit approval verb is still required.

## Regression coverage

Added tests cover:

- “Yes, go ahead and add it” completing a pending Calendar create with no second planner call,
- one provider write for one confirmed event,
- browser-local midnight anchoring for “tomorrow”,
- UTC-backed timestamps canonicalizing to the same Denver wall-clock time shown in the event preview,
- the desktop sending both local timestamp and timezone with Connected Action turns.
