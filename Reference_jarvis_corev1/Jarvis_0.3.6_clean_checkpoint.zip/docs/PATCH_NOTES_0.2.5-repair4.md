# 0.2.5-repair4 — Calendar Ownership

## What changed

This live-acceptance repair fixes natural agenda questions that could bypass Connected Actions and make Jarvis sound as if Calendar results were still pending even though no provider lookup had actually started.

- “What do I have tomorrow?” and similar day-scoped agenda questions now route to Calendar even when the user does not say `calendar`, `schedule`, `meeting`, or `event`.
- Common agenda reads use a deterministic backend path: calculate the requested day in the effective user timezone, query Google Calendar immediately, retain the exact event selection for follow-ups, and return grounded Calendar speech/cards in the same turn.
- The common read path no longer spends a Luna planning call just to decide that a day-scoped agenda request is a Calendar list.
- Task wording such as “What do I have to do tomorrow?” remains excluded from Calendar routing.
- Luna’s ordinary conversation instructions now prohibit invented connected-action progress such as “I’m checking” or “the results aren’t back yet” unless that state is supplied by the application.

## Unchanged

0.2.5 multi-speaker identity, repair1 owner identity separation, repair2 speaker labels, repair3 guided voice enrollment/confidence, Google OAuth state, tasks/reminders, memory, speech-provider settings, and `.env` are unchanged.
