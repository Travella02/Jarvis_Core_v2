# 0.3.6-repair3 — Reauth Handoff

**Date:** 2026-09-03  
**Required previous release:** 0.3.6-repair2  
**VERSION remains:** 0.3.6  
**Status:** Live acceptance repair candidate

## Why this repair exists

Repair2 passed live security/UX testing, but the successful external-browser password page remained open after identity verification. The user had to close the tab manually before returning to Jarvis. The same live test also exposed that the source async security suite depended on `pytest-asyncio` without declaring it.

## What changed

- A successful purpose-bound **reauthentication** page now attempts a standards-based `window.close()` handoff after a short delay.
- The auto-close behavior applies only after successful security reauthentication; failure/password-entry pages do not close.
- If the browser refuses script-driven close because the tab was opened by an external application, the page stays on the verified success state and shows a concise manual-close fallback.
- Jarvis does not use Browser Control, the browser extension, native input injection, remote debugging, or OS automation to force the tab closed.
- This UX change does not consume or approve the permission challenge; the exact trusted Jarvis confirmation remains required after identity proof.
- `pyproject.toml` now declares a development-only `test` extra with bounded `pytest` and `pytest-asyncio`, keeping test tooling out of Jarvis runtime dependencies while making fresh development environments reproducible.

## Security boundary

The repair does not create a new authorization path. Browser completion is still identity assurance only. Exact challenge review, trusted Electron attestation, single-use challenge/grant semantics, Game Mode, and Cloud/system authority are unchanged.

## Issues

See ISSUE-325 and ISSUE-326.

## Commit rule

Do not commit yet. Continue 0.3.6 live acceptance. Keep repair3 and all prior patch/repair artifacts until Tanner explicitly accepts the complete 0.3.6 release. No Git tag.
