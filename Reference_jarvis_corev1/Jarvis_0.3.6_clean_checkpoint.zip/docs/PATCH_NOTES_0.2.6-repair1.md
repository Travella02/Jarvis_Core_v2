# 0.2.6-repair1 — Duplicate Discovery

## What changed

The first live Computer Actions request exposed a Windows discovery edge case: one installed application can appear through App Paths, Start Apps, Start Menu shortcuts, and executable discovery at the same time. Jarvis treated those technical routes as separate choices and could ask which `Discord` the user meant even though every option was visibly the same app.

This repair collapses identical visible app matches before ambiguity handling. When `Open Discord` exactly matches multiple `Discord` discovery routes, Jarvis selects the strongest launch route and opens it immediately.

True ambiguity is still protected. A vague request such as `Open Visual` may still ask whether the user means Visual Studio or Visual Studio Code because those are genuinely different visible applications.

Clarification wording also deduplicates display labels defensively, so repeated identical names are never spoken as separate options.

## Preserved behavior

- Learned aliases remain person-scoped and local.
- Successful launch targets are cached for faster future requests.
- Windows App Paths / Start Apps / launcher metadata still outrank deep filesystem scans.
- Jarvis still searches the PC automatically when fast discovery is insufficient.
- Ambiguous different applications still require clarification rather than guessing.
- No destructive computer-control capability is added.
