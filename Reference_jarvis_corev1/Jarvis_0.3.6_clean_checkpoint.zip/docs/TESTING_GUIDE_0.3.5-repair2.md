# 0.3.5-repair2 — Browser Media Live Acceptance Guide

**Do not commit yet.** Apply over the current `0.3.5-repair1` candidate.

## Apply
Extract the repair ZIP into the Jarvis project root and run:

```powershell
python .\apply_0_3_5_repair2_patch.py
```

## Automated validation

```powershell
python -m pytest -q tests/test_browser_access.py tests/test_voice_lab_client.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

## Start
Use one command only:

```powershell
npm run desktop
```

## Repair-specific live checks
1. Play a YouTube video and say `Full screen YouTube.` The video should enter fullscreen and Jarvis should **not speak a success confirmation**.
2. Say `Minimize YouTube.` while the video is fullscreen. It should exit fullscreen and Jarvis should **not speak a success confirmation**.
3. Try `Pause YouTube.`, `Resume YouTube.`, and `Start the video over.` Successful visible actions should remain silent.
4. A failed/unverified browser media action should still produce a concise spoken failure.
5. If Google needs reconnecting, open **Controls → Connected apps → Google Workspace** and press **Reconnect Google**. Complete Google sign-in in the system browser, return to Jarvis, and press Refresh only if automatic detection has not updated yet.
6. Re-test `What do I have on my calendar tomorrow?` after reconnecting Google.

Then continue the 0.3.5 Billing-specific live acceptance. Do not remove patch artifacts or commit until explicit acceptance.
