# 0.2.1-repair5 — Draft Stability

Stabilizes the manual Gmail draft editor in both compact and Fullscreen views and fixes a routing collision that could treat spoken draft-field changes as memory corrections.

## Changes

- Compact email editing no longer gets trapped behind the long-answer preview clamp.
- The compact editor is height-bounded with its own scrollable field region, while **Cancel** and **Save changes** stay reachable.
- Fullscreen editing uses the same bounded editor layout, so the action controls remain visible even with a long Message field.
- Saving from Fullscreen updates the exact Gmail draft and refreshes both Fullscreen and compact email previews.
- `Change the subject to Today`, `Change the message to ...`, tone rewrites, and other matching pending-draft edits now stay on the Connected Actions/Luna path instead of being intercepted as generic memory corrections.
- Pending confirmation/cancellation language uses the same continuation-priority rule, preserving the exact action already under review.
- Ordinary memory corrections are unchanged when there is no matching pending Connected Action.

## Safety boundary

This repair does not loosen send protection. Manual or spoken edits only modify the exact unsent Gmail draft already tied to the pending send action. A separate explicit send confirmation is still required after the final review.

## Apply it

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair5_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```
