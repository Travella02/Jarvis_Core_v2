# Testing Guide — 0.2.2-repair5 Reply Context

## Primary live test

1. Wake Jarvis.
2. Ask: **“Can you read Tanner's SUPPORT email to me?”**
3. Without naming Tanner or SUPPORT again, say: **“Can you reply and say thank you so much, I really appreciate it. I'm super excited too.”**

Expected:

- Jarvis uses the exact email thread that was just opened/read.
- A real Gmail reply draft is created.
- The draft `To` field targets Tanner, not the connected account.
- Jarvis says a short acknowledgement such as **“I drafted the reply to Tanner. Want me to send it?”**
- Jarvis does not report a reply-draft preparation error.

## Confirmation test

After reviewing the draft, say:

**“Perfect, yes, go ahead and send it.”**

Expected: the exact pending draft sends once with no second confirmation.

## Explicit target regression

Start a fresh reply request:

**“Respond to Tanner's SUPPORT email and say thank you.”**

Expected: explicit sender/subject targeting still works exactly as before.

## Ambiguity safety

If multiple emails are shown and no single email has been opened/read, say:

**“Reply to it and say thanks.”**

Jarvis must not silently guess which email you meant.
