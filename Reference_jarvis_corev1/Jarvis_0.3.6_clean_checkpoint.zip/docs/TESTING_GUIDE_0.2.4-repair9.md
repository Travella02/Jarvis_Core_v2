# Testing 0.2.4-repair9 — Natural Continuity

## 1. Grounded time regression

Say:

`Is there anything I need to do tomorrow?`

Then:

`What time?`

Expected: the existing Call Tanner reminder resolves to **2 PM**, never 8 PM.

Then ask:

`When will you remind me?`

Expected: still **2 PM**.

## 2. Gmail clarification continuation — critical regression test

Say:

`Can you draft an email to Tanner?`

If Jarvis asks what it should say, answer naturally without repeating `email` or `draft`, for example:

`Say hi, I was just wondering how you're doing. Please get back to me ASAP.`

Expected:

- Jarvis stays in the Gmail/Connected Actions workflow.
- A real Gmail draft is created.
- The email draft card appears with recipient, subject/message preview, edit controls as applicable, and the send option.
- The message is **not sent** until you explicitly approve sending it.
- Jarvis must not merely say `I'll draft that` and stop without a card.

## 3. Voice naturalness

Have a normal conversation for a few minutes. Include:

- a one-phrase factual reply such as `What time?`
- a casual question
- `What are you able to do?`
- a longer explanation

Expected:

- Cedar should sound less over-enunciated and less like a status readout.
- Short replies should feel quick and conversational rather than carefully announced.
- Spoken capability answers should be conversational prose rather than markdown-like bullet reading unless you explicitly ask for a list.
- Classic, Casual, and Warm should feel different in delivery without changing factual truth.

## 4. Response modes

Try Short, Normal, High, and Full. The mode changes how much Jarvis is allowed to say, not whether the voice sounds warm/natural. A simple question can still receive a one-phrase answer in any mode.

## 5. Interruption

Interrupt Jarvis during a longer spoken answer.

Expected: playback stops promptly and Jarvis returns to listening without duplicating the interrupted answer.
