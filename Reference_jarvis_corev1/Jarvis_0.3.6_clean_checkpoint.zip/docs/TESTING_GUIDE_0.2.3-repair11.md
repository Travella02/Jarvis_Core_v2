# Testing Guide — 0.2.3-repair11 Response Lock

## Preconditions
- 0.2.3-repair10 is installed.
- Google Calendar is connected.
- A real test meeting exists and Jarvis has just displayed or updated it.

## Primary acceptance flow
1. Wake Jarvis.
2. Say: **“Jarvis, can you actually cancel that meeting?”**
3. Expected: exactly one Jarvis answer is produced.
4. Expected: Jarvis asks for confirmation to remove/cancel the exact meeting.
5. Expected: Jarvis does not say to open Google Calendar manually, does not claim he cannot control Calendar, and does not show two contradictory answer paragraphs above the Calendar card.
6. Confirm once with: **“Yes, cancel it.”**
7. Verify the event is removed from Google Calendar and Jarvis reports one grounded completion.

## Cancellation safety check
Repeat with another disposable event, but answer **“No, keep it.”** Jarvis must cancel the pending delete action and leave the real Calendar event untouched.

## Regression checks
- Schedule/update speech still uses the correct local wall-clock time from repair7.
- Unknown attendees still ask for an email instead of erroring.
- Gmail Connected Actions still render one grounded response rather than a Realtime paraphrase plus the action card.
