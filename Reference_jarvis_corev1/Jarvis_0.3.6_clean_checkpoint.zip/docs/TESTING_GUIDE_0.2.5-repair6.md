# 0.2.5-repair6 — Natural Responses Testing Guide

## Primary wording test

Keep the `Call Tanner` reminder at 2 PM tomorrow and ask:

> What do I have tomorrow?

Expected: Jarvis should keep the **2 PM** fact exact but phrase the task like normal conversation. Good examples include:

> You've just got to call Tanner at 2.

or

> Just that call to Tanner at 2 PM.

He should avoid mechanical wording such as:

> Tomorrow, you've got Call Tanner at 2 PM.

The exact sentence does not need to match the examples; natural wording is the goal.

## Short factual follow-up

Ask:

> What time?

Expected:

> 2 PM.

No extra explanation is required.

## Response-mode check

Try a simple question and an open-ended question in Short, Normal, and High.

Expected:

- Short/Normal/High are maximum spoken lengths, not targets.
- Simple questions stay short in every mode.
- Open-ended answers can become more detailed when the selected mode allows it.
- Jarvis should remain friendly and conversational rather than turning the answer into a slogan or structured status report.

## Gmail payload regression

Ask Jarvis to draft an email. When he asks for the body, provide wording that contains a conversational sentence such as "I was wondering how you're doing."

Expected: Jarvis drafts the email and acknowledges the completed draft. He must not answer the email body as though it were addressed to him.

## Tool-progress regression

Ask a normal question that does not actually invoke Calendar, Gmail, Tasks, or another connected action.

Expected: Jarvis must not invent phrases such as "I'm checking," "I'm waiting on the results," or similar background-progress claims.
