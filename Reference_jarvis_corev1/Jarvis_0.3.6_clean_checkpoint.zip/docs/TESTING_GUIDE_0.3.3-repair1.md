# 0.3.3-repair1 — Live Turn Continuity Testing

Do not commit until live acceptance passes.

## Focused automated check

```powershell
python -m pytest -q tests/test_runtime_reliability.py tests/test_release_consistency.py
npm run desktop:check
node --test tests_js/runtime_reliability.test.cjs tests_js/browser_access.test.cjs
```

## Live acceptance

1. Wake Jarvis and make **Resume YouTube** the first real turn. If the browser action succeeds silently, immediately say **How are you doing, Jarvis?** without sleeping/waking. Jarvis must hear the second turn.
2. Repeat **Pause YouTube**, **Resume YouTube**, and one other silent local action. The microphone must remain usable after every action.
3. With an unknown/guest speaker, say **“I’m doing pretty good, thank you for asking.”** Jarvis must treat that as conversation, not create/bind a person named “doing pretty good” and not answer “Nice to meet you.”
4. Start with a non-zero session cost, then perform Browser Control. The session total must not decrease or reset to `$0.0000`.
5. Confirm Account still opens and the visible version remains **0.3.3 · Runtime Reliability**.
