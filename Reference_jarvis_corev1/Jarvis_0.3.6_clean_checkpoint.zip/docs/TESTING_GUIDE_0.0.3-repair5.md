# Testing Guide — 0.0.3 Wake Playback Repair

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

Hard-refresh the Voice Lab with `Ctrl+F5`, then repeat each full wake phrase at least five times:

- “Jarvis, tell me a joke.”
- “Hey Jarvis, what can you help me with?”
- “Yo Jarvis, give me a short fun fact.”

Every attempt must produce:

- One visible `YOU` bubble.
- One Jarvis response.
- No extra `Processing speech...` bubble.
- No repeated answer.
- One response-count increment.

Also verify:

- Saying only “Jarvis” still produces one brief acknowledgement.
- The microphone accepts the next question after Jarvis finishes speaking.
- Jarvis-speaking time increases during audible output and stops afterward.
- Interrupting a normal post-wake response still works.
