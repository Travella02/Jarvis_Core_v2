# Testing Guide — 0.0.5 Electron Shell Repair 2

## Install

```powershell
py -3.12 apply_0_0_5_repair2_patch.py
```

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
npm run desktop:check
```

Expected unit-test result:

```text
Ran 80 tests
OK
```

## `.gitignore` verification

```powershell
git diff -- .gitignore
```

Any existing custom ignore rules should remain. Missing Electron rules may be appended:

```text
node_modules/
apps/desktop/dist/
apps/desktop/out/
out/
```

## Desktop acceptance

Start the desktop shell:

```powershell
npm run desktop
```

Complete the full Electron Shell acceptance checklist from `docs/TESTING_GUIDE_0.0.5.md` before committing.
