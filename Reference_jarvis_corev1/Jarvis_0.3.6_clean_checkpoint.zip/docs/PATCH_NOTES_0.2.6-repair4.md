# 0.2.6-repair4 — Verified Launch

## Why this repair exists

0.2.6-repair3 could choose a sensible Windows launch route and return immediately, but Windows accepting `ShellExecute`/`os.startfile` did not prove that the requested application actually surfaced. In the live Discord test Jarvis repeatedly said “Opening Discord” while no Discord window appeared.

## What changed

- Desktop application launches are now **verified before Jarvis claims success**.
- Jarvis attempts the strongest known route for the logical app, waits briefly for a matching application window, restores it if minimized/hidden, and brings it forward.
- If a shortcut/AppID route is accepted by Windows but produces no visible app, Jarvis automatically tries other known routes for the same logical application.
- When all known routes fail, Jarvis performs a short targeted scan of normal application install roots and retries a direct executable when available.
- A route is only marked `launch_verified=true`, promoted in the learned app catalog, and taught the requested alias after verification succeeds.
- Failed shell handoffs are recorded as failures so they lose priority instead of becoming permanently “learned” false-success routes.
- Files/folders and trusted Steam/Epic URI handoffs keep their existing behavior because they do not expose a stable same-name application window immediately.
- Existing app aliases, alias forgetting, Memory → Apps, closing apps, and user-specific alias ownership remain unchanged.

## Design rule

For desktop applications, **an OS launch call returning without an exception is not success**. Success means Jarvis can observe and surface the requested application window.

## Safety

The repair does not add arbitrary command execution. Discovery still refuses unsafe batch/script deep-discovery, app close still protects Jarvis/critical Windows processes, and ambiguous logical apps still require clarification.
