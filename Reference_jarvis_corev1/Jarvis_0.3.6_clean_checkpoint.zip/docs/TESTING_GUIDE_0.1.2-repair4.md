# Testing Guide — 0.1.2-repair4 Validation Isolation Repair

## Apply

```powershell
py -3.12 apply_0_1_2_repair4_patch.py
```

The installer must report 193 passing Python tests and 33 passing Node tests even when the private `.env` still contains the previous response-profile defaults.

## Memory navigation acceptance

1. Start Jarvis with `npm run desktop`.
2. Begin from Home.
3. Say: `Jarvis, show me everything about ORVEX.`
4. Memory Explorer must become visible immediately.
5. A close transcription such as `Orvix` must resolve to ORVEX when that entity exists.
6. The command must appear only once and no blank Jarvis bubble may remain.

## Response-profile acceptance

Start a new Realtime session after changing modes.

- Test: one sentence, no more than 25 words by default.
- Short: no more than three sentences and 50 words by default.
- Normal: adaptive, cost-conscious, no more than 100 words by default.
- High: detailed, no more than 200 words by default.
- Full: no fixed sentence or word cap.

A direct request for longer-form output may exceed the profile's normal sentence/word default. Cedar must not be cut off by a small transport token ceiling.

## Private configuration check

Confirm the API key and unrelated `.env` values are unchanged. Custom legacy values that differ from the former defaults must remain effective.
