# 0.2.1 — Action Intelligence Testing Guide

## Before testing

1. Start from the accepted `0.2.0 — Connected Actions` project state.
2. In the same Google Cloud project already used by Jarvis, enable the **People API** in addition to Gmail API and Google Calendar API.
3. Apply `0.2.1`, start Jarvis, and open **Controls → Connected apps**.
4. If Google shows **Reconnect needed** for Contacts, use **Enable Contacts** and approve the additional read-only Contacts permission.
5. Use a disposable recipient and clearly named test events for external-write tests.

Do not commit `.env`, OAuth secrets/tokens, local memory databases, voice data, logs, or local connected-action databases.

## Acceptance flow

### 1. Contact-aware draft

Ask:

> Draft an email to Kenleigh saying this is an Action Intelligence test.

Expected:
- Luna resolves the name through Google Contacts first when a direct email address is not present.
- If Contacts has no usable match, Jarvis falls back to trusted local recipient history and Gmail correspondence.
- If exactly one strong person/address match exists, Jarvis creates a draft addressed to that email.
- If multiple equally plausible matches exist, Jarvis asks which one instead of guessing.
- The written conversation shows a clear `EMAIL DRAFT` preview with status, recipient, subject, and exact body.
- Nothing is sent.
- A separate send confirmation is now bound to the exact displayed draft.

### 2. Thread-aware reply draft

Send a test email to the connected Gmail account, then ask:

> Find my latest email from [test sender], tell me what they need, and draft a reply.

Expected:
- Gmail search finds the relevant message/thread.
- Jarvis reads the thread context.
- Luna summarizes the request and composes the reply.
- A reply draft is created in the same Gmail thread.
- The written result shows the thread summary plus a clear `EMAIL DRAFT` preview with the exact reply recipient, subject, and body.
- Realtime speaks only the concise prepared result.
- The reply remains unsent until separately confirmed.

### 3. Revise the pending/latest draft

Say:

> Change the draft to say that Friday works better.

Expected:
- The existing draft is updated rather than replaced by several duplicate drafts.
- The recipient and thread remain correct.
- The draft remains unsent.

### 4. Send exactly once

After verifying the displayed email preview, say:

> Yes, send it, please.

Expected:
- Jarvis uses the exact pending draft that was displayed; it never asks you for a Gmail draft ID.
- `Send it` and short contextual confirmation such as `Yes, please` are also supported.
- Gmail sends the draft exactly once.
- Jarvis reports success only after Gmail confirms the send.
- The written result changes to `EMAIL SENT` / `Status: Sent` while preserving the exact recipient, subject, and body.
- Repeating a send command must not send the same completed draft twice.

### 5. Combined Gmail + Calendar read

Ask:

> What emails need my attention, and what meetings do I have tomorrow?

Expected:
- One Luna workflow handles both services.
- Both requested parts are answered.
- No external writes occur.
- Realtime does not separately reinterpret either request.

### 6. Calendar availability

Ask:

> When am I free tomorrow afternoon?

Expected:
- Calendar free/busy data is used for the requested period.
- Times are interpreted in the configured/local timezone.
- No calendar event is created.

### 7. Email to Calendar proposal

Use a test email that contains a clear meeting date/time, then ask:

> Find the email about the test meeting and add it to my calendar.

Expected:
- Jarvis reads the relevant Gmail thread.
- Luna extracts the proposed title/date/time/duration from the evidence.
- Jarvis presents one pending Calendar action.
- The event does not exist before confirmation.

### 8. Pending Actions UI

For the proposed event, verify the Connected Apps panel shows one Pending Action card with:
- provider/action summary,
- proposed details,
- **Review**,
- **Edit in chat**,
- **Confirm**,
- **Cancel**.

Select **Edit in chat**, change the time, and submit the edit.

Expected:
- The existing pending action is revised.
- A second duplicate pending action is not created.

Then select **Confirm**.

Expected:
- Google Calendar creates the revised event exactly once.
- The pending card disappears or moves to completed audit history.

### 9. Cancel safety

Create another confirmation-required test action, then select **Cancel**. Also test a pending draft send by saying `Cancel it`.

Expected:
- No external write happens.
- `Cancel it`, `No thanks`, and `Keep it as a draft` are treated as cancellation, never confirmation.
- Later saying “Yes” does not resurrect or execute the cancelled action.

### 10. Contacts-scope regression

Disconnect and reconnect a Google account without Contacts permission, if practical.

Expected:
- Gmail/Calendar connection state remains truthful.
- Contact lookup reports that Contacts access needs to be enabled instead of fabricating an email address.
- **Enable Contacts** starts the authorization flow for the missing scope.

### 11. Non-action regression

Ask:

> Explain thermodynamics.

Expected:
- Connected Actions is not invoked.
- Normal conversation behavior, response modes, hybrid long-form answers, interruption, memory, wake/sleep, and Fullscreen behavior remain unchanged.

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance repair — 0.2.1-repair2 Draft Continuity

The draft/send portion of acceptance additionally requires:

- A successfully created/replied/revised Gmail draft is shown as a dedicated `EMAIL DRAFT` preview card with status, sender/recipient, subject, and exact body.
- The preview is visibly marked as saved but not sent until Google confirms a send.
- When Jarvis asks whether to send that displayed draft, natural confirmations including `Yes, send it, please`, `Yes, please`, and `Send it` act on that exact pending draft without requesting a draft ID or replanning for one.
- Cancelling the send leaves the Gmail draft saved and performs no external send.

See `docs/TESTING_GUIDE_0.2.1-repair2.md` for the focused regression flow.

## Live acceptance repair — 0.2.1-repair3 Email Review

The draft/send acceptance additionally requires:

- Natural explicit approval such as `Yes, please go ahead and send it` must confirm the already-reviewed pending draft on the first try. It must not trigger a second confirmation prompt or planner rediscovery.
- The compact `EMAIL DRAFT` / `EMAIL SENT` presentation must remain structured when opened in Fullscreen; fullscreen may not flatten the email into raw `From:/To:/Subject:` text.
- Fullscreen email state, sender, recipients, subject, and exact message body must match the compact preview.
- Normal non-email fullscreen answers must remain unchanged.

See `docs/TESTING_GUIDE_0.2.1-repair3.md` for the focused regression flow.

## Repair4 acceptance — Draft Editing

`0.2.1-repair4` adds direct draft editing and stabilizes pending-draft language handling found during live acceptance.

Before accepting 0.2.1, verify all of the following:

- `Draft an email to Tanner asking how he's doing` creates a nonblank draft body.
- The compact email preview exposes **Edit** and can save To/Cc/Bcc/Subject/Message changes to the exact Gmail draft without sending.
- Fullscreen exposes the same editor and stays synchronized with the compact preview.
- `Change the subject to Today` and message/tone edit requests update the same pending draft through Luna.
- `No, don't send` leaves the draft saved and does not produce a Gmail routing failure.
- After editing, one explicit send confirmation sends the exact edited draft once.

See `docs/TESTING_GUIDE_0.2.1-repair4.md` for the isolated repair flow.

## Repair5 acceptance — Draft Stability

`0.2.1-repair5` closes the editor usability and routing issues found during live repair4 testing.

Before accepting 0.2.1, verify all of the following:

- Compact **Edit** never traps the form behind the long-answer clamp; the fields scroll and **Cancel**/**Save changes** remain reachable.
- Fullscreen **Edit** keeps **Cancel**/**Save changes** reachable even when the Message is long.
- Saving in either view updates the same Gmail draft and keeps it unsent.
- `Change the subject to Today` updates the pending Gmail draft instead of being handled as a memory correction.
- `Make the message a little friendlier` preserves the edited subject and updates the same exact draft.
- One explicit final confirmation sends the exact edited draft once.

See `docs/TESTING_GUIDE_0.2.1-repair5.md` for the isolated repair flow.
## Repair6 acceptance — Natural Confirmation

`0.2.1-repair6` closes the last observed double-confirmation gap from live repair5 testing.

Before accepting 0.2.1, verify all of the following:

- With an exact pending Gmail draft, `Perfect, thanks, Jarvis. Go ahead and send it.` sends on that first confirmation.
- Jarvis does not ask for a second confirmation and does not replan/rediscover the draft.
- `Great, Jarvis. Yes, please.` and `Looks good. Send it.` also remain natural confirmations of the existing pending action.
- `Perfect, thanks, Jarvis. Don't send it.` cancels without sending.
- `Perfect, thanks, Jarvis. I don't think you should send it.` never auto-sends.
- All repair5 draft editing, subject editing, tone editing, fullscreen editing, and exact-draft send behavior remain unchanged.

See `docs/TESTING_GUIDE_0.2.1-repair6.md` for the isolated repair flow.

