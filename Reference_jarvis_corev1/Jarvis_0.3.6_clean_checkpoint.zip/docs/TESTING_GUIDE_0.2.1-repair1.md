# Testing Guide — 0.2.1-repair1 Recipient Resolution

Use the same connected Google test account from the 0.2.1 acceptance test. Do not add the test person to Google Contacts before the primary regression.

## Install and start

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair1_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```


## 1. Gmail-history recipient fallback

Choose a person who is **not** in Google Contacts but who appears in a recent sent or received Gmail message. Then say:

> Draft an email to [name] saying, thank you, I appreciate it. I will talk to you soon.

Expected:

- Jarvis checks Contacts first.
- When Contacts has no usable address, Jarvis searches Gmail correspondence automatically.
- If one strong person/address match exists, Jarvis creates the draft to that address.
- Jarvis does not ask you to manually provide the address.
- Nothing is sent.

Open Gmail and verify the draft recipient is the correct address before continuing.

## 2. Local reuse

Without changing Contacts, ask Jarvis to create a second harmless draft to the same person.

Expected:

- The same correct address is reused from local recipient identity history.
- Jarvis does not need another Gmail history scan for an already learned unambiguous mapping.
- Nothing is sent.

## 3. Ambiguity safety

If practical, use two correspondents whose display names share the same requested first name, then ask for a draft using only that first name.

Expected:

- Jarvis does not guess between equally strong matches.
- Jarvis asks which person/address you mean.
- No draft is created until the ambiguity is resolved.

## 4. Contacts regression

Ask for a draft to a person who **is** saved uniquely in Google Contacts.

Expected:

- Contacts remains the first/highest-confidence source.
- The draft uses the saved contact address.
- Gmail fallback is not necessary.

## 5. Send safety regression

After verifying a disposable draft, say:

> Send it.

Expected:

- Existing 0.2.1 send confirmation/safety behavior is preserved.
- The draft is sent only through the established explicit-send path and only once.

## 6. Continue 0.2.1 acceptance

If all repair checks pass, resume the remaining tests in `docs/TESTING_GUIDE_0.2.1.md`. Do not start 0.2.2 until the complete 0.2.1 acceptance flow passes.

## Automated validation performed for this repair

- Python: 347/347 tests passed.
- Desktop syntax check: passed.
- Node desktop tests: 86/90 passed; the same 4 packaging-only tests are blocked because the uploaded source workspace does not contain `node_modules` / Electron Packager development dependencies.
