# 0.2.1-repair6 — Natural Confirmation Testing

Use a disposable email recipient/message because the confirmation test intentionally sends a real Gmail draft.

## Apply

After extracting the repair ZIP into the Jarvis project root:

```powershell
py -3.12 apply_0_2_1_repair6_patch.py
npm run desktop
```

## 1. Exact live regression

Create or reuse a disposable pending Gmail draft. Make any desired edits first. When Jarvis is visibly waiting to send the reviewed draft, say exactly:

> Perfect, thanks, Jarvis. Go ahead and send it.

Expected:
- Jarvis treats the sentence as the explicit confirmation of the already-pending exact draft.
- Gmail sends that draft once on this first confirmation.
- Jarvis does not ask `Would you like me to send it?` a second time.
- Luna does not need to rediscover or re-plan the draft before send.

## 2. Other natural prefaces

With a fresh disposable draft, try one of these before the explicit approval:

> Great, Jarvis. Yes, please.

> Thanks, Jarvis. Go ahead.

> Looks good. Send it.

Expected: the exact pending action completes once without an extra confirmation.

## 3. Cancellation safety

Create another disposable draft and say:

> Perfect, thanks, Jarvis. Don't send it.

Expected:
- No Gmail send occurs.
- Jarvis leaves the provider draft saved.
- The pending send is cancelled.

## 4. Ambiguous/negative safety

Create another disposable draft and say:

> Perfect, thanks, Jarvis. I don't think you should send it.

Expected:
- Jarvis must not automatically send the email.
- The polite preamble must not override the negative/uncertain final meaning.

## 5. Regression checks

Verify repair5 behavior still works:
- compact Edit scrolls with Save/Cancel reachable,
- fullscreen Edit saves,
- `Change the subject to Today` updates Gmail,
- `Make the message a little friendlier` updates the same draft,
- a simple `Yes` still sends a pending draft once,
- `No, don't send` still cancels safely.
