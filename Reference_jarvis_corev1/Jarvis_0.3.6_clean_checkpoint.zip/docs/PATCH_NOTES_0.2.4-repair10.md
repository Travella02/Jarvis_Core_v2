# 0.2.4-repair10 — Human Voice

This repair changes direction after repair9 live testing exposed three related problems: Gmail body-only clarification replies still lost their action route on the backend, dedicated Cedar TTS still sounded like an older monotone readout, and a failed/slow action or speech path could leave the desktop feeling stuck.

## Hybrid voice: natural Realtime delivery, deterministic protected facts

Repair7's fact-safety boundary remains intact, but dedicated TTS is no longer used for every Luna-authored response.

- Luna/Jarvis Core still decides the response meaning, wording, personality, and response-mode depth.
- Ordinary conversation and non-factual action dialogue are performed by the existing Realtime Cedar session so Jarvis can regain the more natural timing, pitch movement, and emotional delivery that passed earlier voice testing.
- Realtime receives the already-authored line as a performance target; it is not asked to re-solve the user's request.
- Strict application facts remain on the deterministic speech path. Task/reminder times, Calendar facts, local clock answers, and other protected grounded outputs continue to use exact speech so values such as `2 PM` cannot mutate to `8 PM`.
- Personality and Short / Normal / High / Full remain separate controls. Response mode is still a ceiling, not a quota.

This is intentionally a hybrid mouth rather than another TTS-prompt adjustment: natural dialogue gets the expressive Realtime voice while fact-sensitive output retains the exact safety path.

## Gmail clarification route is now owned by the backend

Repair9 remembered the clarification route in the browser, but `/api/actions/turn` still re-routed each new utterance from its text. A dictated email body such as `Say hi, I was just wondering how you're doing...` contains no Gmail keyword, so the backend could still return a routing failure.

Repair10 adds session-scoped clarification ownership inside `ConnectedActionService` itself. When Gmail asks for missing draft information, the backend remembers the exact Gmail route for the bounded clarification window. The next natural reply inherits that route even if it contains no words like `email`, `draft`, or `Gmail`. Once a concrete operation is selected, the route is cleared so unrelated conversation cannot be hijacked.

The normal draft safety contract is unchanged: Jarvis creates the real Gmail draft/card, but sending still requires explicit user approval.

## Stuck-turn recovery

The desktop now has bounded recovery for both Connected Actions and dedicated speech:

- Connected Action requests have a 30-second client timeout. A timeout aborts the request, clears action ownership/clarification state, and returns Jarvis to Listening instead of leaving a permanent in-flight promise.
- Dedicated speech synthesis has a bounded generation timeout.
- Dedicated audio playback has a duration-aware watchdog.
- Routing/planner failures clear stale generic action clarification ownership immediately.
- All failure paths release voice ownership and restore Listening so the next user turn can proceed normally.

## Preserved behavior

- `Call Tanner` remains grounded at **2 PM**, never 8 PM.
- Existing Google OAuth, `.env`, memory, voice profiles, task/reminder data, personalities, and response-mode settings are untouched.
- Unknown speakers remain identity-neutral and are never assigned `sir`/`ma'am` unless that person explicitly saved a preference.
- Interruption remains supported on both Realtime delivery and exact dedicated speech.
