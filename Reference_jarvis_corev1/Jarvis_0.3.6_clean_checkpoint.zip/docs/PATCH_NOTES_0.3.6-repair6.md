# 0.3.6-repair6 — Steam Isolation

**Date:** 2026-09-03  
**Required previous release:** 0.3.6-repair5  
**VERSION remains:** 0.3.6  
**Status:** Live acceptance test-tooling repair candidate

## Why this repair exists

The Repair5 automated regression rerun passed 198 tests but one pre-existing Computer Actions unit test failed on the real Windows machine. `test_steam_manifest_becomes_reliable_uri_launch_target` created one synthetic Rocket League Steam manifest under pytest's temporary directory, but `WindowsAppDiscovery` also intentionally read the host user's real `HKCU\Software\Valve\Steam` registry entry. The fixture therefore discovered the user's real Steam library as well and returned 16 games instead of the single synthetic game the test expected.

## What changed

- The affected Steam-manifest unit test now explicitly masks the module-level `winreg` provider for that fixture only.
- The fixture still runs `WindowsAppDiscovery(..., platform_name="nt")` and still proves the normal `ProgramFiles(x86)\Steam` manifest-to-`steam://rungameid/...` behavior.
- Production `jarvis/computer/apps.py` is unchanged. Real Jarvis continues to consult the Windows Steam registry and discover actual installed Steam libraries.
- No permission, confirmation, executor, Browser, Computer Actions, Game Mode, billing, account, or security behavior is weakened.

## Root principle

A unit test that supplies a complete synthetic filesystem fixture must not accidentally merge real host state into its expected result. Test isolation is fixed at the test boundary rather than deleting useful production discovery behavior.

## Issue

See ISSUE-329.

## Commit rule

Do not commit yet. Apply repair6 over the exact repair5 candidate, rerun the same automated suites, and resume Live Batch 2 only after the suite is clean. Keep all patch/repair/backups until Tanner explicitly accepts the complete 0.3.6 release. No Git tag.
