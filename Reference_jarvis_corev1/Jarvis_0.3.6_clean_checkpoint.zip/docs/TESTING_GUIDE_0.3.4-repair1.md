# 0.3.4-repair1 — Web Authentication & Account Gate Testing Guide

## Goal

Confirm that an existing or new installation can always reach a verified Jarvis account without entering a cloud password inside Electron, and that signed-out users cannot access normal Jarvis functionality.

## Live acceptance

1. Fully close Jarvis, apply the repair, then run `npm run desktop`.
2. If the installation has not completed its first-run setup, that existing setup layer may appear first. After first-run setup, a signed-out installation must show only the Jarvis account gate; normal workspace tabs must not be usable underneath it.
3. Click **Create account**. The default browser must open the Jarvis development account portal.
4. If this installation already contains Account Foundation data, the browser page must say that existing Jarvis data was found and offer to upgrade it rather than rejecting creation as “already linked.”
5. Create an account using a normal 10-digit US phone such as `3853335329` or a valid email. The phone should be accepted and stored canonically; no E.164 knowledge should be required from a US user.
6. Enter different values in **Password** and **Type password again** once. The browser must reject the mismatch before completing signup. Then use matching passwords of at least 12 characters.
7. In the development relay, use the displayed development verification code. Production must never display this code in-band.
8. After verification, the browser should show **AUTHENTICATION COMPLETE** and the desktop should unlock automatically without asking for the cloud password again.
9. Confirm the existing account/tenant/data identity and local Jarvis data remain present after a legacy upgrade.
10. Sign out. The full-screen account gate must immediately return and normal Jarvis controls must be inaccessible.
11. Click **Forgot email or password?**. Start recovery using the verified email or phone, enter the development recovery code, identify the account, reset the password with matching confirmation, then sign in with the new password.
12. Confirm the old password no longer works and previously issued cloud sessions were revoked by the reset.
13. After sign-in, confirm Cloud Sync controls appear without any desktop password/connect-device form. Enable Tasks & reminders, run **Sync now**, and confirm there is no unexpected conflict.
14. Run one Browser Control smoke test and one spoken follow-up to ensure 0.3.3 Runtime Reliability behavior remains intact.
15. Confirm the visible release remains **0.3.4 · Cloud Sync**. Do not commit until live acceptance passes.

## Expected result

A user can recover from both fresh-install and legacy-bound account states through browser-managed account creation/sign-in/recovery, and the desktop never becomes a second password UI.

## Installer safety

The repair installer is hash-gated against the original unaccepted 0.3.4 Cloud Sync candidate. It normalizes only LF/CRLF representation differences, accepts already-applied repair files, backs up overwritten source, and must refuse genuine unexpected edits rather than forcing the repair through. It does not include `.env`, runtime `data/`, credentials, caches, `.venv`, or `node_modules`.
