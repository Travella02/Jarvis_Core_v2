# 0.1.8-repair1 — Memory Hygiene

This live-acceptance repair keeps Jarvis's knowledge graph grounded in user-authored evidence, makes natural filler-prefixed memory commands reliable, and contains the Memory Explorer filters inside their panel.

## What changed

- Assistant responses remain exact, timestamped conversation events but no longer create new people, projects, acronyms, preferences, relationships, food entities, or generic named concepts.
- Assistant messages may still link to an entity that already exists, preserving useful source timelines for known people, organizations, and projects.
- A conservative one-time startup repair removes generic graph nodes that were created only from assistant wording and have no user evidence, facts, tasks, relationships, or actor history.
- Cleanup preserves every exact assistant response and does not remove a concept that the user established independently.
- Natural preambles such as `Um, actually, forget that` are normalized consistently in the desktop renderer and core command parser.
- Recognized forget commands now reach the trusted local memory lifecycle path instead of receiving a stale general-model limitation response.
- The Memory Explorer search and filter form now wraps and shrinks responsively, keeping Search and other controls inside the timeline card.

## Data-safety contract

- Existing source events are not deleted by graph hygiene.
- Only assistant-only generic derived entities with no durable dependent state qualify for automatic removal.
- User-authored entities, facts, relationships, tasks, actor records, and aliases attached to retained entities remain untouched.
- A later genuine user statement can recreate a previously false generic concept normally.
- Forget remains a reversible lifecycle state; permanent deletion is still a separate explicit action.

## Validation

Automated coverage verifies assistant-source authority boundaries, known-entity linking, conservative graph cleanup, conversational forget routing, responsive filter containment, and all accepted Speaker Recognition, Self Awareness, and Memory Intelligence behavior.
