# 0.1.5 — Identity Foundations

Jarvis now has a durable local identity layer backed by SQLite memory schema version 5 for people, speaker attribution, aliases, relationships, privacy boundaries, and future voice/face recognition enrollment.

## Identity foundation

- Dedicated person profiles with canonical and preferred names, aliases, roles, relationships, trust, retention, privacy boundaries, and memory permissions.
- Protected local-owner identity for Tanner.
- Source-backed speaker attribution and correction history.
- Future-safe voice and face enrollment status without exposing raw biometric templates through normal memory APIs.
- People & Identity workspace with profile search, attributed timelines, related evidence, relationship views, and attribution history.

## Canonical identity repair

- Understands authoritative corrections such as “Kenleigh is the proper spelling.”
- Parses multiple confirmed aliases in one statement.
- Preserves an existing surname when the user corrects only a first name.
- Chooses the evidence-rich profile instead of creating another person.
- Merges duplicate profiles while retaining every original name as an alias.
- Relinks attributed events, person relationships, proactive subjects, and attribution references to the canonical identity.
- Repairs already-stored canonical correction statements once after startup.

## Functional identity controls

The profile drawer now uses in-app forms rather than unsupported browser prompts:

- Edit canonical/preferred name, relationship, role, and notes.
- Set privacy boundary, retention, and trusted state.
- Add aliases.
- Set scoped memory permissions.
- Select and merge duplicate people with explicit confirmation.
- Persist all operations through trusted local APIs with audit and undo support.

## Safety and preservation

Similar names are not merged merely because they look alike. Canonical changes require explicit user wording or explicit UI confirmation. Original memory events remain immutable evidence. Old names, attribution history, timestamps, and supporting evidence remain preserved.

## Validation

- 242 Python tests passed.
- 55 Node tests passed.
- Python and JavaScript syntax checks passed.
- Doctor and core diagnostics passed.
- Desktop-runtime staging passed.
- Fresh `0.1.5` repair installation and safe reapplication passed.
- Private `.env` preservation verified.
