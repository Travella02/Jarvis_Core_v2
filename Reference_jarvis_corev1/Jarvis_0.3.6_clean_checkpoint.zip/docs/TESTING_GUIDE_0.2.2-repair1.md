# Testing Guide — 0.2.2-repair1 Gmail Polish

## 1. Natural confirmation with conversational lead-in

Create and review a disposable Gmail draft, then say:

> Perfect, thanks, Jarvis. Go ahead and send it.

Expected:

- the exact reviewed draft sends on this first confirmation;
- Jarvis does not ask “Would you like me to do that?” or ask for a second yes;
- the sent email card is shown;
- only one Gmail send occurs.

This repair also tolerates a harmless speech-recognition error in the assistant vocative before the explicit send phrase.

## 2. Negative control

Create another disposable draft and say:

> Perfect, thanks. I don’t think you should send it.

Expected: Jarvis must not send the draft.

## 3. Show one specific email

Ask:

> Show me the email from Google Cloud.

Expected:

- Jarvis opens the matching Gmail thread when one exists;
- the result is displayed as a Gmail-style card, not plain From/To/Subject text;
- From, To, Subject, and Message are visually separated;
- the actual message body is shown when Gmail provides it.

## 4. Show multiple emails

Ask for several messages, for example:

> Show me my three most recent unread emails.

Expected:

- Jarvis keeps the fast Gmail search path;
- each returned message appears as its own Gmail-style card;
- cards show the available snippet/message preview.

## 5. Fullscreen

Open Fullscreen on a read-email result.

Expected: the Gmail cards remain structured in fullscreen rather than flattening into plain text.

## 6. Speed regression

Connected Actions should retain the noticeably faster behavior from 0.2.2. Check Connected Apps → Last action for the measured action latency.
