# 0.0.7 — Sleep Response Correlation Repair

## Summary

This repair prevents delayed output-audio buffer events from an earlier Realtime response from closing Cedar's current sleep acknowledgement.

## Fixed

- Bound the sleep acknowledgement to its exact Realtime response ID.
- Filtered `output_audio_buffer.started` and `output_audio_buffer.stopped` by `response_id`.
- Ignored stale output-buffer events from the preceding tool-call response.
- Filtered acknowledgement `response.done` handling by the same response ID.
- Reset response-correlation state between sleep sequences.

## User-visible result

When Jarvis accepts a natural sleep request, Cedar can finish **“Of course, sir.”** before the session changes to Sleeping. A late buffer-stop event from an older response can no longer terminate the active sign-off.

## Issue record

See `issues/ISSUE_045_STALE_AUDIO_BUFFER_EVENT_CLOSED_SLEEP_ACK.md`.
