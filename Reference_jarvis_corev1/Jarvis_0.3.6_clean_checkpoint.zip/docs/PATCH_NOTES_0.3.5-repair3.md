# 0.3.5-repair3 — Isolated YouTube Fullscreen

**Date:** 2026-09-01  
**Required previous release:** `0.3.5-repair2`  
**Application version remains:** `0.3.5`  
**Status:** Live-acceptance repair candidate

## Purpose
Repair the intermittent YouTube fullscreen rendering glitch found during 0.3.5-repair2 live acceptance, where page descriptions, recommendations, comments, and third-party overlays could remain visible over the video even though Jarvis reported fullscreen success.

## What changed
- Jarvis no longer synthetically clicks YouTube's fullscreen button from the extension content script.
- Native element fullscreen is attempted only when Chromium reports a real active user gesture.
- Voice-driven fullscreen normally uses a Jarvis-owned top-level immersive portal that temporarily moves the live YouTube player container above the page rather than relying on `position: fixed` inside YouTube's transformed/layout ancestors.
- The portal preserves the real player DOM, playback state, controls, and event listeners, then restores the same player to its original parent/sibling position on fullscreen exit.
- Immersive success is now verified against viewport geometry, not merely the presence of an internal boolean flag.
- If the fallback cannot actually cover the viewport, Jarvis restores the page and reports failure instead of claiming fullscreen succeeded.
- Repair2's silent-success behavior remains unchanged: successful fullscreen/minimize actions remain silent; failures still speak.

## Why this is safer
Synthetic `.click()` on a YouTube fullscreen button can cause YouTube to mutate its page/fullscreen CSS even when Chromium rejects the underlying Fullscreen API because the voice command is not a trusted browser user gesture. That leaves the page in a half-entered visual state. Repair3 avoids that page-owned transition and uses a reversible Jarvis-owned visual boundary instead.

## Calendar result
Google reconnect was completed successfully during live acceptance and the Calendar test passed. Repair3 does not change Google OAuth, Calendar, Billing, or Connected Actions behavior.

## Files materially changed
- `extensions/jarvis_browser_bridge/content.js`
- `tests_js/browser_access.test.cjs`
- release consistency tests
- repair notes/testing/handoff/manifest
- ISSUE-314 documentation/index

## Rollback
The repair installer backs up every replaced file before changing it. Restore the reported `0.3.5-repair3_<timestamp>` backup if repair3 fails acceptance. Do not delete account, Billing, OAuth, memory, or other user data as part of source rollback.

## Acceptance state
Do not commit yet. Re-test repeated YouTube fullscreen/minimize cycles after applying repair3. Any further fixes remain `0.3.5-repair4`, etc. No Git tag.
