# 0.2.0-repair3 — Reliable Action Routing

Fixes a live Connected Actions regression where requests containing natural plurals such as `emails` could bypass Luna and fall through to Realtime.

## Changes

- Gmail routing now recognizes `email/emails`, `message/messages`, and `draft/drafts` plus existing Gmail terms.
- Calendar routing now recognizes singular and plural calendar/event/meeting/schedule language.
- The desktop sends a trusted domain hint to Luna for explicit Gmail or Calendar turns.
- Luna may not classify a routed Gmail or Calendar turn as unrelated; it must select an appropriate connected action or ask one concise clarification.
- Explicit connected-action turns no longer fall through to ordinary Realtime responses after an action-router error.
- If a Google operation succeeds but Luna's response-writer request fails afterward, Jarvis keeps the successful provider result and renders a deterministic emergency summary instead of losing the action result.
- Google connection state is checked before Luna planning for explicit Google turns to avoid unnecessary model spend when the account is disconnected.

## Cost and architecture

Realtime remains speech-only for Connected Actions. Luna continues to perform the normal interpretation, tool selection, argument extraction, and response writing. The new deterministic formatter is an error-recovery path only after a provider result already exists.
