# 0.1.7-repair2 — Hybrid Answers

This repair separates long-form speech from long-form writing so Realtime speaks one concise summary while a lower-cost text model generates the complete on-screen answer in parallel.

## Changes

- Removed the second Realtime companion response that could duplicate or switch Jarvis’s speech.
- Realtime now creates exactly one answer for a substantial request: the spoken summary bounded by Test, Short, Normal, High, or Full mode.
- Added a trusted local `POST /api/text/detailed-answer` route backed by the OpenAI Responses API.
- Added a separately configurable written-answer model. The default is `gpt-5.6-luna` with low reasoning effort.
- Added one stable Jarvis answer card. It begins with a neutral loading message and is filled with the complete written answer; the temporary spoken transcript is not shown and then replaced.
- The spoken summary and detailed text request begin in parallel to reduce perceived latency.
- Added text-token usage and cost accounting to the existing session, daily, and monthly budget ledger.
- Added safe cancellation for interruption, a new turn, sleep, disconnect, provider failure, and window shutdown.
- If the text model is unavailable, the spoken summary becomes the written fallback instead of producing a duplicate answer.
- Preserved live capability grounding, durable memory context, first-person Jarvis wording, response-mode behavior, speaker recognition, and existing safety boundaries.

## Configuration

```env
JARVIS_TEXT_MODEL=gpt-5.6-luna
JARVIS_TEXT_REASONING_EFFORT=low
JARVIS_DETAILED_TEXT_MAX_OUTPUT_TOKENS=4096
JARVIS_DUAL_CHANNEL_ANSWERS_ENABLED=true
```

These values are optional because backward-compatible defaults are supplied by the configuration loader. The patch does not overwrite the user’s private `.env` file.

## Compatibility

- Version remains `0.1.7` because this repairs the unaccepted Self Awareness update.
- Existing installations keep their API key, memory database, voice profiles, response preferences, and private settings.
- Simple turns still use one normal Realtime response and do not invoke the written-answer model.

## Validation

- 281 Python tests passed.
- 71 source-available Node tests passed.
- Four unchanged Electron packaging tests require the complete project’s excluded `node_modules` tree and remain mandatory in the installer.
