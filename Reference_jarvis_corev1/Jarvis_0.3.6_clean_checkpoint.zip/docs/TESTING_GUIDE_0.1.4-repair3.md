# 0.1.4-repair3 — Clean Corrections & Interruption Sync Testing Guide

## Automated validation

The patch installer runs:

- 225 Python tests
- 48 Node tests
- Desktop syntax checks
- Doctor diagnostics
- Core diagnostics
- Desktop-runtime staging
- Private `.env` preservation verification

## Correction acceptance flow

1. Start Jarvis with `npm run desktop`.
2. Say: “I need to follow up with Boston tomorrow.”
3. Correct it: “Hey, sorry, Jarvis, I actually meant Austin.”
4. Open **Memory → Proactive** and select **Refresh locally** if the automatic refresh has not already completed.
5. Confirm the commitment says **follow up with Austin tomorrow**.
6. Confirm it does not contain `meant Austin`, `actually Austin`, or Boston.
7. Open **Why this?** and confirm the original Boston statement and the Austin correction are both preserved.
8. Refresh again and confirm the corrected item remains singular and stable.

Existing malformed items such as **follow up with meant Austin tomorrow** should repair themselves after one local refresh.

## Interruption acceptance flow

1. Ask Jarvis for an answer long enough to speak for several seconds.
2. Interrupt him mid-response with a new question or statement.
3. Confirm the interrupted bubble is marked **Interrupted by user**.
4. Confirm no additional old-response text appears after the interruption.
5. Confirm Jarvis answers the new turn audibly and the matching text appears once.
6. Repeat the interruption twice to verify an older cancelled `response.done` cannot silence a newer response.
7. Close and reopen Jarvis and confirm proactive corrections remain persisted.
