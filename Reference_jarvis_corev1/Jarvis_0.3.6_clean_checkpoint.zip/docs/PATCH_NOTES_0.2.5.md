# 0.2.5 — Multi-Speaker Intelligence

0.2.5 makes the live Jarvis conversation speaker-aware. Jarvis can distinguish alternating speakers inside one room, keep each person's conversational/action context separate, show who spoke in the transcript, and onboard an unknown speaker without guessing identity or gender.

## Live speaker lanes

- Every voice turn is resolved against consented Voice Profiles first.
- When no saved profile confidently matches, Jarvis creates a short-lived in-memory `Guest N` speaker cluster for the current live session.
- Repeated turns that conservatively match the same unknown voice stay in that same temporary lane.
- Speaker bubbles are relabeled from the generic `YOU` label to the recognized person's name, `Likely <name>`, or `Guest N`/`Unknown speaker`.
- Recent conversation sent to Luna preserves those speaker labels so first-person statements and preferences are not silently attributed to the wrong person.

## Neutral unknown-speaker onboarding

Unknown speakers remain identity- and gender-neutral. Jarvis never infers `sir`, `ma'am`, gender, or another form of address from vocal characteristics. When an unknown person's identity becomes relevant, Jarvis can naturally ask what to call them. A person can explicitly provide a name and preferred form(s) of address, which are stored on the canonical person profile and used naturally later.

A self-declared identity inside the room is conversational attribution, not authentication. It does not silently create a permanent biometric profile.

## Consent boundary for persistent voice recognition

Temporary unknown-speaker embeddings remain process-local and memory-only. Raw audio is not retained by the voice-profile service. After an unknown speaker identifies themselves, Jarvis may offer to remember their voice for next time, but permanent cross-session recognition still requires the existing explicit Voice Profile enrollment/consent flow.

## Speaker-scoped action continuity

Connected Action clarification/focus state is now scoped to the current live speaker. If one person starts an email, Calendar, or task clarification and another person speaks, Jarvis does not hand the first person's unfinished action context to the second person. Shared room conversation remains available as reference, while action ownership stays speaker-specific.

## Safer unknown-speaker clustering

Unknown-speaker matching is deliberately conservative. A false split is preferable to merging two people and crossing their context or preferences. Pitch-center differences are used only as a split cue; they are never used to infer gender or identity.

## Scope limitation

0.2.5 supports natural alternating or rapid turn-taking between multiple people. True simultaneous/overlapping-speech diarization is not implemented yet; that is a later ambient-conversation milestone.

## Acceptance target

The release passes when a known speaker and a second unknown speaker can alternate naturally, the unknown person can give a name/address preference without `sir`/`ma'am` guessing, Jarvis keeps their bubbles/context/actions separate, and a temporary identity does not become a permanent Voice Profile without explicit consent.
