# 0.1.0 — Windows Finalization Repair

## Summary

This pre-acceptance repair targets the remaining Windows Electron Forge stall after source and runtime payload size were proven compact. It replaces the single opaque `Finalizing package` spinner with method-level timestamps, packages directly under `out`, and temporarily bypasses Electron executable icon/version editing.

## Changed

- Added `scripts/windows_packager_diagnostics.cjs` to trace the Windows Packager lifecycle.
- Added `scripts/run_alpha_forge.cjs` as the alpha package/make launcher.
- Changed `alpha:package` and `alpha:make` to use the diagnostic launcher.
- Set Packager `tmpdir: false` and `overwrite: true` so progress is visible directly in `out` and no final temporary-directory move is required.
- Disabled `runResedit` unless `JARVIS_ALPHA_ENABLE_RESEDIT=1` is explicitly supplied.
- Preserved the Squirrel Setup icon and the future executable branding configuration.

## Diagnostic behavior

The build writes:

```text
build\alpha-packaging-diagnostic.log
```

The log records start, completion, duration, and failure for:

- initialization and ASAR creation
- Electron executable rename
- runtime bundle copying
- executable resource editing or its deliberate bypass
- signing
- final output completion

The launcher also prints a heartbeat every minute with the last recorded stage.

## Expected tradeoff

The diagnostic build may show Electron's default icon and executable metadata for the installed application executable. This is intentional and temporary. The installer icon remains configured. Branding will be restored only after the package and installer path is confirmed stable.

## Validation

- Python and Node regression suites passed in the prepared project tree.
- Node syntax checks passed for the Forge runner, diagnostic module, and Forge configuration.
- A native Windows Forge/Squirrel run is still required for acceptance.
