# 0.2.1-repair1 — Recipient Resolution

Fixes the live 0.2.1 acceptance failure where a named email recipient had to exist in Google Contacts even when Jarvis could already identify that person from recent Gmail correspondence.

## Changes

- Named recipients now resolve through a layered, safety-first path instead of stopping at Google Contacts.
- Resolution order is: Google Contacts → trusted local recipient identity history → recent Gmail correspondence → broader Gmail history.
- Recent Gmail sender and recipient headers are inspected for matching names and email addresses. Jarvis does not infer an address from message body text alone.
- The connected account's own email address is excluded from correspondence candidates.
- Exact/full-name and strong token matches are preferred. If equally strong candidates map the same name to multiple addresses, Jarvis asks which person/address the user means instead of guessing.
- A successful Contacts or Gmail-history resolution is remembered in the local connected-action identity cache so later requests can reuse it without scanning Gmail again.
- Missing Google Contacts permission no longer blocks a named Gmail draft when Gmail history can resolve the recipient. Explicit Contacts-only requests still truthfully require Contacts permission.
- Luna remains the action planner. Realtime remains speech-only for connected actions.

## Safety boundary

This repair does not send email automatically. Creating a draft remains confirmation-free because it is non-executing; sending the draft still requires the existing explicit-send flow.

## Primary regression

The live acceptance case:

> Draft an email to Tanner saying, thank you, I appreciate it. I will talk to you soon.

must succeed when Tanner is absent from Google Contacts but appears unambiguously in recent Gmail sender/recipient metadata.

## Apply it

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair1_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```
