# 0.0.5 — Electron Shell

## Summary

Moves the proven Realtime Voice Lab into the first native Jarvis desktop shell while preserving the independent loopback Python core, secure WebRTC provider boundary, wake behavior, simulation mode, and Cost Control safeguards.

## Added

- Electron 43 desktop main process with a hardened preload boundary.
- Automatic local Python-core startup and health polling.
- Loading and recovery views when the core is starting or unavailable.
- Windows tray controls for Open, Wake, Sleep, Restart core, and Quit.
- Single-instance protection.
- Minimize-to-tray behavior and persistent window bounds.
- Clean Python child-process shutdown when Jarvis quits.
- Electron Forge packaging foundation for Windows Squirrel and ZIP artifacts.
- Build-time staging of the Python runtime without `.env`, runtime data, logs, or caches.
- External private `.env` support through `JARVIS_ENV_FILE`.
- Authoritative local date, time, timezone, and UTC-offset context in every Realtime session.
- Narrow spoken sleep-command detection for phrases such as “That’s all, Jarvis” and “Go to sleep, Jarvis.”

## Security and privacy

- Electron uses `contextIsolation: true`, `nodeIntegration: false`, and `sandbox: true`.
- The permanent OpenAI API key remains in the Python process.
- Packaged resources never include `.env`.
- Packaged mode stores private configuration in Electron’s user-data directory.
- External window creation is denied by the desktop shell.

## Development commands

```powershell
npm run desktop
npm run desktop:check
npm run desktop:package
npm run desktop:make
```

## Acceptance boundary

This is the first desktop shell, not the final futuristic Jarvis interface. The current Voice Lab is intentionally reused inside Electron so native lifecycle behavior can stabilize before the orb, panels, workspace, and final visual system are redesigned.
