# 0.2.4-repair9 — Natural Continuity

This repair keeps the repair7/repair8 safety architecture but changes two parts that failed live acceptance: Cedar still sounded too much like a scripted readout, and a Gmail draft clarification could fall out of Connected Actions before the real draft/card was created.

## Natural speech, without giving speech ownership of facts

Luna/Jarvis Core still determines the exact wording and the existing grounded fact guard remains authoritative. Realtime remains the live listening/interruption layer. Cedar remains the dedicated Speech API output layer for the approved script.

The change is in how Cedar is directed. Repair8 sent a large instruction stack with exactness, anti-robot, pitch, rhythm, pause, personality, purpose, and exception rules. The script is already the Speech API input, so repair9 removes the redundant content rulebook and gives Cedar a compact performance note instead: respond like a person in the moment, use relaxed conversational pacing, natural pitch movement, subtle emotion, meaning-based emphasis, and small human pauses.

Luna also receives stronger speech-first wording rules. Spoken answers should not look like a formatted report: no bullets, numbered lists, headings, or colon-introduced lists unless the user specifically asks for a list. Jarvis should use the shortest natural context-aware phrasing that actually answers the turn.

Response modes are unchanged: Short, Normal, High, and Full control maximum spoken depth, not warmth or expressiveness.

## Gmail clarification continuity restored

Connected Actions now retains a bounded clarification route after a non-Calendar action asks for missing information. This matters for natural follow-ups such as the body of an email, which often contains no provider/action keywords.

Example:

- `Can you draft an email to Tanner?`
- Jarvis asks what it should say.
- `Say hi, I was just wondering how you're doing. Please get back to me ASAP.`

The final line is now routed back to the same Connected Action flow instead of ordinary conversation. The real Gmail draft should be created, its card should appear, and sending still requires explicit confirmation.

## Preserved behavior

- The task-time truth boundary remains deterministic; `2 PM` must never become `8 PM`.
- Existing Gmail/Calendar/Contacts OAuth and stored data are untouched.
- Draft creation never implies sending.
- Interruption still stops dedicated speech.
- Personality and speaker-specific address preferences remain separate from response-length mode.
- Unknown speakers remain neutral; no guessed `sir`/`ma'am`.
