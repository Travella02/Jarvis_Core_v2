# 0.2.0-repair2 — Stable Action Delivery

This repair stabilizes the handoff from Luna and Google tools to the Realtime voice layer.

- Empty speech artifacts no longer appear as `Voice message` bubbles.
- Luna’s prepared result is displayed immediately in one stable Jarvis card.
- Realtime speaks the prepared summary without independently choosing tools or calling sleep.
- The result card is no longer dependent on delayed provider metadata.
- Connected-action work keeps the session active while Luna or Google is still processing.
- Gmail and Calendar read results must contain useful information instead of generic speech such as “Sure.”
- Existing OAuth tokens, `.env`, memories, and action history are preserved.
