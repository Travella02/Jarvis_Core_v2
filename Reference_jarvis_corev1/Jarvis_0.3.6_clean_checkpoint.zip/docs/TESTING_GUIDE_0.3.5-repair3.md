# 0.3.5-repair3 — YouTube Fullscreen Isolation Live Test

**Do not commit yet.** Apply over the current `0.3.5-repair2` candidate.

## Apply
Close Jarvis. Extract the repair ZIP into the Jarvis project root and allow replacement of the repair payload files, then run:

```powershell
python .\apply_0_3_5_repair3_patch.py
```

## Automated validation

```powershell
python -m pytest -q tests/test_browser_access.py tests/test_voice_lab_client.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

## Start
Use one command only:

```powershell
npm run desktop
```

## Repair-specific live checks
1. Open the same YouTube/Sidemen video used during repair2 testing.
2. Say `Fullscreen YouTube.` The video/player should fill the screen with a clean black/player surface. The YouTube description, comments, recommendation rail, vidIQ panels, and other page overlays must **not** remain visible over the video.
3. Say `Minimize YouTube.` The exact same player should return to its normal page position and playback should continue normally. Jarvis should not speak a success confirmation.
4. Repeat fullscreen → minimize at least **five times**. No cycle should produce the half-fullscreen overlay state shown during repair2 live acceptance.
5. While fullscreen, test `Pause YouTube.` and `Play YouTube.` to confirm the structural media target remains usable.
6. After minimizing, scroll/interact with the normal YouTube page and confirm its layout is restored rather than leaving the player detached or the page locked.
7. If fullscreen cannot be verified, Jarvis should fail truthfully rather than claiming success.

Google Calendar already passed after reconnect during repair2 acceptance. After repair3 passes, continue the 0.3.5 Billing-specific live acceptance. Do not remove apply/patch artifacts or commit until explicit acceptance.
