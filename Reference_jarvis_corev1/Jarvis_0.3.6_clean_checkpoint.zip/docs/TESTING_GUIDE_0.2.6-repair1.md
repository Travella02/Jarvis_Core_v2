# Testing 0.2.6-repair1 — Duplicate Discovery

## Primary regression

Say:

> Open Discord.

### Pass

- Discord opens.
- Jarvis does **not** say `Discord, Discord, and Discord`.
- Jarvis does not ask which Discord you mean when the visible app name is identical.

Close Discord and ask again. The second launch should remain fast because the successful target/alias is cached locally.

## Other exact apps

Try two or three installed programs that may have Start Menu entries and direct executables, for example:

> Open Spotify.
> Open Steam.
> Open VS Code.

Exact obvious app names should launch without meaningless duplicate-name clarification.

## Genuine ambiguity safety

If you have both Visual Studio and Visual Studio Code installed, try:

> Open Visual.

Jarvis is allowed to clarify because those are different visible applications.

## Alias learning

After successfully opening a program, use a natural alias on a later turn. Jarvis should learn successful aliases per speaker and resolve them faster in the future.
