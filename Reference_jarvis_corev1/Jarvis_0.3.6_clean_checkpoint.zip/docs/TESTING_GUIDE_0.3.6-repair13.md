# 0.3.6-repair13 Live Testing — Action Context & False VAD Stability

1. Run the targeted Node tests, `desktop:check`, the full desktop test suite, and the 0.3.6 Python regression group.
2. Gmail continuity: say `Draft an email to Tanner`, then `Say hi`, then `Yes`. If either short follow-up is labeled `Unknown speaker`, Jarvis must keep the draft context and reach the trusted send-permission prompt instead of saying it lost action context.
3. Say `No` on a fresh draft confirmation with transient Unknown attribution. It may safely leave the draft unsent; it must not complain about the original speaker or lose context.
4. Positively recognized different-speaker test: a different enrolled person must not silently inherit the first person's active Connected Action.
5. False-VAD test: while Jarvis is Speaking or Thinking, create ordinary room/mic noise without intentionally speaking. A short false VAD edge must not interrupt Jarvis and must never strand the orb in Thinking.
6. Real barge-in test: while Jarvis is speaking, deliberately say a command. Interruption should still happen quickly after the short debounce or transcript evidence.
7. Trusted permission modal: speech remains inert; only on-screen Allow/Cancel may decide the action.
