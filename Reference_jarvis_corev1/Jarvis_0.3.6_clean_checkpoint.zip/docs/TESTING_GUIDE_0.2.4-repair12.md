# Testing 0.2.4-repair12 — Context Separation

Use your existing OpenAI speech provider first. ElevenLabs is not required for this acceptance pass; repair12 is about Luna response semantics, not changing the mouth again.

## 1. Grounded time regression

Ask:

`Is there anything I need to do tomorrow?`

Then:

`What time?`

Expected for the existing Call Tanner reminder:

`2 PM.`

The exact phrasing can be similarly concise, but it must remain **2 PM**, never 8 PM.

## 2. Gmail body must not become conversation with Jarvis

Ask:

`Can you draft an email to Tanner?`

When Jarvis asks what it should say, answer naturally:

`Say hi, I was just wondering how you're doing. Please get back to me ASAP.`

Expected:

- the real Gmail draft/card appears;
- the email body is placed in the draft;
- the draft remains **not sent**;
- Jarvis acknowledges the completed draft naturally and asks whether you want it sent;
- Jarvis must **not** answer the email body as though `how you're doing` was a question to him;
- specifically, a response such as `Hi, I'm doing well...` is a failure.

The exact good acknowledgement is intentionally not hardcoded. Natural examples include `Done—the draft's ready. Want me to send it?` or `Got it. I've got the draft ready—want me to send it?`

## 3. Return to unrelated conversation cleanly

Do **not** send the draft yet. Immediately ask:

`What do you think makes a life meaningful?`

Expected:

- Jarvis answers this current question, not any older Gmail/body text;
- he does not mention the draft unless your new question refers to it;
- the answer should sound like a coherent conversational thought, not a clipped slogan or circular definition;
- Jarvis returns to Listening normally afterward.

A short answer is fine if Short/Test mode is selected, but it should still make semantic sense.

## 4. Response-mode behavior

Try one open-ended question in **Short**, **Normal**, and **High**.

Expected:

- all three answers can reason intelligently;
- Short says less;
- Normal gives a natural conversational answer;
- High can expand when useful;
- none should pad simple questions merely to fill the mode;
- none should collapse a nuanced question into an awkward motto just to be brief.

## 5. Artifact-payload generalization

If convenient, try one additional content-bearing action, such as revising a draft body or creating a task whose text contains a conversational sentence.

Expected: Jarvis treats the supplied text as content for the action. He does not personally answer the content unless you separately address that question to Jarvis.

## 6. Speech provider regression

Controls → Audio should still show the replaceable speech-provider setup from repair11. OpenAI remains usable without additional configuration; ElevenLabs remains optional when its local credentials/voice ID are configured.

Changing the speech provider must not change the facts or action semantics above.
