# Testing Guide — 0.2.3-repair4 Calendar Grounding

## Test 1 — local 3 PM stays 3 PM
Say:

`Can you schedule a meeting with Tanner for tomorrow at 3 PM?`

Expected:
- Jarvis speech says 3 PM, not 9 PM.
- The Calendar card says 3:00 PM in the local timezone.
- The date is tomorrow according to the computer's local date.
- Nothing is created until confirmation.

Confirm with:

`Yes, go ahead and add it.`

Verify Google Calendar shows the same local time.

## Test 2 — clarification stays in Calendar
With that meeting still present, say:

`Can you make it 30 minutes instead of an hour? Or actually an hour instead of 30 minutes?`

Jarvis should ask which duration you mean. Answer:

`To one hour.`

Expected:
- Jarvis proposes a one-hour update.
- He does not claim it is already changed.
- Confirm once, then verify Google Calendar is one hour long.

## Test 3 — add attendee to the exact meeting
Say:

`Can you add Austin to that meeting tomorrow?`

Expected:
- Jarvis keeps the exact meeting already in context.
- Tanner remains an attendee.
- Austin is added if his email can be resolved.
- If Austin cannot be resolved, Jarvis asks for the needed email instead of throwing a generic Calendar error.
- One final confirmation applies the update.
