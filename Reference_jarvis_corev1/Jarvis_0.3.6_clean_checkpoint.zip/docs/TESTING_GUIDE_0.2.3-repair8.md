# Testing Guide — 0.2.3-repair8 Attendee Clarification

## Primary live test
Use the meeting that already works correctly in local time.

1. Ask Jarvis: **“Can you add Austin to that meeting tomorrow?”**
2. Make sure Austin is not in Google Contacts and has no known email in Jarvis/Gmail history.
3. Expected: Jarvis asks for Austin's email address. He should not tell you to edit Calendar manually and should not claim he cannot control Calendar.
4. Reply naturally with the email, for example: **“His email is austin@example.com.”**
5. Expected: Jarvis shows the same meeting with the existing attendee(s) preserved and Austin added, then asks once for confirmation.
6. Say: **“Yes, update it.”**
7. Verify Google Calendar contains Austin on that exact meeting.

## Continuity checks
- The meeting's already-correct local time must stay unchanged.
- A previously changed one-hour duration must stay unchanged.
- Tanner must remain an attendee while Austin is added.
- The email-address follow-up should not start a new Calendar search or require you to repeat which meeting you meant.

## Repeat-resolution check
After the successful update, use Austin's name in another Gmail or Calendar action. Jarvis should be able to reuse the user-supplied email identity instead of asking again.
