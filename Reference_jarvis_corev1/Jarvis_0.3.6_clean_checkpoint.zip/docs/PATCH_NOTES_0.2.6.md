# 0.2.6 — Computer Actions

## What changed

Jarvis can now open local Windows applications, games, files, folders, and project directories from a natural request without requiring the user to know or provide an executable path.

The local computer-action pipeline is intentionally separate from Luna and Realtime reasoning. The renderer recognizes a direct open/launch request, the loopback-only core resolves it through `ComputerAppService`, Windows performs the launch, and Jarvis only reports success after the operating system accepted the launch request.

## Autonomous discovery

Discovery is progressive so common requests stay fast:

1. Reuse a previously successful per-person alias or cached launch target.
2. Inspect Windows **App Paths**.
3. Inspect **Get-StartApps** / AppsFolder registrations.
4. Inspect Start Menu and Desktop shortcuts.
5. Inspect PATH executables.
6. Read **Steam** library manifests and launch games through `steam://rungameid/...`.
7. Read **Epic Games Launcher** manifests and use the Epic launcher URI when available.
8. Search common install locations.
9. If no strong application match exists, perform a bounded query-directed search of fixed drives for a matching executable/shortcut.

Explicit file/folder/project requests use the same progressive strategy, beginning with the user's common resource folders and falling back to fixed-drive search. System metadata, recycle folders, reparse/symlink loops, and development dependency trees are skipped.

Jarvis never asks a normal user to locate an `.exe` for it.

## Learned aliases

Every successful natural name becomes a local alias for the recognized person. Generated aliases also include executable names, compact spellings, acronyms, vendor-free names, and conversational forms such as `VS Code` for Visual Studio Code.

Example:

- First request: `Open Rocket League.`
- Later request: `Open RL.`
- After a successful launch, the requested alias is persisted locally and future launches can bypass discovery.

Aliases are tenant-aware and person-aware. One person's preferred nickname for an app does not silently become another person's private preference.

## Safe selection

Jarvis does not blindly run the first fuzzy filename it sees. Exact learned aliases and installed-app registrations rank highest. Installers, uninstallers, updaters, crash reporters, helpers, and service executables are penalized. If two candidates remain genuinely ambiguous, Jarvis asks which one rather than guessing.

Opening an app/file/folder is treated as a non-destructive user-requested action and does not require a second confirmation. Editing, moving, copying, deleting, browser control, and general mouse/keyboard automation are not added in this release.

## Persistence

The launch catalog is stored beneath the existing Jarvis data directory at `data/computer/app_catalog.json` (or the configured `JARVIS_DATA_DIR`). It stores discovered launch targets, usage metadata, and aliases; it does not copy application binaries or user documents.

## Configuration

The feature defaults on for Windows:

- `JARVIS_COMPUTER_ACTIONS_ENABLED=true`
- `JARVIS_COMPUTER_DEEP_SEARCH_ENABLED=true`
- `JARVIS_COMPUTER_DEEP_SEARCH_TIMEOUT_SECONDS=35`

The deep-search timeout is a safety/latency boundary, not a request for the user to provide the missing path. Jarvis keeps every safe candidate it discovers so future requests get faster.
