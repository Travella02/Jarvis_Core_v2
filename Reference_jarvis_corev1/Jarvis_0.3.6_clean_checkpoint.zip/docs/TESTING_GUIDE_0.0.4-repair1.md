# Testing Guide — 0.0.4 Transcript Repair

## Automated checks

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

When Node.js is installed, also run:

```powershell
node --check apps\desktop\lab\app.js
```

## Live acceptance

1. Start Jarvis in **Live OpenAI** mode.
2. Wake him with a natural request, such as “Jarvis, give me a one-sentence greeting.”
3. After Jarvis answers, speak a normal follow-up without saying the wake word.
4. Confirm the follow-up user bubble changes to **Voice input**.
5. Confirm it does not remain on **Processing speech…**.
6. Confirm Jarvis answers only once for that spoken turn.
7. Send a typed message and confirm its exact text still appears.
8. Verify cost totals and response counting remain unchanged.

## Acceptance boundary

Commit `0.0.4` only after the ordinary spoken follow-up reliably shows **Voice input** and all previous Cost Control behavior still passes.
