# 0.2.3-repair1 — Calendar Follow-through

## Summary

This live-acceptance repair keeps Calendar edits conversationally natural while preserving every unconfirmed change until the user explicitly approves the Google Calendar write.

## What changed

- **Human calendar answers:** A question such as “What do I have on my calendar tomorrow?” now answers naturally (for example, “You don’t have anything on your calendar tomorrow”) instead of saying the calendar is “clear for that time.”
- **Truthful pending wording:** Calendar edits no longer sound completed before Google has been changed. “Make it 30 minutes instead of an hour” now produces a proposal such as “Got it—30 minutes instead. Want me to update the meeting?”
- **Cumulative pending edits:** Repeated changes to the same pending Calendar action now build on one another instead of dropping an earlier unconfirmed change.
- **Duration continuity:** A 60-minute event changed to 30 minutes carries the new end time into the final provider update after confirmation.
- **Additive attendee continuity:** “Add Austin too” resolves Austin and appends that person to the already-preserved attendee list rather than replacing or ignoring existing attendees.
- **Grounded timezone preservation:** Contextual updates keep the provider event’s real timezone when the planner’s required schema emits an unused UTC default.
- **Safety unchanged:** Calendar creates, updates, and deletes still require a separate explicit confirmation. Conflict detection and deletion behavior remain confirmation-protected.

## Architecture

Realtime remains the voice layer. Luna continues to interpret Calendar intent, while local Connected Actions code binds exact provider IDs, merges pending proposal state, resolves attendees, recalculates duration, checks conflicts, and waits for confirmation before calling Google.

## Regression coverage

Added tests cover:

- natural empty-calendar wording for tomorrow,
- a 30-minute duration revision remaining pending until confirmation,
- the final Google update carrying the 30-minute end time,
- chained duration + attendee edits sharing the same pending action,
- Austin being appended alongside the existing attendee,
- timezone preservation across contextual pending edits.
