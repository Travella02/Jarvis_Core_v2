# 0.2.1-repair6 — Natural Confirmation

## What this repair fixes

Live repair5 testing confirmed that draft composition, editing, fullscreen editing, subject changes, tone changes, and provider-backed sending all worked. One conversational gap remained: a natural acknowledgement before an explicit send command could cause Jarvis to ask for confirmation a second time.

Example that previously failed:

> Perfect, thanks, Jarvis. Go ahead and send it.

The exact pending Gmail draft was already waiting for confirmation, but the confirmation matcher expected the approval phrase to begin at the start of the utterance. The polite preamble therefore prevented deterministic confirmation and allowed the request to re-enter planning.

## Repair

- Pending Connected Actions now normalize a small, bounded set of benign conversational prefaces before evaluating the final decision clause.
- Natural acknowledgements such as `Perfect`, `Great`, `Thanks`, `Thank you`, `Looks good`, `Sounds good`, and an optional `Jarvis` vocative can precede an explicit confirmation or cancellation.
- The decisive clause must still independently match the existing confirmation/cancellation grammar. A friendly preamble alone never sends anything.
- The frontend continuation detector and the backend Connected Action service use the same decision-normalization concept so the request stays on the exact pending action path.
- Negative or uncertain language is not converted into approval. For example, `Perfect, thanks, Jarvis. I don't think you should send it.` is not an automatic send confirmation.
- Natural cancellation with the same preamble remains safe: `Perfect, thanks, Jarvis. Don't send it.` cancels the pending send and leaves the Gmail draft saved.

## Safety contract

This repair broadens conversational phrasing without weakening the external-write boundary. Jarvis still requires a clear final approval command before Gmail sends. Provider completion remains the source of truth for success.
