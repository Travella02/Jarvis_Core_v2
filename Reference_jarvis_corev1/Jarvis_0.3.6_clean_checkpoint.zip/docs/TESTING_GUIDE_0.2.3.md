# 0.2.3 — Calendar Intelligence Testing

## Apply

After extracting the update ZIP directly into the accepted 0.2.2 project root:

```powershell
py -3.12 apply_0_2_3_patch.py
npm run desktop
```

## One-time Calendar availability permission

Open **Controls → Connected apps**. If Jarvis shows **Enable Calendar Availability**, click it and approve Google once. This grants the free/busy permission used for live open-slot scheduling; no new OAuth client ID or secret is required.

## Acceptance flow

### 1. Calendar read + structured card

Ask:

> What do I have on my calendar tomorrow?

Expected:
- Jarvis queries Google Calendar.
- Spoken output is short and humanized.
- The written result uses structured Calendar event cards with date/time and other available event details.
- Fullscreen preserves the Calendar formatting.

### 2. Fixed-time attendee event

Ask:

> Schedule a meeting with Tanner tomorrow at 3 PM for an hour.

Expected:
- Tanner resolves through the connected person-resolution path.
- Jarvis builds a Calendar event preview addressed to the resolved attendee.
- Nothing is created yet.
- Jarvis asks once for explicit confirmation.

Before confirming, say:

> Actually make it 4.

Expected:
- The same pending event changes to 4 PM.
- The one-hour duration remains intact.
- No duplicate pending event is created.

Then say:

> Perfect, schedule it.

Expected:
- Google creates the exact reviewed event once.
- Jarvis reports success only after provider confirmation.

### 3. Contextual event follow-up

Ask Jarvis to show one specific event, then say:

> Move that to Friday at 2.

Expected:
- Jarvis binds `that` to the exact event just shown.
- The existing duration and attendees remain unless you asked to change them.
- The move waits for separate confirmation.

Then try:

> Make it 30 minutes.

and:

> Add Austin too.

Expected:
- Both changes remain tied to the same event.
- The attendee is resolved safely and appended rather than replacing existing attendees.

### 4. Conflict detection

Create or locate an event occupying a known time, then ask Jarvis to schedule another event over the same period.

Expected:
- Jarvis identifies the overlap before executing the write.
- The Calendar card/confirmation warns about the conflict.
- Jarvis still requires explicit confirmation before creating the conflicting event.

### 5. Personal availability

Ask:

> When am I free Thursday afternoon for an hour?

Expected:
- Jarvis uses live Calendar free/busy data.
- It presents provider-grounded open slots rather than guessing.
- No event is created.

### 6. Smart schedule from an availability window

Ask:

> Find a time Thursday afternoon when I'm free for an hour and schedule an ORVEX planning meeting.

Expected:
- Jarvis finds a real open slot in the requested window.
- It proposes one concrete event and shows a Calendar preview.
- Creation still waits for your explicit confirmation.

### 7. Mutual availability safety

Ask:

> Find a time Thursday afternoon when Tanner and I are both free for an hour and schedule a meeting.

Expected:
- Jarvis tries live free/busy for both calendars only because you explicitly requested mutual availability.
- If Google exposes Tanner's availability, Jarvis proposes a jointly free slot.
- If Google cannot expose Tanner's free/busy data, Jarvis clearly says that and does **not** guess Tanner is available. It may offer to schedule using only your availability instead.

### 8. Sleep/wake pending-action continuity

Prepare a Calendar create/update/delete action but do not confirm it. Let Jarvis sleep, wake him again as the same recognized actor, then say:

> Go ahead and schedule it.

Expected:
- The exact pending Calendar action is recovered in the fresh voice session.
- Jarvis does not force you to restate the event.
- Another recognized actor must not inherit the pending write.

### 9. Delete safety

Ask Jarvis to cancel/delete a disposable Calendar event.

Expected:
- Jarvis shows/identifies the exact target and asks for confirmation.
- Nothing is deleted before confirmation.
- After confirmation, Jarvis reports deletion only after Google confirms it.

### 10. Regression checks

Verify Gmail draft/edit/reply/send, unread/read-state control, natural confirmations, Short response limits, wake/sleep, interruption, memory, and ordinary non-action conversation still behave as accepted in 0.2.2.

## Automated validation

```powershell
py -3.12 -m unittest discover -s tests -p "test_*.py"
npm run desktop:check
npm run desktop:test
```
