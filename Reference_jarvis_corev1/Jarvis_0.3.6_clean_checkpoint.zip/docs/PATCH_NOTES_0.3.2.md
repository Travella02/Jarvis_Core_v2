# 0.3.2 — Account Foundation

Account Foundation gives Jarvis a stable local-first account identity layer without moving existing feature data to the cloud yet. It is the ownership boundary that 0.3.3 Cloud Sync can build on instead of retrofitting identity after synchronization exists.

## What changed

- Added durable account, tenant, membership, installation, device, and session identities under `data/accounts/accounts.sqlite3`.
- Added create-account, sign-in, sign-out, current-session, and display-name update APIs.
- Passwords are salted and hashed with Python's standard-library `scrypt`; plaintext passwords and raw session tokens are never persisted.
- Browser sessions use a random opaque token stored only as a SHA-256 hash in SQLite and delivered to the local UI through an `HttpOnly`, `SameSite=Strict` cookie.
- Account write endpoints retain the existing trusted-local-client header boundary.
- Added a dedicated Account workspace to the desktop UI for signup, login, session/device identity, tenant identity, and sign-out.
- Existing local data remains local and untouched. The account database records an `installation_bindings.data_namespace` mapping from the authenticated tenant to the existing `JARVIS_LOCAL_TENANT_ID` namespace so 0.3.3 can attach/sync the right data deliberately.
- A local installation cannot silently rebind its existing data namespace to a different account. Account switching is intentionally blocked until the storage layer can isolate/switch tenant data safely.
- Added an explicit SQL schema reference under `migrations/0001_account_foundation.sql` for future cloud migration work.

## Version promotion

All current product/release surfaces are promoted to `0.3.2` during testing: `VERSION`, Python project metadata, npm package metadata, the Browser Bridge package revision, desktop release labels/static asset revisions, handoff metadata, release-consistency tests, and `RELEASE_MANIFEST.json`.

## Deliberately not included

- No cloud upload, backup, restore, or cross-device synchronization yet. That is 0.3.3.
- No billing, subscription plan, quota, or entitlement logic yet. That is 0.3.4 and remains configuration-driven rather than hardcoded into individual features.
- Existing memory/action/task databases are not rewritten or uploaded in this update.
- Account identity does not treat speaker recognition as authentication.

## Acceptance target

The update is accepted when a clean 0.3.1 install can apply the patch, create an account, remain signed in across normal local requests, sign out, sign back in to the same tenant, reject an incorrect password, preserve existing Jarvis data/functionality, and pass the automated regression suite.
