# 0.2.5-repair3 — Voice Confidence

## What changed

This live-acceptance repair improves how Jarvis enrolls and recognizes known voices without weakening the neutral unknown-speaker safety model.

- Voice Profiles now provide a guided three-sample enrollment flow with varied phrases selected for broad speech coverage.
- Each recording is checked locally before it is accepted. Weak samples are rejected with a retry message instead of quietly degrading the profile.
- Profiles show recognition readiness (`Building`, `Ready`, or `High`) in addition to sample count and average quality.
- Matching now combines a quality-weighted multi-sample centroid with support from the strongest enrolled samples.
- Strong profiles receive a small bounded threshold calibration rather than a global threshold reduction.
- A recently confirmed known speaker can retain identity across a short borderline follow-up when the same person remains the clear profile candidate. That continuity is session-only and expires quickly.
- Runner-up separation remains mandatory, so two similar enrolled people are not force-assigned just because one is numerically first.

## Privacy and identity rules

Raw enrollment audio is still discarded after the protected local signature is created. Enrollment still requires explicit consent. Guided phrases, quality scoring, and session continuity do not infer gender, forms of address, permissions, or identity for an unknown person.
