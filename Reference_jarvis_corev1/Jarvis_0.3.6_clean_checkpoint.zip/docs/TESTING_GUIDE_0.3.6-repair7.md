# 0.3.6-repair7 — Friendly Confirmation Testing

Apply only over the exact verified `0.3.6-repair6` live candidate.

## Automated checks

```powershell
python -m pytest -q tests/test_browser_confirmation_security.py tests/test_permission_executor_enforcement.py tests/test_permission_confirmation_security.py tests/test_phase5_adversarial_security.py tests/test_permission_confirmation_api.py tests/test_permissions_api.py tests/test_authenticated_reauth_security.py tests/test_browser_access.py tests/test_computer_apps.py tests/test_server.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

## Live Batch 2 restart

Set Browser Control to `Always ask` and say `Jarvis, open a new tab.`

Expected prompt is short consumer copy such as:

> Permission required. Allow Jarvis to open a new browser tab?

The prompt must not display `tab_new`, JSON, raw target/action arguments, permission keys, or developer/security diagnostics. Jarvis must be the foreground owner when the prompt appears; File Explorer or another unrelated application must not be brought forward.

### Cancel
Click Cancel. No tab opens, the request is terminal, no Computer Actions fallback occurs, and focus returns to Jarvis.

### Allow / one-use
Request a new tab, Allow it, then make the identical request again. The second request must require a fresh confirmation. The prior approval may never be reused.

Continue the remaining 0.3.6 live confirmation-boundary guide only after these checks pass. Do not commit until explicit 0.3.6 acceptance.
