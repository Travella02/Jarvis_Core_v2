# Testing Guide — 0.0.5 Electron Shell Repair 1

## Install

```powershell
py -3.12 apply_0_0_5_repair1_patch.py
```

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Desktop acceptance

Start the app with:

```powershell
npm run desktop
```

Confirm the native window, automatic Python-core startup, simulation mode, live voice, tray controls, single-instance behavior, spoken sleep commands, correct local date/time, minimize-to-tray behavior, window-bounds restoration, core restart, and complete process shutdown.

## Cross-platform regression

The installer was tested against a CRLF `.gitignore` that was textually identical to the accepted baseline. It was also tested against a genuinely modified `.gitignore`, which remained correctly blocked.
