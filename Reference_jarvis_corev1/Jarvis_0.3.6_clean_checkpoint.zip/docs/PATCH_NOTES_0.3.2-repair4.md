# 0.3.2-repair4 — Account Navigation

This repair keeps the 0.3.2 Account Foundation feature set and fixes the Account rail tab falling back to Home during live acceptance.

## What changed

- Added `account` to the canonical desktop workspace allowlist in `setActiveWorkspaceView()`.
- The existing Account button and Account workspace can now be selected through the same navigation path as Home, Controls, Tasks, Insights, Memory, and System.
- Added regression coverage that verifies Account is not only rendered but is also an allowed navigable workspace.
- ISSUE-299 records the live symptom, exact root cause, fix, test coverage, and lesson.

## Version

The application version remains **0.3.2**. `repair4` is only the pre-acceptance repair label. All current application version surfaces remain 0.3.2.
