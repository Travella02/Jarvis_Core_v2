# 0.2.3-repair9 — Action Ownership

## Summary
This repair closes the routing gap exposed by the attendee test. When a Calendar request refers to “that meeting” and there is only one matching meeting in the requested day, Jarvis now grounds that exact Google event before asking any follow-up question. If a newly named attendee cannot be resolved, Jarvis asks for the email instead of asking which meeting or falling back to ordinary Realtime.

It also adds a hard ownership contract for connected Google capabilities: when the live capability registry reports Gmail or Google Calendar actions as available, Realtime must not claim that Jarvis cannot access or control those services and must not tell the user to perform a supported action manually. Connected Actions owns execution; Realtime owns speech.

## What changed
- Contextual attendee additions such as “Add Austin to that meeting tomorrow” first query the bounded Calendar day when needed.
- If exactly one Google Calendar event matches that day, Jarvis binds it automatically instead of asking “Which meeting?”
- Unknown attendees then go directly to the existing safe email clarification: Jarvis asks for Austin’s email and preserves the exact event while waiting.
- Short selection replies such as “The one with Tanner” remain inside Connected Actions instead of falling through to ordinary Realtime.
- The Realtime session prompt now contains an explicit Connected Google action ownership rule based on the live capability registry.
- Connected Gmail/Calendar capability descriptions now explicitly state that Realtime must not redirect supported work to manual app instructions.
- The working local-time authority introduced in repair7 is unchanged.

## Capability truth rule
When Gmail or Calendar Connected Actions are available, Jarvis may not say that he cannot access, schedule, update, reply, send, or otherwise control those connected services merely because a request escaped normal routing. He also may not invent success. If routing ever misses, Realtime must use a brief neutral handoff while Connected Actions remains the source of truth. Genuine connection or permission failures may still be stated accurately.

## Safety
The single-event shortcut only activates when the requested Calendar window contains exactly one provider event or there is already exactly one grounded event in context. Multiple possible meetings still require clarification. Unknown attendee emails are never guessed, and Calendar writes still require explicit confirmation before Google is changed.

## Validation
- Python: 420/420 passed.
- Desktop JavaScript syntax: passed.
- Connected Actions frontend contract: passed.
- Full Node source suite: 86/90 passed; the same four unchanged Electron packaging tests remain blocked because the uploaded source workspace does not include `@electron/packager` development dependencies.
