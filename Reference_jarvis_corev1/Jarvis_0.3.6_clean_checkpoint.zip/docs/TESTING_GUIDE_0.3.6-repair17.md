# 0.3.6-repair17 Live Testing — Blocked Action Preflight & Error Fidelity

Do not make the final 0.3.6 acceptance commit or clean patch artifacts yet. Apply Repair17 only over the exact `0.3.6-repair16` candidate.

## Live test A — Calendar Block stops immediately

1. Set **Calendar Actions** to `Block`.
2. Say: **“Jarvis, create an event tomorrow at 5 PM called Blocked Calendar Test.”**

**Pass:** Jarvis immediately says the action is blocked by Permissions & Security. He does **not** ask how long the event should be, does not open a native permission prompt, and does not create the event.

## Live test B — Block remains terminal across a continuation

1. Temporarily set Calendar to a mode that lets Jarvis prepare an exact event proposal.
2. Before confirming the reviewed action, change Calendar to `Block`.
3. Say **“Yes.”**

**Pass:** the pending action terminates as blocked, the provider action does not execute, and Jarvis gives the explicit Permissions & Security blocked message instead of a Google error.

## Live test C — Repair16 regression

Re-run one `Allow once`, one `Always allow`, and one normal consequential Calendar/Gmail confirmation.

**Pass:** Repair16 behavior is unchanged: permission choice and action review remain separate; no new duplicate confirmation appears.

## Automated checks

Run the new blocked-action preflight tests, Connected Action confirmation-security tests, permission foundation/executor/API tests, Calendar single-confirmation tests, release consistency, `npm run desktop:check`, and the normal 0.3.6 regression group before final acceptance.

## Security invariant

Repair17 only moves hard denials earlier and preserves their exact meaning. It never consumes a grant, creates a grant, or bypasses the executor permission boundary.
