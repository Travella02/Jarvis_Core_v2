# Testing Guide — 0.0.5 Wake Acceleration Repair

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

Expected unit result:

```text
Ran 100 tests
OK
```

## Live acceptance

1. Launch with `npm run desktop` and wait until the wake listener reports that it is ready.
2. Say only **“Jarvis.”** Measure the time from the end of the word to the start of Cedar's acknowledgement.
3. Return Jarvis to sleep and say **“Jarvis, tell me a short joke.”** Confirm one request and one response.
4. Repeat the test at least five times. Later wake cycles should benefit from provider keep-alive and remembered room-noise calibration.
5. Say a clear sentence that does not include Jarvis. The temporary speculative connection should close without a response, and local wake listening should resume.
6. Confirm the Provider Events panel includes safe events such as `wake.transcription.completed`, `wake.preconnect.ready`, `wake.microphone.reused`, or `wake.fast_path.ready`.
7. Stay silent and make ordinary room noise to ensure false-wake protection did not regress.
8. Confirm the initial window remains fully contained on one monitor.
9. Close the window with X and confirm Electron and the Python core both terminate.

## Acceptance boundary

Do not commit `0.0.5` until wake-only and wake-plus-request are clearly faster, no duplicate opening turn returns, non-Jarvis speech does not produce a response, and shutdown/window behavior remain correct.
