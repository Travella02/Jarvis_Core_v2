# 0.1.2-repair3 — Deterministic Memory Navigation & Response Caps

Repairs the remaining live voice-to-interface navigation failure and aligns the five response profiles with the accepted product behavior.

## Deterministic Memory navigation

- Visual memory commands are now owned by one local renderer path rather than competing local and Realtime-tool paths.
- A recognized command switches the workspace synchronously before any memory API request or Jarvis response begins.
- The switch clears Focus mode, activates the Memory rail item, sets `hidden`, `aria-hidden`, `inert`, and an explicit display rule on every workspace, and keeps a short visibility guard active while results load.
- Specific subjects prefer an entity page; broad, speaker, and temporal requests use the filtered timeline.
- Conservative fuzzy matching still resolves small transcription variants such as `Orvix` to an existing `ORVEX` entity.
- The former `show_memory` model tool and follow-up response path are removed. This prevents blank Jarvis bubbles, duplicate action ownership, and claims that the explorer is still loading.
- Duplicate transcript variants and repeated visual commands are suppressed by normalized content signatures.
- Renderer asset URLs advance to `0.1.2-repair3` so Electron cannot continue serving the previous script.

## Accepted response profiles

| Mode | Default sentence cap | Default word cap | Intended behavior |
|---|---:|---:|---|
| Test | 1 | 25 | One minimal useful sentence |
| Short | 3 | 50 | Direct and brief |
| Normal | Adaptive | 100 | Question-dependent and cost efficient |
| High | Adaptive | 200 | Detailed with useful context |
| Full | None | None | Complete detail |

The sentence and word limits are hard default policies. Jarvis may exceed them only when the user explicitly requests longer-form output, such as a story, a full page or document, a complete transcript, a long list, or an intentionally detailed report.

Each mode is configurable in the private `.env` with:

- `JARVIS_RESPONSE_<MODE>_MAX_SENTENCES`
- `JARVIS_RESPONSE_<MODE>_MAX_WORDS`
- `JARVIS_RESPONSE_<MODE>_MAX_OUTPUT_TOKENS`

The default provider token ceiling is `0`, meaning the model-supported maximum, so a transport limit does not cut Cedar off mid-sentence. Owners may still configure a provider ceiling. Legacy `MEDIUM` and `TARGET_WORDS` settings migrate to `HIGH` and `MAX_WORDS`.

## Validation

- 192 Python tests passed.
- 33 Node tests passed.
- JavaScript and Python syntax checks passed.
- Core doctor and diagnostic checks passed.
- Desktop runtime staging passed.
- Fresh patch installation and safe reapplication passed.
- Private `.env` preservation passed.
