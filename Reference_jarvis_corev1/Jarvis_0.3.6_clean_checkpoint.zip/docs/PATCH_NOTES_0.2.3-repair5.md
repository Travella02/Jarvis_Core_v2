# 0.2.3-repair5 — Calendar Truth

This live-acceptance repair makes Jarvis describe the exact Calendar action he is actually preparing instead of letting speech or cards drift away from provider truth.

## Primary Google Calendar timezone fallback
Some desktop runtimes can report `UTC` even though the connected Google Calendar is configured for a local timezone. That produced the exact failure seen in testing: Google scheduled the intended 3 PM instant, while Jarvis spoke and rendered 9 PM UTC.

For ordinary Calendar requests, Jarvis now uses the primary Google Calendar timezone as the fallback source of truth whenever the desktop timezone is UTC/unknown. The provider timezone is cached for 30 minutes so this does not add a network lookup to every Calendar turn. Explicit UTC/GMT requests remain UTC.

## Grounded confirmation wording
Calendar confirmation speech no longer re-parses the first duration phrase from the raw utterance. It now derives the duration from the final grounded event preview that will actually be written to Google.

If a self-correcting request produces a one-hour proposal, the card and speech both describe one hour. Jarvis can no longer say `30 minutes` while the pending action and eventual Google update are one hour.

## One Calendar truth across surfaces
For a Calendar proposal, the same canonical event now drives:
- Luna planning context,
- spoken confirmation,
- Calendar card date/time/duration,
- pending-action state,
- and the Google Calendar write.

## Safety
Creates, updates, and deletes still require explicit confirmation. Provider timezone fallback changes presentation/grounding only; it does not weaken write confirmation or ambiguity handling.
