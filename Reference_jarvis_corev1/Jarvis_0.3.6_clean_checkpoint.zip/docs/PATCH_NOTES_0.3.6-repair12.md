# 0.3.6-repair12 — Default Autonomy & Turn Stability

Repair12 addresses live-test friction discovered after Repair11.

## Changes

- Permission preference labels are simplified to **Default**, **Always allow**, **Always ask**, and **Block**.
- **Default** keeps Jarvis autonomous for routine/reversible actions while preserving trusted review for consequential or security-sensitive actions.
- Trusted permission cancellation is silent because the visible modal already communicates the cancellation.
- Temporary **Unknown speaker** attribution no longer blocks a pending Connected Action decision such as Yes/No; positively attributed different speakers still reset conversational action context. Consequential execution remains protected by the trusted permission/executor boundary.
- Voice transcript duplicate suppression is scoped to the same microphone turn, so repeating the same phrase in a new turn is not discarded. Duplicate suppression also cannot leave Jarvis stuck in Thinking.

## Security invariant

This repair does not make dangerous actions default-allow. Gmail send, consequential Calendar writes/deletes, destructive file/process operations, security changes, credential access, and financial actions retain their stronger policy levels.
