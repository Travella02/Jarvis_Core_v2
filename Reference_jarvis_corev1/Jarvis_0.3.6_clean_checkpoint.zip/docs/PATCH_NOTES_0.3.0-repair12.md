# 0.3.0-repair12 — Media Control & Natural Research

This repair closes the remaining live Browser Control and Web Intelligence routing gaps without changing the accepted freshness/search architecture.

- Pause/resume now routes deterministically from the desktop into Browser Control and targets the best matching live media tab instead of depending only on the active-tab content script.
- Browser media volume can be set structurally with natural requests such as `Set YouTube volume to 35%`.
- Named YouTube result continuation tolerates harmless title spacing differences such as `data center` versus `datacenter` while remaining grounded in visible `/watch` results.
- Natural current-information questions such as `What are the latest updates in Rocket League?` route directly to Web Intelligence without requiring explicit `search` wording.
- Browser-result continuations that do not match a grounded visible result fall through instead of letting the general browser planner invent a click.
- Game Mode, Web Intelligence freshness verification, adaptive search economics, and the Web Intelligence card renderer remain unchanged.
