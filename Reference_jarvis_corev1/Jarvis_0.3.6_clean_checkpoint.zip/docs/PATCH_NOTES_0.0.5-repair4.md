# 0.0.5 — Electron Shell Repair 4

## Summary

This repair fixes the Windows-only npm launch failure that occurred after all Python validation had passed. The Electron Shell installer now resolves the executable Windows command shim (`npm.cmd`) instead of attempting to launch Node's extensionless POSIX npm script as a native Win32 program.

## User-visible symptom

```text
ERROR: [WinError 193] %1 is not a valid Win32 application
```

The failure occurred during `npm install --no-audit --no-fund` after Node.js itself had successfully reported its version.

## Root cause

The Windows Node installation included both `npm` and `npm.cmd`. The installer resolved `npm` first. Because the extensionless file is a shell script and the Python installer launches commands without a shell, Windows rejected it as a native executable.

## Changes

- Added `jarvis.desktop.node_tools` for centralized Node/npm executable discovery.
- Windows now prefers `npm.cmd`, then `npm.exe`, then `npm`.
- The installer uses the resolved Windows shim for dependency installation and desktop JavaScript validation.
- The doctor uses the same resolution logic.
- Added `ISSUE_025_WINDOWS_NPM_SHIM_RESOLUTION.md`.
- Added a deterministic regression test that simulates both Windows npm files and confirms `npm.cmd` wins.

## Validation target

- 82 automated tests.
- JavaScript syntax validation for Electron main, preload, and Voice Lab renderer.
- Doctor and secret-safe diagnostic.
- Desktop runtime staging.
- Installer rerun and rollback behavior.
- Custom `.gitignore` preservation.
- Byte-for-byte `.env` preservation.
