# Testing Guide — 0.0.1-dev1-realtime-repair3

## Install

Stop the running core with `Ctrl+C`, extract the patch into the existing `Jarvis_Real_Time` project, then run:

```powershell
py -3.12 apply_0_0_1_dev1_realtime_repair3_patch.py
```

Do not rerun repair1 or repair2. The real ignored `.env` remains in place and is not modified.

## Automated tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Expected summary:

```text
Ran 32 tests
OK
```

## Doctor

```powershell
.\.venv\Scripts\python.exe scripts\doctor.py
```

Expected: all required checks pass and the API key is either reported as configured with its value hidden or, if not configured, an actionable warning is shown.

## Start command

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

Open `http://127.0.0.1:8765` if the browser does not open automatically.

## Manual acceptance sequence

1. Select the intended microphone and speaker.
2. Press **Connect** once.
3. Confirm the provider-events panel shows both `webrtc.offer.ready` and `webrtc.answer.ready`.
4. Confirm there is no `Failed to parse SessionDescription` or `Invalid SDP line` message.
5. Wait for `session.created`, then say a simple greeting.
6. Confirm Jarvis replies through the selected speaker and a transcript/provider event appears.
7. Send one typed message.
8. Press **Disconnect**, verify the microphone is released, then connect again.

## Expected result

The status changes from Connecting to Connected, the data channel opens, provider session events arrive, and audio can flow in both directions.

## If it still fails

Capture screenshots of:

- The visible error text in the Voice Lab.
- The provider-events panel, especially events after `webrtc.answer.ready`.
- The terminal error, if any.

Do not include `.env`, the API key, browser Network response bodies, raw SDP, ICE credentials, or `logs/realtime_events.jsonl` without first checking it for sensitive data.

A failure after `webrtc.answer.ready` with a different message means answer delivery succeeded and the next WebRTC/provider issue is now visible. A missing `webrtc.answer.ready` means the server did not return a successful SDP response.
