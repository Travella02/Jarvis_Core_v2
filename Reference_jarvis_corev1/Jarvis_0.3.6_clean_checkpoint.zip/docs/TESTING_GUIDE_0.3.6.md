# 0.3.6 — Permissions & Security Testing Guide

> **Current live candidate:** Apply `0.3.6-repair1 — Windows Hygiene Startup` before continuing this guide on Windows. The repair fixes ISSUE-323, where the one-time legacy hygiene migration could be blocked by an already-open `logs/core.log`. See `docs/TESTING_GUIDE_0.3.6-repair1.md`.

**Do not commit 0.3.6 until this full live acceptance passes and the update is explicitly accepted.**

## Apply from the project root

Extract the patch ZIP into the committed clean 0.3.5 project root, then run:

```powershell
python .\apply_0_3_6_patch.py
```

The installer must:

- require `VERSION` 0.3.5 (or report an already-applied exact 0.3.6 payload rather than blindly re-overlaying it);
- verify the release manifest and every payload hash;
- verify baseline hashes for every file it will replace;
- create a timestamped rollback backup before changing source;
- install only manifest-authorized files from `patch_files/`;
- preserve `.env`, OAuth/provider credentials/tokens, local databases, Memory, Voice Profiles, browser state, logs, user data, and `.git`;
- finish with `VERSION` 0.3.6 and the permanent `RELEASE_MANIFEST.json` installed.

If baseline verification fails, stop. Do not force the installer over a modified/unknown source tree.

## Automated validation

Core security/adversarial group:

```powershell
python -m pytest -q tests/test_phase5_adversarial_security.py tests/test_permission_confirmation_security.py tests/test_authenticated_reauth_security.py tests/test_permission_confirmation_api.py tests/test_permission_executor_enforcement.py tests/test_permissions_foundation.py tests/test_permissions_api.py tests/test_browser_confirmation_security.py tests/test_connected_action_confirmation_security.py tests/test_sensitive_data_hygiene.py
```

Release consistency:

```powershell
python -m pytest -q tests/test_release_consistency.py
```

Full Python suite (split into deterministic groups if the environment has a command timeout):

```powershell
python -m pytest -q tests
```

Desktop validation:

```powershell
npm install
npm run desktop:check
npm run desktop:test
```

If exactly four `tests_js/alpha.test.cjs` packaging tests fail only because `@electron/packager/dist/unzip` or `@electron/packager/dist/win32` is unavailable, repair/install the project Node dependencies and rerun. Do not classify any product-behavior failure as a dependency gap.

## Start Jarvis

From a source checkout use the desktop entrypoint only:

```powershell
npm run desktop
```

Electron owns/supervises the local Core. Do **not** start a second `python -m apps.core` process on port 8765 before `npm run desktop`.

## Live acceptance — permissions and confirmation

1. **Version / account gate** — Confirm visible release surfaces show `0.3.6 · Permissions & Security`; sign-in/account continuity must still work.
2. **Permissions workspace** — Open Controls → Permissions & Security. Confirm the permission list loads, descriptions are understandable, and changing a normal configurable preference persists for this device.
3. **Block really blocks** — Set a safe test permission to Block/Deny, attempt its real action, and confirm the underlying executor does not run. Restore the setting afterward using the required security flow.
4. **Protection downgrade authentication** — Make a permission stricter, then attempt to lower protection. Confirm Jarvis requires the purpose-bound authenticated Account flow; simply editing UI/local HTTP state must not lower it.
5. **Confirm once** — Exercise a safe test action configured for Confirm once. Approve it in the trusted desktop prompt, repeat within the same live runtime/session as appropriate, and verify the scoped grant behaves exactly as described. Restart Core/Jarvis and prove the grant is gone.
6. **Confirm every time / Always ask** — With the permission preference set to `Always ask`, exercise an exact consequential test action twice. Each distinct action must require a fresh trusted confirmation unless the user explicitly chooses the prompt's `Always allow` option; replaying an old one-use confirmation must never authorize a second action.
7. **Exact mutation resistance** — Begin a confirmable action, then change its target/body/resource before confirmation. The old challenge must fail and the modified action must require a new review.
8. **Long exact review** — Use a safe test Gmail/Calendar/Browser action with enough content to open the scrollable trusted review. Verify the beginning **and end** of the consequential content are visible before approval and that Cancel performs nothing.
9. **Authenticated confirmation** — Exercise an authenticated-confirmation permission. Confirm browser Account reauthentication is purpose-bound to that exact challenge and cannot be reused for a changed action.
10. **Gmail / Connected Actions** — Create a harmless draft and test the send-confirmation boundary without sending anything unintended. Confirm an affirmative chat phrase alone cannot bypass trusted user presence and that only the exact approved draft sends.
11. **Calendar** — Use a disposable test event. Confirm create/update/delete actions retain exact challenge binding and no modified event executes under an older confirmation.
12. **Browser consequential action** — Use a harmless test page/form or equivalent non-production action. Confirm the trusted prompt shows the exact element/action and Cancel prevents the click/commit.
13. **Memory protection/deletion** — Exercise a disposable memory record. Confirm read/write/delete/protection-change boundaries are distinct and deletion/protection lowering cannot reuse unrelated confirmation.
14. **Voice Profile enrollment/deletion** — Use a disposable voice profile/sample. Confirm consent and trusted permission review occur before biometric processing; changing the sample after confirmation must not reuse the old approval.
15. **Game Mode supremacy** — With Game Mode active/protected, attempt a permissioned browser/computer input path that Game Mode forbids. It must remain blocked even if a prior grant/challenge existed.
16. **Cloud-authority loss** — For a Cloud-authoritative test operation, remove/expire trusted account/Cloud authority after a grant exists. The operation must fail closed; local grant state must not revive Cloud authority.
17. **Restart boundary** — Leave a live pending challenge and, separately, an unused one-use/confirm-once grant. Restart Jarvis/Core. All must require fresh authorization afterward.
18. **Cross-scope isolation** — On another device/account/test tenant if available, confirm a challenge/grant from one security scope cannot be reused in another.

## Live acceptance — sensitive-data hygiene

Use **synthetic disposable values only**, never real credentials or payment data.

19. **Conversation / Memory** — Enter a synthetic password/passphrase, verification code, fake bearer token, and fake payment-card-like test value through safe non-executing test text. Confirm those literal values do not appear in persisted conversation/event data or Memory-derived records.
20. **Diagnostics / logs** — Trigger a safe diagnostic/error path containing synthetic secret-like text. Export/read diagnostics and Core/Electron logs; the literal synthetic secret must be redacted.
21. **Connected Actions pending state** — Create a pending action containing synthetic sensitive text. Confirm durable action state is redacted while the live exact action remains reviewable; restart must expire an unrecoverable sensitive pending transaction rather than reconstructing it from redacted storage.
22. **Task/Cloud Sync hygiene** — Try to save/sync a task whose content contains a synthetic credential/payment value. The content-bearing field must be rejected rather than becoming a covert durable secret store. A benign reminder such as “rotate my API key” must remain allowed.
23. **Legacy cleanup** — On a disposable copy containing synthetic legacy artifacts, run/start 0.3.6 and verify bounded cleanup removes known accidental secret copies while preserving `.env`, OAuth/provider stores, encrypted secret storage, account password hashes, browser state, and protected voice embeddings.

## Regression acceptance

24. Wake with a natural phrase containing “Jarvis,” use follow-ups, sleep, wake again, and verify context continuity.
25. Interrupt Jarvis during speech several times and verify prompt stop/new-turn handling.
26. Exercise one accepted typed/Luna request and one current Web Intelligence request.
27. Exercise one accepted Computer Action, one normal Browser media action, one task/reminder, one Memory workflow, and one Speaker Recognition workflow.
28. Exercise account sign-out/sign-in, Cloud Sync, Billing/entitlement hard stop, and an authorized development top-up/resume test so 0.3.6 security did not bypass 0.3.5 financial authority.

## Failure rules

- A stale/replayed/cross-scope/modified confirmation succeeding is a release blocker.
- A Block/Deny setting that still lets the executor run is a release blocker.
- Game Mode being bypassed by a permission grant is a release blocker.
- Lowering protection without required authentication is a release blocker.
- A real credential/payment literal reaching an accidental persistence sink is a release blocker.
- Do not weaken executor checks, confirmation binding, Cloud authority, or Game Mode merely to make a test pass.

## Before commit after acceptance

After Tanner explicitly accepts the complete live candidate:

```powershell
Remove-Item .\apply_0_3_6_patch.py -Force -ErrorAction SilentlyContinue
Remove-Item .\patch_files -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item .\.patch_backups -Recurse -Force -ErrorAction SilentlyContinue
```

Also remove downloaded patch ZIPs and any temporary loaders/staging kept inside the repository. Keep permanent `0.3.6` source/config/tests/docs/issues/`RELEASE_MANIFEST.json`. Inspect `git status` and the staged diff for secrets/generated files, then make the single focused accepted 0.3.6 commit. **Do not create a Git tag.**

## Live acceptance repair2 — Trusted Security Session

If repair2 is applied, authenticated protection-lowering UX must satisfy both usability and exact-action safety:

- first change after the recent-auth window expires: bound account identifier + password in browser, then exact trusted Jarvis approval;
- additional sensitive changes inside the configured short window: no browser/password round-trip, but each receives its own exact trusted Jarvis approval;
- cancel leaves the preference unchanged;
- Core restart/logout clears the recent-auth window;
- recent-auth never replaces challenge/action fingerprinting, executor grant consumption, Cloud authority, Game Mode, or native attestation.

See `docs/TESTING_GUIDE_0.3.6-repair2.md` and ISSUE-324.

## 0.3.6-repair3 — Reauth Handoff live check

After repair3, a successful external-browser security reauthentication should attempt to close its own tab and return focus to Jarvis. Browser security policy may refuse script-closing of an externally opened tab; in that case the verified page must remain harmless and show the manual-close fallback. The browser page must never close before successful password proof and browser completion must never replace the exact trusted Jarvis confirmation. Source/development test environments can install the declared async test tools with `python -m pip install -e ".[test]"`.

## 0.3.6-repair4 — Clean Reauth Completion live check

After repair4, successful browser reauthentication still makes the repair3 best-effort standards-based close attempt. If browser policy keeps the tab open, the page must remain a calm successful completion state and tell the user: **"Authentication approved. You may now safely close this browser tab and return to Jarvis."** Do not show browser-policy diagnostics as an error, and do not weaken the exact trusted desktop confirmation that follows identity proof.

## 0.3.6-repair5 — Trusted Executor Confirmation live check

After repair5, Browser/Computer permissions set to **Always ask** must resolve through Jarvis's trusted native exact-action confirmation rather than an ordinary conversational `Yes` turn. Cancelling the native prompt must terminate the request without browser execution, app-launch fallthrough, Luna planning, or another capability attempt. Repeating the request must create a fresh confirmation; approving must execute exactly once, and another request under Always ask must prompt again. The trusted prompt must use natural executor-owned wording such as **"Allow Jarvis to open a new browser tab?"**. Voice challenge authority follows the live `session_speaker_id` lane: temporary display uncertainty may not broaden scope, and a different speaker lane must fail closed. See `docs/TESTING_GUIDE_0.3.6-repair5.md` and ISSUE-328.

## 0.3.6-repair6 — Steam Isolation automated check

After repair6, the synthetic Steam manifest regression must be host-independent even on a Windows developer PC with a real Steam library. Run `python -m pytest -q tests/test_computer_apps.py::test_steam_manifest_becomes_reliable_uri_launch_target` first, then rerun the full Repair5 Python regression command before `desktop:check` and `desktop:test`. Repair6 must not modify production Steam discovery; `HKCU\Software\Valve\Steam` remains a valid real Jarvis discovery source. See `docs/TESTING_GUIDE_0.3.6-repair6.md` and ISSUE-329.


## Repair7 — Friendly Confirmation

After applying `0.3.6-repair7`, rerun the automated permission/browser/computer suites, `desktop:check`, and `desktop:test`. Then restart Live Batch 2 from the Browser Control `Always ask` case.

The native prompt should be short natural consumer copy such as `Permission required. Allow Jarvis to open a new browser tab?`. It must not dump executor tokens, JSON, raw argument blocks, or permission keys. When the prompt appears, Jarvis must become the foreground owner rather than File Explorer or another unrelated application. Cancel remains terminal. Allow remains one-use: repeating the identical action must produce a fresh prompt.

## Repair8 live check — explicit URL/domain ownership

After applying `0.3.6-repair8`, verify `Open YouTube.com in a new tab` and `Open example.com in a new tab` route to Browser Control rather than Computer Actions. Test once with Browser Control Allowed and again with Always ask. In Always ask, Allow must execute only the exact destination once; Cancel must be terminal. Also confirm ordinary app launches such as `Open Discord` still use Computer Actions. See `docs/TESTING_GUIDE_0.3.6-repair8.md`.

## 0.3.6-repair9 live continuation — Trusted Interaction

After Repair8 URL routing passes, verify the trusted native prompt is also a conversation-isolation boundary. With a harmless Gmail send awaiting permission, spoken `Yes`, `Allow it`, `Go ahead`, unrelated speech, and target-changing commands must not appear as normal turns, receive conversational responses, execute, or queue behind the prompt. A clear denial such as `Cancel it`, `Never mind`, `Stop`, or `Don't send it` may close the exact active native prompt as Cancel; it must never produce an approval attestation or send the email.

Then verify the clipped result footer `Answer continues — Open fullscreen` is itself clickable and opens the shared fullscreen reader. Structured Gmail, Calendar, Tasks, email-read, and Web Intelligence cards must retain a working Fullscreen affordance even when generic height heuristics would not otherwise require it. Continue using only harmless test content until the exact review/cancel/allow boundary is fully accepted.

## Repair10 — Regression Alignment

Repair10 is a test-tooling alignment patch over the exact Repair9 live candidate. It must not change production runtime files.

Run:

```powershell
node --test --test-reporter=tap .\tests_js\realtime_interruption_sync.test.cjs .\tests_js\account_foundation.test.cjs
npm run desktop:check
npm run desktop:test 2>&1 | Tee-Object .\repair10_desktop_test.log
```

Expected: the three stale Repair9 source-contract failures are gone and the full Electron suite is green. Then resume the Repair9 trusted-interaction live checks for spoken approval quarantine, denial-only vocal cancellation, and working structured-card Fullscreen.


## Repair11 live checks — Conversation Continuity

- `Draft an email to Tanner.` -> `Say hi.` must continue even if the short reply is temporarily `Unknown speaker`.
- A different positively recognized speaker must not inherit the action session.
- Unknown speech must not confirm/execute an attributed owner's pending action.
- While a trusted permission dialog is open, all voice is inert; only on-screen Allow/Cancel may decide.
- Recheck both email-card Fullscreen controls.


## Repair12 acceptance additions

Verify permission labels (Default / Always allow / Always ask / Block), routine Default automation, protected dangerous actions, silent trusted-modal cancellation, Unknown-speaker Yes/No continuity into trusted review, two deliberate identical voice turns both being processed, and no stuck Thinking state.


## Repair13 — Action Context & False VAD Stability

- Re-test `Draft an email to Tanner` → `Say hi` → `Yes`, including a transient `Unknown speaker` label on the short reply. The same draft session must survive and reach trusted review.
- Re-test `No` on the pending draft; it must remain unsent without original-speaker/context errors.
- While Jarvis is speaking, allow normal microphone/room noise: short false VAD starts must not interrupt or strand Thinking.
- Then deliberately barge in and verify interruption still works promptly.
- Reconfirm trusted permission prompts remain voice-inert.

## Repair14 live acceptance additions — Single Confirmation & VAD Recovery

- Under `Default`, test an exact Gmail draft: Jarvis's `Would you like me to send it?` + user `Yes` is the single confirmation; no second permission popup may appear.
- Set Gmail send to `Always ask`, approve the next native prompt with **Always allow**, then verify the saved permission becomes `Always allow` and future sends no longer show the permission popup unless the setting is changed again.
- Verify a destructive/system-sensitive non-persistable capability shows **Allow once** or a stronger boundary and never becomes permanently allowed from its prompt.
- Verify permission persistence is trusted-main/Core-derived; renderer code must not send or control a persistence-upgrade header.
- Exercise microphone/background noise, including a transcript-less VAD turn long enough to survive the short debounce. Jarvis must recover automatically and must not remain stuck in Thinking. Deliberate transcript-backed barge-in must still work.


## Repair15 — Calendar single-confirmation acceptance

After applying `0.3.6-repair15`, set Calendar permissions to **Default**, create a disposable event, ask Jarvis to delete/cancel that exact event, and answer `Yes` to Jarvis's exact natural review. The event must be deleted exactly once with **no second native permission popup**. Then set Calendar delete to **Always ask** and repeat: the trusted native prompt must appear and its positive action must be **Allow once**, never **Always allow**. Finally verify Block prevents deletion and Calendar create/update still keep their accepted single-confirmation behavior. See `docs/TESTING_GUIDE_0.3.6-repair15.md` and ISSUE-340.

## Repair16 live acceptance — Permission & Action Confirmation Separation

After Repair15 Calendar Default deletion passes, apply Repair16 over the exact Repair15 candidate and validate the general permission-choice model.

- Under **Always ask**, a persistable permission prompt must offer **Cancel / Allow once / Always allow**.
- **Allow once** must execute only the exact current action and leave the permission on Always ask; a later matching action must prompt again.
- **Always allow** must persist capability permission and suppress later native permission popups, while consequential Connected Actions still require Jarvis's separate exact conversational review before provider execution.
- **Cancel** must be terminal and must not change the saved preference.
- **Block** remains terminal and non-persistable/authenticated/restricted/forbidden/system-safety permissions must not expose Always allow.
- Repeat the separation with Calendar deletion and Gmail send, then regress a routine Browser permission to verify ordinary Always allow remains hands-off.

See `docs/TESTING_GUIDE_0.3.6-repair16.md` and ISSUE-341 for the exact sequence and security invariant.

## Repair17 live acceptance — Blocked Action Preflight & Error Fidelity

Set Calendar Actions to `Block` and request `Create an event tomorrow at 5 PM called Blocked Calendar Test.` Jarvis must stop immediately with the Permissions & Security blocked message, ask no duration question, show no native permission prompt, and perform no Calendar write. Also verify an already-reviewed pending action becomes terminal if the permission is changed to Block before confirmation. See `docs/TESTING_GUIDE_0.3.6-repair17.md` and ISSUE-342.
