# Testing Guide — 0.0.7 Sleep Local Playback Repair

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Start Jarvis with `npm run desktop`.
2. Wake Jarvis and ask one short question.
3. Say **“That's all, Jarvis.”**
4. Confirm Cedar audibly completes **“Of course, sir.”** before the interface changes to Sleeping.
5. Repeat with **“Go back to sleep, Jarvis.”** and **“Thanks, that's everything.”**
6. Repeat at least five full wake/sleep cycles.
7. Confirm the terminal does not show repeated `listening -> waking` warnings during the sign-off.
8. Confirm no new Realtime call begins until the prior sign-off and shutdown have completed.
9. Confirm Jarvis can wake normally immediately after the sign-off completes.

## Expected diagnostics

A correct sequence should include safe events similar to:

```text
sleep.acknowledgement.response_created
sleep.acknowledgement.buffer_stopped — awaiting local playback
sleep.acknowledgement.audio_started
sleep.acknowledgement.complete — ...local_playback_settled
```

The interface must remain Speaking while Cedar is audible, even if the provider buffer-stop event has already arrived.
