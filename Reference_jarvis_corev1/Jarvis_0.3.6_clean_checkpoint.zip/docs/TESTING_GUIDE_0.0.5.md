# Testing Guide — 0.0.5 Electron Shell

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Desktop launch

```powershell
npm run desktop
```

Confirm that Jarvis opens in a standalone window without opening a browser tab and that the Python core starts automatically.

## Manual acceptance

1. Launch Jarvis through Electron.
2. Confirm only one Jarvis instance can run.
3. Confirm the existing simulation and live modes work.
4. Close the window and confirm Jarvis remains available in the tray.
5. Restore the window from the tray.
6. Use tray Wake and Sleep.
7. Restart the core from the tray and confirm the interface reconnects.
8. Say “That’s all, Jarvis” during a natural conversation and confirm the paid Realtime session closes.
9. Repeat with “Go to sleep, Jarvis.”
10. Relaunch and confirm the window position and size are restored.
11. Ask Jarvis for the current date and time and confirm the local answer is correct.
12. Quit from the tray and confirm no Electron or Jarvis Python process remains.

## Packaging foundation

```powershell
npm run desktop:package
npm run desktop:make
```

The first packaged launch may create a private Python environment and install the core dependencies. Code signing and production installer polish remain future work.
