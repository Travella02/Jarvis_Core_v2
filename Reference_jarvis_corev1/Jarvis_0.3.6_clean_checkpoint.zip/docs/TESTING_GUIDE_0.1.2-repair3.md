# Testing Guide — 0.1.2-repair3 Deterministic Memory Navigation & Response Caps

## Start

Close Jarvis, extract the ZIP directly into the project root, then run:

```powershell
py -3.12 apply_0_1_2_repair3_patch.py
npm run desktop
```

A Windows reinstall is not required for development acceptance.

## Memory navigation acceptance

1. Start on Home and say: “Jarvis, show me everything about ORVEX.”
   - The interface must switch to Memory immediately, before or while Jarvis begins speaking.
   - The ORVEX entity page should open when the entity exists.
   - Jarvis should provide a brief acknowledgement or summary.
2. Say: “Show me everything about Orvix.”
   - The existing ORVEX entity should resolve when it is the clear close match.
3. Type: “Open my memories.”
   - Memory Explorer should open without a false subject filter.
4. Say: “Show me what I told you yesterday.”
   - Memory should open to a filtered timeline.
5. Ask: “What do you know about ORVEX?”
   - Jarvis should answer verbally without forcing a workspace change.
6. Confirm the visual request appears once in chat and no empty Jarvis bubble appears.
7. Confirm Jarvis never says the Memory Explorer is still loading or that he lacks a database merely because the local UI owns the display action.

## Response profile acceptance

Open Controls and confirm the options are Test, Short, Normal, High, and Full.

- Test: one sentence, no more than 25 words.
- Short: no more than three sentences and 50 words.
- Normal: adapts to the question, prefers lower cost, and stays within 100 words.
- High: answers in detail and stays within 200 words.
- Full: has no configured sentence or word cap.

Sleep and wake Jarvis after changing modes because the profile is fixed when a Realtime session begins.

Then test the explicit exception: select Short and ask for a 500-word story. Jarvis may exceed the Short default because the longer output was explicitly requested, and the answer should finish naturally.

## Custom `.env` test

The patch preserves the private `.env`. Copy only settings you want to customize from `.env.example`, for example:

```text
JARVIS_RESPONSE_NORMAL_MAX_SENTENCES=0
JARVIS_RESPONSE_NORMAL_MAX_WORDS=90
JARVIS_RESPONSE_NORMAL_MAX_OUTPUT_TOKENS=0
```

Use whole numbers. `0` means no fixed cap for that setting. Restart Jarvis after editing `.env`.

## Regression checks

- Ordinary typed and voice messages render once.
- Wake request preservation, interruption, sleep, timers, and cost accounting remain functional.
- Memory capture, search, timeline, entity pages, provenance, corrections, deletion, undo, summaries, and exports still work.
- Close and reopen Jarvis; local memories and private configuration remain available.
