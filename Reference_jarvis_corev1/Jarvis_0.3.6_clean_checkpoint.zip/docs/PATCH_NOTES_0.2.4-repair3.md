# 0.2.4-repair3 — Contextual Intelligence

This repair turns Tasks & Reminders from an isolated list into a grounded conversational work surface. Jarvis can now connect an active task to durable memory, reason about what the work actually involves, preserve the current project across natural follow-ups, and keep voice concise without making the underlying reasoning shallow.

## What changed

- Added an actor/tenant-scoped short-term working-memory frame separate from durable memory.
- The frame persists the active task records, resolved memory subject/entity, focus terms, ordered workstreams, safe state summary, and prior contextual answer.
- Working context survives Realtime sleep/reconnect and is hydrated by the desktop after restart when it is still recent.
- Added a dedicated Luna contextual-reasoning path for task/project questions such as “What does that involve?”, “What should I do first?”, “break that down,” and natural follow-ups such as “What about deployment?”
- Contextual reasoning receives authoritative task records, query-specific durable memory, recent conversation, and the current working frame in one request.
- Remembered facts and model-inferred plans are explicitly separated: Jarvis may propose professional next steps but may not present them as prior user decisions or completed work.
- Ordered `focus_items` allow phrases such as “the first one,” “the second option,” and “after that” to retain a stable referent.
- `focus_terms` let topic-linked dialogue continue naturally without routing every unrelated conversation into Tasks.
- “Can you show me?” after a grounded task is now a deterministic visual action that reuses the exact task record and does not require another Luna call.
- Normal simple task answers remain voice-first. Explicit show/display requests render cards.
- Short/Test response modes limit spoken length only; they do not reduce reasoning depth or the richer on-screen contextual answer.
- The general memory/detailed-answer endpoints now receive the same working-task context as a fallback, preventing ordinary Realtime from falsely claiming it does not know the active task.

## Safety and truthfulness

- Durable memory remains the authority for remembered user/project facts.
- Task records remain the authority for task state, due dates, reminders, priority, and completion.
- Proposed plans are not written into durable memory as facts merely because Luna suggested them.
- Working context is local, tenant/actor scoped, expiring, and stored separately from durable memory.
- A completely different task resets inherited focus workstreams so projects do not contaminate each other.
- Existing Gmail, Calendar, task/reminder data, OAuth credentials, and `.env` are not migrated or replaced.
