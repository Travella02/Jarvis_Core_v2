# 0.3.5-repair5 — Native YouTube Control

**Date:** 2026-09-01  
**Required installed release:** 0.3.5-repair4  
**Version remains:** 0.3.5

## Purpose

Repair two Browser Control findings from live acceptance: natural partial YouTube titles could collapse into generic media resume and time out, while DOM-emulated fullscreen remained unreliable in Edge even after the updated Browser Bridge was explicitly reloaded.

## What changed

- Natural `play/open/click <title>` requests now reach the grounded named-result matcher before broad contextual media normalization.
- YouTube result matching accepts confident partial/closest title matches such as `Play Sidemen Sleepover.` -> `SIDEMEN SLEEPOVER (USA EDITION)` without requiring the complete title.
- YouTube play-result activation uses the grounded visible `/watch?...` URL directly instead of a synthetic DOM click.
- Voice-driven YouTube fullscreen no longer relies on the repair3/repair4 DOM-isolation fallback as its normal execution path.
- Added a Windows-only native fullscreen executor that can send **only YouTube's `F` shortcut**, after exact browser focus and Game Mode authorization checks.
- Browser focus identity and Game Mode authorization are rechecked immediately before `SendInput`; a focus race fails closed.
- Native fullscreen is unavailable while Game Mode is active, while Game Mode is arming, when the safety layer is unavailable/disabled, or when Game Mode authority is stale.
- Browser Bridge prepares the real YouTube player and verifies the actual fullscreen state after the native shortcut.
- Game Mode UI/spoken feedback explicitly tells users that native/synthetic browser shortcuts such as voice-triggered fullscreen are unavailable while a game is protected, while structural controls remain available.
- General mouse/keyboard automation remains disabled. No injection, hooks, process-memory access, or game-targeted input was added.

## Competitive-game safety

The fullscreen exception is intentionally narrower than normal Computer Actions. It is blocked for the entire duration of an active/pending Game Mode session, not merely when the protected game owns foreground focus. If the safety gate cannot prove it is safe, fullscreen does not dispatch input.

Anti-cheat presence by itself still cannot activate Game Mode, preserving the existing Snipping Tool/browser false-positive protections.

## Security / authority impact

No Billing, entitlement, provider, payment, OAuth, account, Cloud Sync, or Realtime authority boundary is moved client-side. This repair changes local Browser Control routing and introduces one tightly bounded Game Mode-gated Windows browser shortcut.

## Compatibility / migration

No data migration. Apply only over the tested 0.3.5-repair4 candidate. User data, `.env`, Billing/Cloud databases, OAuth/provider tokens, memory, voice profiles, browser state, and Git history remain untouched.

Because Browser Bridge files changed, reload the unpacked Jarvis Browser Bridge extension once after applying repair5 and open a fresh YouTube tab before live testing.

## Rollback

The installer creates timestamped backups under `.patch_backups/0.3.5-repair5_*`. Do not manually clean patch/backups until 0.3.5 is accepted.
