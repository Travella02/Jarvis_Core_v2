# 0.2.2-repair1 — Gmail Polish

This live-acceptance repair keeps the speed improvements from 0.2.2 while fixing the two remaining Gmail interaction gaps found in live testing.

## Natural send confirmation survives transcription noise

A confirmation such as:

> “Perfect, thanks, Jarvis. Go ahead and send it.”

now executes the already-reviewed pending draft even if speech recognition misheard or imperfectly transcribes the assistant vocative before the explicit send command.

The safety boundary remains strict:

- there still must be an explicit send/confirm decision;
- conversational praise by itself never sends;
- negative or uncertain language such as “I don’t think you should send it” never becomes approval;
- the exact pending provider draft is still the only draft executed.

## Read Gmail now looks like Gmail

`gmail_search` and `gmail_read_thread` results now receive structured read-only email presentations instead of plain-text metadata.

Each email card can show:

- From
- To
- Subject
- Date / unread state
- Message content (full body for thread reads; Gmail snippet for search-list results)

Multiple results are displayed as a stack of email cards. Fullscreen preserves the same structured presentation.

## Singular email requests retrieve full content

When the user explicitly asks to show/open/read/view one specific email, Jarvis upgrades a metadata search plan to `gmail_read_thread` locally. This prevents requests such as “show me the email from Google Cloud” from stopping at metadata/snippet when the full thread body is available.

Multi-message search/summarization still uses the fast concurrent metadata path from 0.2.2.

## Architecture

Realtime remains the speech renderer. Luna remains the planner/reasoner for Connected Actions. The new confirmation recovery is deterministic and bounded to explicit pending-action decisions, while Gmail card rendering is purely a presentation-layer improvement over provider-grounded data.
