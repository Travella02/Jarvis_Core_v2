# 0.1.4-repair4 — Authoritative Corrections & Auto Refresh

This repair makes proactive commitments converge on one current corrected record and moves normal refresh ownership into the local Jarvis core.

## Fixed

- “I actually meant Brock” now targets the specific recent Rock commitment and its immutable source event.
- Correction rules carry target item and source-event lineage rather than applying broad text replacement.
- The current proactive item changes to Brock while the original Rock statement and later correction remain exact evidence.
- Legacy malformed values such as `follow up with meant Austin tomorrow` are canonicalized.
- Clean and malformed variants merge into one item; stale rows are marked superseded instead of remaining open.
- Superseded correction tombstones cannot be reopened by later candidate regeneration.
- Repeated refreshes and restarts remain idempotent.

## Automatic proactive refresh

- User-authored memory events now signal the backend proactive loop immediately.
- A configurable debounce coalesces one spoken turn without losing a later correction.
- The periodic refresh remains as a fallback.
- The renderer reloads the resulting state and no longer owns automatic analysis.
- The manual **Refresh locally** button remains available for diagnostics and recovery, but is not required for normal use.

## Configuration

```text
JARVIS_MEMORY_PROACTIVE_EVENT_DEBOUNCE_MS=700
```

The accepted range is 100–10,000 milliseconds.

## Safety

- Original memory events remain immutable.
- Corrections alter only derived proactive state and evidence relationships.
- No external actions are granted or performed.
