# 0.0.9 — Interface Layout

## Summary

This release refines the first product-facing interface into a more practical daily desktop layout. The Home workspace now gives the conversation more room by default, supports user-selectable panel proportions, improves transcript scrolling, and turns the Controls workspace into compact purpose-built modules without changing the proven voice lifecycle.

## Added

- Persisted **Conversation**, **Balanced**, and **Presence** Home layout modes.
- Collapsible navigation rail with persisted state.
- Smart transcript following that respects manual scroll position.
- A **Jump to latest** control when new content arrives while the user is reading older messages.
- Multi-line typed composer with Enter-to-send and Shift+Enter-for-new-line behavior.
- Keyboard workspace shortcuts: Ctrl+1 through Ctrl+4.
- Conversation Focus shortcut: Ctrl+Shift+F.
- Responsive panel proportions across desktop, laptop, narrow, and compact widths.

## Changed

- Conversation-first is now the default Home layout.
- The Home orb panel is more compact while retaining all quick controls and mirrored authoritative metrics.
- Controls are separated into Session, Audio, and Lifecycle modules.
- Insights and System use clearer module headings and denser metric grids.
- The transcript composer remains anchored while the message history scrolls independently.
- Existing orb presentation hysteresis and gradual state transitions remain unchanged.

## Preserved contracts

- All established operational element IDs remain available.
- Wake, interruption, typed parity, silent model-confirmed sleep, simulation, cost controls, and Desktop Presence use the same underlying event paths.
- `.env`, API-key isolation, and local ownership are unchanged.
