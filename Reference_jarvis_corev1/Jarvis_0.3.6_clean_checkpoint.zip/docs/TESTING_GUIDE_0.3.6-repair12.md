# 0.3.6-repair12 — Live Testing

1. Open **Controls → Permissions & Security** and verify the selector labels read **Default**, **Always allow**, **Always ask**, and **Block** where applicable.
2. Leave Browser navigation on **Default** and verify a routine request such as opening a new tab runs without a permission prompt.
3. Verify a dangerous/consequential action such as sending an email still reaches the trusted permission prompt. Cancel it and confirm Jarvis does not say “Okay, I won’t do that.”
4. Say **“Draft an email to Tanner.”** then **“Say hi.”** If the second phrase is temporarily labeled Unknown speaker, the draft must still complete.
5. At the send decision, let **“Yes.”** be labeled Unknown speaker. Jarvis must continue to the trusted permission review instead of saying it needs the original speaker. The trusted Allow button remains the only authorization.
6. Repeat **“Say hi” twice** as two distinct microphone turns. Both turns must be captured/handled; the second must not disappear and Jarvis must not remain stuck in Thinking.
7. Confirm a positively recognized different speaker still cannot silently inherit another recognized speaker’s action context.
8. Rerun desktop:check, desktop:test, and the 0.3.6 Python regression group before acceptance.
