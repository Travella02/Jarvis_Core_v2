# Testing Guide — 0.2.3-repair6 Calendar Continuity

## One-time Google permission
After installing, open:

`Controls → Connected apps`

If the button says **Enable Calendar Timezone**, click it and approve Google once. This adds only the read-only Calendar settings permission; the existing client ID and secret do not change.

## Test 1 — local timezone must match Google Calendar
Say:

`Can you schedule a meeting with Tanner for tomorrow at 3 PM?`

Expected:
- Jarvis says 3 PM, not 9 PM.
- The Calendar card shows 3:00 PM in the timezone used by the Google Calendar UI.
- The date is the correct local tomorrow.
- After confirmation, Google Calendar shows the same 3 PM.

Confirm with:

`Yes, go ahead and add it.`

## Test 2 — natural pause / split request
Speak this naturally with a noticeable pause after `for`:

`Can you schedule a meeting with Tanner for...`

Then continue:

`Tomorrow at 3 PM, please.`

Expected:
- Jarvis does not claim he cannot schedule Calendar events.
- The stale clarification from the partial phrase is suppressed if the continuation arrives while it is still planning.
- Connected Actions combines the conversational context and prepares one Calendar proposal.
- The proposal uses the correct local 3 PM.

## Test 3 — duration regression
With the event present, ask to change its duration and confirm once.

Expected:
- Spoken duration matches the proposal card.
- Google Calendar receives the same duration after confirmation.

## Test 4 — attendee regression
Say:

`Can you add Austin to that meeting tomorrow?`

Expected:
- The exact meeting stays grounded.
- Existing attendees remain present.
- Austin is added after contact resolution.
- One confirmation applies the update.
