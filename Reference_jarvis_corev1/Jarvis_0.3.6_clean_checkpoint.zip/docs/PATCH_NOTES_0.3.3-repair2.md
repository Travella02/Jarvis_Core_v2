# 0.3.3-repair2 — Natural Media Grounding

This repair keeps the product version at **0.3.3 — Runtime Reliability** while tightening Browser Control after live acceptance exposed incorrect pause-state claims and unwanted scrolling.

## What changed

- Natural media language is normalized by intent rather than requiring exact phrases. Polite wrappers such as “can you…”, “would you mind…”, “for me”, and trailing “please” no longer push simple playback commands into Luna planning.
- Common pause/resume variants use the deterministic structural `media_control` path and do not scroll or click page controls.
- Recent media context supports pronoun forms such as “pause this” and “resume it” without losing the grounded YouTube tab.
- Luna remains available for novel wording, but its Browser Planner now has dedicated `media_*` operations and is forbidden from substituting click/scroll for a recognized media-control goal.
- Browser snapshots expose structural HTML media state. A planner cannot claim “already paused” or another playback state unless that state is actually observed or a media action is verified by the bridge.
- Planner-originated media operations now use the same post-action `verified=true` requirement as deterministic media controls.

## Versioning

The Jarvis product version remains **0.3.3**. `repair2` is only the unaccepted repair label.

The repair2 installer is cumulative: it accepts either the original 0.3.3 Runtime Reliability candidate or the known 0.3.3-repair1 candidate, then installs the same final repair2 source. This keeps cross-device live testing safe without weakening source-edit protection.
