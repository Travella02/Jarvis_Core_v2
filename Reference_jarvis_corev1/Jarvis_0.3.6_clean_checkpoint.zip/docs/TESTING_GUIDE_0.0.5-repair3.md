# Testing Guide — 0.0.5 Electron Shell Repair 3

## Install

```powershell
py -3.12 apply_0_0_5_repair3_patch.py
```

## Automated checks

The installer runs the complete unit suite, JavaScript syntax checks, the doctor, the safe diagnostic, runtime staging, and environment validation.

Manual verification after installation:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
npm run desktop
```

## Time-context check

Ask Jarvis for the current local date and time. Confirm the answer matches the computer's timezone and does not use the UTC calendar date when local time is still on the prior day.
