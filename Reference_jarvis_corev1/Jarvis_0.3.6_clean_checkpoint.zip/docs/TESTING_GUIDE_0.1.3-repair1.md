# Testing Guide — 0.1.3-repair1 Source-Aware Consolidation

## Automated validation

- 207 passing Python tests
- 41 passing Node tests
- Electron/renderer syntax checks
- Doctor and core diagnostics
- Desktop runtime staging
- Fresh patch installation and safe reapplication
- Private `.env` preservation

## Manual acceptance

1. Start Jarvis with `npm run desktop`.
2. Open Memory and add or say:
   - `I created a new business called ORVEX.`
   - `My goal is to grow Orvex into a major esports company.`
   - `We decided to register Orbex as an LLC.`
   - `We need to file the Orvix trademark.`
3. Let Jarvis respond normally so assistant mentions also exist.
4. Open **Memory → Consolidation** and select **Consolidate now**.
5. Open the ORVEX entity.
6. Confirm Key facts, Goals, Decisions, and Open items contain the four source-backed records.
7. Confirm **Source timeline** contains the user's statements.
8. Confirm **Jarvis conversation mentions** contains Jarvis replies separately.
9. Restart Jarvis and confirm the repaired profile remains.

Existing databases do not require the statements to be entered again. The next consolidation run reprocesses the preserved ledger.
