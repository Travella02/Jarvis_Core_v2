# Testing Guide — 0.2.3-repair13

## Primary acceptance flow

1. Make sure the connected Gmail account has exactly one unread inbox message.
2. Ask: **“Do I have any unread emails?”**
3. Jarvis should report the one message directly. He should not say **“I’d start with…”** when there is only one choice.
4. Ask: **“Can you mark that as read, please?”**
5. Jarvis should mark that exact message as read and give one short Connected Actions response.
6. Ask again: **“Do I have any unread emails?”**
7. The message should no longer be counted as unread.

## Regression checks

- There should be no spoken Realtime answer claiming Jarvis cannot mark email as read.
- There should not be two competing spoken answers.
- Requests such as **“mark those all as read”** after a bounded unread overview should continue to mark only the recently selected messages.
- Calendar behavior from 0.2.3-repair12 should remain unchanged.
