# 0.2.9 — Natural Interruption Testing Guide

Do not commit the release as accepted until the live barge-in tests below pass.

## Test 1 — ordinary conversation barge-in

1. Wake Jarvis.
2. Ask a question that produces several seconds of speech, for example: `Explain what Game Mode does and why it is useful.`
3. After Jarvis has been speaking for about one second, talk over him with: `Actually, what time is it?`

Expected:

- Jarvis stops the first reply promptly.
- The user's interruption appears as one normal transcript turn.
- Jarvis answers the time question.
- The old Game Mode explanation does not resume later.

## Test 2 — repeated interruption

1. Ask Jarvis another question that produces a longer spoken answer.
2. Interrupt with a new question.
3. While Jarvis answers the new question, interrupt again with a third question.

Expected:

- Each new speech turn supersedes the previous turn.
- No old reply restarts after a later turn begins.
- The orb returns to Listening as soon as the interruption starts and then follows the normal Listening → Thinking → Speaking lifecycle.

## Test 3 — Computer Actions after interruption

1. Start a normal conversational answer.
2. Interrupt while Jarvis is speaking with: `Open Snipping Tool.`
3. After it opens, say: `Close Snipping Tool.`

Expected:

- Jarvis stops the conversational reply.
- Snipping Tool opens/closes normally.
- No stale conversational speech plays after the action.

## Test 4 — Game Mode regression

1. Open Rocket League and confirm `GAME MODE · Rocket League` appears.
2. Ask Jarvis a normal question and interrupt him while he is speaking.
3. Open and close Snipping Tool while Rocket League remains open.
4. Close Rocket League.

Expected:

- Natural interruption works exactly as it does outside Game Mode.
- Game Mode remains active while Rocket League is running.
- Safe Computer Actions remain available.
- Game Mode clears after Rocket League closes.
