# 0.2.4-repair4 — Task Follow-up Grounding

This repair closes a conversational continuity gap found after Contextual Intelligence began switching cleanly between different tasks. Jarvis could correctly focus a new reminder task and still lose its structured schedule when the user followed with a very short question such as “What time?”.

## What changed

- Added a dedicated task-attribute follow-up grammar for natural questions such as:
  - “What time?”
  - “When?”
  - “What day?” / “What date?”
  - “When will you remind me?”
  - “When is it due?”
  - “What priority?”
  - “Is there a reminder set?”
- The desktop now keeps those terse follow-ups inside Connected Actions whenever there is recent grounded task focus.
- The backend resolves the question directly against the current actor-scoped task records instead of asking Realtime or rerunning Luna planning.
- Reminder-only tasks are treated as scheduled work. A reminder at 2 PM is no longer mistaken for an unscheduled task merely because `due_at` is empty.
- Task timestamps are converted from their stored UTC instant into the task/user timezone before Jarvis speaks them.
- Relative date wording is humanized (`today`, `tomorrow`, otherwise weekday/date).
- If both a due time and reminder time exist and differ, Jarvis reports both rather than collapsing them into one timestamp.
- If the user explicitly asks about the reminder, Jarvis answers from `reminder_at`; if they ask what is due, Jarvis answers from `due_at` and can mention a reminder separately when useful.
- If a task truly has no due/reminder time, Jarvis says so directly instead of inventing a schedule.
- Working-context rendering now recognizes time/date/due/priority questions as relevant to the active task.
- The rule stays narrow: “What time is it?” remains an ordinary clock question rather than being hijacked by stale task context.

## Why this matters

A human assistant does not require the user to repeat “What time is the reminder for the task you just mentioned?”. Once the subject is grounded, “What time?” should be enough. This repair makes the structured task record—not generic model recollection—the authority for that kind of conversational shorthand.

## Data and safety

- No schema migration is required.
- Existing tasks/reminders are preserved.
- Existing working memory is preserved.
- No Google permissions or reconnect are required.
- `.env`, OAuth tokens, memory databases, and task databases are not included in the repair payload.
