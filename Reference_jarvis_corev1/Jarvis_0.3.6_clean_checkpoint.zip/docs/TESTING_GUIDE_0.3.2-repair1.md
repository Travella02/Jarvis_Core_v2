# Testing Guide — 0.3.2-repair1 Windows Checkpoint Verification

The application/release version under test remains `0.3.2`.

## Installer

1. Start from accepted Git commit `0e987e8` with no tracked changes. Untracked patch-delivery files are allowed.
2. Extract the repair ZIP into the Jarvis project root.
3. Run `py -3.12 .\apply_0_3_2_account_foundation_repair1_patch.py`.
4. Verify the installer reports the accepted 0.3.1 checkpoint and applies 0.3.2 successfully instead of flagging clean Windows line endings as edits.
5. Verify `.env`, `data/`, credentials, caches, and other local runtime state were not changed.

## Automated regression

Run:

- `py -3.12 -m pytest -q`
- `npm run desktop:check`
- `node --check extensions/jarvis_browser_bridge/service_worker.js`
- `node --check extensions/jarvis_browser_bridge/content.js`
- `npm run desktop:test`

## Live Account Foundation acceptance

1. Launch Jarvis.
2. Create an account and confirm account, tenant, device, and installation identities are shown.
3. Confirm the session survives normal local requests/reloads.
4. Sign out and sign back in to the same account.
5. Confirm a wrong password is rejected.
6. Confirm an attempt to bind the existing installation data namespace to a different account is blocked.
7. Confirm existing Browser Control and normal Jarvis behavior remain intact.

Do not commit until automated tests and live acceptance pass. After acceptance, remove the installer and payload directory, inspect `git status --short`, then commit the 0.3.2 source.
