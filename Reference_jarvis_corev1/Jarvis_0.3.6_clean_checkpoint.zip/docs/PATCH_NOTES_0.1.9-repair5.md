# 0.1.9-repair5 — Fact-First Recall

This narrow live-acceptance repair keeps provenance internal during ordinary recall and exposes it only when the user asks for the source or history.

## Changes

- Ordinary memory answers receive clean current facts without timestamps, source medium, confidence, or evidence labels.
- Jarvis no longer volunteers phrases such as “based on your voice note from…” during a normal recall question.
- Explicit questions such as “How do you know that?”, “When did I tell you?”, and history requests still receive grounded provenance.
- If recall depends on an exact remembered statement rather than a structured fact, the context includes the statement text without audit metadata.
- Realtime and detailed-text prompts explicitly reserve source, date, medium, confidence, and evidence lineage for source/history requests.

## Safety

- No memories, facts, entities, relationships, timestamps, or source events are removed.
- Provenance remains fully available in Memory Explorer and for explicit source questions.
- Context resolution, lifecycle filtering, ambiguity handling, Fullscreen gating, and response-mode behavior are unchanged.
