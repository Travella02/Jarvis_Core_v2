# 0.1.2-repair5 — Silent Visual Commands

Display-only memory commands now behave as interface actions rather than conversational prompts.

## Changes

- `Show`, `open`, `display`, `pull up`, and equivalent memory commands open Memory Explorer without a spoken or text response.
- Narration still occurs when the user explicitly asks for it, including phrases such as `give me a short summary`, `tell me about it`, `explain it`, or `show me and tell me about ...`.
- Typed and wake-preserved display-only commands stay entirely local and do not create a Realtime response.
- Live voice commands arm suppression from partial transcription, cancel any automatically created response, clear queued audio, and remove any temporary Jarvis bubble.
- The Realtime system instruction now treats display-only requests as silent interface commands.
- Renderer assets are cache-busted to `0.1.2-repair5`.

## Safety and scope

The exact user command is still recorded in local memory. This repair changes only whether Jarvis narrates after opening the requested visual result.
