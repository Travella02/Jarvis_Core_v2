# 0.3.6-repair9 — Trusted Interaction

**Date:** 2026-09-03  
**Required previous release:** 0.3.6-repair8  
**Status:** Live acceptance repair candidate

## Fix

Repair8 URL routing passed live testing. The next Gmail confirmation check exposed two interaction defects around the trusted review experience.

First, one desktop continued transcribing and conversationally processing microphone speech behind the native permission modal. Spoken `Yes` still could not authorize the action, so the security boundary held, but prompt-time speech could appear in chat and receive a response. Repair9 makes the modal an explicit conversation quarantine: the microphone transport may stay connected, but normal prompt-time speech is discarded before chat, memory, routing, or response generation. A narrow denial-only grammar (`No`, `Cancel it`, `Never mind`, `Stop`, `Don't send it`, and equivalents) can cancel the exact active native prompt hands-free. Electron main closes the native message box through its AbortSignal and treats that path exactly like Cancel. Voice never receives an Allow path or attestation capability.

Second, the bottom `Answer continues — open Fullscreen` text on clipped result cards was CSS decoration rather than a control. Repair9 replaces it with a real button wired to the shared fullscreen reader and makes every structured Jarvis presentation card eligible for Fullscreen, including Gmail drafts even when generic height heuristics would not otherwise show the reader control.

The Repair5/Repair7 authorization invariant is unchanged: `exact challenge → trusted approval → one-use grant → executor consumes grant → execution`. Repair9 only adds a fail-closed voice-denial path and improves review presentation.

See ISSUE-332 and ISSUE-333.
