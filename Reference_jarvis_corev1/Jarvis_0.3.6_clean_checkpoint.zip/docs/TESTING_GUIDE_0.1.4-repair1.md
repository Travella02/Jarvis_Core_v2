# 0.1.4-repair1 — Corrective Follow-Through Testing Guide

## Automated validation

The patch installer runs:

- 222 Python tests
- 45 Node tests
- Desktop syntax checks
- Doctor diagnostics
- Core diagnostics
- Desktop-runtime staging
- Private `.env` preservation verification

## Acceptance flow

1. Start Jarvis with `npm run desktop`.
2. Say: “I need to follow up with Chemly tomorrow.”
3. Correct it with: “I said Kenley, not Chemly.”
4. Open **Memory → Proactive** and refresh locally.
5. Confirm there is one open commitment and its title says **Kenley**, not Chemly.
6. Select **Why this?** and confirm both the original statement and correction remain as evidence.
7. Refresh again and confirm no duplicate commitment appears.
8. Say: “We need to file the ORVEX trademark.”
9. Confirm Jarvis briefly acknowledges tracking the task rather than saying he cannot file it.
10. Then explicitly say: “File the ORVEX trademark for me now.”
11. Confirm Jarvis explains that direct filing is not yet available and does not claim completion.

## Expected result

Active proactive state follows the user’s latest correction, original evidence remains intact, and planning statements no longer trigger execution disclaimers.
