# 0.2.3-repair6 — Calendar Continuity

This live-acceptance repair closes two remaining Calendar Intelligence gaps: Jarvis must use the same local timezone the user sees in Google Calendar, and a natural pause inside one scheduling request must not leak a false Realtime answer.

## Google Calendar UI timezone is now the wall-clock source of truth
The previous repair fell back to the primary calendar resource timezone. Live testing showed that this can still be `UTC` even while the Google Calendar interface is rendering the account in a local timezone.

Jarvis now requests Google's read-only Calendar settings permission and reads the user's Calendar UI `timezone` setting. For ordinary local-time requests this value is preferred over the primary calendar resource timezone whenever the desktop runtime reports UTC/unknown. The provider timezone is cached for 30 minutes. Explicit UTC/GMT requests remain UTC.

If the desktop reports UTC and the existing OAuth token does not yet include `calendar.settings.readonly`, Jarvis refuses to prepare a misleading Calendar proposal and asks for one Google reconnect instead. This is safer than speaking or rendering 9 PM while Google will display the event at 3 PM.

## Split spoken requests stay inside Connected Actions
A natural pause can make Realtime finalize an incomplete phrase such as:

`Can you schedule a meeting with Tanner for...`

followed immediately by:

`Tomorrow at 3 PM, please.`

Previously the second fragment could be evaluated before the first Calendar planner call had established clarification context, so it fell through to ordinary Realtime and produced a false capability denial.

The desktop now recognizes short Calendar continuations that arrive while a Calendar action is still in flight. It waits for the first action, suppresses the stale clarification if the continuation supersedes it, and re-routes the follow-up through Connected Actions. The second fragment can include a day, date/time, duration, or attendee email.

## One truthful response path
Calendar scheduling still uses Luna for action reasoning and Google as provider truth. Realtime remains speech-only. A split utterance can no longer create one Realtime answer plus a separate Connected Actions answer for the same scheduling intent.

## Safety
Calendar creates, updates, and deletes still require explicit confirmation. The new timezone scope is read-only and is used only to match Jarvis speech/cards to the timezone the user actually sees in Google Calendar.
