# 0.2.8-repair1 — Nonblocking Game Mode

## Symptom
After Game Mode activated, Computer Actions became noticeably slower, authoritative speech such as “Opening Rocket League” could fail to play, the desktop could remain in Thinking, and sleeping could coincide with the local core being restarted. Windows logs could show `WinError 10054` while the Realtime/core connection was torn down.

## Root cause
The Game Mode status endpoint was not a passive status read. The desktop polled it every second, and each read could synchronously enumerate Windows processes/windows. The same scan also ran inline when a game was launched or closed. That allowed Game Mode observation work to block the FastAPI/Realtime event loop and delay Computer Actions completion. If the core stopped answering its 1.4-second Electron heartbeat often enough, the desktop supervisor could restart it, which then tore down active Realtime connections.

## Fix
- Game Mode process/window observation now runs only on its dedicated background worker in production.
- Status reads are snapshot-only and never start a Windows process scan.
- Launching/closing apps only wakes the Game Mode worker; it no longer performs observation inline with Computer Actions.
- Risky future input authorization fails closed when the Game Mode snapshot is stale instead of performing a blocking safety scan.
- The HTTP config and Game Mode status routes explicitly request nonblocking snapshots.
- The positive-game-identity and anti-cheat-independent firewall policy is unchanged.

## Expected result
Computer Actions and authoritative speech should return to pre-Game-Mode responsiveness while the Game Mode badge updates asynchronously within the normal polling window. Sleeping should no longer cause a supervisor restart simply because Game Mode observation starved the core event loop.
