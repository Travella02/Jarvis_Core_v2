# 0.2.2-repair6 — Inbox Control

This repair closes two live acceptance gaps found after the Gmail reply workflow passed end to end.

## Fixed

- Gmail now requests the `gmail.modify` OAuth scope so Jarvis can change message read state instead of falsely claiming inbox control is unavailable.
- A contextual request such as **“Can you mark those all as read?”** uses the exact bounded Gmail selection Jarvis just summarized or displayed.
- Opening/reading a singular Gmail thread marks that thread as read when the connected account has the new permission.
- Creating a reply draft also marks the source thread as read, matching the behavior users expect after reading and responding.
- Existing Google connections remain usable for prior capabilities, but must reconnect once to grant the new Gmail state-change permission.
- Connected-action spoken responses are now deterministically clamped to the active response profile before Realtime speaks them.
- Ordinary Realtime turns also receive an explicit per-turn hard sentence/word ceiling derived from the live response-mode settings.

## Safety

Mark-as-read changes are limited to the Gmail message IDs grounded by the active request or the immediately preceding Gmail selection. Jarvis does not treat a broad unread count as permission to silently clear an entire mailbox.

## Expected behavior

1. Reconnect Google once after installing this repair so the new Gmail permission is granted.
2. Ask **“Do I have any unread emails?”**
3. Ask **“Can you mark those all as read?”**
4. Jarvis should mark only the messages he just identified and answer briefly.
5. Open/read or reply to one unread email; it should no longer appear as unread afterward.
6. In Short mode, Connected Actions must stay within the configured **3 sentence / 50 spoken word** ceiling.
