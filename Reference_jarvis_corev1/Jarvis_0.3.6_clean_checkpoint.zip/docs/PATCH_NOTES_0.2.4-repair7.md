# 0.2.4-repair7 — Natural Voice Pipeline

## Why repair7 exists

The repair6 live acceptance test proved the remaining failure was no longer the task database or the desktop timezone conversion. The Tasks view correctly showed **Call Tanner — 2:00 PM**, while Jarvis still said **8 PM** after the follow-up **“What time?”**.

That contradiction changed the repair strategy. A model-owned outgoing speech layer was still a fact-mutation boundary. More instructions to Realtime were not enough, so repair7 removes Realtime from normal answer generation.

## New voice ownership

Jarvis now separates listening, reasoning, truth, wording, and speech:

- **Realtime is the ears/live session.** It keeps live microphone transport, turn detection, wake-session behavior, transcript events, and interruption plumbing. It is not the source of the final wording for normal Jarvis replies.
- **Luna/Jarvis Core is the brain and language layer.** It produces the exact conversational script Jarvis should say for general replies and broader Connected Action answers.
- **The fact guard owns authoritative application facts.** Structured task/reminder times are re-derived from the stored instant using the current desktop timezone/offset instead of trusting an LLM-written clock phrase.
- **Dedicated Speech/TTS with Cedar is the mouth.** It receives the final application-owned text and synthesizes that text without being asked to reason about the answer.
- **The UI displays the authoritative script first.** A later audio transcript cannot replace a correct application answer with a different fact.

## The 2 PM path is now deterministic

For direct task schedule follow-ups such as:

> What time?

Jarvis does not ask another language model to rewrite the clock at all. If the structured task says the reminder is 2:00 PM locally, the authoritative spoken script is simply:

> 2 PM.

That is both more natural and safer. The same structured reminder instant is also used for follow-ups such as **“When will you remind me?”**.

Broader task answers can still be humanized by Luna, but the truth guard rejects a rewritten response when required clock literals disappear or when a conflicting clock is introduced. For example, a generated answer containing both **2 PM** and **8 PM** is rejected rather than spoken.

## More natural conversation

The new Luna voice layer is told to speak like a person in an ongoing conversation instead of a form or status screen. It can use contractions, pronouns, fragments, and very short answers when context already makes the subject obvious.

Examples of the intended style:

- **“What time?”** → **“2 PM.”**
- **“When am I supposed to call Tanner?”** → **“2 PM.”** or another equally short grounded answer when context requires it.
- A broader planning question can receive a longer conversational explanation rather than a rigid `task name + field + value` template.

Assistant boilerplate such as “Based on your tasks,” “You currently have,” “According to your calendar,” and automatic “anything else?” endings is explicitly discouraged unless it is genuinely useful.

## Response modes stay authoritative

**Test / Short / Normal / High / Full remain speech ceilings, not quotas.** A simple question can still receive a two-word answer in High or Full mode. A complex request can expand up to the selected mode's configured ceiling.

Full mode remains capable of speaking a long answer. Long TTS scripts are split at natural sentence/word boundaries for delivery instead of being sent as one oversized speech request.

## Personality foundation

Repair7 adds a global **Personality** selector under the desktop Audio controls. Current profiles are:

- **Classic** — composed, intelligent, warm, understated
- **Casual** — relaxed and conversational
- **Warm** — friendly and encouraging
- **Direct** — concise and practical
- **Witty** — subtle dry humor when appropriate

Personality changes wording and delivery style, not authoritative facts. It is deliberately separate from response length so a user can prefer, for example, **Witty + Short** or **Classic + High**.

This is the generalized foundation for future per-person personality preferences.

## Speaker identity and forms of address

Repair7 strengthens the multi-user rule:

- An unknown or unconfirmed speaker stays **identity-neutral**.
- Jarvis must not infer gender from a voice and must not default to **sir** or **ma'am**.
- Explicitly saved forms of address on a confidently recognized person's profile can be used occasionally when natural.
- The backend no longer silently borrows the local owner's identity for an unknown voice in the new Luna voice path.
- Existing Voice Profiles and durable address-name memory remain the source for known-speaker personalization.

Future simultaneous multi-person diarization is **not claimed complete in this repair**. Repair7 creates the correct response/personality boundary so later diarization can select the active person's memory, address preferences, response settings, and personality without changing the speech architecture again.

## Interruption behavior

Dedicated Cedar speech can be interrupted. When the user begins a new turn, Jarvis stops/aborts the current speech playback and returns control to the live listening session instead of allowing two responses to overlap.

## Privacy and existing data

This repair does not replace `.env`, OAuth credentials/tokens, local memory, voice profiles, tasks, reminders, or user databases.

The Voice Core UI also identifies Cedar speech as AI-generated so the application does not present synthesized speech as a human recording.

## Acceptance target

The blocking acceptance path is:

1. **“Is there anything I need to do tomorrow?”**
2. **“What time?”**
3. Jarvis must answer **2 PM** for the existing Call Tanner reminder shown as 2:00 PM in the Tasks view.
4. **“When will you remind me?”** must still resolve to **2 PM**.
5. **“What time is it?”** must still use the current Windows-local clock.

The exact wording may now be shorter and more conversational. The fact may not change.
