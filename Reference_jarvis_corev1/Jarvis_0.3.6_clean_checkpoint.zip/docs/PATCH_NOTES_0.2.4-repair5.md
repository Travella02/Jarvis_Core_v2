# 0.2.4-repair5 — Universal Time Authority

This repair replaces several feature-specific timezone fixes with one shared user-local time authority. The live failure showed the same task as **2:00 PM** in the desktop Tasks workspace while a spoken task follow-up said **8:00 PM**, and a direct “What time is it?” question fell through to Realtime and incorrectly claimed that Jarvis could not see the clock.

## What changed

### One source of truth for user-local time

- Added `jarvis.core.time_context` as the shared time authority for Jarvis features.
- The desktop sends an offset-bearing local timestamp (for example `2026-08-12T02:23:00-06:00`) together with its reported timezone name.
- If the timezone label says `UTC` while the observable desktop wall clock carries a non-zero offset, **the wall clock and explicit offset win**.
- A valid IANA zone such as `America/Denver` is preserved when it agrees with the desktop offset, retaining normal DST semantics.
- If a timezone label and the observable client clock disagree, Jarvis does not silently shift the user's requested time to satisfy the bad label.

### Existing tasks are repaired without a database migration

Older task/reminder records can contain a correct UTC instant but a stale `timezone="UTC"` label. Jarvis now combines the stored instant with the user's current trusted timezone when speaking or recurring those tasks. This means an existing reminder stored as `20:00Z` can correctly be spoken as **2 PM local** instead of **8 PM**.

No task database rewrite or destructive migration is required.

### New task/reminder writes use the same authority

- Task creation and time edits use the effective desktop-local timezone.
- Direct Task API writes carry the same client-local timestamp as Connected Actions.
- Recurring task completion and reminder claiming use the current trusted user timezone rather than blindly reusing an old UTC label.
- The reminder poller sends the browser-local clock on every claim, so background reminder delivery and conversational task follow-ups agree.

### Realtime receives the real local clock too

The current desktop-local date/time is now supplied when creating a Realtime session, when refreshing the session profile, and in per-turn private guidance. Realtime is explicitly told that the desktop wall clock is authoritative and must never claim it cannot see the current local time when that context is available.

For direct utility questions such as:

> “What time is it?”

or:

> “What date is it?”

the desktop answers deterministically from the actual local OS/browser clock before generic Realtime reasoning. This avoids latency, model guessing, capability denials, and unnecessary voice-model reasoning for information the device already knows exactly.

The narrow task continuation remains intact: a terse **“What time?”** immediately after a grounded task still means “what time is that task/reminder?”, while **“What time is it?”** means the current clock.

### Calendar behavior is preserved

Calendar's successful local-wall-clock strategy now uses the same shared timezone helpers instead of remaining an isolated special case. The goal is one rule across Calendar, Tasks, reminders, Realtime, and future time-aware systems.

## Permanent design rule

Any Jarvis subsystem that needs user-local date/time should consume the shared time authority instead of independently trusting Python/server UTC, provider timezone metadata, or a potentially incorrect browser timezone *name*.

**Observable desktop wall clock + explicit UTC offset = final authority when metadata disagrees.**

This is intended to prevent the same six-hour drift from reappearing as new capabilities are added.

## Data and safety

- No schema migration is required.
- Existing tasks, reminders, memory, and working context are preserved.
- No Google reconnect is required.
- `.env`, OAuth tokens, local databases, and other private runtime data are not included in this repair payload.
