# 0.2.1-repair4 — Draft Editing

Fixes the remaining Gmail draft-review instability found during 0.2.1 acceptance and adds a first-class editable email experience. A reviewed Gmail draft can now be changed either directly in the UI or by telling Jarvis what to change, while the exact provider draft remains saved and unsent until a later explicit send confirmation.

## Changes

- Unsent Gmail preview cards now have an **Edit** control in both compact conversation view and Fullscreen.
- Manual editing supports **To**, **Cc**, **Bcc**, **Subject**, and **Message**. **From** remains read-only because it is the connected Google account.
- **Save changes** writes directly to the exact Gmail draft ID already under review. It does not create a replacement draft and does not send the message.
- The same pending send action is refreshed after an edit, so a later send confirmation still targets the exact reviewed draft.
- Voice/typed instructions such as `Change the subject to Today`, `Make the message friendlier`, `Replace the message with ...`, or `Add ... to the message` are routed back through Luna and update the exact pending draft rather than falling through to ordinary Realtime conversation.
- Fields the user did not ask to change are carried forward from the reviewed draft.
- Intent-only new-email requests such as `Draft an email to Tanner asking how he's doing` now get a grounded nonblank email body. If the primary planner omits the body, Luna performs a dedicated new-email composition pass rather than creating a blank Gmail draft.
- Exact dictated wording is preserved when the user supplies the actual message text.
- Natural negative send phrases such as `No, don't send`, `Please don't send it`, and `No, do not send` cancel only the pending send and leave the Gmail draft saved.
- Cancellation is handled before re-planning, so Jarvis no longer responds with the generic Gmail routing failure for a clear `don't send` request.
- The compact and Fullscreen email presentation stays synchronized after manual edits.

## Safety boundary

Draft creation and draft editing remain non-sending operations. Sending the email still requires a later explicit confirmation. Manual editing is allowed only for the exact pending Gmail draft associated with the local trusted action ID and provider draft ID; stale or already-completed actions are rejected.

## Primary regressions

1. Say:

> Draft an email to Tanner asking how he's doing.

Expected: the saved draft contains a real nonblank message, not an empty body.

2. Click **Edit**, enter a subject such as `Checking in`, change the message, and click **Save changes**.

Expected: the same Gmail draft updates, remains `Draft saved · Not sent`, and the compact/Fullscreen preview reflects the new content.

3. Say:

> Change the subject to Today.

Then:

> Make the message a little friendlier.

Expected: Luna updates the exact pending draft and preserves fields that were not requested to change. Nothing sends.

4. Say:

> No, don't send.

Expected: Jarvis says it will leave the message saved as a draft and does not re-enter the Gmail planner or send anything.

## Apply it

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair4_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```
