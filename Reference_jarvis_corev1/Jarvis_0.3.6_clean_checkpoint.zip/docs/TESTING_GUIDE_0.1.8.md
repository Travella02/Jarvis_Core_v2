# 0.1.8 — Memory Intelligence Testing Guide

## Install

1. Commit the accepted `0.1.7 — Self Awareness` state.
2. Close Jarvis completely.
3. Extract the `0.1.8` ZIP directly into the `Jarvis_Real_Time` project root and allow files to merge.
4. Run `py -3.12 apply_0_1_8_patch.py` from the project root.
5. Start Jarvis with `npm run desktop`.

## Acceptance flow

### 1. Explicit remember

Say or type:

`Jarvis, remember that my test launch date is October 3.`

Expected:

- Jarvis gives one short confirmation such as `I’ll remember that.`
- Asking `What is my test launch date?` returns October 3.
- The command sentence itself does not become a competing current fact.

### 2. Correction with preserved history

Say:

1. `My favorite test color is blue.`
2. `Jarvis, change blue to green.`
3. `What is my favorite test color?`

Expected:

- Jarvis confirms the correction briefly.
- Green is the only current answer.
- The original blue statement still exists in the source timeline as superseded history.

### 3. Mark incorrect without replacement

Say a temporary fact, then say:

`Jarvis, that’s wrong.`

Expected:

- Jarvis marks the previous assertion incorrect.
- It no longer appears in current recall or consolidated understanding.
- The exact source and lifecycle change remain visible in the event detail history.

### 4. Forget and restore

1. Say: `My temporary test code is 4821.`
2. Say: `Jarvis, forget that.`
3. Ask for the code.
4. Open Memory Explorer, locate the event, and choose **Restore current**.
5. Ask again.

Expected:

- After forgetting, the code is excluded from current recall.
- The event remains visible as forgotten historical evidence.
- Restoring it makes the fact current again.

### 5. Task lifecycle

1. Say: `I need to file the test trademark tomorrow.`
2. Confirm it appears as an open proactive item and entity open item.
3. Say: `Jarvis, mark the test trademark complete.`
4. Confirm it disappears from all open-item views.
5. Say: `Jarvis, restore the test trademark task.`

Expected:

- Completion updates the source event, fact, proactive item, and entity profile together.
- Reopening restores the item without duplicating it.

### 6. Clear completed tasks

Complete one or more temporary tasks, then say:

`Jarvis, clear those completed tasks.`

Expected:

- Jarvis gives one short count-aware confirmation.
- The items leave the completed-task list and current recall.
- Their exact historical source remains auditable.

### 7. Memory Explorer controls

Open an event and verify controls for:

- Restore current
- Complete
- Dismiss
- Supersede
- Mark outdated
- Mark incorrect
- Forget
- Delete source event

Open an entity and verify current facts expose lifecycle controls. Confirm the detail drawer shows lifecycle history with previous and new states.

### 8. Undo

Change a task or fact lifecycle, then use the existing Memory Undo control.

Expected:

- The event or fact state is restored.
- Linked proactive state and entity open items are restored as well.
- No duplicate fact or proactive item is created.

### 9. Safety against accidental commands

Ask:

- `Do you remember my favorite color?`
- `Can you remember what I told you yesterday?`

Expected: Jarvis answers normally. These questions must not trigger a remember, forget, correction, or lifecycle write.

### 10. Regression checks

- Voice recognition still attributes confident speakers before memory writes.
- Forms of address remain durable and revocable.
- Sleeping audio does not flash the Waking state without a confirmed wake phrase.
- Response modes still update live.
- Long questions still produce the accepted concise speech plus detailed written answer outside Full mode.
- Full mode still uses one complete Realtime response.
