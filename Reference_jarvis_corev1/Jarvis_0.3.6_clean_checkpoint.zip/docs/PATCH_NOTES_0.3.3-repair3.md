# 0.3.3-repair3 — Contextual Media References

## Symptom
During live acceptance, broad media commands worked, but **“Start it over, please.”** was interpreted as a Computer Actions request to launch an app named “it over.”

## Root cause
The Browser Control desktop follow-up gate recognized `start it over` only when no trailing politeness phrase followed it. The server-side natural-media parser already stripped suffixes such as `please`, but the renderer never handed that utterance to Browser Control. Computer Actions then matched the generic `start <app>` grammar and searched for `it over`.

## Repair
- Allow polite trailing wrappers on contextual media follow-ups.
- Generalize pronoun media references across `it`, `this`, and `that`.
- Expand the media-action hint for restart/from-beginning phrasing.
- Prevent bare conversational pronoun targets such as `it`, `this`, `that`, or `it over` from being treated as plausible app names.
- Give recent Browser media context an explicit defensive boundary ahead of Computer Actions.
- Preserve the structural/verified media executor introduced by repair2; no new DOM clicking or scrolling fallback is added.

## Expected result
After a video is established as the active media target, phrases such as **“Start it over, please.”**, **“Restart it, please.”**, **“Start this over, thanks.”**, and **“Play that from the beginning, please.”** remain Browser Control media-seek operations and cannot become app searches.

The product version remains **0.3.3 — Runtime Reliability** until live acceptance.
