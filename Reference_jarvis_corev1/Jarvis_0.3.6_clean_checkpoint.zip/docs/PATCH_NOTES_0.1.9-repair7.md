# 0.1.9-repair7 — Guided Conversational Recall

This repair removes the hard exact-response interception introduced in repair6. Query-specific memory now guides the Realtime model without replacing the user's full utterance.

## Changes

- Removed `direct_reply` routing from both voice and typed turns.
- Every normal memory question now reaches the Realtime conversational model with the complete original user message.
- Simple recall still receives concise private wording guidance, but the model may respond naturally within the selected response mode.
- Compound questions such as “What do you remember about my fiancée and how do you know?” preserve and answer both parts in order.
- Source-only follow-ups remain one short source/date sentence.
- Suggested provenance now prefers the fact's original evidence timestamp and medium instead of a newer recall question in the timeline.
- Detailed companion generation remains disabled for ordinary recall and provenance questions unless the user explicitly asks for depth.

## Expected behavior

- “What do you remember about my fiancée?” → one concise natural fact answer.
- “How do you know that?” → one concise provenance answer.
- “What do you remember about my fiancée and how do you know?” → the fact followed by its provenance, without losing either part.
