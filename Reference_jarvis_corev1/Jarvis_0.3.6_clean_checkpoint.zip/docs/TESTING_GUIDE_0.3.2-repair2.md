# Testing Guide — 0.3.2-repair2 Canonical Checkpoint Verification

## Apply

From the accepted 0.3.1 project root:

```powershell
py -3.12 .\apply_0_3_2_account_foundation_repair2_patch.py
```

Expected: the installer accepts the known LF/CRLF-only baseline differences and applies **0.3.2 — Account Foundation**.

## Automated checks

```powershell
py -3.12 -m pytest -q tests/test_accounts.py tests/test_account_api.py tests/test_release_consistency.py tests/test_capability_registry.py tests/test_desktop_presence.py tests/test_doctor_script.py tests/test_runtime_entry.py tests/test_server.py tests/test_voice_lab_client.py
```

```powershell
npm run desktop:check
```

```powershell
node --check extensions/jarvis_browser_bridge/service_worker.js
node --check extensions/jarvis_browser_bridge/content.js
```

Then run the full Python and Node suites before acceptance.

## Live acceptance

1. Launch Jarvis.
2. Create an account from the Account workspace.
3. Confirm account/tenant/device identity persists across restart.
4. Sign out, verify the signed-out state, then sign in with the same credentials.
5. Verify a wrong password is rejected.
6. Confirm existing Browser Control and local Jarvis data still work and were not moved or erased.
7. Confirm all visible/current release labels read **0.3.2**.

Do not commit until live acceptance passes.
