# 0.1.7 — Self Awareness

Jarvis now carries an authoritative live understanding of what he is, how the current application is built, which features are available, which integrations are missing, and what each limitation actually means. Longer questions use a hybrid presentation: Realtime speaks one concise response-mode-sized summary while a separate text model writes the complete answer in one stable conversation card.

## What changed

- Added a local capability registry covering identity, version, architecture, runtime configuration, implemented features, disabled features, unavailable integrations, requirements, and safety boundaries.
- Injected the registry into every Realtime session and live response profile so capability answers are based on the running build instead of model assumptions.
- Added `GET /api/capabilities` for inspectable local capability truth without exposing secrets.
- Grounded answers about email, calendars, files, applications, web research, messaging, calls, camera vision, and autonomous execution in the tools that actually exist.
- Added long-form intent detection for explanation, analysis, planning, comparison, architecture, capability, limitation, and other substantial requests.
- Long-form turns create one Realtime spoken summary plus one independently generated Responses API written answer.
- The default written-answer model is the separately configurable `gpt-5.6-luna`; it is not a second Realtime response.
- One stable Jarvis card begins with the exact transcript Jarvis spoke and then continues with the complete written answer.
- Detailed answers preserve paragraphs and line breaks, remain silent, do not call tools, and are separately metered in the usage ledger.
- Interruption, provider error, sleep, disconnect, a new turn, and window shutdown cancel or settle pending written answers safely.
- Local simulation demonstrates the same stable-card presentation without API cost.

## Capability truth contract

- Jarvis may describe, explain, draft, summarize, brainstorm, plan, and reason using the language model.
- Jarvis may only claim an external action happened when an implemented tool returns evidence that it happened.
- A missing connector is described as a missing connector, not as a general inability to understand the task.
- Voice recognition remains probabilistic attribution rather than authentication.
- Runtime and configuration claims come from the current registry and active session profile.

## Spoken and written answer contract

- Simple acknowledgements and short questions remain one response.
- Substantial questions receive one concise spoken summary and one complete written answer generated in parallel.
- Test, Short, Normal, and High limit speech for dual-channel turns; Full remains one complete Realtime response and does not start the companion text model.
- The exact spoken transcript leads the written answer. The detailed continuation begins directly with deeper material and must not mention internal routing, a second model call, or token caps.
- The detailed response uses a separate text-model inference and adds lower-cost text-token usage rather than a second Realtime response.
- Capped spoken summaries include a brief natural handoff to the written detail while staying inside the active sentence and word limits.
- Long Jarvis messages expose an app-local fullscreen reader with safe text-only rendering, scrolling, Escape/backdrop close, and focus restoration.
- Detailed hybrid answers stay as compact conversation previews: the beginning remains visible, the words visibly fade into an explicit Fullscreen continuation cue, and the complete text is read in Fullscreen.

## Validation

Automated validation covers the capability registry, API exposure, Realtime prompt grounding, response-mode preservation, text-only companion creation, interruption cleanup, simulation behavior, UI labels, release metadata, and the existing Speaker Recognition acceptance suite.
