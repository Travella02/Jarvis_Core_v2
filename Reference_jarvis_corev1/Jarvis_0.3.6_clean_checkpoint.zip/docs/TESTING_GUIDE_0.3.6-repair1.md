# 0.3.6-repair1 — Windows Hygiene Startup Live Test

**Do not commit yet.** This repair applies over the currently installed 0.3.6 candidate and keeps the application version at `0.3.6` while the unaccepted repair label is `0.3.6-repair1`.

## Before applying

Close Jarvis completely so Electron and Core are no longer running. Do not delete `logs/core.log`, `data/security/`, the original 0.3.6 patch artifacts, or `.patch_backups/`; the repair is specifically intended to let the existing one-time migration complete safely.

## Apply

Extract the repair ZIP into the Jarvis project root and run:

```powershell
python .\apply_0_3_6_repair1_patch.py
```

The installer must require `VERSION=0.3.6`, verify the exact base 0.3.6 candidate manifest and every replaced-file baseline hash, verify all repair payload hashes, create a timestamped backup, and preserve `.env`, OAuth/provider tokens, local databases, Memory, Voice Profiles, browser state, logs, user data, Git history, and the original 0.3.6 patch/recovery artifacts.

## Targeted automated validation

```powershell
python -m pytest -q tests/test_runtime_entry.py tests/test_sensitive_data_hygiene.py tests/test_server.py tests/test_release_consistency.py
```

```powershell
npm run desktop:check
npm run desktop:test
```

Do not run `npm audit fix` or `npm audit fix --force` during candidate validation because that would mutate the dependency tree being tested.

## Repair-specific Windows live check

Start Jarvis normally:

```powershell
npm run desktop
```

Expected:

1. Jarvis starts normally and Core reaches application startup complete.
2. The startup output does **not** contain `Sensitive-data legacy cleanup will retry` with `WinError 5` for `core.log`.
3. `data\security\sensitive_data_hygiene_v1.json` exists after the successful cleanup.
4. Reboot/relaunch Jarvis once more. The cleanup should be an idempotent no-op and Jarvis should still start without the warning.
5. Do **not** inject a real password, API key, verification code, card number, or other secret into logs for this test.

If the warning still appears, stop live acceptance and report the exact sanitized warning. Do not delete the hygiene marker or logs unless we deliberately diagnose them.

## Continue full 0.3.6 acceptance

After the repair-specific check passes, continue `docs/TESTING_GUIDE_0.3.6.md` from the live Permissions & Security section. The full release still requires explicit acceptance before commit.

## Cleanup only after final acceptance

Keep `apply_0_3_6_patch.py`, `patch_files/`, `apply_0_3_6_repair1_patch.py`, `repair1_files/`, repository-local `.patch_backups/`, and any downloaded/staged patch ZIPs until Tanner explicitly accepts the complete 0.3.6 release. Then remove temporary installer artifacts before the focused commit. Keep permanent source/config/tests/docs/issues/manifest. No Git tag.
