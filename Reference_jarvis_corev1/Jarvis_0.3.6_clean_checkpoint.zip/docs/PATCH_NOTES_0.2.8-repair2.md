# 0.2.8-repair2 — Private Transcript Routing

## Symptoms

Two input-layer regressions remained after the nonblocking Game Mode repair:

- `Can you also open Snipping Tool, please?` could bypass Computer Actions even though the direct `Open Snipping Tool` form worked.
- A silent or low-information microphone turn could briefly surface the private Realtime transcription guidance as if the user had spoken it.

Game Mode itself remained healthy: Rocket League stayed protected, normal Snipping Tool open/close actions were allowed, sleep/wake worked, and the Game Mode badge cleared after Rocket League closed.

## Root causes

The Computer Actions grammar omitted conversational continuation tokens such as `also`, and its target cleanup did not understand trailing `too` / `as well`.

Separately, `input_audio_transcription.delta` text was written directly into the visible user bubble before the completed transcript passed the existing internal-artifact filter. That made the completion filter too late to guarantee UI privacy.

## Fix

- Add bounded continuation grammar for `also`, optional leading `and` / `then`, and trailing `too` / `as well` cleanup.
- Keep discussion/explanation questions out of Computer Actions.
- Buffer Realtime transcription deltas privately on the pending voice turn instead of rendering them.
- Finalize a user transcript only after completed text passes the internal-artifact guard.
- Use buffered text only as a completion fallback; never as a raw visible stream.
- Suppress substantial partial fragments of the private transcription guidance, not only one exact full-string match.
- Leave Game Mode detection/firewall behavior unchanged.

## Expected result

Natural continuation commands should route to Computer Actions consistently while Rocket League is protected, and touching the microphone without meaningful speech should never expose the private transcription prompt in conversation or durable memory.
