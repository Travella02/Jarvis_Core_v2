# Testing Guide — 0.2.3-repair5 Calendar Truth

## Test 1 — 3 PM must be 3 PM everywhere
Say:

`Can you schedule a meeting with Tanner for tomorrow at 3 PM?`

Expected:
- Jarvis says 3 PM, not 9 PM.
- The Calendar card shows 3:00 PM in the connected primary Google Calendar timezone.
- The date is the correct local tomorrow.
- Google Calendar ultimately shows the same 3 PM after confirmation.

Confirm with:

`Yes, go ahead and add it.`

## Test 2 — speech must match the grounded duration
With the meeting present, say:

`Can you make it 30 minutes instead of an hour? Or actually, an hour instead of 30 minutes?`

If Jarvis asks which duration, answer:

`To one hour.`

Expected:
- The proposal card shows one hour.
- Jarvis says one hour.
- Jarvis never says 30 minutes while the card is one hour.
- After one explicit confirmation, Google Calendar is one hour long.

## Test 3 — regression check for attendee edit
Say:

`Can you add Austin to that meeting tomorrow?`

Expected:
- The exact meeting remains grounded.
- Existing attendees remain present.
- Austin is added after resolution.
- One confirmation applies the update.
