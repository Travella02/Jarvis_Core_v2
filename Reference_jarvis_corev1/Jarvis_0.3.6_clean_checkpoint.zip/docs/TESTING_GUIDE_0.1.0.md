# Testing Guide — 0.1.0 Desktop Alpha

## Source validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Build the Windows alpha

Run from a committed `0.1.0` source tree on 64-bit Windows:

```powershell
npm run alpha:scope
npm run alpha:make
npm run alpha:verify
```

The first build downloads the official Python 3.12.10 embeddable package, verifies its SHA-256 digest, installs Jarvis dependencies, and creates a checksum-protected one-file runtime bundle. Unchanged later builds reuse both the Python runtime and bundle. The Forge launcher writes method-level progress to `build\alpha-packaging-diagnostic.log`, prints a one-minute heartbeat, packages directly into `out`, and temporarily bypasses executable resource editing. The expected installer is:

```text
out\make\squirrel.windows\x64\Jarvis_Real_Time_Setup.exe
```

## Clean-machine acceptance

1. Copy only `Jarvis_Real_Time_Setup.exe` to a Windows account or computer without the repository.
2. Install Jarvis and confirm Start Menu and desktop shortcuts are created.
3. Launch Jarvis without PowerShell, npm, Python, or a visible console.
4. Complete first-run setup and confirm the key field is blank after restart.
5. Confirm wake-only, wake-plus-request, follow-up conversation, interruption, silent sleep, and simulation.
6. Restart Windows and confirm the startup preference behaves correctly.
7. Export diagnostics and verify the report contains no API key or bearer token.
8. Check for updates and confirm the current version is shown without automatic installation.
9. Quit Jarvis and confirm no Electron or Python process remains.
10. Uninstall Jarvis and confirm program files are removed. User data remains available for a future reinstall unless deleted manually.

## Upgrade acceptance

Build a second internal package with a higher version and install it over the alpha. Confirm the application upgrades rather than creating a duplicate installation and that encrypted settings remain available to the same Windows user.

## Privacy checks

- Search the installation resources, logs, diagnostic export, and source control for the API key.
- Confirm the renderer never receives the decrypted stored key.
- Confirm installed data and logs are written outside `resources` and `app.asar`.

## Expected automated result

```text
Python tests: 160 passed
Node tests: 16 passed
```

## Packaging scope expectation

`npm run alpha:scope` must confirm a compact Electron source tree and a valid one-file runtime payload. Electron `extraResource` must contain only `runtime_bundle.zip` and its manifest. `alpha:verify` rejects an `app.asar` larger than 25 MiB, a damaged/checksum-invalid bundle, missing required archive entries, or loose packaged runtime directories.


## Finalization diagnostics

If Forge does not complete, preserve `build\alpha-packaging-diagnostic.log`. The last method-level `START`, `DONE`, `SKIP`, or `FAIL` line identifies the exact Windows packaging operation. The diagnostic alpha may use Electron's default application executable icon/metadata; the Squirrel Setup icon remains configured.
