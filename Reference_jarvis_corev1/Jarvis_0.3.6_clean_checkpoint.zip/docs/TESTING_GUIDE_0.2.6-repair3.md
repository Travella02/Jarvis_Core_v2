# Testing Guide — 0.2.6-repair3 Reliable App Control

Run these tests on the same Windows machine where repair2 said **“Opening Discord.”** but Discord did not actually surface.

## 1. Reliable launch

Fully close Discord first.

Say:

> Open Discord.

Pass when Jarvis responds quickly **and Discord actually opens**. The first launch after this repair may spend a small amount of time reconciling an old low-trust route with the local Start Menu/registry catalog, but it must not perform the previous 20-second deep search for a known app.

Close Discord manually once, then say **Open Discord** again. The repeat should resolve immediately from app memory.

## 2. Close application

Say:

> Close Discord.

Pass when Discord closes and Jarvis does not claim success if it was not actually running.

## 3. Learn an alias

Say:

> Group chat is another name for Discord.

Then:

> Open group chat.

Pass when Discord opens using the same logical app memory without a fresh PC-wide search.

## 4. Forget an alias

Say:

> Jarvis, I no longer want group chat as a nickname for Discord.

Pass when Jarvis confirms the nickname was forgotten.

Then open **Memory → Apps**. Discord should appear once as a logical app card, and `group chat` should no longer appear in that person’s learned aliases.

You can also add a temporary alias in Memory → Apps and remove it with the **×** control beside that alias.

## 5. Canonical name still works

After forgetting `group chat`, say:

> Open Discord.

Discord must still open. Forgetting a nickname must never remove the canonical app identity.

## 6. Real ambiguity remains safe

If the PC has two genuinely different similarly named apps (for example Visual Studio and Visual Studio Code), use a deliberately vague request such as:

> Open Visual.

Jarvis may ask which distinct application you mean. It must not ask the user to choose between duplicate copies of the same visible app name.
