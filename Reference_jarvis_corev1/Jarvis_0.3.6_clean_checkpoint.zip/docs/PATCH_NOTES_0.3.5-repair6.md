# 0.3.5-repair6 — Win32 Native Fullscreen ABI

**Date:** 2026-09-01  
**Required installed release:** 0.3.5-repair5  
**Version remains:** 0.3.5

## Purpose

Fix the live Windows failure where repair5 correctly selected the intended YouTube video but could not dispatch the narrowly scoped native `F` fullscreen shortcut even though Game Mode was inactive.

## Root cause

Repair5's ctypes `SendInput` declaration used a keyboard-only `INPUT` union. The real Windows `INPUT` union must also be sized for `MOUSEINPUT`. On 64-bit Windows the reduced union produces the wrong `cbSize`, so Windows rejects `SendInput` before any key reaches Edge.

## What changed

- The native browser helper now declares the complete Win32 `INPUT` ABI with mouse, keyboard, and hardware union members.
- Win32 fields use fixed-width 16/32-bit integer types plus pointer-sized `ULONG_PTR`, producing the platform-correct 28-byte (32-bit) or 40-byte (64-bit) `INPUT` structure.
- Jarvis still dispatches only the bounded YouTube `F` key pair; no general mouse/keyboard API was added.
- Failed `SendInput` calls retain the Windows error code in the internal native-action result for diagnostics.
- Core gives Browser Bridge's foreground request a short asynchronous settle interval before the existing native focus/Game Mode checks run.
- Added a regression that directly validates the full Win32 `INPUT` layout so the ABI defect cannot silently return.

## Game Mode safety

Repair6 does not relax repair5's competitive-game guard. Native fullscreen is still blocked for active/pending Game Mode, stale/disabled/unavailable safety authority, non-browser foreground targets, unexpected YouTube windows, and any focus race before dispatch. The browser target is still authorized twice and foreground identity is still re-read immediately before `SendInput`.

## Security / authority impact

No Billing, entitlement, payment, provider, OAuth, Cloud Sync, or Realtime authority changes. No new general automation capability. This is a local Win32 ABI correction inside the already-bounded native YouTube fullscreen executor.

## Compatibility / migration

No data migration and no Browser Bridge source change in repair6, so the unpacked extension does not need another reload solely for this repair. Apply only over the tested 0.3.5-repair5 candidate. User data, `.env`, Billing/Cloud databases, OAuth/provider tokens, memories, voice profiles, browser state, and Git history remain untouched.

## Rollback

The installer creates timestamped backups under `.patch_backups/0.3.5-repair6_*`. Do not clean patch/backups until 0.3.5 is accepted.
