# 0.2.5-repair5 — Unified Agenda

## What changed

Broad day-level questions now mean the user's whole agenda instead of being owned by only Calendar or only Tasks.

Examples such as **“What do I have tomorrow?”**, **“Do I have anything tomorrow?”**, and **“What’s going on today?”** now run one grounded agenda read that checks:

- local Tasks and Reminders for the requested day, and
- Google Calendar events for the same user-local day.

Jarvis combines the results chronologically and speaks one concise answer. A 9 AM Calendar event and a 2 PM reminder are therefore reported together instead of one silently hiding the other.

## Domain specificity stays intact

Explicit requests still remain narrow:

- “What’s on my calendar tomorrow?” → Calendar only.
- “What tasks do I have tomorrow?” / “What do I have to do tomorrow?” → Tasks and Reminders only.
- “What do I have tomorrow?” → unified Calendar + Tasks/Reminders agenda.

The unified read is deterministic and does not require a Luna planning call. If Calendar is unavailable, Jarvis still reports any local tasks it can verify and clearly says Calendar could not be included.

## Safety and continuity

- Existing local-time authority remains in place for task/reminder times.
- Existing Calendar timezone authority remains in place for provider events.
- Duplicate title/time pairs are suppressed in the spoken agenda.
- Unified agenda responses are fact-safe speech.
- Existing task and Calendar context remain available for follow-up turns.
