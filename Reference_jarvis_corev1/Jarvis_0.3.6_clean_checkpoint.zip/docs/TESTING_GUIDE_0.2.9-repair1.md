# 0.2.9-repair1 Live Testing

## Test 1 — first-answer barge-in

1. Put Jarvis to sleep.
2. Wake him naturally and ask: “Jarvis, explain what Game Mode does and why it is useful.”
3. As soon as Jarvis has spoken several words, talk over him: “Actually, what time is it?”

Expected: the Waking state is visibly shown, Jarvis stops the first answer promptly, the interruption appears as the user turn, and Jarvis answers the new question. The Game Mode explanation never resumes.

## Test 2 — interrupt during Thinking

1. Wake Jarvis and ask a question that requires a longer response.
2. If the UI reaches Thinking before speech starts, immediately say: “Never mind, open Snipping Tool.”

Expected: the old pending response is invalidated, Snipping Tool opens, and the old answer never starts speaking later.

## Test 3 — repeated full-duplex conversation

After the first barge-in succeeds, ask another long question and interrupt that answer with a third request. Repeat once more.

Expected: every audible response can be interrupted; only the newest turn owns future speech.

## Test 4 — no wake duplication regression

Repeat five natural full wake phrases such as “Jarvis, tell me the time.”

Expected: exactly one user request and one Jarvis answer per physical wake utterance. No phantom Processing speech turn and no Jarvis self-echo turn should appear.

## Test 5 — Game Mode regression

With Rocket League protected by Game Mode, repeat Test 1 and then open/close Snipping Tool. Finally close Rocket League.

Expected: barge-in behavior is unchanged, safe external actions remain available, and Game Mode clears when the game closes.
