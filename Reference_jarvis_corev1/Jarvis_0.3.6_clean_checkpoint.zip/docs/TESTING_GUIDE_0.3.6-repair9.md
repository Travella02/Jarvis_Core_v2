# 0.3.6-repair9 — Trusted Interaction Testing

Apply only over the exact verified `0.3.6-repair8` live candidate. Do not commit until all 0.3.6 live acceptance is explicitly complete.

## Automated checks

```powershell
python -m pytest -q tests/test_conversation_viewport.py tests/test_permission_confirmation_security.py tests/test_browser_confirmation_security.py tests/test_connected_action_confirmation_security.py tests/test_permission_executor_enforcement.py tests/test_release_consistency.py
node --test tests_js/permission_modal_ux.test.cjs tests_js/self_awareness.test.cjs tests_js/connected_actions.test.cjs tests_js/browser_access.test.cjs tests_js/browser_url_routing.test.cjs
npm run desktop:check
npm run desktop:test
```

The reconstructed patch workspace may not contain every historical Repair1–Repair7 documentation fixture or the latest full settings tree; the real checkout remains authoritative for the complete regression commands.

## Live Test A — Prompt-time speech quarantine

Use a harmless pending Gmail draft and trigger a send that requires the trusted native permission prompt.

While the native prompt is open, say:

> Yes, allow it.

PASS:
- the email is not sent;
- the prompt remains open;
- the utterance does not appear as a normal user chat turn;
- Jarvis does not answer the utterance;
- no new command executes or queues behind the permission decision.

Then say an unrelated phrase such as:

> Whoo!

PASS: it is likewise discarded while the trusted prompt remains open.

## Live Test B — Hands-free denial

Trigger the same harmless send again. While the trusted prompt is open, say:

> Cancel it.

PASS:
- the native permission prompt closes as Cancel without a mouse click;
- the email is not sent;
- Jarvis may give the normal brief cancellation response after the prompt closes;
- normal listening resumes.

Repeat once with `Never mind` or `Don't send it`.

Security regression: `Yes`, `Allow it`, `Go ahead`, and `Do it` must never close the prompt as approval.

## Live Test C — Real fullscreen footer

Create or display a Gmail draft long enough for the compact Jarvis bubble to clip. Click the bottom:

> Answer continues — Open fullscreen

PASS: that exact bottom affordance is a real button and opens the fullscreen reader. The fullscreen draft must preserve all visible email fields/body and must remain Not sent unless a separate trusted send action is approved.

Also verify a shorter Gmail/Calendar/Task structured card exposes a working `Fullscreen` control even when the card itself is not overflowing.
