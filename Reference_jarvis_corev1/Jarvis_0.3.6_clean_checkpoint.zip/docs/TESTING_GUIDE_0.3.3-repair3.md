# 0.3.3-repair3 — Contextual Media References Testing Guide

1. Start Jarvis 0.3.3 with the Browser Bridge connected and a YouTube video open.
2. Establish media context with **“Resume the video.”** or **“Pause the video.”**
3. While staying in the same awake session, test each phrase:
   - **“Start it over, please.”**
   - **“Restart it, please.”**
   - **“Start this over, thanks.”**
   - **“Play that from the beginning, please.”**
4. Each command must remain in Browser Control, move the current video to the beginning, and must not search for/open an app such as `it over`.
5. Verify there is no unintended page scrolling/clicking and that the microphone continues listening after the silent structural action.
6. Confirm the session cost never decreases/resets in the same awake session.
7. Quick regression: **“Open Chrome.”** should still route to Computer Actions, proving valid explicit app launches remain intact.
8. Do not commit until live acceptance passes.
