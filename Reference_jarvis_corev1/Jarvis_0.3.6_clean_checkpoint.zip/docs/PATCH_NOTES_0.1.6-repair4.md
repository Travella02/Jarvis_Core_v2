# 0.1.6-repair4 — Durable Addressing & Live Profiles

This acceptance repair closes the remaining gaps in forms of address, live response-length controls, and proactive-task lifecycle cleanup.

## Durable and revocable forms of address

- Natural punctuation is accepted in commands such as **“From now on, call me Boss.”**
- Forms of address remain separate from identity aliases, but they now appear in the generic person entity view under **Preferred forms of address**.
- Adding, replacing, removing, or clearing a form refreshes the active Realtime context immediately.
- After a title is removed, current-turn guidance explicitly prevents older conversation history from reintroducing it.
- Short deterministic confirmations remain in place, including **“Got it, Boss.”** and **“I won’t call you Boss anymore.”**

## Response mode controls now affect live replies

- The renderer now loads the complete server-owned Realtime instruction profile for the selected Test, Short, Normal, High, or Full mode.
- Speaker-specific guidance is applied through an ordered `session.update` before `response.create`, instead of replacing the session instructions with response-only instructions.
- The response selector remains available while Jarvis is awake.
- Changing the selector updates the active session immediately and remains saved for later sessions.
- The selected profile keeps its configured sentence/word guidance and output-token setting alongside memory, lifecycle, style, and privacy instructions.

## Proactive-memory lifecycle cleanup

- Completing or dismissing a proactive item now updates its linked structured fact when one exists.
- Entity profiles refresh immediately after complete, dismiss, or reopen actions.
- Exact source events remain preserved, but dismissed/completed event-backed commitments no longer reappear as active open items.
- A one-time startup repair rebuilds profiles that contained terminal tasks from earlier versions.
- Reopened items become active again; terminal facts are not silently reopened by later consolidation.

## Validation

- 262 Python tests passed.
- 65 JavaScript tests passed in the uploaded source-only environment.
- Four unchanged packaging-only JavaScript tests were blocked because the source ZIP omitted `node_modules`; the installer requires all 69 tests in the complete project.
- JavaScript and Python syntax checks passed.
- The uploaded memory database was tested on a working copy: dismissed follow-up items disappeared from Tanner’s consolidated profile while the still-open trademark task remained.
