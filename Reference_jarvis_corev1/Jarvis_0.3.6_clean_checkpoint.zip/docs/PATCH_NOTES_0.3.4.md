# 0.3.4 — Cloud Sync

## Summary

0.3.4 turns Account Foundation into the online account boundary for Jarvis and adds a revision-safe cross-device synchronization platform. Normal Jarvis use now requires a signed-in, verified online account that is cloud-connected to the Jarvis service. An account must prove control of at least one email address or phone number before assistant features unlock.

## What changed

- Added a deployable Jarvis Cloud relay with registration, contact verification, login/logout, device registration, device revocation, tenant-scoped push/pull, and expiring bearer sessions.
- Signup and login automatically attach the desktop installation to Jarvis Cloud; a fresh device can recover the same stable account and tenant after valid cloud authentication.
- Added email-or-phone account identity with normalized phone numbers and explicit verification challenges. Development simulation may expose the code for testing; production requires a deployment-owned delivery provider and never returns the code to the client.
- Added the account gate to both desktop controls and the production local API. Guest/Unknown speaker attribution remains separate from the authenticated account owner.
- Added Cloud Sync state, task scope controls, manual sync, conflict visibility, and authorized-device management to Account.
- Tasks/reminders are the only portable user-data scope in 0.3.4. Memory, voice embeddings, OAuth/provider tokens, API keys, browser session state, usage logs, and diagnostics remain outside Cloud Sync.
- Added server revision authority with monotonically increasing revisions, per-record base revisions, mutation idempotency, cancellation tombstones, and conflict preservation instead of timestamp-based silent overwrite.
- Fixed paginated pull semantics so a device can never advance past records it has not actually received.
- The relay now derives tenant and device authority from the authenticated session, rejects unsupported sync scopes and oversized records, and prevents client payloads from spoofing another device as record origin.
- Cloud session tokens expire, rotate on a fresh login from the same registered device, are revocable on logout, and are invalidated when another authorized device revokes that device.
- Added a bounded authentication-attempt limiter in the relay. Production deployment should additionally enforce distributed/edge rate limiting.
- Removed the product claim that Jarvis is an offline/local-first service. Jarvis is an online assistant; device-resident stores remain implementation, cache, execution, and secret boundaries rather than an offline-service promise.

## Security boundary

0.3.4 does not claim end-to-end encryption. Hosted transport must use HTTPS/TLS, the relay enforces authenticated tenant isolation, and sensitive credentials/biometric data are excluded from sync payloads. The deeper cryptographic, step-up authentication, passkey/2FA, recovery, and authorization work remains planned for the Permissions & Security milestone.

## Upgrade behavior

Existing 0.3.3 device data is preserved. Account and sync databases are extended/created in the per-user data directory. `.env`, OAuth tokens, API keys, voice profiles, browser state, local memory, logs, and other device data are not copied into the patch payload or overwritten by the installer.
