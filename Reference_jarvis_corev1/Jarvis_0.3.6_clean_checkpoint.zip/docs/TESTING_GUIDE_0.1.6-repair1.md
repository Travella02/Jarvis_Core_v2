# Testing Guide — 0.1.6-repair1

## Apply

1. Close Jarvis.
2. Extract the repair ZIP directly into the project root and approve file replacement.
3. Run `py -3.12 apply_0_1_6_repair1_patch.py`.
4. Start the development app with `npm run desktop`.

## Test recognized speaker response

1. Keep an enrolled Voice Profile enabled with at least two good samples.
2. Wake Jarvis and ask: “Do you know who I am based on my voice?”
3. Jarvis should answer using the local match and should not say voice identification is unavailable.
4. Open the memory event and confirm the same person and recognition confidence are recorded.

## Test speaker identity at wake

1. Put Jarvis to sleep.
2. Have the enrolled person say: “Jarvis, who am I?”
3. The opening response should know the recognized speaker.
4. Open the wake event in Memory and confirm the enrolled person—not the generic local owner—is the actor.
5. Repeat with an unenrolled speaker; Jarvis should not force the enrolled identity.

## Test Exact Event & Provenance controls

Open any disposable memory and verify:

- **Edit exact text** opens a form, saves, and retains the change after restart.
- **Correct speaker** opens a known-person selector and updates attribution history.
- **Move category** opens a category editor and updates the timeline filter category.
- **Mark important**, **Mark outdated**, and **Mark incorrect** update immediately.
- **Set privacy** opens a selector and persists.
- **Delete memory** opens an in-app confirmation and can be recovered with **Undo latest reversible change**.

## Regression checks

- Typed messages still receive one response.
- Display-only “show me…” commands remain silent.
- Combined display-and-summary commands still narrate once.
- Interruption still cancels the old response and the next response speaks normally.
- Sleep intent still uses the controlled sleep tool.
