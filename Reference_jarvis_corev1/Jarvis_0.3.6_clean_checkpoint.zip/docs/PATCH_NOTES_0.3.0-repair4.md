# 0.3.0-repair4 — Resilient Browser Research

- Keeps exact browser-observed URLs grounded across the entire autonomous task instead of only the current snapshot.
- Removes hostname/brand-name trust that could admit invented deep links.
- Rejects generic recoverable “couldn't access/verify from here” completion on current/official research goals and performs a bounded site-scoped recovery search.
- Adds bounded post-navigation DOM settling for JavaScript-heavy pages before Luna decides what to do next.
- Preserves the structural DOM-only Browser Access boundary, external-commit confirmation, secret-field blocks, Natural Interruption cancellation, and Game Mode separation.
