# Testing Guide — 0.0.3 Wake Detection

## Automated validation

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
node --check apps\desktop\labpp.js
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live validation checklist

1. Start Jarvis and verify the page opens at `http://127.0.0.1:8765`.
2. Confirm the wake keyword and wake-listener status appear in the Session panel.
3. While Jarvis is sleeping, say **"Jarvis"** only. Confirm the session wakes.
4. Put Jarvis back to sleep, then say **"Hey Jarvis what is the weather looking like today?"**. Confirm Jarvis wakes and answers the entire request without needing a second prompt.
5. Repeat with another natural opener, such as **"Yo Jarvis tell me a joke"**.
6. Stay idle and confirm the warning message appears before idle sleep.
7. Confirm Jarvis returns to sleep after the configured idle timeout.
8. Trigger a few turns and confirm the Awake & cost panel updates:
   - Awake time
   - Idle countdown
   - Session cost
   - Cost per awake minute
   - Today total
9. Say **"that's all Jarvis"** while awake and confirm Jarvis returns to sleep.
10. Confirm manual Sleep still closes the session and manual Wake still works.

## Acceptance boundary

Tanner should commit `0.0.3` only after the natural wake phrase flow feels reliable on his machine and the idle timer / cost panel behave as expected.
