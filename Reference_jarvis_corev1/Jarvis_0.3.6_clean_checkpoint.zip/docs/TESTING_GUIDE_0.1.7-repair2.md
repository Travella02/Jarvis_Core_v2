# Testing Guide — 0.1.7-repair2

## Acceptance flow

1. Start Jarvis and select **Test** or **Short** response mode.
2. Ask: “Explain your complete architecture and capabilities in detail.”
3. Confirm Jarvis speaks exactly one concise summary.
4. Confirm he does not begin a second, competing spoken answer.
5. Confirm only one Jarvis card appears for the answer.
6. The card may briefly say **Preparing the complete answer…**, then it should display the full written response once. It must not first show the spoken transcript and visibly replace it.
7. Confirm the complete written answer is detailed, readable, and written as Jarvis using “I,” “me,” and “my.”
8. Change between Test, Short, Normal, and High. Confirm spoken length changes while the detailed written answer remains complete.
9. Ask a simple request such as “Who am I?” Confirm it remains one ordinary Realtime response and does not start the text model.
10. Interrupt a long answer or immediately ask a new question. Confirm the old written request is cancelled and cannot overwrite the new answer.
11. Put Jarvis to sleep during a long request. Confirm no late written answer appears after sleep.
12. Review the usage panel and confirm written text cost is included without being counted as Realtime audio.

## Optional configuration checks

Set `JARVIS_TEXT_MODEL` to another supported Responses API text model, restart Jarvis, and confirm `/api/config` reports the selected model. Invalid reasoning effort or token settings should fail configuration validation rather than silently using an unsafe value.

## Failure fallback

Temporarily use an invalid text model in a test environment. Jarvis should preserve the spoken summary as the written card and display a local configuration warning; it should not issue a second Realtime answer.
