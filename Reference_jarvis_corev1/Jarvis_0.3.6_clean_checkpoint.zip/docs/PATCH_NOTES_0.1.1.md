# 0.1.1 — Total Recall

Builds the first durable memory foundation for Jarvis: an exact local event ledger, autonomous categories and entities, provenance-aware facts, safe duplicate handling, Realtime recall, and a Memory workspace.

## What changed

- Added a local SQLite memory database under the configured Jarvis data directory.
- Every stored event preserves the exact text, actor, source, session, local timestamp, local date, timezone, confidence, privacy level, metadata, category, entities, and supporting facts.
- Added source types ready for voice, wake voice, typed chat, Jarvis responses, vision, web, app activity, tools, files, email, calendar, system events, and imports.
- Added autonomous category creation and deterministic first-pass extraction for new businesses, projects, organizations, teams, meals, preferences, relationships, and named concepts.
- Added an entity and alias graph so future speaker identity, vision identity, files, tools, and connected services can attach to the same memory records.
- Added provenance-linked fact consolidation: repeated facts increase support without deleting their original evidence.
- Added idempotency by provider/source event ID so duplicated Realtime events are not stored twice.
- Added safe consolidation that merges only provably identical same-second events. Repeated real-world experiences on different dates remain separate.
- Enabled Realtime input transcription for durable ordinary voice memory. It can be disabled independently in configuration.
- Injected bounded current facts and recent exact events into new Realtime sessions so Jarvis can recall prior information without loading the entire database into every prompt.
- Added a Memory workspace with statistics, manual capture, full-text search, date/category filters, autonomous category browsing, exact timeline entries, and safe consolidation controls.
- Voice turns, typed turns, preserved wake utterances, Jarvis responses, and simulation responses now flow into the same local event ledger.

## Storage and privacy

The database is stored at:

```text
<Jarvis data directory>\memory\jarvis_memory.sqlite3
```

The database is local and is never served beyond the loopback-only Jarvis core. This release preserves privacy and provenance fields, but separate database-at-rest encryption, speaker authentication, selective sharing boundaries, and cross-device synchronization remain future work.

## Important design rule

Jarvis keeps three distinct levels:

1. Exact source events and evidence.
2. Structured entities, categories, relationships, and facts.
3. Bounded context rendered for active conversations.

Derived knowledge may be consolidated later, but the exact event remains the source of truth unless Tanner explicitly deletes it.

## Current limits

- Autonomous classification is intentionally deterministic in this foundation release. Rich model-assisted category invention, contradiction resolution, causal graphs, salience scoring, and background consolidation will build on this schema in later versions.
- Voice identity and face identity are not yet implemented; events currently use Tanner or Jarvis as the actor unless another actor is provided.
- Vision, web history, email, calendar, files, and app activity have schema support but are not yet connected as automatic producers.
- The SQLite file is local but not yet protected by a separate encrypted vault.
- Deletion, correction, entity merging, export, backup, and memory access boundaries will be expanded in the Memory Explorer and consolidation updates.

## Validation

- Python unit and integration tests cover timestamps, categories, entities, facts, duplicate prevention, episodic preservation, search, Realtime context, API routes, configuration, and UI contracts.
- Node tests cover the installed desktop, packaging, process supervision, and new memory UI/source wiring.
- The patch installer validates file hashes, applies with backups, runs automated tests, and supports safe reapplication.
