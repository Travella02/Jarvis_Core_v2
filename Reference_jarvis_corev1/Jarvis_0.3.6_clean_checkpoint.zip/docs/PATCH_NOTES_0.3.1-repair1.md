# 0.3.1-repair1 — Quiet Action Feedback

This live-acceptance repair keeps the 0.3.1 Browser Control candidate on the accepted `0.3.0` release metadata while addressing action feedback and the remaining media-control reliability gaps.

## Changes
- Visible low-risk Browser Control fast-path successes are silent; failures and ambiguity still speak.
- Visible Computer Actions app open/close successes are silent.
- Gmail mark-read remains audibly confirmed because the state change may be invisible, but confirmations are short and contextually varied instead of one fixed sentence.
- Natural media-command normalization accepts broader phrasing for pause/resume, volume, mute, seek, restart, playback speed, and fullscreen.
- Media operations are state-verified before Browser Control accepts success.
- YouTube's main structural video is preferred over incidental page media.
- Restart seeks to the beginning and resumes playback.
- Enter-fullscreen gains a reversible Jarvis immersive fallback plus Chromium window fullscreen when native Fullscreen API entry is blocked by user-gesture rules.
- Web Intelligence search, freshness verification, cards, citations, caching, and browser source handoff are unchanged.

## Live acceptance focus
1. Play a YouTube result, then use natural follow-ups such as “Pause it,” “Keep playing,” “Turn it down to 20%,” “Go forward half a minute,” “Start it over,” “Put it back to normal speed,” and “Go fullscreen.”
2. Confirm successful visible controls happen without Jarvis speaking.
3. Confirm volume actually changes, restart actually returns to the beginning and continues, and fullscreen visibly enters/exits.
4. Trigger a browser media failure and confirm Jarvis speaks the failure instead of claiming success.
5. Open/close a visible desktop app and confirm successful execution is silent.
6. Mark Gmail messages read and confirm Jarvis still gives a short natural audible acknowledgment.
7. Ask a current-information Web Intelligence question to verify 0.3.0 research behavior is unchanged.
