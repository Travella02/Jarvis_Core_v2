# 0.1.2 — Memory Explorer

## Summary

Memory Explorer turns the `0.1.1` Total Recall database into a visible, searchable, and correctable personal knowledge system. Exact events remain the immutable evidence layer unless Tanner deliberately deletes one; the explorer adds structured controls around how those events are found, interpreted, organized, and presented.

## Added

- Visual event timeline grouped by local calendar date.
- Natural-language memory search with deterministic interpretation of:
  - entity names such as projects, businesses, people, and concepts;
  - `today`, `yesterday`, `last Tuesday`, and bounded `last N days` ranges;
  - speaker, source, importance, and review-status intent.
- Search filters for date range, category, source, status, and important memories.
- Event detail drawer with exact text, local timestamp, timezone, speaker, source, kind, category, privacy, confidence, event ID, linked entities, and evidence-backed facts.
- Correction controls for exact text, speaker attribution, category, privacy, importance, and active/outdated/incorrect status.
- SQLite schema version 2 with event status, important marker, update timestamp, and an operation audit ledger.
- Soft deletion with reversible restore.
- Entity pages with aliases, related timeline, structured relationships, evidence counts, confidence, and merged-record visibility.
- Reversible entity merge and split controls that preserve source records and aliases.
- Daily summaries showing event range, categories, actors, and important moments.
- JSON and Markdown exports of the currently filtered memory view.
- UI and API protections that keep writes behind the trusted local-client header and render memory text through `textContent` rather than HTML injection.

## Memory integrity rules

- Exact source events remain the primary evidence.
- Distinct real-world events are not merged because their wording is similar.
- Corrections are audit logged.
- Text corrections re-run deterministic entity and fact extraction.
- Content corrections are preserved in the operation history but are not advertised as one-click reversible because derived graph changes must not be restored partially.
- Deletions, event metadata changes, and entity merge/split operations are reversible.
- A merged entity remains a separate source record linked to its canonical entity, so the operation can be undone without destroying provenance.

## Database migration

Existing `0.1.1` databases migrate in place. The update adds columns and the operation table without deleting existing events, entities, categories, facts, aliases, or evidence links.

## Deliberately deferred

- Model-assisted semantic embeddings and vector search.
- Autonomous contradiction resolution and memory consolidation during idle time.
- Speaker recognition, face recognition, vision ingestion, web-history ingestion, and app-activity ingestion.
- Natural spoken commands for every explorer action.
- Encrypted memory-database storage and per-speaker authorization boundaries.
- Cross-device synchronization and automated backup scheduling.
