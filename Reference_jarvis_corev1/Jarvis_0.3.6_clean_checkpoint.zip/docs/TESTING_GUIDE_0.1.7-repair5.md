# Testing Guide — 0.1.7-repair5

## Compact continuation preview

1. Select Test, Short, Normal, or High.
2. Ask for a detailed multi-section explanation.
3. Confirm the written answer card is substantially shorter than the conversation panel and does not dominate the chat.
4. Confirm the opening of the answer remains visible.
5. Confirm the final visible lines gradually fade rather than stopping at a sharp cutoff.
6. Confirm **Answer continues — open Fullscreen** appears at the bottom of the preview.

## Fullscreen continuity

1. Click **Fullscreen** on the preview.
2. Confirm the complete answer is present with no missing text.
3. Close the reader and confirm the compact preview remains in the same conversation position.

## Resize and regression checks

- Resize the app and switch among Conversation, Balanced, and Presence layouts; the preview should remain between 210 and 330 pixels tall.
- Short Jarvis replies should continue to display normally.
- Full response mode should still use one complete Realtime response without the hybrid companion.
- The fullscreen reader should still close by button, Escape, and backdrop click.
