# 0.0.4 — Transcript Repair

**Fixes unresolved ordinary voice-turn placeholders without adding separate transcription expense.**

## User-visible repair

Ordinary follow-up speech no longer stays on **“Processing speech…”** after Jarvis has already answered. When exact input transcription is unavailable, the user bubble is finalized as:

```text
Voice input
```

Wake phrases still show the captured request text, typed messages still show their exact text, and Jarvis output transcripts remain unchanged.

## Cost-control decision

This repair intentionally does not turn on OpenAI input-audio transcription. Realtime input transcription is a separate asynchronous ASR process and defaults to off. Enabling it automatically would introduce additional usage merely to improve the display.

## Engineering changes

- Added placeholder detection for `Listening…` and `Processing speech…` variants.
- Added deterministic fallback finalization at `response.created` and `response.done`.
- Added fallback handling for user-item completion events that contain no usable transcript.
- Prevented fallback labels from triggering natural-language sleep-command routing.
- Added Conversation-panel guidance explaining the cost-conscious behavior.
- Added `ISSUE_019_NORMAL_VOICE_TRANSCRIPT_MISSING.md`.

## Validation

The complete 68-test automated suite, JavaScript syntax validation, doctor, safe diagnostic, installer, idempotent rerun, and `.env` preservation were validated before delivery.
