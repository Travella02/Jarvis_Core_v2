# 0.2.2 — Action Speed

Jarvis keeps the Action Intelligence behavior from 0.2.1, but removes avoidable latency from common Gmail and Calendar workflows.

## Faster grounded action completion

- Provider-confirmed draft creation, draft revision, email sending, calendar writes, and pending-confirmation prompts no longer make a second Luna call just to restate a result Jarvis already knows exactly.
- Luna still plans and reasons when reasoning is actually required: interpreting the user's request, composing/revising natural language, understanding email threads, summarizing reads, and coordinating multi-step workflows.
- Realtime remains speech-only for connected actions.
- Provider success is still required before Jarvis says an external write succeeded.

## Concurrent Gmail metadata reads

- Gmail search previously hydrated message metadata one message at a time after receiving the message ID list.
- Metadata hydration now runs concurrently with a bounded six-request window while preserving Gmail result order.
- This accelerates inbox summaries, recipient discovery from correspondence, and any workflow that begins with a Gmail search.
- The concurrency bound avoids unbounded provider fan-out.

## Session recipient fast path

- Once a person is safely resolved to one email address during the current Jarvis app session, that exact name/address mapping is cached in memory for 30 minutes.
- Repeated actions to the same person can skip another Contacts/Gmail lookup during that short window.
- The cache is session-local only. Durable recipient evidence remains in the existing tenant-scoped ActionStore.
- Ambiguous recipient matches are never cached as a single answer.

## Visible action latency

- Connected Apps now shows **Last action** latency for provider-backed action requests.
- Manual Gmail draft saves and Pending Action confirmations report the same timing metric.
- This timing is local end-to-end server processing time for the connected action and is intended to make regressions visible during live testing.

## Safety and architecture

- Confirmation rules are unchanged: sending email and changing Calendar state still require a separate explicit confirmation.
- Natural confirmation/cancellation behavior from 0.2.1 remains intact.
- The local fast path is only used when the result is deterministic and grounded in provider/local action state; read summarization and open-ended reasoning still go through Luna.
- Gmail metadata concurrency preserves the original result order and does not broaden OAuth permissions.
