# Testing Guide — 0.0.1-dev1

## 1. Install

Extract the patch ZIP into the existing `Jarvis_Real_Time` project root. Allow Windows to merge `patch_files`. Then run from PowerShell:

```powershell
py -3.12 apply_0_0_1_dev1_patch.py
```

The installer verifies the current version, checks every manifest checksum, backs up replaced files, installs FastAPI/HTTPX/Uvicorn into `.venv`, runs all automated tests, runs the doctor, and runs the safe core diagnostic.

## 2. Create the private `.env`

After installation:

```powershell
Copy-Item .env.example .env
```

Open `.env` locally and set:

```text
OPENAI_API_KEY=your_private_openai_api_key
```

Do not paste the key into chat, screenshots, project documentation, GitHub, or patch files. Verify Git ignores it:

```powershell
git check-ignore -v .env
```

## 3. Automated tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Expected summary:

```text
Ran 26 tests
OK
```

These tests use a mocked OpenAI transport and do not spend API credit.

## 4. Environment doctor

```powershell
.\.venv\Scripts\python.exe scripts\doctor.py
```

After `.env` is configured, every structural check should show `PASS`, including:

```text
[PASS] OPENAI_API_KEY configured (value hidden)
Project: Jarvis_Real_Time
Version: 0.0.1-dev1
Model: gpt-realtime-2.1-mini
Voice: marin
```

The actual key must never be printed.

## 5. Safe diagnostic

```powershell
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

Expected: project/version, sleeping state, WebRTC unified transport, model, voice, and only `yes/no` for key configuration.

## 6. Start Jarvis

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

Expected:

- The terminal shows `Jarvis_Real_Time 0.0.1-dev1`.
- The local Voice Lab opens at `http://127.0.0.1:8765`.
- The API key is never displayed.
- Closing the browser does not terminate the Python core; stop the core with `Ctrl+C`.

## 7. Manual live acceptance sequence

1. Confirm the page shows the configured model and voice.
2. Click **Refresh devices** and allow microphone permission.
3. Select the desired microphone, speaker, and `marin` or `cedar`.
4. Click **Connect**.
5. Confirm the status becomes **Connected**, a handshake time appears, and `session.created` appears in Provider events.
6. Say: “Hello Jarvis, introduce yourself.” Confirm Jarvis responds by voice and naturally addresses you as “sir.”
7. Ask two follow-up questions without repeating “Jarvis.”
8. Send one typed message using the input at the bottom of the conversation panel. Confirm Jarvis answers through the same live session.
9. Mute and unmute the microphone.
10. Change the output speaker if your Chromium build supports it.
11. Click **Disconnect**. Confirm the microphone indicator turns off and the status returns to Offline.
12. Reconnect once without restarting Python.

## 8. Privacy checks

- Open browser developer tools and inspect `/api/config`; it must contain `key_configured`, never the key.
- Search `logs/core.log` and `logs/realtime_events.jsonl`; the key must not appear.
- Run `git status`; `.env`, logs, and runtime data must remain ignored.

## 9. Common failures

- **`OPENAI_API_KEY is missing`** — create `.env`, add the key, and restart the core.
- **401/403 from OpenAI** — key, project permissions, billing, or model access may be incorrect. The UI shows a safe generic failure; inspect the terminal request ID without sharing secrets.
- **Microphone list has generic names** — click Refresh devices and grant permission.
- **No speaker selector support** — Chromium may not expose `setSinkId`; use the Windows default output device.
- **Port already in use** — change `JARVIS_PORT` in `.env`, then restart.
- **Connection opens but no speech response** — preserve the event log and terminal output, remove secrets, and report the exact provider event names.

## 10. Commit after acceptance

```powershell
git status
git add .
git commit -m "0.0.1-dev1: add secure Realtime WebRTC voice lab"
git push
```

Do not commit until the automated tests pass and the live connect/disconnect test has been completed.
