# Testing Guide — 0.0.7 Sleep Lifecycle Repair

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Launch Jarvis with `npm run desktop`.
2. Wake Jarvis and hold a short conversation.
3. Say “That’s all, Jarvis.”
4. Confirm Cedar completes the entire “Of course, sir.”
5. Confirm the interface remains awake/speaking until the sign-off is complete.
6. Confirm the state then changes to Sleeping and wake monitoring resumes.
7. Repeat with “Go back to sleep, Jarvis” and “Thanks, that’s everything.”
8. Confirm the terminal contains no `sleeping -> speaking` traceback.
9. Wake Jarvis again immediately after each completed sign-off.
