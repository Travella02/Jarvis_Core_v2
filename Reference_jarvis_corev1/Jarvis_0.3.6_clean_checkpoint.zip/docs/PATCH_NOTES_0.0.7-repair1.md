# 0.0.7 — Sleep Playback Repair

## Summary

This repair prevents the audible “Of course, sir.” sleep acknowledgement from being truncated before Cedar finishes speaking.

## Root cause

The client reused the normal 300 ms remote-audio silence threshold as the final sleep shutdown boundary. Cedar can naturally pause near the comma for long enough to cross that threshold, and `response.done` can arrive before queued WebRTC playback has drained.

## Changes

- Added a dedicated 1,100 ms sleep-acknowledgement silence window.
- Added minimum audible-duration validation.
- Added acknowledgement-specific first-signal and last-signal tracking.
- Added a final drain guard after sustained silence.
- Replaced direct shutdown from `response.done` with a re-checking playback-completion timer.
- Cancelled pending shutdown whenever audible output resumes.
- Extended bounded no-audio and maximum-wait fallbacks.
- Prevented fallback timeouts from terminating active acknowledgement playback.
- Added Issue 043 and regression coverage.

## Versioning

The installed project version remains `0.0.7` because this repairs the unaccepted Voice Lifecycle release.
