# 0.0.7 — Silent Sleep Repair

## Summary

Live acceptance showed that a second Realtime audio response used only for a short sleep sign-off remained vulnerable to local playback races across Chromium, WebRTC, and the selected audio device. Tanner chose the simpler and more cost-conscious behavior: when the model confirms clear sleep intent, Jarvis now ends the session silently.

## Changes

- Retired the dedicated Cedar sleep acknowledgement response.
- Handles `sleep_jarvis` as soon as function-call arguments are complete, with `response.done` retained only as a fallback.
- Cancels any in-progress response and clears queued output audio before shutdown.
- Disables the conversation microphone before closing the Realtime session.
- Prevents duplicate tool events from running the sleep sequence twice.
- Removes any partial sleep-response bubble from the conversation panel.
- Marks the sleep sign-off metric as **Silent** and still records sleep-intent-to-completion timing.
- Treats the legacy `JARVIS_SLEEP_ACKNOWLEDGEMENT_ENABLED` option as disabled.

## Result

Natural endings remain model-decided, but no extra text or audio response is requested. This eliminates the playback cutoff race and reduces output-audio cost.
