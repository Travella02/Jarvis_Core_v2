# 0.1.4-repair1 — Corrective Follow-Through

This repair makes proactive memory honor later user corrections and distinguishes remembered plans from requests to execute external actions.

## Fixed

- Spoken or typed corrections such as “I said Kenley, not Chemly” now update the active commitment title, fingerprint, reminder text, and future proactive recall.
- Short contextual corrections such as “I meant Kenley” can resolve the most recent unambiguous commitment reference.
- A one-word corrected name can be recorded as a correction when it immediately follows Jarvis repeating a different name.
- The original misheard transcript remains immutable evidence; the correction is added as separate authoritative evidence.
- Repeated proactive refreshes no longer recreate the old misspelled commitment or create duplicate corrected items.
- Declarative statements such as “We need to file the ORVEX trademark” are treated as commitments to track, not as commands to perform the filing immediately.
- Capability disclaimers are reserved for direct execution requests such as “File the trademark for me now.”
- The Realtime prompt now accurately states that Jarvis has durable local memory while still lacking external action tools.

## Safety and provenance

- Corrections update derived proactive state only; exact original events are never rewritten.
- Every corrected proactive item links both the original event and the correction event in its evidence view.
- Ambiguous contextual corrections are ignored rather than guessed.
- No external action is performed by this repair.
