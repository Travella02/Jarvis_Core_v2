# 0.3.5-repair1 — Live Acceptance Repair Testing Guide

**Do not commit yet.** This repair applies over the currently installed 0.3.5 candidate and keeps the application version at `0.3.5` while the unaccepted repair label is `0.3.5-repair1`.

## Apply

Extract the repair ZIP into the Jarvis project root and run:

```powershell
python .\apply_0_3_5_repair1_patch.py
```

The installer must require `VERSION=0.3.5`, verify the exact 0.3.5 repair baseline for every replaced file, create a timestamped backup, and preserve `.env`, user/account data, Billing/Cloud databases, OAuth/provider tokens, memories, voice profiles, browser state, logs, and Git history.

## Targeted automated validation

```powershell
python -m pytest -q tests/test_billing_cloud_authority.py tests/test_cloud_sync.py tests/test_cloud_sync_api.py tests/test_cloud_sync_relay.py tests/test_server.py tests/test_browser_auth.py
```

```powershell
python -m pytest -q tests/test_electron_shell.py tests/test_desktop_presence.py tests/test_release_consistency.py
```

```powershell
npm run desktop:check
npm run desktop:test
```

Production dependency audit:

```powershell
npm audit --omit=dev
```

Expected on the current accepted dependency tree: `found 0 vulnerabilities`.

## Start Jarvis correctly

Use **one command only** from the project root:

```powershell
npm run desktop
```

Electron prepares and supervises Core automatically. Do **not** start `python -m apps.core` in another terminal first.

If port 8765 is already occupied, stop the manually started Core/conflicting process and relaunch `npm run desktop`.

## Repair-specific live checks

1. **Existing account continuity** — Launch with the same account/session that existed before 0.3.5. Jarvis must load without an ASGI traceback ending in `billing account is not provisioned`.
2. **Billing summary** — Open Account. The customer-safe Billing/usage area must load successfully. No raw internal allowance units, provider pricing, reservation IDs, or settlement evidence may appear.
3. **No re-registration requirement** — The existing account must not need to be deleted or recreated just to receive Billing state.
4. **Ledger preservation** — Repeated restarts/reconciliation must not reset monthly consumption or purchased top-up state.
5. **Startup ownership** — With port 8765 free, `npm run desktop` starts exactly one supervised Core and the Jarvis window loads.
6. **Port-conflict behavior** — Optional development check: deliberately start Core manually, then launch Electron. Electron should detect the occupied port and stop with actionable guidance rather than entering a restart loop. Stop the manual Core immediately afterward.
7. **Normal 0.3.5 regression** — Continue wake/sleep, interruption, typed reasoning, Web Intelligence, speech, Computer Actions, Browser/YouTube, Connected Actions, Cloud Sync, and the 0.3.5 Billing/Realtime acceptance checks.

## Before commit after full 0.3.5 acceptance

Do not clean patch artifacts merely because repair1 passes. Finish the full 0.3.5 live acceptance first. After explicit acceptance, remove all `apply_*` scripts, `patch_files/`, downloaded patch ZIPs/staging files, and repository-local `.patch_backups/`; keep permanent docs/issues/manifest. Inspect `git status` and staged diff for secrets/generated files, then make one focused accepted 0.3.5 commit. Do not create a Git tag.
