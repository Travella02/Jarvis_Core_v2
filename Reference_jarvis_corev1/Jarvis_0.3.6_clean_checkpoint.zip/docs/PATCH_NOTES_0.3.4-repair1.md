# 0.3.4-repair1 — Web Authentication & Account Gate

## Why this repair exists

Live acceptance of the original 0.3.4 Cloud Sync candidate exposed an account deadlock: an installation already bound by Account Foundation could be unable to create a new verified cloud identity, old credentials had no recovery path, ordinary US phone formatting was rejected, and the desktop itself was collecting account passwords. Because Cloud Sync, Billing, device management, and future security all depend on account authority, this is a release blocker rather than UI polish.

## What changed

- Normal signed-out use is now behind one full-screen account gate. The regular Jarvis workspace is hidden and non-interactive until the account is signed in, verified, and cloud-connected.
- Create account, Sign in, and recovery open in the user's default system browser. The desktop renderer no longer contains signup/login/cloud-password fields or password submission handlers.
- Development uses a local browser account portal to prove the browser-auth boundary without requiring the final ORVEX website. Production can replace the portal URL with the hosted HTTPS account service without rebuilding desktop account forms.
- Existing Account Foundation installations can upgrade their existing bound account/tenant identity instead of creating a conflicting local identity or losing their data namespace.
- Ten-digit US phone numbers and common punctuation are normalized to canonical E.164 storage; international contacts still use an explicit country code.
- Signup requires Password + Type password again and rejects mismatches before account registration.
- Browser recovery supports verified email/phone lookup, one-time recovery codes, password reset, and revocation of existing cloud sessions after reset.
- Browser-auth completion is one-time and bound to an opaque desktop polling secret; the local Jarvis session cookie remains HttpOnly.
- The current first-run setup overlay remains above the account gate. The planned cinematic onboarding can replace that first-run experience later without weakening the mandatory account gate.

## Security boundary

This development portal is not presented as the final production OAuth deployment. It proves the external-browser/client boundary and keeps cloud passwords out of the Electron renderer. Before external beta, the portal should move to the hosted Jarvis/ORVEX HTTPS account origin and use the production native-app authorization flow (Authorization Code + PKCE, short-lived access tokens, rotating refresh/device sessions, and production verification delivery).

## Preserved behavior

Cloud Sync remains tasks/reminders-only in 0.3.4. Memory, voice embeddings, OAuth/provider tokens, API keys, browser session state, usage logs, and diagnostics remain outside the sync payload. Browser Control, Runtime Reliability, Account identity separation, and normal signed-in Jarvis behavior are unchanged except for the account-entry boundary.

## Validation

- 688 Python tests across all 57 regression files passed when run in isolated batches; the monolithic all-tests process exceeds the artifact runner's execution window, so the same files were validated in bounded groups.
- Complete Node suite: 145/149 passed. The same four source-only Electron packaging tests remain blocked because `@electron/packager` internal modules are not installed in the artifact environment.
- `npm run desktop:check` passed.
- Browser Bridge `service_worker.js` and `content.js` syntax checks passed.
- One stale Desktop Alpha regression assertion was corrected so it distinguishes the intentional development-only `.venv` self-repair path from the packaged bundled-Python path; packaged builds still do not create a `.venv`.
