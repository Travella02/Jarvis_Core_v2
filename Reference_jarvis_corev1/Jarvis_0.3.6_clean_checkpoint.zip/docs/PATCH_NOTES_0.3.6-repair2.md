# 0.3.6-repair2 — Trusted Security Session

**Date:** 2026-09-02  
**Required previous release:** 0.3.6-repair1  
**VERSION remains:** 0.3.6  
**Status:** Live acceptance repair candidate

## Why this repair exists

The first Permissions & Security live test proved hard Block enforcement, but lowering/restoring several settings required a complete browser Account reauthentication for every single change. That was secure but unnecessarily painful for normal users.

## What changed

- Added a short-lived **recent identity assurance** window after successful account-password reauthentication.
- Default window is 5 minutes (`JARVIS_SECURITY_REAUTH_WINDOW_SECONDS=300`), bounded to 60–900 seconds.
- The proof is process-memory-only and bound to account, tenant, device, installation and actor. It dies on Core restart and is cleared on logout/new sign-in.
- The browser reauthentication page is pre-bound to the currently signed-in Jarvis account, so the user normally enters only their password.
- Password proof no longer consumes the exact permission challenge or creates an action grant.
- Every authenticated security action still requires its own complete, Core-derived trusted Electron confirmation and challenge-specific attestation.
- A compromised renderer cannot silently use the recent-auth window to weaken settings: it still cannot create the trusted native attestation.
- Exact-action fingerprinting, replay protection, cross-scope protection, one-use grants, Game Mode and Cloud/system authority remain unchanged.

## User experience

For the first protection-lowering action after the window expires:

1. enter the Jarvis account password once in the browser;
2. return to Jarvis and approve the exact change in the trusted confirmation prompt.

For additional security-sensitive changes during the short window:

1. no browser/password round-trip;
2. approve each exact change in Jarvis.

This is deliberately not a blanket "unlock all security" mode.

## Issue

See `ISSUE-324`.

## Commit rule

Do not commit. Continue 0.3.6 live acceptance and keep this repair as `0.3.6-repair2` until the complete release is explicitly accepted. No Git tag.
