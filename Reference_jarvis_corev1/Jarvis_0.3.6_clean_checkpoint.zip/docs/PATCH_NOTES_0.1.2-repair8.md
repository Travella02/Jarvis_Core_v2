# 0.1.2-repair8 — One-Pass Summary

Prevent a short visual-memory summary from restating the same fact in its final sentence or clause.

## What changed

- Short visual-memory summaries now use an exact one-sentence contract.
- The sentence is limited to 40 spoken words.
- Every clause must add a new fact; a closing clause that paraphrases the subject, category, event, date, or lack of details must be omitted.
- The standard and detailed narration modes remain flexible but still cannot append a duplicate recap.
- Cache-busts the renderer scripts so Electron cannot reuse the repair7 prompt.

## Expected behavior

`Show me everything about ORVEX and give me a short summary.` opens Memory Explorer and speaks one sentence such as: `The displayed record says you created ORVEX as a business in Work and Businesses on July 29, 2026 at about 4:23 AM.` Jarvis must stop there rather than restating that ORVEX is a business.

## Validation

- 195 Python tests passed.
- 37 Node tests passed.
- Desktop JavaScript syntax checks passed.
- Core doctor and diagnostic checks passed.
- Desktop runtime staging passed.
- Fresh patch installation and safe reapplication passed.
