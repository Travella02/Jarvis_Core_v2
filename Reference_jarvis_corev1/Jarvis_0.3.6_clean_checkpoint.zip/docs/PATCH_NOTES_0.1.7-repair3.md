# 0.1.7-repair3 — Complete Answers

This repair makes hybrid answers feel like one continuous response, keeps Full mode entirely on Realtime, and adds a focused fullscreen reader for long Jarvis messages.

## Changes

- The exact transcript Jarvis speaks is now placed at the beginning of the complete written answer.
- The final answer card waits for both parallel branches to settle, so it cannot finalize before the spoken opening is known.
- The lower-cost text model is instructed to begin with deeper detail rather than repeat the spoken overview.
- Test, Short, Normal, and High retain hybrid routing: capped Realtime speech plus a complete written answer from the configured text model.
- Capped spoken summaries end with a natural handoff, inside the active response limits, explaining that the full details are available in the written answer.
- Full mode bypasses the companion text request. Realtime speaks and displays the complete response without a separate continuation or handoff.
- Detailed answers and other sufficiently long Jarvis messages now expose a **Fullscreen** reader action.
- The reader fills the application viewport, preserves line breaks, supports independent scrolling, closes with the button, backdrop, or Escape, and restores keyboard focus.
- Generated answer text continues to be inserted with `textContent`; no model-generated HTML is executed.

## Compatibility

- Version remains `0.1.7` because this repairs the current unaccepted Self Awareness update.
- Existing API keys, memories, voice profiles, forms of address, response settings, and private local data remain untouched.
- The written-answer model and budget accounting introduced in repair2 remain unchanged.

## Validation

- 281 Python tests passed.
- 72 source-available Node tests passed.
- Four unchanged Electron packaging tests require the complete project dependency tree; all 76 Node tests passed with that tree available.
- Desktop JavaScript syntax and runtime staging were validated.
