# 0.0.3 — Wake Playback Repair

## Summary

Prevents the first-turn microphone from reopening between provider completion and actual remote-audio playback completion.

## Changed

- Split opening-turn completion into two independent signals: provider `response.done` and analyser-observed remote audio.
- Removed the immediate microphone release path when `response.done` arrives before playback begins.
- The wake input gate now releases after the opening audio has been heard and returned to sustained silence.
- Added a bounded no-audio fallback for text-only, failed-audio, and analyser-unavailable cases.
- Cancelled the fallback immediately when remote audio is detected.
- Increased the final acoustic-tail delay before reopening the microphone.
- Increased the gate safety limit so a longer opening response is not interrupted by the old short timeout.

## Issue record

- `issues/ISSUE_016_WAKE_GATE_AUDIO_RACE.md`

## Validation

- Full automated suite passed.
- JavaScript syntax validation passed.
- Doctor and safe diagnostic passed.
- Installer succeeded from the exact repair4 baseline.
- Idempotent rerun changed zero files.
- Test `.env` remained byte-for-byte unchanged.
