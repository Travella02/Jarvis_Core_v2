# 0.2.9-repair2 — Natural Turn Control

## What changed

- Preserves the working 0.2.9 Realtime-style interruption path from repair1.
- Lets a new computer action survive natural correction/cancellation prefaces such as “Never mind…”, “Actually, never mind…”, “sorry…”, and “scratch that…”.
- Keeps action routing conservative: explanatory discussion such as “Never mind what I said about opening Discord” is not executed.
- Adds a local explicit-silence command path. Standalone requests such as “You don’t have to say anything” or “Please don’t respond” end the turn without asking Luna or TTS to produce a reply.
- Makes deterministic spoken sleep tolerant of a small bounded set of common ASR near-matches for “Jarvis”, including “dervis” and “jervis”, but only inside an already-clear sleep/dismissal phrase.
- Allows a sleep phrase to carry a trailing silence request, for example “That’s all, dervis. You don’t have to say anything.” The result is silent sleep.

## Safety / scope

This repair does not change Game Mode, browser access, mouse/keyboard execution, memory storage, credentials, package metadata, or the accepted release version. It only repairs natural turn routing and lifecycle handling around the already-working interruption pipeline.
