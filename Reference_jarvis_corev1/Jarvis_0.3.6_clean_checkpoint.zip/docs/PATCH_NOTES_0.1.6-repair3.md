# 0.1.6-repair3 — Human Addressing

This acceptance repair makes speaker-aware conversation sound natural and concise, and adds durable, multi-value forms of address that each recognized user can add, replace, or revoke without changing their canonical identity.

## Short, human identity replies

- Confident identity questions now receive a direct answer such as **“You’re Tanner.”**
- Uncertain matches use ordinary language such as **“You sound like Tanner, but I’m not completely sure.”**
- Jarvis no longer says that a recognizer matched someone, explains confidence, or narrates attribution mechanics unless the user explicitly asks how voice recognition works.
- Simple preference confirmations are deterministic and brief rather than model-expanded.
- The Realtime prompt now favors the shortest complete human answer and suppresses unnecessary restatement, disclaimers, capability advertising, and follow-up offers.

## Durable forms of address

- A person can have several active forms of address, such as **Boss**, **Chief**, and **Captain**.
- Forms of address are stored separately from canonical names and aliases, so calling someone “Boss” never changes who the person is.
- Natural commands can add, replace, remove, or clear preferences:
  - “From now on, call me Boss.”
  - “You can also call me Chief.”
  - “Only call me Captain.”
  - “Don’t call me Chief anymore.”
  - “Just use my real name.”
- One-name confirmations use a short exact response such as **“Got it, boss.”**
- Multiple active choices are supplied to future responses and used occasionally rather than repeated in every reply.
- Preferences persist locally, appear in person details, survive safe person merges, and participate in undo history.

## Speaker and privacy boundaries

- Voice commands update only a confidently recognized person profile.
- An uncertain candidate is never treated as confirmed and cannot inherit or modify that person’s names or titles.
- Typed commands update the protected local-user profile.
- Recognition remains attribution rather than authentication, and forms of address do not grant memory access.

## Response lifecycle repair

- Preference and identity turns create one exact bounded response after local speaker resolution.
- A duplicate response request left in the previous repair path was removed.
- Silent sleep handling remains ahead of all response creation.

## Validation

- 257 Python tests passed.
- 63 JavaScript tests passed in the source-only validation environment.
- The four packaging-only JavaScript tests could not load `@electron/packager` because the uploaded source ZIP correctly omitted `node_modules`; their source was unchanged and the patch installer reruns the complete 67-test suite in the full project.
- JavaScript and Python syntax checks passed.
- Address parsing, persistence, removal, replacement, clearing, merge/undo, API exposure, speaker-context enrichment, and exact short-response behavior are covered by regression tests.
