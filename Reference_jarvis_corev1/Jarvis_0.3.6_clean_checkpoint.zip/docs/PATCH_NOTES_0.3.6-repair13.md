# Jarvis 0.3.6-repair13 — Action Context & False VAD Stability

Repair13 addresses two live-acceptance failures that remained after Repair12.

- A pending Connected Action now keeps its original action session when the same conversational speaker temporarily falls back to `Unknown` for a yes/no/send/cancel decision. This fixes `Draft an email -> Say hi -> Yes` losing the draft context. A positively recognized different person still resets the action context, and consequential execution still requires the trusted permission surface/executor grant.
- Realtime `speech_started` is no longer trusted as an immediate barge-in edge. Jarvis debounces it for 180 ms, or accepts meaningful transcript evidence sooner, before interrupting speech/browser work.
- Short VAD starts with no transcript get a bounded 900 ms recovery path that removes placeholder speech and restores Speaking/Thinking/Listening according to the real active state instead of leaving Jarvis stuck in Thinking.
- Connection cleanup clears all new VAD/barge-in timers.

No executor permission checks are weakened. Trusted permission prompts remain completely voice-inert.
