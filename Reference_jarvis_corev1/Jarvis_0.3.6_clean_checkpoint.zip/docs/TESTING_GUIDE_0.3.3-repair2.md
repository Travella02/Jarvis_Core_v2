# 0.3.3-repair2 — Live Test Guide

This repair is cumulative and may be applied over either the original 0.3.3 Runtime Reliability candidate or 0.3.3-repair1. Reload the unpacked Jarvis Browser Bridge extension once after applying it, then refresh the YouTube tab so the updated content script is active.

1. Start a playing YouTube video and say **“Can you pause the video, please?”** It must pause on the first attempt and must not scroll the page.
2. Resume it, then try several natural forms such as **“Would you mind pausing the video for me?”**, **“Hold the video, please.”**, **“Could you resume the video for me?”**, and **“Keep the video playing, please.”**
3. Follow a media action with **“Pause this for me.”**, **“Resume it.”**, and **“Start it over, please.”** The recent media target should remain grounded.
4. Watch Jarvis's response. It must never claim **“already paused”** while the video is visibly playing, and it must not report success when the bridge cannot verify the resulting state.
5. Confirm the page does not move/scroll during a pause or resume command.
6. Confirm microphone continuity and cumulative session cost behavior from repair1 remain correct.

Do not commit 0.3.3 until these live checks pass.
