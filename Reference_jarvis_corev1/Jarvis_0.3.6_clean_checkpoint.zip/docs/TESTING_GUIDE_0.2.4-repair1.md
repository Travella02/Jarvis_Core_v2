# Testing 0.2.4-repair1 — Today Task Visibility

## Primary live test

1. Keep the existing undated “Finish the ORVEX website” task.
2. Keep the “Call Tanner” reminder scheduled for tomorrow.
3. Ask: **“What do I need to get done today?”**
4. Jarvis should show/summarize **Finish the ORVEX website** and should not say there are no matching tasks.
5. The future Call Tanner reminder should remain scheduled for tomorrow rather than appearing as due today.

## Regression test

Ask: **“What reminders do I have tomorrow?”** The reminder-only Call Tanner item should be included even though it has no separate due date.
