# Testing Guide — 0.2.1-repair5 Draft Stability

Run these tests after applying repair5 over `0.2.1-repair4`.

## 1. Compact manual editor

Say:

> Draft an email to Tanner asking how he's doing.

Select **Edit** in the compact email card.

Expected:
- The email editor remains inside a bounded card.
- The field area can scroll when needed.
- **Cancel** and **Save changes** remain reachable instead of being clipped by `Answer continues — open Fullscreen`.

Change Subject to `Checking in`, change the Message, then select **Save changes**.

Expected:
- The same Gmail draft updates.
- The preview returns to `Draft saved · Not sent`.
- The new Subject and Message are visible.
- No email is sent.

## 2. Compact cancel

Open **Edit** again, make a temporary change, then select **Cancel**.

Expected:
- The editor closes.
- The temporary unsaved change is discarded.
- The previously saved Gmail draft remains unchanged.

## 3. Fullscreen manual editor

Open the same draft in **Fullscreen**, then select **Edit**.

Expected:
- The email card stays visually structured.
- The editor is bounded to the fullscreen viewport.
- The fields scroll inside the card if necessary.
- **Cancel** and **Save changes** stay visible/reachable.

Change the Subject and Message and select **Save changes**.

Expected:
- Fullscreen returns to the structured email preview with the new content.
- Closing Fullscreen shows the same updated content in the compact card.
- The draft remains unsent.

## 4. Spoken/typed subject edit routing

With that draft still awaiting send confirmation, say exactly:

> Change the subject to Today.

Expected:
- Jarvis updates the exact pending Gmail draft.
- The preview shows Subject `Today`.
- Jarvis does **not** answer with a generic memory-correction response such as `I corrected that to today`.

Then say:

> Make the message a little friendlier.

Expected:
- Luna revises the exact same draft body.
- Subject remains `Today`.
- Nothing is sent.

## 5. Final send continuity

Say:

> Okay, go ahead and send it.

Expected:
- The exact edited draft sends once.
- Jarvis reports provider-confirmed success.
- The structured card becomes `EMAIL SENT`.

## 6. Memory regression

After the pending Gmail action is gone, make an ordinary memory correction such as a known test correction used in the existing suite.

Expected:
- Memory correction behavior remains unchanged when there is no matching pending Connected Action.
