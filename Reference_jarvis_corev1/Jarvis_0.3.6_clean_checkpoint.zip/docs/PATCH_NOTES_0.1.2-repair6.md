# 0.1.2-repair6 — Grounded Visual Narration

Combined visual-and-spoken memory commands now complete the local display first, then create a fresh grounded response from the exact records shown on screen.

## Changes

- Preserves the in-flight Memory Explorer navigation promise across partial and completed voice transcripts.
- Recovers correctly when a partial `show me...` transcript initially arms silent-response suppression but the final transcript adds `give me a summary` or `tell me about it`.
- Cancels the provider's premature generic response and requests a new response only after the local visual result is ready.
- Supplies the response with exact displayed entity details, relationships, timestamps, actors, and event text.
- Explicitly tells the response that Memory Explorer is already open and visible.
- Prevents claims that Jarvis cannot open or display memory, or that the explorer is still loading.
- Applies the same behavior to typed, normal voice, and wake-preserved requests.
- Keeps pure display commands silent.
- Cache-busts renderer assets to `0.1.2-repair6`.

## Expected behavior

- `Show me everything about ORVEX.` opens Memory Explorer and stays silent.
- `Show me everything about ORVEX and give me a short summary.` opens Memory Explorer and then gives a short summary.
- `Show me and tell me about ORVEX.` opens Memory Explorer and then explains the displayed evidence.
- `What do you know about ORVEX?` remains a verbal recall question and does not navigate the interface.
