# 0.0.5 — Wake Speed & Window Repair

## Summary

This repair reduces the delay between finishing a wake phrase and Jarvis beginning the model wake/Realtime handoff, while keeping the false-wake and duplicate-turn protections from the previous stability repairs. It also prevents stale Electron window state from reopening across multiple monitors.

## Wake latency changes

- Reduced adaptive wake-microphone calibration from 1,200 ms to 300 ms.
- Reduced the Web Audio processor from 2,048 to 1,024 samples for quicker local VAD updates.
- Replaced the 1,200 ms forced silence floor with a bounded 450–700 ms completion window.
- Reuses a usage/budget summary for 30 seconds instead of serially reloading it for every wake.
- Defers audio-device enumeration until after WebRTC connects.
- Retains adaptive noise thresholding, consecutive signal frames, minimum voiced evidence, peak checks, wake transcription, microphone ownership transfer, and first-turn input gating.

## Window changes

- Changed the preferred initial size to 1100×720.
- Caps startup width and height at 82% of one display’s work area.
- Discards saved bounds unless the complete rectangle fits inside one current display.
- Does not save maximized window bounds as the normal launch size.
- Reapplies validated bounds before first show.
- Adds **Reset window size** to the tray menu.

## Issue records

- `issues/ISSUE_034_MODEL_WAKE_LATENCY.md`
- `issues/ISSUE_035_MULTI_MONITOR_WINDOW_RESTORE.md`

## Validation

- 96 Python tests passed.
- Electron main-process and Voice Lab JavaScript syntax passed.
- Doctor and secret-safe diagnostic passed.
- No paid OpenAI calls are performed by automated validation.
