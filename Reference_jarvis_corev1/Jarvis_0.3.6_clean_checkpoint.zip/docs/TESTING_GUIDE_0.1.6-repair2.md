# Testing Guide — 0.1.6-repair2

## Apply

1. Close Jarvis.
2. Extract the repair ZIP directly into the project root and approve file replacement.
3. Run `py -3.12 apply_0_1_6_repair2_patch.py`.
4. Start the development app with `npm run desktop`.

## Test an unknown voice

1. Disable or delete the test speaker’s Voice Profile, or use a person whose voice is not enrolled.
2. Wake Jarvis and ask: **“Do you know who I am based on my voice?”**
3. Jarvis should ask whether you want to create a Voice Profile. He must not say voice recognition is unavailable.
4. Say **“Yes.”**
5. Jarvis should open **Memory → Voice profiles** without speaking another long response.
6. Confirm that the page asks you to choose the correct person and confirm consent.

## Test a recognized voice

1. Enable a profile with at least two clear samples.
2. Put Jarvis to sleep.
3. Say: **“Jarvis, who am I?”**
4. Jarvis should answer with one natural sentence using the matched name.
5. He should not explain local matching, confidence, attribution, or privacy unless asked.
6. Open the event provenance and confirm the matched person and confidence remain recorded.

## Test silent sleep

1. Wake Jarvis and have a normal exchange.
2. Say: **“That’s all.”**
3. Jarvis should return to sleep without speaking or showing an assistant closing message.
4. Repeat with **“Thanks, Jarvis, that’s it.”** and **“You can go back to sleep.”**
5. Confirm the next wake and first response work normally.

## Regression checks

- Interruption still cancels only the old response and the next response speaks.
- Voice identity remains attribution rather than authentication.
- Unknown speakers are never forced into an enrolled profile.
- Voice enrollment still requires explicit consent.
- Exact Event & Provenance controls continue to open working in-app forms.
