# 0.1.8-repair2 — Grounded Memory Identity Testing Guide

## Install

1. Close Jarvis completely.
2. Extract the repair ZIP directly into the `Jarvis_Real_Time` project root and allow files to merge.
3. Run `py -3.12 apply_0_1_8_repair2_patch.py`.
4. Start Jarvis with `npm run desktop`.

## Acceptance flow

### 1. Remaining generic entity cleanup

After startup, open **Memory → Entities & relationships** and refresh.

Expected:

- Weak standalone entries such as `AND`, `NOT`, `LLC`, `HTTP`, `TCP`, or similar vocabulary disappear when they have no independent fact, relationship, task, actor, alias, or stronger user evidence.
- Genuine entities such as people, businesses, projects, foods, and user-established preferences remain.
- Exact conversation events that originally mentioned removed vocabulary remain in the timeline.

### 2. Questions do not create acronym entities

Ask:

`Can you explain CPU, GPU, RAM, AND, NOT, HTTP, and LLC?`

Refresh Memory afterward.

Expected:

- Jarvis answers normally and the exact conversation is recorded.
- None of those terms becomes a new standalone entity merely because the user asked about it.
- A term already supported by a real user fact or relationship is not erased.

### 3. Truthful durable-memory acknowledgement

Say or type:

`My temporary repair-test code is 4821.`

Expected:

- Jarvis responds naturally and briefly, such as `Got it—I’ll remember that.`
- He does not say that he lacks a database, needs a separate memory tool, or can remember only during the current session.

Then restart Jarvis and ask:

`What is my temporary repair-test code?`

Expected: Jarvis can recall `4821`, confirming that the memory is durable across sessions.

### 4. Forget remains truthful

Say:

`Um, actually, forget that.`

Then ask:

`What is my temporary repair-test code?`

Expected:

- Jarvis confirms the completed operation briefly.
- He no longer recalls the code as current truth.
- He does not offer to track it for the current session only.
- The original statement remains visible as forgotten historical evidence.

### 5. Merge a duplicate local-owner profile

Open **Memory → Entities & relationships**.

1. Select **Merge duplicate** on the canonical person profile you want to keep, such as the enrolled or named person profile.
2. Confirm that a placeholder profile such as `Local Owner` appears as a merge candidate and is labeled as a local-owner profile.
3. Review the preview and complete the merge.

Expected:

- The retained profile contains the combined source timeline, aliases, facts, relationships, permissions, and voice identity references according to the existing merge policy.
- The duplicate profile no longer appears as a separate person.
- Exact provenance is preserved and the operation appears in memory history for recovery.

### 6. Regression checks

- Remember, correct, forget, complete, dismiss, restore, clear completed, and Undo still work.
- Current recall excludes terminal or superseded evidence.
- Voice attribution and preferred forms of address remain attached to the correct person.
- Memory search controls remain inside their panel.
- Hybrid long answers and response modes retain their accepted behavior.
