# 0.3.0-repair11 — Media Continuation Polish

This repair finishes the remaining live Browser Control and Web Intelligence continuity gaps without changing the accepted freshness/search architecture.

- YouTube result speech now reports the actual video title without appending duration metadata.
- Visible YouTube results can be selected naturally by title, not only by `first`, `second`, etc.
- `Pause the YouTube video` and `resume/play the video` use a deterministic structured media-control operation instead of a Luna browser-planning turn.
- Web Intelligence suppresses a redundant concluding recap when it simply repeats the spoken summary.
- The Browser Bridge remains structural DOM/media control only; no synthetic desktop input is added and Game Mode remains unchanged.
