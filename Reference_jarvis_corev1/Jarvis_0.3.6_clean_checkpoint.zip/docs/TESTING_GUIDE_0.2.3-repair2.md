# Testing Guide — 0.2.3-repair2 Calendar Routing

## Goal

Verify that Calendar requests never produce an ordinary Realtime capability refusal and that relative dates are resolved from the user's local day.

## Test 1 — Scheduling owns the whole turn

Say:

> Can you schedule a meeting with Tanner for tomorrow at 3 PM?

Expected:

- Jarvis gives one Calendar-owned response.
- Jarvis does not say that he cannot directly schedule or control Calendar.
- A Calendar proposal card appears.
- The event is still uncreated until explicit confirmation.

## Test 2 — Verify the date

Before confirming, inspect the Calendar card. “Tomorrow” must mean the next date in your local timezone, not the next date relative to UTC.

If the current local date is August 10, the proposal must be August 11 even if UTC has already rolled over to August 11.

## Test 3 — Confirm once

Say naturally:

> Perfect, schedule it.

Expected:

- The exact pending event is created once.
- Jarvis gives one success response.
- Google Calendar contains the same date and time shown in the reviewed card.

## Regression check

Repeat the 30-minute + attendee flow from repair1 to confirm Calendar follow-through still works:

1. Prepare a one-hour meeting.
2. Say “Make it 30 minutes instead of an hour.”
3. Say “Add Austin too.”
4. Confirm once.
5. Verify the final provider event is 30 minutes and contains both attendees.
