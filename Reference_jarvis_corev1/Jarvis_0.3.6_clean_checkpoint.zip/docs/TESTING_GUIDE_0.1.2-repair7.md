# Testing Guide — 0.1.2-repair7 Single Summary

1. Close Jarvis and apply the patch.
2. Start the development desktop with `npm run desktop`.
3. Wake Jarvis and say: `Jarvis, show me everything about ORVEX and give me a short summary.`
4. Confirm Memory Explorer opens and displays ORVEX.
5. Confirm Jarvis gives exactly one concise summary.
6. Confirm he does not say both an opening overview and a second “Short summary” containing the same facts.
7. Confirm the reply has no filler label such as “Okay, quick note,” “Short summary,” or “In summary.”
8. Say: `Jarvis, show me and tell me about ORVEX.` Confirm the explanation remains grounded and does not append a duplicate recap.
9. Say: `Jarvis, show me everything about ORVEX.` Confirm the display-only command remains silent.

Automated validation: 195 passing Python tests and 36 passing Node tests.
