# 0.1.4-repair2 — Contextual Corrections

This repair makes proactive memory understand correction intent even when Realtime transcription changes “I meant Kenley” into a phrase such as “I met Ken Lee.”

## Fixed

- Contextual corrections with conversational filler such as “well,” “actually,” “sorry,” and “Jarvis” now resolve against the most recent unambiguous commitment.
- The common speech-to-text homophone `I meant` → `I met` is accepted only when explicit correction context is present.
- Split-name transcriptions such as `Ken Lee` are normalized to the existing or intended single-name form `Kenley` during correction processing.
- The renderer records explicit `correction_old` and `correction_new` metadata when the preceding Jarvis response identifies the misheard name.
- Existing stored correction events are reprocessed during the next local proactive refresh, so Tanner does not need to repeat the correction after installing this repair.
- The active proactive title, fingerprint, future recall text, and evidence view update together.
- Original misheard transcripts remain immutable historical evidence, while the corrective event is added as newer authoritative evidence.
- Repeated refreshes remain idempotent and do not recreate the old spelling or duplicate the commitment.

## Safety and scope

- Homophone handling requires explicit correction language and a recent unambiguous commitment target; ordinary statements about meeting someone are not rewritten without that context.
- Corrections modify only derived proactive state. Exact source events are never overwritten.
- No external action is performed by this repair.
