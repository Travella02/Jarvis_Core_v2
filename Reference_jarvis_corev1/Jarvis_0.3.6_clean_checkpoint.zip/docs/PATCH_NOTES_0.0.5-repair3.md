# 0.0.5 — Electron Shell Repair 3

## Summary

Repairs a platform-dependent local-time test that caused the Electron Shell installer to roll back on Mountain time systems near the UTC date boundary.

## Changes

- Preserves the timezone of explicitly supplied timezone-aware datetimes.
- Continues using the computer's current local timezone for normal production sessions.
- Adds deterministic UTC and Mountain Daylight Time rollover coverage.
- Adds recruiter-friendly `ISSUE_024_TIMEZONE_DEPENDENT_TEST.md`.
- Retains the additive `.gitignore` merge and all prior Electron Shell repairs.

## Safety

The failed Repair 2 installation rolled back before acceptance. Repair 3 still preserves `.env`, validates checksums, backs up changed files, and restores the previous state if validation fails.
