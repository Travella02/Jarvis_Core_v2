# 0.1.6 — Speaker Recognition Testing Guide

## Acceptance flow — enrollment

1. Start Jarvis with `npm run desktop`.
2. Open **Memory → People & identities** and ensure a test person exists.
3. Open **Memory → Voice profiles**.
4. Select the person, check the consent confirmation, and upload one clear single-speaker recording.
5. Add at least one second sample using **Record sample** or another file.

Expected result:

- One voice profile is attached to the selected person.
- Sample count and enrollment quality update.
- No `.wav`, `.mp3`, `.m4a`, or other raw enrollment file is retained under the voice-profile storage directory.
- On Windows the profile reports DPAPI protection.
- Restarting Jarvis preserves the profile.

## Acceptance flow — recognition

1. Keep Jarvis awake and have the enrolled person speak a normal sentence.
2. Open Memory and inspect that voice event.
3. Repeat with a different or unknown speaker.

Expected result:

- A strong match attributes the event to the enrolled person and includes recognition confidence and provenance.
- A moderate match is labeled as likely rather than authoritative.
- Insufficient or ambiguous speech remains **Unknown speaker**.
- Recognition does not expose memories outside the person’s configured privacy boundary.

## Profile controls

- Disable and re-enable a profile.
- Adjust the threshold and confirm it persists.
- Delete one sample and verify the profile recalculates quality.
- Delete the voice identity and verify the person, aliases, relationships, and memories remain.
- Confirm deleting a voice identity removes the protected `.jvvp` files.

## Tenant-isolation check

Create two test tenant IDs against the same test database. Enroll a person under tenant A and verify tenant B lists no profile and cannot match tenant A’s signature. This is a storage/query boundary test; hosted SaaS still requires authenticated tenant derivation and separate authorization.

## Validation baseline

The installer expects 247 Python tests and 58 Node tests to pass. Windows live microphone recognition remains the final acceptance test.
