# 0.3.6-repair2 — Trusted Security Session Testing

## Apply

Close Jarvis completely. Extract the repair ZIP into the project root and run:

```powershell
python .\apply_0_3_6_repair2_patch.py
```

Expected release label: `0.3.6-repair2 — Trusted Security Session`.

## Automated checks

```powershell
python -m pytest -q tests/test_authenticated_reauth_security.py tests/test_config.py tests/test_phase5_adversarial_security.py tests/test_permission_confirmation_security.py tests/test_permission_confirmation_api.py tests/test_permissions_api.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

## Live check

The brief security session removes repeated password entry only; you must still approve each exact change in Jarvis.

1. Launch Jarvis and open **Controls → Permissions & Security**.
2. Set at least two ordinary permissions to **Block**; verify their underlying actions remain blocked.
3. Restore the first blocked permission to a less-protective setting.
   - Browser Account reauthentication should open.
   - The signed-in email/phone should already be shown; normally only the password is entered.
   - After password success, return to Jarvis and approve the exact setting change in the trusted desktop prompt.
4. Within five minutes, restore a second blocked permission.
   - The browser/password page should **not** open again.
   - Jarvis must still show a trusted exact-action confirmation for that second setting change.
5. Cancel one trusted prompt. The corresponding preference must remain unchanged.
6. Wait for the configured recent-auth window to expire (or restart Core/Jarvis), then lower another protection. Browser password reauthentication must be required again.
7. Sign out and sign back in; any previous recent-auth window must not survive.

## Security failure conditions

Stop acceptance if any of these occur:

- a second sensitive change executes with neither browser proof nor trusted exact confirmation;
- a renderer-only action can lower protection during the recent-auth window without the native prompt;
- an authenticated confirmation can be replayed for a changed action;
- recent-auth survives Core restart/logout;
- the account identifier must still be manually retyped for every reauthentication despite an existing bound account.

Do not commit or delete patch/backups until complete 0.3.6 live acceptance.
