# 0.0.7 — Sleep Local Playback Repair

## Summary

This repair prevents a correctly correlated server-side audio-buffer stop from closing the Electron session before Cedar's final samples finish playing locally.

## Fixed

- Changed provider `output_audio_buffer.stopped` from a shutdown trigger to advisory evidence.
- Added a 4.2-second minimum local playback window after Cedar first becomes audible.
- Kept acknowledgement-specific silence hysteresis after the most recent local audio signal.
- Added a bounded seven-second no-audio fallback for analyser or device failures.
- Blocked local wake monitoring and speculative connections throughout sign-off teardown.
- Re-armed wake monitoring only after the Realtime peer and media tracks finish closing.

## User-visible result

Jarvis should complete the full **“Of course, sir.”** before changing to Sleeping. Residual sign-off audio can no longer start a competing wake connection.

## Issue record

See `issues/ISSUE_046_SERVER_DRAIN_PRECEDED_LOCAL_PLAYBACK.md`.
