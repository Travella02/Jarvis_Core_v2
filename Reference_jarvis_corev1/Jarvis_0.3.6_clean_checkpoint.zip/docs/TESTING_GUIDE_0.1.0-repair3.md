# Testing Guide — 0.1.0 Runtime Packaging Repair

## Apply

Extract the repair ZIP directly into the `Jarvis_Real_Time` project root, approve folder merging/replacement, then run:

```powershell
py -3.12 apply_0_1_0_repair3_patch.py
```

The patch validation will build `runtime_bundle.zip` immediately when a valid `build\python` runtime is already present. Otherwise `npm run alpha:make` creates it automatically.

## Build

Remove only incomplete Forge output from the previous cancelled build:

```powershell
Remove-Item -Recurse -Force .\out -ErrorAction SilentlyContinue
```

Do not remove `build\python`, `build\cache`, `build\desktop_runtime`, or `.venv`.

Run:

```powershell
npm run alpha:make
```

Expected preflight messages include:

```text
Bundled Python 3.12.10 runtime already staged ... reusing it.
Fingerprinting prepared Python and desktop runtime files...
Creating one-file runtime bundle ...
Runtime bundle ready ...
Electron source scope verified ...
One-file runtime payload verified ...
Electron Forge will copy only app.asar, runtime_bundle.zip, and its small manifest.
```

On an unchanged retry, the bundle stage should instead report:

```text
Runtime bundle is current and will be reused ...
```

## Timing and stall rule

The bundle creation may take several minutes the first time because it compresses the Python runtime and reports progress every 250 files. Electron's `Finalizing package` stage should then move within approximately 2–10 minutes on Tanner's laptop. Treat the exact same stage as stalled only after 20 minutes with effectively no Node/Electron CPU or disk activity.

## Verify

After Forge returns to the PowerShell prompt:

```powershell
npm run alpha:verify
```

Expected installer:

```text
out\make\squirrel.windows\x64\Jarvis_Real_Time_Setup.exe
```

Verification must confirm:

- `app.asar` is below 25 MiB.
- `resources\runtime_bundle.zip` exists and passes SHA-256 and ZIP integrity checks.
- `resources\runtime_bundle-manifest.json` exists.
- Required Python/core/interface entries are present inside the bundle.
- Loose `resources\python` and `resources\desktop_runtime` directories are absent.

## Installed acceptance

1. Run the generated setup executable.
2. Launch Jarvis from the Start menu.
3. Confirm the loading window reports runtime preparation on the first launch.
4. Allow first-launch extraction to complete without closing Jarvis.
5. Confirm setup, Cedar voice, natural wake request preservation, interruption, conversation, silent sleep, and full process exit.
6. Close and reopen Jarvis; the runtime should be reused without extracting again.
7. Run diagnostics and confirm the Python version reports 3.12.10.
