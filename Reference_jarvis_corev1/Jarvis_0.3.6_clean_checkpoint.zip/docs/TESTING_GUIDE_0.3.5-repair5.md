# Testing Guide — 0.3.5-repair5

## Apply

Close Jarvis completely. Extract the repair ZIP into the Jarvis project root, replacing the repair payload files when Windows asks, then run:

```powershell
python .\apply_0_3_5_repair5_patch.py
```

Do **not** start `python -m apps.core` separately. Electron owns Core in this source checkout.

## Reload Browser Bridge once

Repair5 changes the unpacked Edge extension. Edge does not automatically reload changed extension source files.

1. Open `edge://extensions`.
2. Enable **Developer mode** if needed.
3. Find **Jarvis Browser Bridge** and click **Reload**.
4. Close any old YouTube tabs that were open before the reload.
5. Open a fresh YouTube tab.

## Automated validation

```powershell
python -m pytest -q tests/test_browser_access.py tests/test_game_mode.py tests/test_voice_lab_client.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

The dependency-installed Windows environment should report the complete Node suite with no failures. Repair5 adds three Browser/Game Mode Node assertions over repair4, so the expected total on the user's current Windows checkout is **154/154** if no unrelated tests change.

Do not run `npm audit fix --force` as part of this repair.

## Live test A — natural closest-match YouTube play

Start Jarvis with:

```powershell
npm run desktop
```

Then:

1. Say `Open a new tab and search YouTube for Sidemen.`
2. On the visible results page say `Play Sidemen Sleepover.`
3. Jarvis should select the closest grounded visible match (for the current test page, `SIDEMEN SLEEPOVER (USA EDITION)`) without requiring the full exact title and without a `media_control timed out` error.
4. Repeat with another visible video using only a distinctive partial title.
5. `Play the first result.` must still work.

Jarvis must not guess an unrelated result if no candidate is confident enough.

## Live test B — native YouTube fullscreen

With the selected video playing:

1. Say `Fullscreen YouTube.`
2. YouTube itself should enter its real fullscreen player state. Normal page content, recommendations, description/comments, and vidIQ page panels must not remain around the video.
3. Say `Minimize YouTube.` and verify YouTube exits fullscreen normally.
4. Repeat fullscreen/minimize at least five times.
5. Pause/resume once while fullscreen.

Successful visible fullscreen/minimize actions should remain silent. Failures should be reported.

## Live test C — competitive Game Mode safety

This test verifies that the native shortcut can never become gameplay automation.

1. Launch a known competitive game such as Rocket League and wait until Jarvis shows **GAME MODE** protection active.
2. You may Alt+Tab back to Edge/YouTube, but **leave the protected game running**.
3. Ask `Fullscreen YouTube.`
4. Jarvis must refuse the native fullscreen shortcut and explain that fullscreen/native browser shortcuts are unavailable while Game Mode is protecting the game.
5. The YouTube window may be observed/read, but Jarvis must not send the `F` shortcut and must not inject keyboard/mouse input into any process.
6. Structural browser controls such as pause/play/volume/seek remain the permitted lane because they use Browser Bridge rather than OS input.
7. Close the game (or otherwise wait until Game Mode clearly deactivates), return to YouTube, and confirm `Fullscreen YouTube.` works again.

If Game Mode is arming, unavailable, disabled, or stale, native fullscreen must fail closed rather than bypassing the safety gate.

## Failure interpretation

- Natural partial-title requests timing out or requiring `first result` means ISSUE-316 is not fixed.
- Fullscreen leaving ordinary watch-page UI visible means ISSUE-317 is not fixed.
- Fullscreen claiming success without true YouTube player fullscreen means verification failed.
- **Any native fullscreen shortcut being sent while Game Mode is active/pending is a release blocker. Stop testing immediately and preserve logs/screenshots.**
- Anti-cheat presence alone must not cause a false Game Mode activation.

Do not commit yet. Repairs remain `0.3.5-repairN` until the full 0.3.5 live acceptance suite passes and the user explicitly accepts the release. No Git tag.
