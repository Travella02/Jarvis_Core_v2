# 0.0.3 — Wake Detection

## Summary

This update makes the Jarvis voice lab behave more like a real assistant while keeping the current browser-based engineering shell. Jarvis can now listen for a natural wake phrase while sleeping, accept a longer opening request that contains the wake keyword, go back to sleep after idle time, and surface estimated live usage cost so Tanner can compare responsiveness, awake time, and spend.

## Added

- Local sleeping-state wake listener in the desktop voice lab using the browser speech-recognition layer.
- Natural wake phrase handling so speech such as **"Hey Jarvis what is the weather looking like today?"** can wake Jarvis and forward the text after the keyword as the first request.
- Wake keyword configuration via `JARVIS_WAKE_KEYWORD`.
- Idle return-to-sleep timers via `JARVIS_IDLE_SLEEP_SECONDS` and `JARVIS_IDLE_WARNING_SECONDS`.
- New **Awake & cost** panel showing awake duration, connected state, speaking totals, idle countdown, estimated session cost, cost per awake minute, and a local today total.
- Safe config and diagnostic visibility for wake and idle settings.

## Changed

- Updated the voice-lab release branding to `0.0.3 — Wake Detection`.
- Preserved provider-default turn detection as the recommended mode.
- Kept manual Wake / Sleep / Stop controls alongside the automatic wake listener.
- Kept all API-key handling server-side and secret-safe.

## Notes

- The sleeping-state wake listener uses the browser speech-recognition engine available in the temporary Chromium lab. No OpenAI Realtime session is opened until Jarvis is actually woken.
- Cost numbers are estimates based on provider usage metadata and current configured price assumptions.

## Validation

- Automated unit suite passed before packaging.
- JavaScript syntax check passed.
- `python scripts/doctor.py` passed.
- `python -m apps.core --diagnostic` passed.
