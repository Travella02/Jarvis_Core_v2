# 0.3.6-repair4 — Clean Reauth Completion Testing

## Apply

Close Jarvis completely. Extract the repair ZIP into the project root and run:

```powershell
python .\apply_0_3_6_repair4_patch.py
```

Expected release label: `0.3.6-repair4 — Clean Reauth Completion`.

## Automated checks

```powershell
python -m pytest -q tests/test_authenticated_reauth_security.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

## Live check

1. Launch Jarvis and restart first if the recent-auth window is still fresh.
2. Lower/restore a protected permission so browser password reauthentication is required.
3. Enter the bound account password successfully.
4. If the browser permits the security tab to close, Jarvis should continue to the exact trusted native confirmation.
5. If Edge/Chrome leaves the tab open, the page should read as a successful completion state and show: **"Authentication approved. You may now safely close this browser tab and return to Jarvis."**
6. The page must not frame browser close policy as an error or authorization problem.
7. Close the remaining tab manually, return to Jarvis, and approve/cancel the exact native prompt. The setting must follow only that native choice.

## Failure conditions

Stop acceptance if authentication failure pages close automatically, browser completion itself changes a permission, exact native confirmation is skipped, or any force-close mechanism is added through Browser Control/native automation.

Do not commit or delete patch/backups until complete 0.3.6 live acceptance.
