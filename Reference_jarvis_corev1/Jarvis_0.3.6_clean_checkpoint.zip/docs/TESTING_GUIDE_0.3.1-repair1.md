# Testing Guide — 0.3.1-repair1 Quiet Action Feedback

Keep `VERSION` at the accepted `0.3.0` checkpoint while testing this repair.

## Browser Bridge reload
Because the extension content script and service worker changed, reload **Jarvis Browser Bridge** once from `edge://extensions` or `chrome://extensions` after applying the patch.

## Live acceptance
1. Open a new tab, search YouTube for Linus Tech Tips, and play a visible result.
2. Try these natural variants:
   - `Pause it.`
   - `Keep playing.`
   - `Turn it down to 20%.`
   - `Put YouTube at half volume.`
   - `Go forward half a minute.`
   - `Rewind 10 seconds.`
   - `Start it over.`
   - `Put it back to normal speed.`
   - `Go fullscreen.`
   - `Get out of fullscreen.`
3. For every successful visible control, verify the browser changes and Jarvis does **not** speak a redundant success sentence.
4. Verify volume really changes; do not accept a spoken/visual success with unchanged audio.
5. Verify restart returns the video to the beginning and playback continues.
6. Verify fullscreen visibly enters and exits. Native fullscreen may be replaced by Jarvis immersive/browser-window fullscreen when Chromium blocks native entry without a trusted user gesture.
7. Trigger a real failure if practical (for example, close every media tab and ask to pause the video). Jarvis should speak the failure.
8. Say `Open Snipping Tool.` and `Close Snipping Tool.` Successful visible app actions should be silent; failures still speak.
9. Mark one or more Gmail messages read. Because this is an invisible/background state change, Jarvis should still give a short natural confirmation rather than staying silent.
10. Ask `What are the latest updates in Rocket League?` and verify 0.3.0 Web Intelligence remains grounded and current.

## Acceptance criteria
- no false-success media claims;
- natural media variants route deterministically without Luna browser planning;
- visible low-risk success is silent;
- invisible state changes remain naturally confirmed;
- failure/ambiguity still speaks;
- Web Intelligence and Game Mode behavior are unchanged.
