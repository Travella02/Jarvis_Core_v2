# Testing Guide — 0.2.3-repair10 Attendee Lookup Safety

## Preconditions
- 0.2.3-repair9 is installed.
- Google is connected.
- There is one Tanner meeting tomorrow.
- Austin is not in Google Contacts and has no matching Gmail history/known recipient identity.

## Acceptance flow
1. Wake Jarvis.
2. Say: **“Can you add Austin to the meeting tomorrow?”**
3. Expected: Jarvis does not crash and does not say “I hit a problem using Calendar.”
4. Expected: Jarvis asks for Austin's email address.
5. Reply with a valid test email address for Austin.
6. Expected: Jarvis shows the same Tanner meeting with Austin added to the pending proposal while preserving the existing time, duration, and Tanner attendee.
7. Confirm the update once.
8. Verify Google Calendar contains the new attendee.

## Regression check
The local-time behavior from repair7 must remain correct; event cards and speech should continue to use the user's local wall-clock time rather than UTC.
