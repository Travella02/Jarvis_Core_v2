# 0.1.9 — Context Intelligence Testing Guide

## Apply

1. Commit the accepted `0.1.8 — Memory Intelligence` state.
2. Close Jarvis completely.
3. Extract the `0.1.9` ZIP directly into the `Jarvis_Real_Time` project root and allow files to merge.
4. Run `py -3.12 apply_0_1_9_patch.py`.
5. Start Jarvis with `npm run desktop`.

## Acceptance flow

Use temporary test facts so they can be forgotten afterward.

### 1. Vague business reference across sessions

Tell Jarvis:

> “I created a new business called TESTNOVA.”
>
> “Our goal is to launch the TESTNOVA website.”
>
> “We need to file the TESTNOVA trademark.”

Put Jarvis to sleep, wake him again, and ask:

> “What are we still working on for the business?”

Expected:

- Jarvis understands that “the business” means TESTNOVA when it is the only plausible business.
- He mentions only current goals and unfinished work.
- Completed, dismissed, superseded, or forgotten items do not return.

### 2. Same-session follow-up

Create or mention two businesses, then discuss one of them in the current conversation. Ask:

> “What is left to do for that company?”

Expected: Jarvis prefers the company most recently discussed in that session.

### 3. Ambiguous reference

Create two equally plausible temporary businesses and start a fresh session. Ask:

> “What are we doing with the company?”

Expected: Jarvis asks one short clarification such as:

> “Which one do you mean—TESTNOVA or TESTORBIT?”

He must not guess.

### 4. Relationship reference

Ask:

> “What do you remember about my fiancée?”

Expected: Jarvis resolves the relationship to the correct person profile and answers only with relevant current memory.

### 5. Source explanation

Ask about a remembered decision, then follow with:

> “How do you know that?”

Expected: Jarvis naturally states who said it, approximately when, and whether it is a direct statement or an inference. He should not mention retrieval scores or internal routing.

### 6. Current truth versus history

Create a temporary fact, correct it, then ask:

> “What is the current value?”

Expected: only the corrected value.

Then ask:

> “What was it before I changed it?”

Expected: the old value is described as historical, not current.

### 7. Spoken and written alignment

Outside Full mode, ask a detailed question involving remembered context.

Expected:

- Realtime speaks one concise grounded summary.
- The long written answer uses the same subject and facts.
- The two answers do not contradict each other or refer to different entities.

### 8. Privacy boundary

Have a different recognized voice ask for an unrelated private owner fact.

Expected: Jarvis does not reveal it. Shared information or information belonging to that speaker can still be used when appropriate.

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```
