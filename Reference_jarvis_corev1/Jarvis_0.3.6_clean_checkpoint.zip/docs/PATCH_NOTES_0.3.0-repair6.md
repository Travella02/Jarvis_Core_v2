# 0.3.0-repair6 — Hybrid Web Intelligence

This repair pivots 0.3.0 from browser-first research to a hybrid Web Intelligence + Browser Control architecture.

- Current-information and research requests use OpenAI Responses API `web_search` through Luna instead of driving Google through the Browser Bridge.
- Jarvis speaks a concise response-mode-sized summary and renders the grounded answer in a dedicated Web Intelligence card.
- Cards expose clickable inline citation markers and source rows backed by the source metadata returned by web search.
- Citation/source buttons are real clickable links: the desktop opens only HTTP(S) URLs returned in the grounded Web Intelligence result. Voice follow-ups such as “open the first source” use the cached result-scoped source id and Browser Bridge.
- Requests that explicitly ask Jarvis to open/show the researched source can hand the selected cited URL directly to Browser Control after research completes, and short follow-ups such as “show me that page” reuse the recent grounded result instead of researching again.
- Browser Control remains available for tabs, navigation, current-page reading, clicking, scrolling, media, forms, and other real browser interaction.
- Generic web research is routed before Browser Control; page-specific browser follow-ups remain in Browser Control.
- Natural interruption cancels in-flight Web Intelligence work just as it cancels autonomous browser work.
- Game Mode remains unchanged: structured web search and Browser Bridge DOM/tab actions do not emit synthetic input into protected games.

VERSION and release metadata remain unchanged until live acceptance passes.
