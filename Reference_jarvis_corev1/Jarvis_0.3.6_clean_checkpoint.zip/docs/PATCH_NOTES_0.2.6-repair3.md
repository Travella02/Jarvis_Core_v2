# 0.2.6-repair3 — Reliable App Control

## Symptom

During live acceptance, Jarvis began answering **“Opening Discord.”** almost immediately, but Discord did not actually appear. The previous repair also added aliases but did not let a user naturally revoke an alias once it was no longer wanted.

## Root cause

Windows can expose one visible application through several technical launch routes. A cached `Get-StartApps`/AppsFolder route can be accepted by Windows even when it does not reliably surface the underlying Win32 app. Because the earlier catalog treated each route as its own record, a learned person-specific alias could also remain attached to the weaker route instead of the best route for the same visible app.

The app memory UI likewise exposed technical routes independently and provided an Add alias control but no matching forget/remove control.

## Repair

- Treat identical visible app names as one logical application across technical Windows routes.
- Prefer reliable user-facing launch contracts when several routes exist: launcher URIs and Start Menu shortcuts outrank AppsFolder-only routes.
- Reject cached executable paths that are clearly updater/setup/helper executables rather than the user-facing application.
- If a cached AppsFolder route has not been verified, merge cheap registry/shortcut/game discovery before reusing it so a better route can take over without a deep PC scan.
- Share explicit per-person aliases across every route for the same logical application. This lets a learned alias follow the app when Jarvis discovers a better launch path later.
- Collapse duplicate technical routes in **Memory → Apps** so the user sees one logical app card with the preferred stored target.
- Add reversible aliases. Natural requests such as **“Jarvis, I no longer want group chat as a nickname for Discord”** remove only that person’s learned alias.
- Add a remove control beside person-specific aliases in **Memory → Apps**.
- Preserve genuine ambiguity between different visible applications; only duplicate routes for the same visible app are collapsed.

## Safety

Alias removal is scoped to the current person when a recognized actor is available. General generated app names remain intact, so forgetting a custom nickname cannot make Jarvis forget that Discord itself is Discord.

Jarvis still refuses to deep-discover arbitrary batch/command scripts as applications, and the existing safe close protections remain unchanged.

## Expected behavior

- `Open Discord` should route quickly and use the most reliable stored/discovered launch route.
- A previously cached low-reliability AppsFolder route should not prevent a Start Menu or launcher route from being selected.
- `Group chat is another name for Discord` should work regardless of which technical route is used later.
- `Jarvis, I no longer want group chat as a nickname for Discord` should forget that nickname for that person.
- Memory → Apps should show one Discord card rather than one card per Windows launch route.
