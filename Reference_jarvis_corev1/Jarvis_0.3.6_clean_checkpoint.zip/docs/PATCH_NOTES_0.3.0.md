# 0.3.0 — Web Intelligence

**Release date:** 2026-08-20  
**Required previous version:** 0.2.9 — Natural Interruption

## Purpose

0.3.0 makes Jarvis useful on the live web without forcing browser automation to act as the search engine. It adds grounded current-information research, freshness verification, sourced Web Intelligence cards, exact-source handoff into structured browser control, and natural browser/media continuation while preserving the Game Mode execution firewall.

## Accepted behavior

- Natural current-information questions route to grounded Web Intelligence even when the user does not explicitly say “search.”
- “Latest/current/newest” requests use adaptive freshness verification and first-party chronology checks when needed.
- Recently grounded exact queries can be reused briefly to reduce redundant API/search cost without turning current facts into permanent memory.
- Web Intelligence cards show a concise spoken answer plus a readable detailed result with deduplicated clickable sources and a working **View full result** control.
- Grounded sources can be opened in a new browser tab without overwriting a tab the user was already using.
- Direct browser commands such as opening a new tab, YouTube search, result-number playback, closest grounded title playback, pause/resume, and tab closing work structurally through the Browser Bridge.
- Browser/Web Intelligence workflows continue to work while Game Mode protects an active game.

## Known deferred work

- Structural browser media volume, mute, seeking, playback speed, and fullscreen are intentionally deferred to 0.3.1 Browser Control.
- Card visual design can continue to be polished in later releases without changing the Web Intelligence architecture.

## Acceptance

Live acceptance passed on 2026-08-20 after repair12. Search freshness, natural live-question routing, browser source handoff, YouTube result playback/title matching, pause/resume, and Web Intelligence card flows all passed; browser media volume remained the only deferred capability.
