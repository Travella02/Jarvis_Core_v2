# Testing 0.2.4-repair11 — Voice Independence

Start with the default OpenAI speech provider. Do not configure ElevenLabs until the baseline regressions pass.

## 1. Provider UI and baseline startup

Open **Controls → Audio**.

Expected:

- **Speech provider** is visible.
- **OpenAI** is selected by default.
- ElevenLabs is visible but disabled/not ready until local credentials and a voice ID are configured.
- Jarvis wakes, listens, and returns to Listening normally. It must not enter the repair10 **Attention needed** loop just because it needs to answer.

## 2. Grounded time regression — critical

Say:

`Is there anything I need to do tomorrow?`

Then:

`What time?`

Expected for the existing Call Tanner test reminder: **2 PM**. It must never become 8 PM.

Then ask:

`When will you remind me?`

Expected: still **2 PM**.

This verifies that Luna/Core and the fact guard own the exact words while the speech provider only renders them.

## 3. Gmail body-only continuation and real card

Say:

`Can you draft an email to Tanner?`

When Jarvis asks what it should say, answer naturally without repeating the action keywords, for example:

`Say hi, I was just wondering how you're doing. Please get back to me ASAP.`

Expected:

- the backend keeps the bounded Gmail clarification context;
- the real Gmail draft is created;
- the draft card appears with the existing edit/send controls;
- the draft remains unsent until explicit approval;
- Jarvis does not report that it could not route the request safely.

## 4. Failed clarification must not hijack later conversation

If a Connected Action continuation fails for any reason, immediately ask:

`What is the meaning of life?`

Expected: Jarvis treats it as ordinary conversation. It must not repeat a Google-routing error. The prior clarification route is one-shot and cannot capture unrelated future turns.

## 5. Normal voice and interruption

Have a normal conversation for a minute, including a short answer and a longer answer. Interrupt Jarvis during the longer response.

Expected:

- Luna owns the exact response wording;
- OpenAI speech only performs that text;
- interruption stops playback promptly and returns Jarvis to Listening;
- Short / Normal / High / Full still limit spoken depth as before.

## 6. Optional ElevenLabs setup

Only after the OpenAI baseline passes, add your own credentials locally to `.env`:

```env
ELEVENLABS_API_KEY=your_key_here
JARVIS_ELEVENLABS_VOICE_ID=your_voice_id_here
```

Optional overrides:

```env
JARVIS_ELEVENLABS_MODEL=eleven_v3
JARVIS_ELEVENLABS_OUTPUT_FORMAT=mp3_44100_128
```

`eleven_v3` is the quality-first default for this audition because the goal is to judge emotional/natural delivery. If its latency is too high for live conversation, try `eleven_flash_v2_5` as the lower-latency comparison without changing any Jarvis reasoning code.

Do **not** paste the API key into chat or commit it to Git.

Restart Jarvis, open **Controls → Audio**, and choose **ElevenLabs**.

Repeat a few of the same conversational lines used with OpenAI. Expected: the wording and grounded facts remain identical in meaning; only the rendered voice changes. Switch back to OpenAI from the selector to confirm provider changes do not alter Jarvis Core.

The ElevenLabs adapter is automated/mock-tested by the repair package. Real ElevenLabs audio requires the user's own key and voice ID, so live voice-quality acceptance happens on the user's machine.
