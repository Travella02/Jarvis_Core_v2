# Testing Guide — 0.1.6-repair4

## Apply

1. Close Jarvis completely.
2. Extract the repair ZIP directly into the `Jarvis_Real_Time` project root and allow files to merge/replace.
3. Run `py -3.12 apply_0_1_6_repair4_patch.py` from the project root.
4. Start Jarvis with `npm run desktop`.

## Test punctuated addressing

1. Wake Jarvis with your recognized voice.
2. Say: **“Jarvis, from now on, call me Boss.”**
3. Expected response: **“Got it, Boss.”**
4. Open Tanner in **Memory → Entities**.
5. Confirm **Boss** appears under **Preferred forms of address**, not under **Names and aliases**.
6. Sleep and wake Jarvis, then confirm the preference is still available.

## Test revocation

1. Say: **“Jarvis, don’t call me Boss anymore.”**
2. Expected response: **“I won’t call you Boss anymore.”**
3. Continue the conversation for several turns.
4. Jarvis must not use Boss again unless you add it again.
5. Reopen Tanner’s entity page and confirm **Preferred forms of address** says none active, or shows only the other names you kept.

## Test several names

1. Say: **“You can call me Boss, Chief, or Captain.”**
2. Confirm all three are stored as forms of address.
3. Say: **“Don’t call me Chief anymore.”**
4. Confirm Boss and Captain remain active while Chief is inactive.
5. Say: **“Just use my real name.”**
6. Confirm all special forms are cleared without changing Tanner’s canonical identity.

## Test live response modes

Keep Jarvis awake while performing this test.

1. Select **Test** and ask for an explanation of a moderately detailed topic.
2. Confirm the reply is one brief sentence and no more than the configured Test limit.
3. Select **Short** and ask a similar question; confirm the answer can be longer than Test but remains brief.
4. Select **Normal**, then **High**, and repeat with the same prompt.
5. Select **Full** and explicitly ask for a detailed answer; confirm it is no longer constrained to the shorter profiles.
6. Confirm the UI reports that the newly selected mode is active immediately; no sleep/wake cycle should be required.

## Test cleared proactive items

1. Open **Memory → Proactive Memory** and dismiss or complete a test follow-up item.
2. Open the related person or entity page.
3. Confirm the item disappears from **Open items** immediately.
4. Run memory consolidation or restart Jarvis.
5. Confirm the terminal item does not return.
6. Reopen the item and confirm it becomes active again.

## Regression checks

- Identity questions remain short and human.
- Likely matches say **“You sound like…”** rather than describing the recognizer.
- Unknown-speaker enrollment still opens Voice Profiles after approval.
- Silent sleep still creates no assistant text or audio.
- Exact source events remain in the timeline after a proactive item is dismissed.
- The installer does not modify `.env` or user memory data.
