# 0.1.4 — Proactive Memory

Jarvis now turns consolidated memory into restrained, explainable follow-through without taking external action on the user's behalf.

## Added

- Local proactive-memory engine for confirmed commitments, possible tasks, pending replies, active goals, decisions, deadlines, and tentative routine patterns.
- Memory schema version 4 with durable proactive items, evidence links, lifecycle history, and refresh-run records.
- Priority scoring based on source confidence, urgency, due dates, active projects, importance, and recency.
- Subject-aware relevant recall with cooldowns so useful memories can surface without repeating constantly.
- Completion detection from later user-authored evidence.
- Explicit lifecycle controls: complete, reopen, snooze, dismiss, and inspect why an item exists.
- Proactive Memory workspace with inbox, filters, priority display, evidence explanations, and manual refresh.
- Home overview showing current high-priority follow-through.
- Local background refresh and Realtime context integration.
- Configurable thresholds and intervals through private `.env` values.

## Safety and trust contracts

- Original memory events remain immutable evidence.
- Inferences are labeled separately from confirmed commitments.
- Jarvis does not silently send messages, file documents, spend money, or perform other external actions.
- Every proactive item retains source evidence and can explain why it was surfaced.
- Cooldowns, priority thresholds, snoozing, and dismissal prevent constant interruption.
- Pattern detection remains unconfirmed until the user accepts it.

## Database migration

Existing databases migrate in place to schema version 4. Existing events, facts, entities, consolidation history, aliases, and corrections are preserved.
