# Testing Guide — 0.0.5 Desktop Stability Repair

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
npm run desktop:check
```

## Live acceptance

1. Launch with `npm run desktop`.
2. Confirm the window fits fully inside the laptop work area without maximizing it.
3. Stay silent for at least 30 seconds. Jarvis must remain asleep and no wake transcription should be recorded.
4. Create ordinary room noise without speaking. Jarvis should remain asleep.
5. Say “Jarvis.” Confirm exactly one acknowledgement response.
6. Return to sleep and say “Jarvis, tell me a short joke.” Confirm exactly one user opening and one Jarvis answer.
7. While the opening answer plays, remain silent. Confirm no phantom `Voice input` turn appears.
8. Ask a normal follow-up and confirm the microphone becomes active only after the opening response finishes.
9. Click the window close button while Jarvis is awake. Confirm the window, Electron process, Python core, audio, and speech all stop.
10. Relaunch, choose **Hide Jarvis** from the tray, and confirm this explicit action keeps the app in the background.
11. Quit from the tray and confirm every Jarvis process ends.
12. Move/resize the window, relaunch, and confirm restored bounds still fit entirely on screen.

## Acceptance boundary

Do not commit `0.0.5` until false wakes are absent during a quiet/noise test, opening requests produce one response, close fully quits, and the initial window fits the laptop display.
