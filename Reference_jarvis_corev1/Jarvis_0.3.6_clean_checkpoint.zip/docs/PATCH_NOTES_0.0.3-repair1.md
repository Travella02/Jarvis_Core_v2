# 0.0.3 — Environment Repair

## Summary

Repairs fresh-computer setup for `0.0.3 — Wake Detection`. A Git clone now has a supported path to create or repair its local virtual environment, install the dependencies declared by the project, and validate the complete runtime before live testing.

## Fixed

- Fresh laptop virtual environments could exist without FastAPI, HTTPX, or Uvicorn.
- The update installer assumed runtime dependencies were already installed on the current computer.
- `python -m apps.core --diagnostic` imported Uvicorn and the FastAPI server before checking diagnostic mode.
- The doctor reported missing packages but did not provide the exact repair command.
- Missing imports reduced the number of discovered tests and made source-state failures appear more severe than they were.

## Added

- `scripts/ensure_environment.py` for repeatable per-computer dependency setup.
- Automatic `.venv` creation and dependency installation in the repair installer.
- Lazy server imports so the safe diagnostic works without site-packages.
- Issue record `ISSUE_011_FRESH_LAPTOP_VENV_DEPENDENCIES.md`.
- Regression tests for dependency detection and dependency-free diagnostic startup.

## Versioning

The project version remains `0.0.3` because this repair corrects the unaccepted Wake Detection update rather than adding the next product milestone.
