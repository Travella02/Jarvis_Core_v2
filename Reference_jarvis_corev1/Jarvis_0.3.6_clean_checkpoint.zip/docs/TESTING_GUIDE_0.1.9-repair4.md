# Testing Guide — 0.1.9-repair4

## 1. Natural open-work answer

Ask:

> What are we still working on for the business?

Expected:

- Jarvis resolves the business correctly.
- He gives one direct answer without “let me think,” an audit explanation, or an execution disclaimer.
- No detailed companion or Fullscreen control appears unless you explicitly ask for a detailed breakdown.

## 2. Humanized relationship recall

Ask:

> What do you remember about my fiancée?

Expected:

- Jarvis states the remembered relationship directly.
- He does not say “I remember you mentioning,” “I can’t verify,” or describe confidence.

Then ask:

> How do you know that?

Expected:

- One short natural source sentence, such as “You told me in a voice conversation on August 3, 2026.”
- No “that’s the evidence,” “not a guess,” or reliability disclaimer.

## 3. Decision-only recall

Ask:

> What did we decide about the company?

Expected:

- Jarvis answers with the actual decision to register the company as an LLC.
- He does not mix in goals, trademark tasks, website work, or generic capability limitations.

## 4. Underspecified correction history

Ask:

> What was the old value before I corrected it?

Expected:

- Jarvis asks only: “Which correction do you mean?”
- No partial answer, second paragraph, detailed companion, or Fullscreen control appears.

After naming the correction, Jarvis may answer from preserved history.

## 5. Reader gating

Ask a memory question that produces a medium written answer which fully fits in the card.

Expected:

- No Fullscreen control.

Then ask:

> Explain thermodynamics in detail.

Expected in Test, Short, Normal, or High mode:

- One spoken summary.
- One complete written answer.
- The preview fades and Fullscreen appears only when text is actually hidden.

Expected in Full mode:

- One complete Realtime response without the separate detailed companion.
