# Testing Guide — 0.0.3 Wake Acknowledgement Repair

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Start Jarvis and hard-refresh the Voice Lab once.
2. Confirm Jarvis is sleeping and the wake listener is armed.
3. Say only **“Jarvis.”**
4. Confirm Jarvis wakes and gives one short acknowledgement such as **“Yes, sir?”**
5. Confirm no `YOU` bubble containing hidden acknowledgement instructions appears.
6. Speak a normal request immediately after the acknowledgement and confirm Jarvis hears it.
7. Repeat the wake-only test at least five times.
8. Put Jarvis back to sleep and say **“Hey Jarvis, tell me a joke.”** Confirm the complete natural request still produces one answer.
9. Confirm no extra `Processing speech...` bubble or duplicate response appears.
10. Confirm Jarvis speaking time, response count, cost estimate, interruption, and idle sleep still work.

Do not commit `0.0.3` until both wake-only acknowledgement and full natural wake requests behave reliably.
