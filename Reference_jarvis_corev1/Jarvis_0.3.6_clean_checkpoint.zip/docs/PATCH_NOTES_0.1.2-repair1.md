# 0.1.2-repair1 — Voice Memory Navigation

Connects natural spoken and typed “show/open memory” requests to the Memory Explorer interface instead of limiting Jarvis to a verbal answer.

## What changed

- Added a deterministic local intent parser for visual memory commands.
- Commands such as “Show me everything about ORVEX” now open the Memory workspace automatically.
- Specific subjects resolve to an entity page when a matching entity exists.
- Speaker, date, and broader requests open the filtered exact-event timeline.
- Wake requests use the same path because preserved wake prompts flow through the typed-turn dispatcher.
- Existing Memory Explorer filters are cleared before a new spoken navigation request so stale filters do not hide results.
- Verbal recall questions such as “What do you know about ORVEX?” remain conversation-only and do not unexpectedly move the interface.
- Realtime instructions now tell Jarvis that the local desktop handles the visual display, preventing misleading claims that memories cannot be shown.

## Examples

- “Show me everything about ORVEX.” → opens the ORVEX entity page when available.
- “Show me what Kenleigh said about the business.” → opens a filtered timeline.
- “Open my memories from yesterday.” → opens Memory Explorer with the natural-language query applied.
- “What do you know about ORVEX?” → answers verbally without moving the interface.

## Safety and privacy

The repair does not create a cloud-side memory browser or send additional memory records to a new service. Navigation and entity matching run locally against the existing loopback Memory Explorer API.

## Validation

- 187 Python tests passed.
- 30 Node tests passed.
- JavaScript and Electron syntax checks passed.
- Desktop runtime staging includes the new local navigation parser.
- Patch installation and safe reapplication were validated.
