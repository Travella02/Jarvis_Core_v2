# Testing Guide — 0.0.8 Interface Foundation

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Interface acceptance

1. Launch with `npm run desktop` and confirm Jarvis opens on Home.
2. Confirm the orb is muted while Sleeping.
3. Wake Jarvis and verify the orb passes through Waking/Connecting into Listening.
4. Speak a request and verify Thinking and Speaking states are visually distinct.
5. Confirm Wake, Sleep, and Stop buttons beside the orb mirror the Controls workspace.
6. Switch between Home, Controls, Insights, and System; restart Jarvis and confirm the last workspace is restored.
7. Enter Focus mode and confirm the conversation uses the full window. Press Escape to exit.
8. Confirm awake duration, connection state, session cost, and wake latency mirror the authoritative Insights metrics.
9. Resize to a laptop-sized window and confirm no panel extends beyond the window.
10. Verify simulation, live voice, interruption, silent spoken sleep, tray behavior, X-to-quit, budgets, and core recovery still work.

## Acceptance boundary

Commit only after the new interface remains responsive and every existing voice-lifecycle behavior works without regression.
