# Testing Guide — 0.0.2 Voice Control Repair 1

## Install

Stop the running Voice Lab with `Ctrl+C`. Extract the repair archive into the `Jarvis_Real_Time` project root and allow `patch_files` to merge. Then run:

```powershell
py -3.12 apply_0_0_2_repair1_patch.py
```

The installer verifies the current `0.0.2` files, backs up replacements, preserves `.env`, runs all automated tests, validates JavaScript when Node is available, runs the doctor and safe diagnostic, and rolls back on failure.

## Automated tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Expected summary:

```text
Ran 46 tests
OK
```

## Doctor

```powershell
.\.venv\Scripts\python.exe scripts\doctor.py
```

Expected configuration lines include:

```text
Version: 0.0.2
Voice: cedar
Turn detection: provider_default
Session safety limit: 55 minutes
```

A locally configured semantic profile may replace `provider_default` in that output.

## Start command

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

## Manual acceptance — typed parity

1. Wake Jarvis and wait until the session is connected.
2. Type a short message and press Send once.
3. Confirm one `YOU` bubble appears, not two.
4. Confirm Jarvis produces one response.
5. Send the same exact text again as a deliberate second turn; confirm one new bubble appears for that second submit.
6. Rapidly double-click Send on a third message; confirm the UI does not create two overlapping submits.
7. Confirm the Provider Events panel may show the provider item acknowledgement without creating another transcript bubble.

## Manual acceptance — turn detection

1. Select **Provider default (recommended)**.
2. Disconnect and wake Jarvis again so the profile applies to the new session.
3. Speak several normal sentences and confirm Jarvis begins responding promptly after you finish.
4. Pause briefly mid-thought and observe whether the provider default fits your cadence.
5. Optionally compare **Semantic — auto**, **Semantic — medium**, **Semantic — high**, and **Semantic — low**. Each change requires a new session.
6. Return to **Provider default (recommended)** unless a semantic profile performs measurably better.

## Expected result

Typed input appears once, receives one response, and remains visually synchronized with provider events. Provider-default turn detection should feel similar to the original working Realtime behavior before low semantic VAD was forced.

## Common symptoms

- **The old low profile is still selected:** Refresh the page. This repair uses a new preference version and should select provider default while preserving voice and devices.
- **Doctor reports a semantic profile:** Check `.env` for `JARVIS_TURN_DETECTION_PROFILE`.
- **Typed message still duplicates:** Hard-refresh the page with `Ctrl+F5` to replace cached JavaScript, then retest.
- **Connection fails:** Save the safe error text and provider event names; never include `.env` or the API key.

## Cleanup after acceptance

```powershell
Remove-Item apply_*.py -Force
Remove-Item patch_files -Recurse -Force
```

Then commit the accepted `0.0.2` update and repair together.
