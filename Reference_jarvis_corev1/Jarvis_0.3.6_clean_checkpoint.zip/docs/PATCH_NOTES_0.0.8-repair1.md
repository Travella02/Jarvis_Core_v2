# 0.0.8 — Orb State Repair

## Summary

Stabilizes the Interface Foundation orb so brief provider and audio-playback timing differences do not make it flicker between Speaking and Listening. Legitimate state changes now settle through gradual visual transitions rather than hard color and glow changes.

## Changes

- Added a presentation-only state coordinator behind `setStatus()`.
- Added cancellable Speaking-to-Listening hysteresis.
- Kept real user interruption and speech-start transitions immediate.
- Added a short transient Thinking-to-Listening debounce.
- Added smooth orb, ring, halo, core, status-dot, and state-copy transitions.
- Preserved reduced-motion accessibility.
- Added recruiter-facing issue record `ISSUE_049_ORB_STATE_FLICKER_AND_HARD_TRANSITIONS.md`.

## Compatibility

The Python core, WebRTC transport, wake flow, silent sleep, cost controls, Desktop Presence, and operational state machine are unchanged. The repair affects only renderer presentation stability.
