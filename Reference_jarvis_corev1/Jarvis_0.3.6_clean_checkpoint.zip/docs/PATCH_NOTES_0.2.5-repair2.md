# 0.2.5-repair2 — Speaker Labels

## What changed
This live-acceptance repair makes multi-speaker transcript attribution consistent from the very first turn.

- A preserved wake request now uses the already-resolved local speaker identity when its user bubble is created.
- Typed local turns also use the local person's current display/preferred name rather than a generic `YOU` label.
- Live microphone turns still begin conservatively while recognition is pending, then relabel to the resolved person as soon as recognition completes.
- The generic user fallback is now `Unknown speaker`, not `YOU`, so unresolved speakers remain neutral in multi-speaker mode.
- Owner/admin/account roles remain separate from the human display identity and are never substituted for the speaker name.

## Why
0.2.5-repair1 correctly repaired the local human identity and voice recognition, but the opening wake request used an older transcript-rendering path that never applied the resolved speaker label. That made one known person appear as `YOU` on the first turn and by name on later turns.

## Scope
This is intentionally a presentation/attribution repair. It does not change voice embeddings, identity thresholds, durable memory, Connected Actions, speech providers, response modes, or the 0.2.5 multi-speaker privacy model.
