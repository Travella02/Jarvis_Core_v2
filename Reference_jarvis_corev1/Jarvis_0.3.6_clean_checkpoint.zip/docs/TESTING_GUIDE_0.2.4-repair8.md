# Testing Guide — 0.2.4-repair8 Expressive Speech

## Install

Close Jarvis and extract the repair ZIP directly into the current `0.2.4-repair7` project root, allowing Windows to merge/replace files.

Run:

```powershell
py -3.12 .\apply_0_2_4_repair8_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```

No Google reconnect, `.env` edit, task recreation, memory reset, or manual repair-file cleanup is required.

## Test 1 — Protect the repair7 truth fix

Ask:

> Is there anything I need to do tomorrow?

Then:

> What time?

For the existing Call Tanner reminder, the answer must still resolve to **2 PM**, never 8 PM.

Then ask:

> When will you remind me?

It must still resolve to **2 PM**.

## Test 2 — Short-answer voice quality

Have Jarvis give several very short replies such as:

> What time?

> Are you listening?

> Did that work?

Listen specifically for the repair7 problem: the voice should no longer sound consistently monotone, clipped, or like a status readout. Short replies should have a small natural rise/fall and meaning-driven emphasis without sounding exaggerated.

## Test 3 — Normal conversation

Talk to Jarvis naturally for a minute or two. Good signs:

- sentence pitch and rhythm change instead of repeating the same melody;
- pauses happen around ideas rather than at equal mechanical intervals;
- longer replies do not sound like a narrator reading a document;
- conversational statements finish naturally instead of with the same flat ending every time.

## Test 4 — Personality delivery

Under **Controls → Audio → Personality**, compare at least:

- **Classic** — composed and intelligent, but alive rather than restrained;
- **Casual** — looser timing and more conversational cadence;
- **Warm** — more personable vocal engagement.

The words may differ because Luna owns personality wording, but factual values must not change.

## Test 5 — Response modes

Try **Short**, **Normal**, and **High**. Confirm that response mode changes how much Jarvis says, not whether his voice has emotion. A Short response should not become robotic just because it is brief.

## Test 6 — Interruption

Ask for a longer answer and interrupt Jarvis while Cedar is speaking. Audio should stop promptly and Jarvis should return to listening without overlapping responses.

## Pass criteria

Repair8 passes if:

1. the 2 PM grounded-time path remains correct;
2. no factual regression appears;
3. interruption still works;
4. Cedar sounds noticeably less monotone/robotic than repair7;
5. personality differences affect delivery naturally without becoming theatrical;
6. Short/Normal/High/Full remain response-depth controls.
