# Testing Guide — 0.1.2-repair2 Reliable Memory Navigation & Response Profiles

## Start

Close Jarvis, extract the patch directly into the project root, then run:

```powershell
py -3.12 apply_0_1_2_repair2_patch.py
npm run desktop
```

A Windows reinstall is not required for this acceptance test.

## Visual memory navigation

1. Say: “Jarvis, show me everything about ORVEX.”
   - The interface should switch from Home to Memory.
   - The ORVEX entity page should open when that entity exists.
   - Jarvis should give only a brief acknowledgement or summary.
2. Intentionally say a close variation such as: “Show me everything about Orvix.”
   - The existing ORVEX entity should still resolve when it is the clear close match.
3. Type: “Open my memories.”
   - Memory Explorer should open without adding a false subject filter.
4. Say: “Show me what I told you yesterday.”
   - Memory should open to a filtered timeline.
5. Ask: “What do you know about ORVEX?”
   - Jarvis should answer verbally without forcing a workspace change.
6. Ask: “Show me a picture of a spaceship.”
   - Memory Explorer should not open.

## Response-profile controls

The five response modes are Test, Short, Normal, Medium, and Full.

1. Open Controls and confirm these five options exist: Test, Short, Normal, Medium, Full.
2. Each option should show its approximate word target and token ceiling or model maximum.
3. Select Short, start a fresh awake session, and ask for an explanation.
   - The response should be noticeably shorter than Medium or Full.
4. Select Medium, begin a new session, and ask the same question.
   - Jarvis should provide more detail and finish the final sentence.
5. Test mode should still support automatic sleep after one response when enabled.

Response mode is fixed when a Realtime session starts. Sleep and wake Jarvis, or restart the development app, after changing the profile.

## Custom `.env` test

The patch does not replace the private `.env`. Copy any settings you want to customize from `.env.example` into `.env`, for example the pair belonging to one mode. Use whole numbers only.

- `TARGET_WORDS=0` means adaptive detail.
- `MAX_OUTPUT_TOKENS=0` means the model-supported maximum.

Restart Jarvis after editing `.env`, then verify the Controls label reflects the resolved values.

## Regression checks

- Ordinary typed and voice conversation appears once.
- Wake request preservation, interruption, and sleep remain functional.
- Memory capture, search, timeline, entity pages, provenance, corrections, deletion, undo, summaries, and exports still work.
- Close and reopen Jarvis; local memories and private configuration remain available.
