# 0.0.5 — Electron Shell Repair 2

## Summary

Allows the Electron Shell installer to preserve legitimate local `.gitignore` rules while adding only the Jarvis and Electron exclusions that are missing.

## Fixed

- Removed exact-baseline validation for `.gitignore` only.
- Added additive `.gitignore` merging instead of whole-file replacement.
- Preserved user comments and custom ignore rules.
- Continued protecting normal source files with strict conflict detection.
- Added backup and idempotency coverage for the merged control file.

## Safety

The installer still requires `.git`, `.venv`, the accepted project version, verified payload checksums, and known baselines for normal source files. `.env` is never read, printed, copied, or replaced.

## Validation

- 80 automated tests passed.
- Customized `.gitignore` installation passed.
- CRLF input passed.
- Idempotent rerun passed with zero changed project files.
- `.env` remained byte-for-byte unchanged.
