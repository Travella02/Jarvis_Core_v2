# 0.3.1-repair3 Live Test

Use one already-playing YouTube video with another unrelated browser tab open.

1. `Pause YouTube.`
2. `Keep playing.` — video resumes; Jarvis should stay silent.
3. `Pause YouTube.`
4. `Play YouTube.` — same video resumes; Jarvis should stay silent.
5. `Start it over.` — same video moves to the beginning and resumes; Jarvis should stay silent.
6. `Go forward half a minute.` then `Rewind the video ten seconds.`
7. `Put it back to normal speed.`
8. `What are the latest updates in Rocket League?` — Web Intelligence should remain unchanged.

If the physical media action succeeds but Jarvis still says it could not verify the result, capture the terminal plus the conversation before continuing.
