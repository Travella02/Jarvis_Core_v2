# 0.2.5-repair1 — Owner Identity

## Why this repair exists
0.2.5 multi-speaker attribution correctly recognized the enrolled local voice, but a legacy memory shape could label that person `Local Owner` instead of their real name. The role and the person identity had become conflated.

## What changed
- **Human identity and account role are separate.** `Local Owner` / `Local User` are treated as owner-role placeholders, not durable preferred names once Jarvis already has a stronger person identity.
- **Conservative startup repair.** A generic local-owner root is repaired only when existing local evidence already identifies the human: an exact alias match to a named person or a previously merged human member.
- **Owner permissions survive.** The repaired person remains `is_local_user`, `relationship_to_owner=self`, `access_scope=owner`, trusted, and permanent.
- **No name regression on restart.** A `.env` value such as `JARVIS_LOCAL_USER_NAME=Local Owner` can remain as a generic configuration label without overwriting the recovered person's preferred/display name.
- **Fresh voice labels.** Voice recognition now reads the current preferred/display name from durable person memory instead of trusting a potentially stale label stored when the voice was enrolled.
- **Luna receives role context separately.** When a saved voice profile proves the speaker is the local owner, Luna sees that privately as an account relationship and is explicitly told never to use `local owner` as the person's name.
- **Generalized defaults.** Production fallbacks no longer hardcode a current test user's name; neutral `Local User` is used when no real identity is known.

## What did not change
- Unknown speakers remain neutral and Jarvis still does not infer `sir`/`ma'am` or gender.
- Session speaker bindings remain conversational identity hints, not biometric authentication.
- Existing Voice Profile samples, memory, Google OAuth, tasks/reminders, `.env`, and speech-provider settings are preserved.
- 0.2.5 alternating-speaker behavior and speaker-scoped Connected Action context remain intact.

## Validation
- 501/501 Python tests passed (run in deterministic file groups because the monolithic runner exceeds the sandbox execution window).
- `npm run desktop:check` passed.
- Node: 87/91 passed; the same four unchanged Electron packaging tests are blocked because this source workspace does not contain `@electron/packager` development modules.
- Migration was exercised against the actual legacy memory shape present in the uploaded 0.2.5 project copy: `Local Owner` remained the owner role while the effective person/voice name became the existing human identity and stayed repaired after reopening.
