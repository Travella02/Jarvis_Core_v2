# Testing Guide — 0.2.0-repair2

## Primary acceptance test

1. Connect Google and wake Jarvis.
2. Say: “Summarize my five most recent unread emails.”
3. Confirm the conversation contains only the real transcript. No separate `Voice message` bubble should appear.
4. Jarvis should speak an actual email summary, not only “Sure” or “Okay.”
5. One stable Jarvis result card should remain visible. It must not disappear when speech ends or when Test mode later sleeps.

## Additional checks

- Repeat the unread-email request three times and confirm one user transcript and one Jarvis result per turn.
- Interrupt Jarvis while he is speaking. The written Gmail result should remain visible.
- Ask “What’s on my calendar tomorrow?” and confirm the same stable delivery behavior.
- In Test mode with auto-sleep enabled, confirm the completed answer remains in the transcript after Jarvis sleeps.
- In Short or Normal mode, confirm Jarvis stays awake while Luna and Google are still processing.
- Say only “Hey Jarvis,” then make the request after the acknowledgement. No phantom user bubble should appear between the two turns.

## Regression checks

- Normal non-action questions still use the existing conversation path.
- Draft creation still does not send mail.
- Sending and calendar writes still follow their confirmation rules.
- Voice interruption, sleep, wake, memory, and response modes continue to work.
