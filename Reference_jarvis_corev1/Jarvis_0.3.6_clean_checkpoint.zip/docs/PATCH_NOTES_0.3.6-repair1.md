# 0.3.6-repair1 — Windows Hygiene Startup

**Date:** 2026-09-02  
**Required previous version:** `0.3.6` live candidate  
**Application version remains:** `0.3.6`  
**Status:** Live-acceptance repair candidate

## Purpose

Repair the Windows-only startup ordering issue found during the first real 0.3.6 launch without weakening Phase 4 Sensitive Data Hygiene.

The base 0.3.6 candidate opened `logs/core.log` through `logging.FileHandler` before the one-time legacy hygiene migration attempted its atomic replacement. Windows could reject that replacement with `WinError 5` because the destination log was already open.

## What changed

- The normal Core entry point runs the bounded legacy sensitive-data cleanup before opening any durable Core logging handle.
- `create_app()` still performs cleanup by default for alternate/embedded entry points.
- Normal desktop-owned startup disables only the redundant second `create_app()` cleanup pass because the migration has already been attempted before logging starts.
- A failed pre-log cleanup remains fail-safe for future retry: its marker is not written, Core continues to start, and the warning is redacted.
- Atomic file replacement is retained. The repair does not skip `core.log`, mark an incomplete migration as successful, or rewrite the active file unsafely in place.

## Files materially changed

- `apps/core/__main__.py`
- `apps/core/server.py`
- `tests/test_runtime_entry.py`
- `docs/TESTING_GUIDE_0.3.6.md`
- repair notes/testing/handoff/manifest
- ISSUE-323 and issue index

## Security notes

This was a legacy-migration completion bug, not evidence that new 0.3.6 log writes are persisting raw secrets. New Core file logging is already protected by `SensitiveDataFormatter`. The repair ensures the old pre-0.3.6 contents of the same file can be atomically sanitized on Windows before the logger takes ownership of it.

The strongest fix is ordering, not bypass. We intentionally did **not** weaken the hygiene migration by ignoring a locked log or declaring the migration complete after a partial pass.

## Acceptance state

Do not commit yet. Apply repair1 over the currently installed 0.3.6 candidate, rerun the targeted checks, confirm the Windows warning is gone, then continue the full 0.3.6 live Permissions & Security guide. Any further pre-acceptance fix becomes `0.3.6-repair2`. No Git tag.
