# 0.3.0-repair2 — Browser Bridge Runtime

Browser Access itself was routing correctly, but the local Uvicorn server had no installed WebSocket protocol implementation in the `.venv` used by the desktop app. The extension therefore could not upgrade `/api/browser/ws` and remained disconnected.

This repair adds WebSockets as an explicit project/runtime dependency, updates bootstrap/doctor/embedded-runtime validation, and installs the dependency into the exact development Python runtime used by Electron. Browser automation behavior, Game Mode, Natural Interruption, memory, `.env`, `data/`, and release metadata are otherwise unchanged.
