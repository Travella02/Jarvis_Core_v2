# 0.2.5-repair1 — Live testing

Continue from the exact test that failed. You do not need to recreate your Voice Profile.

## 1. Owner identity regression
Use the same enrolled owner's voice and say:

**“Jarvis, who am I?”**

Expected:
- The human bubble uses your known person name, not `Local Owner`.
- Jarvis answers with your known name, not `Local Owner`.
- Jarvis does not say that `Local Owner` is your name.

## 2. Owner role separation
Ask naturally:

**“Am I the local owner?”**

Expected:
- Jarvis can understand that the recognized person is the local account owner.
- It treats that as a role/account relationship separate from the person's name.
- It does not rename the person to `Local Owner`.

## 3. Restart persistence
Close Jarvis completely, start it again, and repeat:

**“Who am I?”**

Expected: the real person name remains; the generic `.env` owner label does not overwrite it on restart.

## 4. Continue the 0.2.5 multi-speaker test
Have a second known enrolled person speak, then switch back to the owner.

Expected:
- Each known speaker gets their own real person name.
- Switching speakers does not collapse either person into `Local Owner`.

Then have an unknown speaker ask:

**“Who am I?”**

Expected:
- Jarvis stays neutral and asks what to call them if identity matters.
- No automatic `sir`, `ma'am`, gender, or owner-role assumption.

## 5. Quick 0.2.4 regression
Ask one grounded task/reminder time question and perform one Gmail draft continuation.

Expected:
- Grounded times remain correct.
- Gmail continuation still produces the actual draft/card.
- Jarvis returns to normal conversation afterward.
