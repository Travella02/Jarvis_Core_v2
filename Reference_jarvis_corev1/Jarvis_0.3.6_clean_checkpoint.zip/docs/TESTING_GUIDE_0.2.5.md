# Testing 0.2.5 — Multi-Speaker Intelligence

Use two people if possible. This acceptance pass tests alternating speakers, not two people talking over each other at the same instant.

## 1. Known speaker attribution

Have a person with an existing Voice Profile say:

> Jarvis, what do I have tomorrow?

Expected:
- The user bubble changes from `YOU`/`LISTENING` to that person's name after recognition.
- Jarvis uses that person's context/preferences only.

## 2. Unknown second speaker stays neutral

Have a different person with no Voice Profile say:

> What about me?

Expected:
- Jarvis does not call them `sir`, `ma'am`, or guess their identity.
- Jarvis asks what it should call them.
- Their bubble is shown as a temporary `Guest N`/unknown speaker rather than the first person's name.

## 3. Name and preferred address

The second speaker says:

> I'm Alex.

Expected: Jarvis binds that temporary live speaker lane to Alex for this conversation and asks what Alex would like to be called.

Then say one of:

> Just call me Alex.

or

> You can call me Captain.

Expected:
- The explicit preference is saved on Alex's person profile.
- Jarvis confirms naturally and may offer to remember Alex's voice for next time.
- It does not create a permanent Voice Profile unless Alex explicitly accepts enrollment.

## 4. Switch back and forth

Have the first speaker talk again, then Alex, then the first speaker.

Expected:
- Transcript labels follow the person who actually spoke.
- Forms of address do not bleed between people.
- First-person memory/context from one speaker is not presented as belonging to the other.

## 5. Connected Action isolation

Speaker A starts:

> Draft an email to Tanner.

When Jarvis asks what it should say, Speaker B instead asks an unrelated question.

Expected:
- Speaker B's turn does not become Speaker A's email body.
- Speaker B receives a normal answer.
- Speaker-specific Gmail/Calendar/task clarification state is reset/separated on the switch.

## 6. Session-only privacy boundary

If Alex declines Voice Profile enrollment, restart Jarvis and speak as Alex again.

Expected: Jarvis does not claim permanent voice recognition from the prior temporary session. Alex can identify themselves again, or explicitly enroll a Voice Profile for future recognition.

If Alex explicitly enrolls a Voice Profile, restart and test again; then cross-session recognition should use that saved profile.

## 7. Existing regression checks

Also verify:
- Grounded task/reminder times remain correct (the prior `2 PM` regression must not return).
- Gmail drafts still create the real draft card and require explicit send confirmation.
- Sleep/wake and interruption still work.
- Short / Normal / High / Full remain spoken-length ceilings rather than changes to reasoning depth.

## Known limitation

Do not fail 0.2.5 because simultaneous overlapping voices are not separated. Overlapping-speech diarization is deliberately out of scope for this release.
