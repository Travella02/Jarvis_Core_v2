# 0.0.9 — Conversation Viewport Repair

## Summary

This repair fixes the Home conversation panel growing with every new message. The Home row now has a viewport-bounded height, the conversation card keeps a stable footprint, and the transcript owns its own vertical scrollbar.

## Fixed

- The conversation card no longer expands the entire Home workspace as messages accumulate.
- The transcript area now shrinks correctly inside the flex layout and scrolls internally.
- The message composer remains anchored at the bottom of the card.
- The Jump to latest behavior now operates inside a reliably bounded scroll container.
- Desktop and laptop layouts use responsive height clamps.
- Narrow single-column layouts retain a practical standalone conversation height.
- Compact layouts no longer reintroduce a transcript minimum height that can force the card to grow.

## Preserved

- Smart follow mode still respects manual reader position.
- Streaming responses do not force the reader to the bottom after scrolling upward.
- Conversation, Balanced, Presence, and Focus layouts remain available.
- Wake, Realtime voice, interruption, silent sleep, costs, tray lifecycle, and orb state handling are unchanged.
