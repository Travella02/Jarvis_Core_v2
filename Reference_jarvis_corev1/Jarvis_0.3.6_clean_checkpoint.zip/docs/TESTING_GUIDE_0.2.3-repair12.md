# Testing Guide — 0.2.3-repair12

## Primary cancellation test

Have exactly one disposable meeting tomorrow, then say:

> Can you cancel my meeting tomorrow?

Expected:

- Jarvis does **not** ask which meeting if only one exists.
- Jarvis does **not** say he cannot access Calendar.
- One **Remove Calendar Event** proposal is shown.
- The real Google event still exists until confirmation.

Then say:

> Yes, cancel it.

Expected: the exact meeting is removed once.

## Context test

Ask Jarvis to show tomorrow’s Calendar event, then say:

> Cancel that, please.

Expected: the request stays in Calendar Intelligence and produces the deletion confirmation. It must not produce a memory error such as “I couldn’t find a matching memory.”

## Selection-language regression

If multiple meetings exist and Jarvis asks which one, natural answers such as:

> The one with Tanner.

or

> The only one that exists.

must stay in Connected Actions rather than ordinary Realtime.

## Time-truth regression

Ask:

> What do I have on my calendar tomorrow?

The time Jarvis says must match the Calendar card and the user’s local Calendar wall clock.
