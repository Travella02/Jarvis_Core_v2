# 0.1.1-repair1 — Conversation Continuity

Repairs the two acceptance issues found in Total Recall's first live voice test: noisy transcript bubbles and spoken responses ending mid-sentence.

## Conversation transcript cleanup

- Keeps each voice-turn bubble linked to its pending provider transcript while speech recognition finishes.
- Reconciles late transcripts into the original bubble rather than creating a second user message.
- Delays the transcript-unavailable fallback for 2.5 seconds and labels a truly unavailable turn `Voice message`.
- Deduplicates completed transcript events by provider item ID.
- Suppresses the private input-transcription guidance sentence before it can appear in chat, trigger lifecycle handling, or enter durable memory.
- Clears pending transcript timers during connection cleanup.

## Complete spoken responses

- Normal mode now sends `max_output_tokens: "inf"`, allowing the model's supported maximum rather than Jarvis's former 384-token artificial cap.
- Full mode also uses the model maximum.
- Normal mode remains instructed to answer simple requests naturally in one to three concise sentences.
- Test mode remains capped at 96 tokens for inexpensive regression testing.

## Compatibility

- Project version remains `0.1.1` because this is a repair to the unaccepted Total Recall update.
- No database migration is required.
- Existing memories are preserved.
- No Windows reinstall is required for development testing.
