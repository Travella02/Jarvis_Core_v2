# Testing Guide — 0.3.0 Web Intelligence

## Start Jarvis

```powershell
npm run desktop
```

## Quick release checks

1. Ask **“What are the latest updates in Rocket League?”**  
   Expected: Web Intelligence runs automatically and identifies Rocket League patch v2.72 from August 4, 2026 with grounded sources.
2. Ask **“Find the latest RTX 5080 driver on NVIDIA's official site, open it, and tell me what changed.”**  
   Expected: Jarvis returns a grounded current result and opens the exact NVIDIA source in a new tab without replacing an existing user tab.
3. Ask **“Open a new tab and search YouTube for Linus Tech Tips.”** then **“Play the first result.”**  
   Expected: YouTube itself is searched and the first grounded playable result opens/plays.
4. Ask **“Pause the video.”** then **“Resume the video.”**  
   Expected: structural browser media pause/resume succeeds.
5. Open a long Web Intelligence card and click **View full result**.  
   Expected: the fullscreen reader opens the exact result.

## Release metadata checks

```powershell
Get-Content .\VERSION
npm run desktop:check
```

Expected VERSION: `0.3.0`.
