# 0.1.0 — Runtime Packaging Repair

## Summary

The second Windows build attempt proved that the compact Electron source scope was working, but Electron Packager still stalled while finalizing thousands of loose files from the bundled Python and desktop runtimes. This repair converts those runtime trees into one checksum-protected ZIP payload before Electron Forge starts.

## Changed

- Added `scripts/build_runtime_bundle.py` to fingerprint, archive, validate, cache, and visibly report progress for the prepared runtime.
- Changed Electron `extraResource` from two loose directories to:
  - `build/runtime_bundle.zip`
  - `build/runtime_bundle-manifest.json`
- Added SHA-256 verification before the installed application extracts the runtime.
- Added first-launch extraction into the per-user Jarvis data location instead of the read-only installation directory.
- Added an atomic staging/rename flow so a failed extraction cannot be treated as a complete runtime.
- Added a version-specific ready marker so extraction happens only once for each unchanged runtime bundle.
- Updated the loading screen with live runtime-preparation status.
- Updated build verification to reject loose packaged runtime directories and inspect the runtime archive.

## Build behavior

`npm run alpha:make` now performs these visible stages:

1. Stage the compact desktop runtime.
2. Reuse or build Python 3.12.10.
3. Fingerprint and create/reuse the one-file runtime bundle.
4. Verify the compact Electron source and runtime payload.
5. Run Electron Forge against only the Electron shell plus two runtime payload files.

A second build with unchanged runtime content reuses `build/runtime_bundle.zip`.

## First installed launch

The installer carries the runtime as a single archive. On first launch for a version, Jarvis:

1. Displays the loading window.
2. Verifies the archive SHA-256 against its manifest.
3. Extracts into the user's Jarvis runtime directory.
4. Confirms required Python and desktop-core files.
5. Atomically promotes the completed runtime and starts the core.

## Validation

- 158 Python tests passed.
- 13 Node tests passed.
- Electron and Node syntax checks passed.
- Runtime-bundle creation, reuse, source-change rebuild, and tamper recovery are covered by automated tests.
- The local packaging preflight accepted the one-file runtime resource. A full cross-platform Electron package smoke test could not complete because this environment could not reach GitHub to fetch the Windows Electron distribution.

## Windows acceptance still required

The Squirrel Setup executable must still be generated and installed on Tanner's Windows laptop. The repair is accepted only after `npm run alpha:make`, `npm run alpha:verify`, installation, first-launch extraction, wake/conversation/sleep, restart, and shutdown tests pass.
