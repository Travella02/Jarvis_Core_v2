# 0.2.3-repair8 — Attendee Clarification

## Summary
This repair finishes the missing-attendee path in Calendar Intelligence. If Jarvis knows which meeting the user means but cannot resolve a newly named attendee's email address, he now asks for the email and continues the exact same Calendar update when the user provides it.

## What changed
- Expanded desktop Calendar-context routing so natural phrases such as “Add Austin to that meeting tomorrow” stay in Connected Actions.
- Calendar updates now ground the exact provider event before trying to resolve a newly added attendee.
- Unknown attendees no longer cause a Realtime/manual-instructions fallback.
- Jarvis now responds naturally: “I couldn’t find Austin’s email address. What’s Austin’s email?”
- The unresolved attendee request retains the exact event, existing attendees, duration, date, and time for a bounded clarification window.
- A follow-up containing the requested email resumes the exact Calendar update without another Luna planning pass.
- User-supplied attendee emails are saved to the generalized recipient identity store for future Gmail/Calendar resolution.
- The actual Calendar update still requires explicit confirmation before Google is changed.

## Safety
Jarvis does not guess an email address and does not modify Calendar merely because the user supplied an address. The address is added to the pending proposal, then the user still confirms the external write.

## Validation
- Python: 416/416 passed.
- Desktop JavaScript syntax: passed.
- Connected Actions frontend contract: passed.
- Full Node source suite: 86/90 passed; the same four unchanged Electron packaging tests remain blocked because the uploaded source workspace does not include `@electron/packager` development dependencies.
