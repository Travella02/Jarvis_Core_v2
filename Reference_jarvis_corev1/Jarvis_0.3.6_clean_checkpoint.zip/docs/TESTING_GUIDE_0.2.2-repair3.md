# Testing 0.2.2-repair3 — Conversation Continuity

## Test 1 — Reply acknowledgement

Say:

> Respond to Tanner's SUPPORT email and say thank you so much, I really do appreciate it. I'm super excited too.

Expected:
- Jarvis finds the real SUPPORT thread.
- A real reply draft is created and shown in the Gmail-style draft card.
- Jarvis says that he **drafted the reply**; he does not say “here’s a possible reply you could send.”
- The draft is not sent yet.

## Test 2 — Sleep/wake continuity

With the reply draft still waiting for send confirmation, let Jarvis sleep or tell him to sleep. Wake Jarvis again, then say:

> Go ahead and send it.

Expected:
- Jarvis resumes the exact pending reply draft.
- He does not ask to recreate the reply.
- He sends once and reports success.

## Test 3 — Broad unread overview

Say:

> Do I have any unread emails?

Expected:
- Jarvis reports how many unread **inbox** emails you have.
- He may name up to three messages worth looking at first.
- He does **not** automatically render every unread email as Gmail cards.

## Test 4 — Explicit unread list still works

Say:

> Show me my three most recent unread emails.

Expected:
- Three Gmail-style message cards are shown.
- The bounded overview behavior does not override an explicit list request.
