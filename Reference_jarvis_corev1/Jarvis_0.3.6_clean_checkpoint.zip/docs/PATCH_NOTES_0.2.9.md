# 0.2.9 — Natural Interruption

Status: development / live acceptance required.

## Goal

Restore natural Realtime-style barge-in behavior now that Luna authors Jarvis's replies and a dedicated speech provider renders them. A user's new speech turn must stop Jarvis immediately, remain fully transcribable, and permanently supersede any older reply that was still finishing asynchronously.

## Changes

- Treat `input_audio_buffer.speech_started` as an authoritative user barge-in edge for every active speech path, including dedicated TTS playback.
- Do not rely only on `responseActive`; local/dedicated speech and browser playback can briefly outlive that provider flag.
- Clear active playback when the user starts speaking even if an unrelated provider completion raced the UI state.
- Add a monotonic voice-turn epoch. Every new microphone speech turn invalidates asynchronous results from older turns.
- Suppress stale replies after speaker resolution, local memory work, Computer Actions, Connected Actions, memory-context assembly, or Luna scripting instead of allowing old speech to restart after interruption.
- Preserve the existing Realtime VAD/transcription pipeline as the source of the user's actual interrupted utterance; this patch does not add a second speech recognizer or duplicate microphone transcript path.

## Non-goals

- No browser/mouse/keyboard executor changes.
- No Game Mode changes.
- No release-version promotion during live testing.
- No change to speech-provider selection or Luna reasoning ownership.

## Acceptance target

While Jarvis is audibly speaking, the user can begin a new sentence naturally. Jarvis should stop quickly, capture the whole new utterance, answer that new turn, and never resume or emit a late response from the interrupted turn.
