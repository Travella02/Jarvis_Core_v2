# Testing Guide — 0.0.1-dev1-realtime-repair2

## 1. Stop the running core

If Jarvis is running, press `Ctrl+C` and wait for Uvicorn to finish shutting down. Keep the existing private `.env` exactly where it is.

## 2. Install the repair

Extract the repair ZIP into the existing `Jarvis_Real_Time` project root and allow Windows to merge `patch_files`. Run:

```powershell
py -3.12 apply_0_0_1_dev1_realtime_repair2_patch.py
```

Do not rerun dev1 or repair1. The project version remains `0.0.1-dev1`.

## 3. Automated tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Expected summary:

```text
Ran 29 tests
OK
```

The tests must pass whether `.env` contains a configured key or the key is absent. The key value must never be displayed.

## 4. Doctor and diagnostic

```powershell
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

With a configured `.env`, expect:

```text
[PASS] OPENAI_API_KEY configured (value hidden)
```

## 5. Start command

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

Open `http://127.0.0.1:8765` if it does not open automatically.

## 6. Manual connection test

1. Select the desired microphone, speaker, and voice.
2. Click **Connect** once.
3. Confirm `webrtc.offer.ready` appears with a nonzero byte count.
4. Confirm the terminal no longer reports `failed to unmarshal SDP: EOF`.
5. Confirm the lab reaches **Connected** and receives `session.created`.
6. Say: “Hello Jarvis, can you hear me?”
7. Confirm Jarvis answers through the selected speaker.
8. Send one typed message.
9. Disconnect and reconnect once.

## 7. If the live call still fails

Share the terminal error and the provider events after `webrtc.offer.ready`. Do not include `.env`, the API key, Authorization headers, or browser network request headers. A new provider error means the empty-SDP failure is repaired and the next issue is separate.

## 8. Optional installer cleanup

Only after the repair, tests, doctor, and live connection succeed, the old ignored installer artifacts may be deleted:

```powershell
Remove-Item apply_*.py -Force
Remove-Item patch_files -Recurse -Force
```

This does not remove project source files, `.env`, `.venv`, Git history, backups, or documentation already installed under `docs`. Future patches will supply a new installer and `patch_files` directory.

## 9. Commit after live acceptance

```powershell
git status
git add .
git commit -m "0.0.1-dev1: add and repair secure Realtime WebRTC voice lab"
git push
```

The ignored `.env`, logs, `.venv`, patch archives, installers, `patch_files`, and `.patch_backups` must not enter the commit.
