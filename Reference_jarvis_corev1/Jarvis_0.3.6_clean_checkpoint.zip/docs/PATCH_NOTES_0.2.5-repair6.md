# 0.2.5-repair6 — Natural Responses

## What changed

Jarvis's response-writing layer is intentionally simpler.

Luna now gets a short set of conversational rules instead of a large stack of overlapping style instructions:

- answer the current turn,
- sound like a real human,
- stay concise, friendly, and conversational,
- treat the selected response mode as a hard spoken-length ceiling rather than a target,
- use fewer words whenever fewer words are enough,
- preserve grounded facts exactly,
- keep artifact payload such as email bodies separate from dialogue,
- avoid fake tool-progress language,
- use structured/list-style speech only when the user actually asks for it or it is genuinely necessary.

The goal is to let Luna do the natural language work it is good at instead of forcing every reply through increasingly specific response templates.

## Natural task wording

Application labels are no longer supposed to be read mechanically. If a task is titled `Call Tanner`, Luna is explicitly told to fit that label into normal grammar, such as "you need to call Tanner," rather than speaking a database-style phrase such as "you've got Call Tanner."

## Fact safety remains

The simplification does not remove the deterministic truth boundary. Task/reminder follow-up times such as **2 PM** remain protected. Unified agenda and Calendar responses now also lock every clock value that the grounded application answer actually includes before Luna is allowed to humanize the wording.

This means Luna can make a sentence sound natural, but it cannot silently turn a grounded **2 PM** into **8 PM**.

## Response modes

Short, Normal, High, and Full still control spoken length only. They do not reduce reasoning depth.

For capped modes, the configured word and sentence values are hard ceilings. A simple question can still receive a one-word or one-phrase answer even in a larger response mode.
