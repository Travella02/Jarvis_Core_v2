# 0.2.0 — Connected Actions Testing Guide

## Before testing

1. Commit the accepted `0.1.9` project state.
2. Create a **Desktop app** OAuth client in Google Cloud.
3. Enable the Gmail API and Google Calendar API for that project.
4. Add the client ID to the private `.env` as `JARVIS_GOOGLE_OAUTH_CLIENT_ID`.
5. Add the client secret only when Google supplied one: `JARVIS_GOOGLE_OAUTH_CLIENT_SECRET`.
6. Restart Jarvis after changing `.env`.

Do not commit `.env`, OAuth tokens, memory databases, voice samples, logs, or local action databases.

## Acceptance flow

### 1. Connect Google

Open **Controls → Connected apps** and select **Connect Google**.

Expected:
- The system browser opens Google's consent page.
- After sign-in, the browser says Google is connected.
- Jarvis updates to **Connected as _email_** without requiring an app restart.

### 2. Read Gmail

Ask:

> Jarvis, summarize my five most recent unread emails.

Expected:
- Luna interprets and performs the Gmail request.
- Jarvis speaks a short summary once.
- Any longer message list appears in the written answer.
- Nothing is marked sent or changed.

### 3. Draft and send email

Ask:

> Draft an email to a test address with the subject Connected Actions Test and say this is a test draft.

Expected:
- A Gmail draft is created.
- Jarvis says the draft is ready and asks whether to send it.
- The message is not in Sent yet.

Then say:

> Send it.

Expected:
- Gmail sends that draft once.
- Jarvis reports success only after Gmail confirms it.
- The email appears in Sent.

### 4. Read Calendar

Ask:

> What's on my calendar tomorrow?

Expected:
- Jarvis reports only events returned by Google Calendar.
- No confirmation is needed for the read.

### 5. Create Calendar event

Ask:

> Add Connected Actions Test to my calendar tomorrow at 3 PM for thirty minutes.

Expected:
- Jarvis describes the exact proposed event and asks once for confirmation.
- The event does not exist before confirmation.

Say:

> Yes.

Expected:
- The event is created once.
- Jarvis reports success after Google confirms it.

### 6. Delete test event

Ask:

> Delete the Connected Actions Test event.

Expected:
- Jarvis asks for confirmation before deleting.
- After “Yes,” the event is removed and the completed action is audited.

### 7. Safety regression

Verify:
- “Explain thermodynamics” does not call Connected Actions.
- A simple “yes” with no pending action stays a normal conversation turn.
- Realtime speaks only one prepared action result and does not produce a duplicate answer.
- Cancelling a pending action leaves Gmail or Calendar unchanged.
- Disconnect Google removes the local connection.

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```
