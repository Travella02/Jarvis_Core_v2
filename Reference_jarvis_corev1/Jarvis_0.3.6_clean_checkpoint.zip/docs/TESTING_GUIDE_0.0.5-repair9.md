# Testing Guide — 0.0.5 Configuration Isolation Repair

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
npm run desktop:check
```

## Live acceptance

After installation, continue the Desktop Stability acceptance checks:

1. Launch with `npm run desktop`.
2. Confirm the window fits the laptop work area.
3. Stay silent and make ordinary room noise; Jarvis must remain asleep.
4. Say “Jarvis.” and confirm one acknowledgement.
5. Say “Jarvis, tell me a short joke.” and confirm one request and one response.
6. Confirm no phantom `Voice input` turn occurs during the opening response.
7. Close the window with X and confirm Electron, Python, and audio all stop.
8. Test explicit tray Hide and tray Quit separately.

## Acceptance boundary

Do not commit `0.0.5` until the installer passes and the four Desktop Stability behaviors pass live testing.
