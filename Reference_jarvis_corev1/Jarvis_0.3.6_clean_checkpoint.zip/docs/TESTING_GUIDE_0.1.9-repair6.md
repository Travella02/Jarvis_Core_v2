# 0.1.9-repair6 Acceptance Testing

## Simple relationship recall

Ask:

> What do you remember about my fiancée?

Expected:

> Your fiancée is Kenleigh Yarman.

The reply must stop there. It must not say “I remember,” “main detail,” “on record,” offer to track more, or suggest next steps.

## Provenance on demand

Immediately ask:

> How do you know that?

Expected:

> You told me in a voice conversation on August 3, 2026.

The reply must stop there. It must not explain why Jarvis retained the memory or offer to build more context.

## Regression checks

- “What are we still working on for the business?” still returns current ORVEX work.
- “What did we decide about the company?” still returns decisions only.
- “What was the old value before I corrected it?” still asks which correction you mean.
- “What do you remember about ORVEX?” may return multiple relevant facts and must not be forced into the one-fact exact-reply path.
- Small responses do not show Fullscreen; genuinely clipped detailed answers still do.
