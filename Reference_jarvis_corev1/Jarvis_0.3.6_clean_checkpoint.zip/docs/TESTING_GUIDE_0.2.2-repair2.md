# Testing Guide — 0.2.2-repair2 Gmail Reliability

## 1. Encoded Gmail text

Ask Jarvis to show unread emails that previously displayed text such as `I&#39;m`, `can&#39;t`, `&lt;`, or `&gt;`.

Expected:

- apostrophes and angle brackets display normally;
- Gmail cards remain in the structured Gmail-style view;
- fullscreen shows the same cleaned text.

## 2. Reply using sender/name plus subject

With a real email whose sender and subject are easy to identify, say something like:

> Respond to Tanner's SUPPORT email and say, “Thank you, I really do appreciate it.”

Expected:

- Jarvis finds the Gmail thread using the available subject/sender evidence;
- if speech recognition slightly misspells the person's name, a strong subject match can still locate the real thread;
- Jarvis creates a reply draft in that exact thread;
- the reply draft appears in the normal Gmail draft card;
- nothing is sent yet.

## 3. Send the reply

Review the reply draft, then say:

> Perfect, thanks, Jarvis. Go ahead and send it.

Expected:

- the exact reply draft sends once after the explicit confirmation;
- no second confirmation is required;
- no duplicate spoken success response occurs.

## 4. Failure containment

If Gmail or reply composition fails temporarily, Jarvis should show/speak one concise Connected Actions failure result. The local core should not emit an uncaught ASGI exception for the reply workflow, and Realtime should not add a competing second fallback answer.

## 5. Speed regression

The successful Gmail reads and reply workflow should retain the lower latency from 0.2.2. Connected Apps → Last action should continue showing action latency.
