# Testing Guide — 0.1.2 Memory Explorer

## Apply

Close the development Jarvis window. Extract the update directly into the `Jarvis_Real_Time` project root, approve file replacement, then run:

```powershell
py -3.12 apply_0_1_2_patch.py
```

Start the development desktop:

```powershell
npm run desktop
```

The installed Start-menu copy remains on `0.1.0` until a new accepted installer is built.

## Acceptance checks

### Timeline and natural search

1. Open **Memory**.
2. Confirm Timeline, Entities & relationships, and Daily summary tabs appear.
3. Enter `I created a new business called ORVEX.` if ORVEX is not already present.
4. Search `show me everything about ORVEX`.
5. Confirm Jarvis shows the interpreted entity filter and returns the ORVEX event.
6. Search `what did I say today` and confirm the local-date interpretation appears.
7. Test category, source, status, important, and date-range filters.

### Provenance and correction

1. Open **Details & provenance** on an event.
2. Confirm local time, timezone, speaker, source, category, privacy, status, confidence, event ID, entities, and facts are visible.
3. Mark the event important and confirm the gold marker appears.
4. Mark it outdated, then active again.
5. Correct the speaker or category and verify the timeline updates.
6. Correct exact text on a test memory and confirm entities/facts are reanalyzed.

### Delete and undo

1. Delete a disposable test memory.
2. Confirm it disappears from active recall.
3. Select **Undo latest reversible change**.
4. Confirm the exact event returns with its original timestamp and source.

### Entities and relationships

1. Open **Entities & relationships**.
2. Open ORVEX.
3. Confirm aliases, related events, and the `Tanner created ORVEX` relationship appear.
4. Create a disposable alias entity, merge it into ORVEX, verify it appears under merged records, then split or undo it.

### Summary and export

1. Open **Daily summary** and select a date with memories.
2. Confirm event count, first/last time, category counts, actors, and important moments.
3. Return to Timeline and choose **Export JSON** and **Export Markdown**.
4. Confirm the files contain only the current filters and include timestamps, source, category, privacy, and status.

### Persistence

1. Close Jarvis completely.
2. Restart with `npm run desktop`.
3. Confirm edits, flags, entity merges, and restored events remain.

## Automated validation

The patch installer runs the complete Python and Node suites, doctor, core diagnostic, staged-runtime check, and JavaScript syntax checks before accepting the update.
