# 0.2.8-repair3 — Safety Probe

## Goal

Validate the Game Mode executor firewall itself before Jarvis receives any real synthetic keyboard, mouse, browser, or vision-driven control.

## Safety hardening

The existing firewall had one important race-condition gap: an executor could explicitly name Chrome while Rocket League had regained foreground focus just before input dispatch. Because generic Windows input is focus-sensitive, the protected foreground must win over the caller's intended target.

This repair therefore:

- blocks risky synthetic input whenever a protected game is currently foreground, even when the caller supplies a different PID/process/window target;
- applies the same fail-closed rule to an unknown fullscreen foreground application;
- normalizes explicit executable names such as `RocketLeague.exe` before protected-process matching;
- keeps title-only matching conservative, but does not mistake a known Chrome process for Rocket League just because the browser tab title contains `Rocket League`;
- adds a trusted local `/api/game-mode/safety-probe` endpoint and `tools/game_mode_safety_probe.py` CLI;
- keeps the probe entirely dry-run: it calls the same production `authorize` gate but never emits keyboard/mouse input, focuses windows, touches process memory, injects code, installs hooks, or communicates with anti-cheat.

## Release state

This is still 0.2.8 development. VERSION/release metadata are intentionally unchanged until the Game Mode firewall passes live acceptance.
