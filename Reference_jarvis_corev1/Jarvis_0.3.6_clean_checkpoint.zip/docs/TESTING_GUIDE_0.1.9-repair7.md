# 0.1.9-repair7 Acceptance Testing

## Simple recall

Ask:

> What do you remember about my fiancée?

Expected: Jarvis naturally answers that your fiancée is Kenleigh Yarman. He should not add offers, storage narration, or provenance unless asked.

## Source follow-up

Immediately ask:

> How do you know that?

Expected: one short sentence naming the original conversation medium and date. It should reference the original fact source, not today's recall question.

## Compound question

Ask in one turn:

> What do you remember about my fiancée and how do you know?

Expected: Jarvis answers both parts in order—first the fact, then the source/date. He must not answer only the provenance portion.

## Conversational-model regression

Try natural variants:

- “Remind me who my fiancée is and tell me where you learned that.”
- “What do you know about Kenleigh, and when did I tell you?”
- “Who is my fiancée?”

Expected: Jarvis remains conversational and respects the selected response mode. No exact-response bypass should replace or truncate the user's request.

## Other regressions

- “What are we still working on for the business?” resolves ORVEX directly.
- “What did we decide about the company?” returns decisions only.
- “What was the old value before I corrected it?” asks which correction you mean.
- Short answers do not show Fullscreen.
- Explicit detailed questions can still use the hybrid written-answer path outside Full mode.
