# 0.1.2-repair2 — Reliable Memory Navigation & Response Profiles

Repairs live visual memory navigation and makes Jarvis response length fully configurable across five customer-facing presets.

## Reliable visual memory navigation

- Explicit requests such as “Show me everything about ORVEX” now use three cooperating paths:
  1. immediate deterministic local intent handling,
  2. a structured Realtime `show_memory` function tool fallback,
  3. conservative fuzzy entity resolution for small speech-transcription differences.
- The desktop switches to Memory immediately, repeats the switch on the next animation frame, and scrolls the selected explorer view into position.
- Model tool calls are deduplicated by call ID and receive a local result before Jarvis gives a short spoken acknowledgement.
- A close transcript such as “Orvix” can resolve to an existing `ORVEX` entity without changing the stored entity name.
- Broad requests open the timeline; specific subjects prefer an entity page.
- Verbal questions such as “What do you know about ORVEX?” remain conversation-only.
- Static renderer assets are cache-busted, and the loopback server sends no-cache headers for the application shell and scripts.

## Configurable response profiles

Jarvis now supports five response modes:

- Test
- Short
- Normal
- Medium
- Full

Each mode has two independent `.env` settings:

- `TARGET_WORDS` guides how concise or detailed Jarvis should be.
- `MAX_OUTPUT_TOKENS` is the provider hard ceiling that protects cost and runaway output.

A target of `0` means adaptive detail. A token ceiling of `0` means the maximum supported by the selected Realtime model. This avoids using a low hard limit as the primary conversational-style control and reduces mid-sentence cutoffs.

The resolved profiles are published by the local configuration API. The Controls workspace labels each mode with its approximate word target and token ceiling so owners can see what is active.

## Default profiles

| Mode | Target words | Maximum output tokens |
|---|---:|---:|
| Test | 25 | 512 |
| Short | 60 | 1,024 |
| Normal | 140 | 2,048 |
| Medium | 300 | 4,096 |
| Full | Adaptive | Model maximum |

These are defaults only. Owners can set exact values in their private `.env` without changing source code. Existing `.env` files are preserved by the patch installer.

## Validation

- 191 Python tests passed.
- 32 Node tests passed.
- JavaScript and Electron syntax checks passed.
- Core doctor and diagnostic checks passed.
- Desktop runtime staging passed.
- Fresh patch installation and safe reapplication passed.
- Private `.env` preservation passed.
