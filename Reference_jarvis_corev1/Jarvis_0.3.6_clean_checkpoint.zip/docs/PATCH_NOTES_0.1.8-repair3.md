# 0.1.8-repair3 — Clean Entities & Single Wake

This final live-acceptance repair keeps the knowledge graph focused on durable subjects and guarantees that a wake-only turn creates exactly one Realtime response.

## What changed

- Episodic foods and simple preference values are now stored as literal fact values attached to the relevant person rather than as standalone entities.
- Existing low-identity `food` and `preference_subject` nodes are demoted automatically on startup.
- Demotion preserves the exact source event, fact predicate, value, status, evidence, timestamps, confidence, and lifecycle history.
- Future statements such as what a person is eating or a favorite color no longer create entity cards by default.
- Durable people, businesses, projects, places, pets, devices, named objects, and explicitly tracked subjects remain eligible for the entity graph.
- Wake-only acknowledgements are claimed before provider events are sent, preventing connection callbacks from dispatching the same paid response twice.
- The first acknowledgement response is bound to the gated opening turn; any unexpected second response is cancelled and suppressed before it can create another visible card.
- Wake acknowledgement state resets safely on completion, provider error, sleep, disconnect, or rejected speculative wake.

## Data-safety contract

- No exact memory event is deleted by value-entity demotion.
- Facts remain attached to the correct person and retain current, historical, superseded, forgotten, or other lifecycle state.
- The migration is generalized by entity role and type. Current user examples appear only in tests and documentation, not product logic.
- A value node is demoted only when it is not a fact subject, actor identity, relationship participant, or proactive-work subject.

## Validation

Automated coverage verifies literal food/preference facts, safe legacy demotion, source-event preservation, exactly-once wake acknowledgement dispatch, duplicate provider-response suppression, and all previously accepted Memory Intelligence behavior.
