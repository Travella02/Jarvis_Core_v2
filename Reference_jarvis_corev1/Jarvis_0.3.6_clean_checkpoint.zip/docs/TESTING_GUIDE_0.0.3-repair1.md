# Testing Guide — 0.0.3 Environment Repair

## Install

Extract the repair into the `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_0_3_repair1_patch.py
```

The installer will create `.venv` when missing, install the project and its runtime dependencies into that venv, then run the validation suite.

## Manual verification

```powershell
.\.venv\Scripts\python.exe scripts\ensure_environment.py --check-only
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
.\.venv\Scripts\python.exe -m apps.core
```

Expected environment checks:

```text
[PASS] FastAPI installed
[PASS] HTTPX installed
[PASS] Uvicorn installed
```

The test suite should report the complete test count rather than a reduced count caused by import failures.

## Laptop note

`.venv` is intentionally ignored by Git and must be created or repaired separately on every computer. Do not copy a virtual environment between the desktop and laptop.
