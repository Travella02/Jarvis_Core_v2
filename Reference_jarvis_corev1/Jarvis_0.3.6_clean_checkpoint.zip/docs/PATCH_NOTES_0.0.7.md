# 0.0.7 — Voice Lifecycle

## Summary

This release makes waking and sleeping feel like one coherent voice-first lifecycle. It adds selectable wake-latency profiles and replaces the previous text-only sleep confirmation with a very short audible Cedar acknowledgement before the Realtime session closes.

## Added

- `Fast`, `Balanced`, and `Strict` wake profiles.
- `Fast` as the default for the lowest practical wake delay.
- A controlled spoken sleep acknowledgement using the active Realtime Cedar voice.
- A hard 16-token cap and exact short sign-off instruction: **“Of course, sir.”**
- Sleep lifecycle timing for intent detection, first acknowledgement audio, and completed shutdown.
- Bounded timeout fallback so a failed acknowledgement can never leave Jarvis stuck awake.
- Configuration flags:
  - `JARVIS_WAKE_PROFILE`
  - `JARVIS_SLEEP_ACKNOWLEDGEMENT_ENABLED`

## Changed

- The model now calls `sleep_jarvis` without speaking first.
- The local lifecycle controller returns the tool output, requests one tiny audio response, disables microphone input, waits for audible playback to finish, and then closes the session.
- Wake VAD timing and false-wake protection are selected from the active wake profile instead of fixed constants.
- Wake-profile choices persist locally in the desktop renderer.

## Cost behavior

The spoken sign-off is intentionally limited to a few words and 16 output tokens. It is billed as a very small Realtime response and is recorded by the existing usage ledger.

## Validation

- Full Python test suite passed.
- Node desktop tests passed.
- Electron main, preload, presence, and renderer JavaScript validation passed.
- Doctor and secret-safe diagnostic passed.
- Desktop runtime staging passed.
- `.env` preservation and idempotent installer checks passed.
