# 0.1.0 — Runtime Download Repair

## Summary

This repair restores the Windows Desktop Alpha build by replacing an unavailable Python 3.12.13 binary URL with the final official Python 3.12 release that actually provides a Windows embeddable runtime.

## Fixed

- `npm run alpha:make` no longer requests the nonexistent Python 3.12.13 Windows embeddable archive.
- The build now downloads the official 64-bit Python 3.12.10 embeddable package.
- The downloaded archive is validated against the official SHA-256 digest before extraction.
- Invalid cached archives are deleted and downloaded again instead of being silently reused.
- Failed or corrupt temporary downloads are removed automatically.
- The builder now gives a direct compatibility error when it is run with a Python version other than 64-bit Python 3.12.
- `--check-plan` now shows the exact runtime URL and checksum before the native Windows build.

## Preserved

- Jarvis remains a self-contained installed application that does not require system Python after installation.
- The Desktop Alpha version remains `0.1.0` because this is a pre-acceptance repair rather than a new accepted feature release.
- First-run setup, encrypted API-key storage, diagnostics, update checking, Squirrel shortcuts, Realtime voice, wake behavior, and the interface are unchanged.

## Validation

- 153 Python unit tests passed.
- 12 Node desktop tests passed.
- Electron syntax checks, doctor, diagnostic startup, runtime-plan validation, and desktop-runtime staging passed.
- The complete Squirrel build must still be run on 64-bit Windows because the embedded-runtime builder intentionally rejects non-Windows hosts.
