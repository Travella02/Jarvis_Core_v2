# Legacy Migration Inventory

## Frozen legacy source

- **Archive inspected:** `Jarvis Ultimate.zip`
- **Legacy repository:** `Jarvis_Ultimate`
- **Branch:** `main`
- **Frozen commit:** `7b7cc995628a70220745e1a820c9651444af06b1`
- **Commit title:** `0.3.8d2 | 06/30/2026 | 01:39am | Added custom-only layout preset management`
- **Remote recorded in legacy Git metadata:** `Travella02/Jarvis_Ultimate`
- **Working-tree verification:** Every tracked file in the uploaded archive matched the frozen commit after normalizing Windows CRLF/LF line endings. No substantive uncommitted tracked changes were detected.

The legacy archive remains read-only. The new project must never point directly at the legacy live data files or reuse the old repository as its Git history.

## Archive observations

- Approximately 43,670 ZIP entries and 1.38 GB uncompressed.
- The legacy `.venv` accounts for roughly 1.21 GB and is not migrated.
- The included `.git` directory preserves about 82 MB of history and is retained only in the frozen archive.
- The archive contains a real `.env`. It was not read or copied into the new project. Secrets must be re-entered locally later and must never be committed.
- The legacy project includes Python source, a vanilla Electron/JavaScript app shell, JSON memory stores, app alias/index data, raw STT/TTS audio, logs, patch backups, documentation, and a large behavioral test suite.

## Classification

| Legacy area | Treatment | Migration gate |
|---|---|---|
| Persona, “sir” behavior, wake/sleep phrases | **Adapt** | Add as versioned provider prompts after the Realtime session contract exists. |
| OpenAI/local-provider abstractions | **Reference, then rewrite** | New provider interfaces must be version-agnostic and event-driven. |
| Faster-Whisper pipeline | **Adapt later** | Keep as private/offline STT fallback after the primary Realtime voice path is proven. |
| Kokoro TTS and voice assets | **Adapt later** | Keep as offline/emergency speech; do not place it in the primary online speech-to-speech path. |
| App aliases and discovered paths | **Export and validate** | Import through a migration script only after the Applications module and tool contract exist. |
| App Agent behaviors | **Adapt behind new tools** | Port open/close/focus behavior one capability at a time with permission, verification, and audit tests. |
| File Agent behaviors | **Adapt behind new tools** | Port only after safe path policy, recoverable deletion, and audit contracts exist. |
| Entity, preference, and selected long-term memory | **Transform** | Export to neutral records with provenance; validate and review before Memory 2.0 import. |
| Conversation logs | **Archive** | Import summaries or selected episodes only; do not bulk-copy every raw turn by default. |
| Secure vault behavior | **Rewrite** | Use Windows Credential Manager/DPAPI-backed storage; never reuse plaintext or normal-memory secrets. |
| Orb art, visual assets, and state vocabulary | **Reuse as design reference** | Rebuild interaction code in React/TypeScript after the headless core is stable. |
| Electron panel layouts, presets, and pop-outs | **Rewrite** | UI-only state synchronized through core events; no conversation-state ownership in the UI. |
| Old conversation loop and `lifecycle.py` orchestration | **Retire** | Must not become the foundation of the clean core. |
| Old local API and bridge coupling | **Rewrite** | Replace with typed FastAPI/WebSocket contracts after the core event bus exists. |
| JSON memory pipeline | **Retire as live architecture** | Keep only as a migration source; Memory 2.0 will use relational source-of-truth records and append-only events. |
| Behavioral tests | **Port selectively** | Preserve user-visible expectations; rewrite tests tied to obsolete internal coupling. |
| `.venv`, caches, `__pycache__`, logs, raw STT/TTS recordings | **Do not migrate** | Recreate or retain only in the frozen archive. |
| `.patch_backups` and old installer payloads | **Archive only** | Useful for archaeology and rollback history, not for the new repository. |

## Legacy capabilities confirmed by inspection

- Local LM Studio-compatible conversational provider.
- Faster-Whisper speech recognition and local audio recording.
- Kokoro/experimental XTTS speech output.
- Local wake/sleep voice loop.
- Electron desktop shell with orb, conversation, workspace, runtime, voice, and diagnostics panels.
- App open/close/focus, discovery, aliases, and verification behavior.
- JSON-based long-term, short-term, chat archive, candidate, preference, entity, and secure-vault foundations.
- Early File, Screen/OCR, Recorder, Weather, Avatar, and communications-adjacent scaffolding.
- Hundreds of unit/integration test cases documenting prior behavior and regressions.

## Migration sequence

1. Finish the isolated Realtime Voice Lab.
2. Establish the authoritative state machine, event bus, local API, and provider router.
3. Build the first permissioned vertical tool slice.
4. Implement Memory 2.0 and neutral import formats.
5. Rebuild the desktop body in React/TypeScript.
6. Migrate app aliases, selected memories, assets, and stable capabilities one module at a time.

## Security note

The old `.env`, credentials, logs, conversation archives, audio, and memory files are private runtime data. They are intentionally absent from this bootstrap package. Any future migration package must redact logs, avoid copying secrets, and work from explicit exports rather than the live legacy database/files.
