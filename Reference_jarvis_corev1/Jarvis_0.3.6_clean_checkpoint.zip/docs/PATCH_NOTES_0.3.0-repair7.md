# 0.3.0-repair7 — Fresh Web Results

This repair tightens the hybrid Web Intelligence experience after live testing exposed stale chronology, noisy source cards, stale-source routing, and active-tab replacement.

- Recency-sensitive searches now perform an explicit two-pass freshness check: a grounded first pass followed by a high-context challenge pass that searches again, compares dated candidates, and tries to disprove stale preliminary results before Jarvis calls something “latest.”
- The current UTC date is included in Web Intelligence's research instructions, and official listing/chronology pages are preferred when resolving release/update ordering.
- Source URLs are canonicalized to remove tracking parameters and duplicate URL variants.
- Result cards show the cited supporting sources by default instead of dumping every page consulted by the web-search tool.
- Web result output is instructed to use clean plain text, short paragraphs, and bullet characters rather than raw Markdown links/formatting; the desktop also strips common Markdown artifacts defensively.
- The card layout is more readable: wider answer spacing, compact citation badges, responsive source cards, and a two-column source area when space allows.
- Clear fresh research now wins over recent-source continuation. A new request such as “Find the latest RTX 5080 driver … open it …” cannot reuse the prior Rocket League result merely because it contains the words “open it.”
- Explicit source follow-ups such as “open the first source” still work, but source handoff now opens a new browser tab so Jarvis does not replace a tab the user is actively using.

VERSION and release metadata remain unchanged until 0.3.0 live acceptance passes.
