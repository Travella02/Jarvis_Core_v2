# Testing Guide — 0.1.0 Runtime Download Repair

## Apply the repair

Extract the repair package into the current `Jarvis_Real_Time` project root and run:

```powershell
py -3.12 apply_0_1_0_repair1_patch.py
```

## Confirm the corrected runtime plan

```powershell
.\.venv\Scripts\python.exe scripts\build_embedded_python.py --check-plan
```

The output must show:

```text
Python: 3.12.10
Download: https://www.python.org/ftp/python/3.12.10/python-3.12.10-embeddable-amd64.zip
SHA-256: 156c7eea90d58cd7e91a23f28a0056616b13e9f4cf4901b7b99b837b7848c6da
```

## Build the Windows alpha

Run from 64-bit Windows while the Python 3.12 virtual environment is active:

```powershell
npm run alpha:make
npm run alpha:verify
```

The first command should download and verify Python 3.12.10, stage the private runtime, package Electron, and create:

```text
out\make\squirrel.windows\x64\Jarvis_Real_Time_Setup.exe
```

The verification command should report the installer, packaged application, and bundled Python 3.12.10 runtime.

## Retry after an interrupted download

The builder stores the archive under:

```text
build\cache\python-3.12.10-embeddable-amd64.zip
```

A valid cached archive is reused. A corrupt or incomplete archive is deleted automatically and downloaded again. To deliberately rebuild everything:

```powershell
.\.venv\Scripts\python.exe scripts\build_embedded_python.py --force
npm run alpha:make
```

## Full source validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

Expected automated result:

```text
Python tests: 153 passed
Node tests: 12 passed
```

## Start Jarvis after validation

```powershell
npm run desktop
```
