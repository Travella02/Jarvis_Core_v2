# Testing Guide — 0.1.3 Memory Consolidation

1. Start Jarvis with `npm run desktop` and open **Memory → Consolidation**.
2. Add these memories:
   - `I created a new business called ORVEX.`
   - `My goal is to grow ORVEX into a major esports company.`
   - `We decided to register ORVEX as an LLC.`
   - `We need to file the ORVEX trademark.`
3. Select **Consolidate now**.
4. Open the ORVEX entity page. Confirm its profile shows the goal, decision, open item, key fact, and related timeline.
5. Add `I created a new business called ORVIX.` and consolidate again. Confirm a possible-alias finding appears and the two entities remain separate.
6. Add `My favorite color is blue.` followed by `Actually, my favorite color is green.` and consolidate. Confirm green is current while the original blue evidence remains in history.
7. Restart Jarvis and verify profiles, findings, and run history persist.

Automated acceptance requires 204 passing Python tests, 40 passing Node tests, desktop syntax checks, doctor diagnostics, and runtime staging.
