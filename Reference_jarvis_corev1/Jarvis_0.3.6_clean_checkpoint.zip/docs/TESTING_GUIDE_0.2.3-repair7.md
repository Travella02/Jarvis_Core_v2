# Testing Guide — 0.2.3-repair7 Local Time

## Install
Close Jarvis, extract the repair ZIP directly into the current project root, then run:

```powershell
py -3.12 apply_0_2_3_repair7_patch.py
```

Start Jarvis:

```powershell
npm run desktop
```

No Google reconnect is required for this repair.

## Test 1 — exact local wall clock
Say:

> Can you schedule a meeting with Tanner for tomorrow at 3 PM?

Pass criteria:
- Jarvis says **3 PM**, not 9 PM.
- The Calendar card shows **3:00 PM**.
- The card says **Local time** (or the correct IANA timezone), never a misleading UTC wall clock.
- After confirmation, Google Calendar shows the event at **3 PM**.

Then say:

> Yes, go ahead and add it.

The event should be created once.

## Test 2 — duration truth
On that meeting say:

> Make it one hour.

Pass criteria:
- The proposal card shows a one-hour range.
- Jarvis says it is one hour.
- After one confirmation, Google Calendar is one hour.

## Test 3 — attendee regression
Say:

> Add Austin to that meeting.

Pass criteria:
- Tanner remains on the event.
- Austin is added to the proposal.
- One confirmation updates the same Google event.

## Acceptance
Do not commit 0.2.3 until the local-time test and the chained Calendar edit regression both pass live.
