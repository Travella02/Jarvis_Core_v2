# 0.3.4-repair2 — Verification UX

## Why this repair exists

Live acceptance of 0.3.4-repair1 proved that browser-based signup, legacy account upgrade, verification, password recovery, and desktop unlock work end-to-end. It also exposed authentication UX/security gaps that should be corrected before Cloud Sync is accepted: a password mismatch refreshed the page and erased non-secret form fields, browser-native password reveal controls were inconsistent, verification/recovery challenges had no visible expiry or resend flow, and the development portal did not make it obvious that displayed codes are not actually emailed or texted.

## What changed

- Signup now preserves Name, Email, and Phone when server-side validation fails. Password fields are never echoed back.
- Password + confirmation mismatches are caught client-side before submission when JavaScript is available. Only the two password boxes are cleared, both are highlighted in red, and the page shows both an inline error and a top error banner.
- Server-side mismatch handling remains authoritative and preserves the same non-secret fields when JavaScript is unavailable.
- All signup, sign-in, and password-reset password fields now use an explicit persistent show/hide control. The control remains available after repeated toggles.
- Verification and recovery codes remain valid for 10 minutes and now display a live `Code expires in M:SS` countdown.
- Resend is available after a 60-second cooldown with a visible countdown. Resending rotates the code, resets the five-attempt budget, extends expiry by 10 minutes, and invalidates the previous code.
- Verification and recovery challenges permit at most five wrong-code attempts before a new challenge is required.
- Recovery verification is now one-time: a verified recovery challenge cannot be exchanged for multiple password-reset tokens.
- Development pages explicitly state that the local relay displays the code and does **not** send email/SMS. Production continues to require a configured verification-delivery provider and never exposes the code in the response.
- The cloud relay exposes bounded resend endpoints for account verification and account recovery. Production resend delivery uses the same deployment-owned email/SMS sender contract as the initial challenge.

## Security/UX decisions

A 60-second code lifetime would be unnecessarily hostile to real users and provides little security benefit. The implemented policy is a 10-minute one-time code with a 60-second resend cooldown, five failed attempts, immediate invalidation when a replacement code is issued, and session revocation after password reset. This keeps the account flow practical while retaining bounded challenge exposure.

## Preserved behavior

0.3.4 remains Cloud Sync, not a new product version. Browser-based authentication, mandatory signed-out account gating, legacy Account Foundation migration, tasks/reminders-only Cloud Sync, tenant/device isolation, and all 0.3.3 Runtime Reliability behavior remain intact.
