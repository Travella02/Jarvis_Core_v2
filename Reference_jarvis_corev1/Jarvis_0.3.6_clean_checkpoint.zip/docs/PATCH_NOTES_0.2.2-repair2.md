# 0.2.2-repair2 — Gmail Reliability

This live-acceptance repair keeps the Action Speed improvements from 0.2.2 and the Gmail-style read view from repair1 while fixing three issues found in live Gmail testing.

## Gmail message text is decoded before display

Some Gmail messages expose HTML character entities even inside their plain-text alternative. That produced visible artifacts such as `I&#39;m`, `can&#39;t`, and `&lt;...&gt;` inside the Gmail card.

Jarvis now performs bounded entity decoding on Gmail plain-text bodies, HTML-derived bodies, and search snippets before they reach the presentation layer. The desktop UI also performs a defensive decode pass so provider text remains human-readable even if encoded entities slip through upstream.

## Reply-by-name-and-subject no longer depends on contact resolution

A request such as “respond to Jordan's SUPPORT email” may contain both a human name and a strong Gmail subject/search clue. Previously, if the spoken name could not be resolved through Contacts/history—especially after a speech-recognition spelling variation—the reply workflow could stop before Gmail tried the subject query.

Thread lookup now treats contact resolution as a precision signal rather than a hard gate. It tries the resolved sender when available, then the explicit Gmail query/subject, then bounded sender/recent-message fallbacks. Jarvis only replies after Gmail returns a real matching thread.

## Reply failures stay inside one Connected Action response

Unexpected reply-composition edge cases are now contained inside the Connected Actions workflow instead of escaping through the ASGI request. The desktop also suppresses duplicate connected-action speech for the same result within a short bounded window.

This prevents a single failed Gmail request from producing competing spoken fallback responses while preserving the visible error result and normal retry behavior.

## Safety and architecture

- Realtime remains speech-only for Connected Actions.
- Luna remains the Gmail planner/reply composer.
- Reply drafting does not send anything.
- Sending still requires the separate external-write confirmation flow.
- Subject/name fallback never invents a recipient or thread; a real Gmail result is required.
