# 0.1.2-repair7 — Single Summary

Prevent combined visual-memory requests from narrating the same displayed facts twice.

## What changed

- Classifies explicit narration requests as short summary, detailed explanation, or standard explanation.
- A short-summary request now has a specific contract: one paragraph, no more than two sentences and 50 spoken words.
- Tells the Realtime response to state each fact only once.
- Forbids an overview followed by another summary or recap.
- Removes filler preambles and labels such as “Okay, quick note,” “Short summary,” and “In summary.”
- Keeps the narration grounded in the exact Memory Explorer result that is already visible.
- Cache-busts the renderer scripts so Electron cannot reuse the repair6 prompt.

## Expected behavior

`Show me everything about ORVEX and give me a short summary.` opens the memory and gives one concise summary. It must not first describe the record and then repeat the same date, business name, and missing-detail statement under a second summary label.

## Validation

- 195 Python tests passed.
- 36 Node tests passed.
- Desktop JavaScript syntax checks passed.
- Core doctor and diagnostic checks passed.
- Desktop runtime staging passed.
- Fresh patch installation and safe reapplication passed.
