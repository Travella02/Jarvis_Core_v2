# Testing Guide — 0.2.1-repair3 Email Review

Use a disposable recipient/message for the send test because the confirmation intentionally sends real email through the connected Google account.

## Install and start

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair3_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```

## 1. First-confirmation regression

Create a disposable draft, for example:

> Draft an email to Tanner saying thank you, I appreciate it, I will talk to you soon.

Verify the `EMAIL DRAFT` preview is correct and safe to send. Then say exactly:

> Yes, please go ahead and send it.

Expected:

- Jarvis treats this as the explicit confirmation for the already-pending send.
- The exact reviewed draft sends on this first confirmation.
- Luna is not asked to rediscover/re-plan the draft.
- Jarvis does not ask “Would you like me to send it?” a second time.
- Gmail sends the message exactly once.
- Jarvis reports success only after Gmail confirms the send.

## 2. Confirmation variants

With new disposable drafts, verify at least one of these also works on the first confirmation:

> Yes, go ahead and send it.

> Please go ahead and send it.

> Go ahead and send it.

Existing variants such as `Yes`, `Yes, please`, and `Send it` must still work.

## 3. Fullscreen email preview

Create another draft but do not send it. In the conversation, verify the compact preview shows the structured email card. Open **Fullscreen**.

Expected:

- Fullscreen keeps a real email-style card instead of converting the email into plain text.
- The fullscreen title reads `Email draft`.
- Draft state remains visibly `Draft saved · Not sent`.
- From, To, Subject, and Message remain visually separated.
- Cc/Bcc remain visible when present.
- Long message bodies are fully scrollable/readable in fullscreen.

Then send that draft and open the sent result fullscreen if available.

Expected:

- The card reads `EMAIL SENT` / `Sent`.
- The fullscreen title reads `Email sent`.
- Recipient, subject, and body remain intact.

## 4. Cancel safety

Create another disposable draft and say:

> Cancel it.

Expected:

- No email is sent.
- The Gmail draft remains saved.
- The cancellation is not interpreted as approval.

## 5. Non-email fullscreen regression

Open Fullscreen on a normal long Jarvis answer.

Expected: the existing normal fullscreen reader still works and is not forced into email-card styling.

## 6. Continue 0.2.1 acceptance

If these checks pass, resume the remaining flow in `docs/TESTING_GUIDE_0.2.1.md`. Do not begin 0.2.2 until the complete 0.2.1 acceptance flow passes.
