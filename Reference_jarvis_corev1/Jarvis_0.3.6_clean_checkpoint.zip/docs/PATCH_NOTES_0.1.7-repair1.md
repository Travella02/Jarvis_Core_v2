# 0.1.7-repair1 — Unified Answers

This repair presents long-form speech and written detail as one organized Jarvis answer and makes capability knowledge extensible without unsafe code guessing.

## Changes

- Replaced the separate `JARVIS · SPOKEN SUMMARY` and `JARVIS · DETAILED ANSWER` cards with one `JARVIS` response card.
- The card displays the spoken summary while audio is playing, then updates in place to the complete written answer.
- Added first-person enforcement for self-description so Jarvis says “I am…” rather than incorrectly telling the user “You are…”.
- Removed the temporary spoken summary from the context supplied to the detailed text generation, reducing repetition and role confusion.
- Updated simulation mode to exercise the same unified-card behavior without API cost.
- Added live capability-provider registration and auto-discovery under `jarvis.capabilities.providers`.
- Capability snapshots are recomputed from current settings, runtime state, and registered feature providers whenever the API or Realtime session profile requests them.
- New features still must declare what they can do. Jarvis intentionally does not infer or claim capabilities by scanning arbitrary code.

## Compatibility

- Version remains `0.1.7` because this is a repair to the unaccepted Self Awareness update.
- Existing voice, memory, identity, wake, response-mode, and safety behavior is preserved.
- Long-form answers still use a second text-only model generation, so the cost characteristic is unchanged.

## Validation

- 272 Python tests passed.
- 71 source-available Node tests passed.
- Four unchanged Electron packaging tests require the excluded `node_modules` dependency tree and are required by the installer on the complete project.
