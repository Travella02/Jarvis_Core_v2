# 0.2.2-repair3 — Conversation Continuity

This live-acceptance repair keeps the speed gains from 0.2.2 while making Gmail follow-through feel like one continuous assistant workflow.

## What changed

- Reply drafts now receive a provider-grounded acknowledgement such as “I drafted your reply to Tanner’s SUPPORT email…” instead of hypothetical “here’s a reply you could send” wording.
- A reviewed Gmail draft can survive Jarvis sleeping and waking. An explicit follow-up from the same recognized actor recovers the pending draft and binds it to the new session.
- Pending draft continuity never crosses recognized actors.
- Broad unread checks such as “Do I have any unread emails?” no longer render the whole result list.
- Broad unread checks report the inbox unread count and surface at most three priority candidates from a bounded metadata sample.
- Explicit requests such as “show my three newest unread emails” still use the Gmail card list because the user explicitly asked to see messages.
- The unread overview uses a local deterministic response after Google returns the count/metadata, avoiding another response-writing model round trip.

## Safety

Sending still requires an explicit confirmation. Cross-session continuation is limited to a live pending Gmail draft owned by the same recognized actor.
