# 0.0.5 — Configuration Isolation Repair

## Summary

This repair fixes the Desktop Stability installer failure caused by a legitimate private wake-VAD override being inherited by a server test.

## Changes

- Made the server test's wake configuration explicit and deterministic.
- Asserted that `/api/config` returns the active `ProjectSettings` value instead of hard-coding the release default.
- Runs installer validation under a complete secret-free settings overlay.
- Preserves the user's private `.env` byte-for-byte.
- Includes all Desktop Stability changes from Repair 8.

## Issue record

- `issues/ISSUE_033_PRIVATE_ENV_OVERRIDE_IN_SERVER_TEST.md`

## Validation target

- 95 automated tests
- JavaScript syntax validation
- Doctor and safe diagnostic
- Desktop runtime staging
- Installation with a private 750 ms wake-silence override
- Idempotent second installation
- Byte-for-byte `.env` preservation
