# 0.1.8 — Memory Intelligence

Jarvis memory now separates **current truth** from preserved history. Explicit natural commands can remember, correct, forget, complete, dismiss, reopen, and clear completed work without relying on a general model response to perform the change. Every lifecycle mutation remains source-aware and reversible.

## What changed

- Added a deterministic natural-memory command interpreter for voice and typed turns.
- Supported explicit commands such as:
  - `Remember that my launch date is October 3.`
  - `Forget that.`
  - `Change blue to green.`
  - `That’s wrong.`
  - `Mark the trademark task complete.`
  - `Dismiss that goal.`
  - `Restore that task.`
  - `Clear those completed tasks.`
- Memory-control commands are handled before the generic model response so Jarvis gives one short confirmation only after the local write succeeds.
- Added lifecycle states for events, facts, and relationships, including active/current, completed, dismissed, superseded, outdated or historical, incorrect, forgotten, and restored.
- Current recall, consolidated profiles, Realtime context, and open-item views now exclude evidence that is no longer active.
- Exact source events, timestamps, actor attribution, metadata, and correction lineage remain available in history.
- Explicit corrections create a new corrected assertion and supersede the old evidence rather than silently overwriting provenance.
- Forgetting removes a record from current recall while retaining an auditable historical source. Permanent event deletion remains a separate explicit control.
- Completing or dismissing a task updates the source event, derived fact, proactive item, and entity profile together.
- Reopening restores terminal records and their current-memory effect.
- Lifecycle operations capture dependent proactive state so Undo restores the complete linked state, not only the event label.
- Added lifecycle APIs for events, facts, and relationships plus per-record history retrieval.
- Expanded Memory Explorer controls for editing, correcting, completing, dismissing, superseding, marking incorrect, forgetting, restoring, and deleting records.
- Added lifecycle history to the memory detail drawer and current-fact controls to entity profiles.
- Updated Jarvis’s live capability registry so he accurately describes the new memory controls and their limitations.

## Current-truth contract

- An exact event is historical evidence; a current fact or open item is Jarvis’s present understanding.
- Completed, dismissed, superseded, outdated, incorrect, and forgotten evidence cannot silently reappear in current model context.
- A correction preserves both the old source and the new source while only the corrected assertion remains current.
- A memory question such as `Do you remember my launch date?` is not treated as a destructive memory command.
- Destructive or corrective behavior requires explicit wording and conservative target matching.
- Ambiguous commands do not guess across unrelated people, projects, tenants, or records.
- All identity, entity, correction, lifecycle, attribution, merge, and privacy behavior remains generalized for arbitrary users and tenants.

## Existing response behavior preserved

- Short memory confirmations still obey the live response-length profile and remain concise.
- Self-awareness and capability answers continue to use the accepted `0.1.7` hybrid spoken-summary and detailed-written-answer behavior.
- Full mode remains Realtime-only for complete spoken answers.
- Long written answers retain compact faded previews and the fullscreen reader.

## Validation

Automated coverage verifies natural-command parsing, current-truth filtering, correction lineage, forgetting, completion, reopening, completed-task cleanup, lifecycle history, full-state Undo, trusted local API boundaries, Memory Explorer controls, capability grounding, and the accepted Speaker Recognition and Self Awareness behavior.
