# 0.3.4 — Cloud Sync Testing Guide

Do not commit until the live acceptance below passes.

## Automated validation

Run the focused suites if local validation is needed:

```powershell
python -m pytest -q tests/test_cloud_sync.py tests/test_cloud_sync_api.py tests/test_cloud_sync_relay.py tests/test_accounts.py tests/test_account_api.py tests/test_server.py tests/test_capability_registry.py tests/test_desktop_presence.py tests/test_release_consistency.py
```

```powershell
node --test tests_js/cloud_sync.test.cjs tests_js/account_foundation.test.cjs tests_js/runtime_reliability.test.cjs tests_js/browser_access.test.cjs
npm run desktop:check
node --check extensions/jarvis_browser_bridge/service_worker.js
node --check extensions/jarvis_browser_bridge/content.js
```

## Tasks & reminders

Tasks & reminders are the only portable user-data scope in 0.3.4.

## Live acceptance

1. Start Jarvis while signed out. Confirm normal wake/text assistant controls remain locked and Account explains that a verified online account is required.
2. Create an account using a real-looking test email or phone plus a password of at least 12 characters. In development simulation, use the surfaced development verification code; a production relay must never expose the code itself.
3. Complete verification. Confirm Account becomes verified/cloud-connected and normal Jarvis controls unlock without a separate technical Cloud Sync setup step.
4. Close and reopen Jarvis. Confirm the account/session is still recognized and the same account/tenant/device identity is shown.
5. Create at least one task/reminder, enable task Cloud Sync, run Sync now, and confirm the run reports success with no unexpected conflict.
6. Confirm Memory sync is disabled/unavailable and the Account UI explicitly says memory, voice embeddings, OAuth/provider tokens, API keys, browser state, usage logs, and diagnostics are not 0.3.4 Cloud Sync payloads.
7. If a second Jarvis device is available, sign in using the same verified email/phone and password. Confirm it recovers the same account + tenant but receives a distinct device identity, then confirm the synced task appears.
8. Edit the same synced task independently on both devices before either sees the other's change. Sync device A, then device B. Device B must preserve its local edit and report a revision conflict rather than silently overwriting either version.
9. Cancel a task on one device while the other device still has an older copy. The stale device must not overwrite the cloud cancellation; the conflict remains visible.
10. From Account, list authorized devices and revoke the other device. The revoked device's existing cloud session must stop working.
11. Sign out. Confirm the cloud session is revoked and Jarvis returns to the account-required state; local device data is not erased.
12. Re-test one accepted 0.3.3 feature such as `Can you pause the video, please?` and then another spoken turn to confirm Browser Control and microphone continuity did not regress.
13. Confirm visible release surfaces show `0.3.4 · Cloud Sync`.

## Expected product boundary

Jarvis is now positioned as an online service. Network/API loss should produce a clear connectivity failure rather than an offline-service promise. Device-resident caches and local executors may retain state, but normal Jarvis intelligence is not advertised as available offline.
