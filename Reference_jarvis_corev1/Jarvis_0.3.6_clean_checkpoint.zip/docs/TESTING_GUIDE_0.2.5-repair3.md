# 0.2.5-repair3 — Live Test

## Install

Close Jarvis, extract the repair ZIP directly into the existing project root, allow merge/replace, run the repair installer, then start Jarvis normally.

## Test 1 — Guided enrollment

Open **Memory → Voice Profiles**, choose an existing person, confirm consent, and press **Record guided sample**.

Expected:
- Jarvis shows a specific sentence to read.
- The UI shows which guided sample is being recorded.
- A clear recording is accepted and reports its quality.
- The next recording uses a different phrase.
- Three accepted samples produce **High recognition readiness** when their aggregate quality is strong.

## Test 2 — Quality rejection

Intentionally make one recording unusable (very quiet, mostly silence, or too far from the microphone).

Expected:
- The sample is rejected rather than stored.
- Jarvis asks for the guided phrase again with an actionable quality reason.
- The accepted sample count does not increase.

## Test 3 — Known-speaker consistency

With at least three good samples enrolled, speak several normal turns including short ones:

> Jarvis, who am I?
>
> What do I have tomorrow?
>
> What time?

Expected:
- Your known person name is used more consistently instead of frequently falling back to `Unknown speaker`.
- Short follow-ups immediately after a strong recognition can use bounded session continuity.

## Test 4 — Do not create stickiness

When another enrolled person is available, alternate speakers naturally.

Expected:
- Jarvis switches when the other voice is a stronger distinct match.
- If two candidates are genuinely ambiguous, Jarvis remains uncertain instead of forcing the previous speaker identity.
- Unknown people remain neutral and are never assigned `sir`, `ma'am`, or another person's preferences automatically.

## Test 5 — Persistence

Restart Jarvis after the guided samples are enrolled.

Expected:
- The protected samples and readiness state remain available.
- Recognition still uses the multi-sample profile after restart.
