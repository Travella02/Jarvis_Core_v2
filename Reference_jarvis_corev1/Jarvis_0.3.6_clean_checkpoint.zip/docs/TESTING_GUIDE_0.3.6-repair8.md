# 0.3.6-repair8 — URL Routing Testing

Apply only over the exact verified `0.3.6-repair7` candidate. Do not commit until the full 0.3.6 live acceptance is explicitly complete.

## Automated checks

```powershell
python -m pytest -q tests/test_browser_direct_url_routing.py tests/test_browser_confirmation_security.py tests/test_permission_confirmation_security.py tests/test_permission_executor_enforcement.py tests/test_release_consistency.py
node --test tests_js/browser_url_routing.test.cjs tests_js/browser_access.test.cjs tests_js/computer_actions.test.cjs
npm run desktop:check
npm run desktop:test
```

## Live repair check

With Browser Control **Allowed**, say:

> Open YouTube.com in a new tab.

PASS: Browser Control opens `https://youtube.com` in a new tab. Jarvis must not say it could not find an app/file on the PC.

Repeat with:

> Open example.com in a new tab.

Then set Browser Control to **Always ask** and repeat. PASS: the trusted native prompt should say approximately `Permission required. Allow Jarvis to open example.com in a new browser tab?`; Allow opens that exact site once, Cancel performs nothing, and no request falls through into Computer Actions.

Regression check: `Open Discord`, `Open Rocket League`, and normal local file/folder requests must remain Computer Actions rather than Browser Control.
