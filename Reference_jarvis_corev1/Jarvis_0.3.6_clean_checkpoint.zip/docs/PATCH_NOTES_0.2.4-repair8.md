# 0.2.4-repair8 — Expressive Speech

## Why repair8 exists

The live `0.2.4-repair7 — Natural Voice Pipeline` test passed the functional checks: the grounded task/reminder time stayed correct, the new Luna-owned wording path worked, the response-length modes behaved correctly, and the dedicated Cedar speech path remained interruptible.

The remaining acceptance issue was voice quality. Compared with the previous Realtime speech, dedicated Cedar TTS sounded flatter, more monotone, and more robotic.

## Root cause

Repair7 intentionally made the speech layer conservative so it could not reinterpret application facts. The default delivery instruction combined phrases such as **understated** and **expressive but restrained intonation** with an exact-script contract. That protected facts, but it also encouraged an unnecessarily narrow prosody range.

The architecture itself does not need to change. OpenAI's GPT-4o mini TTS supports delivery instructions for emotional range, intonation, speed, and tone, so Jarvis can keep exact application-owned words while asking Cedar for a more human performance.

## Repair

Repair8 keeps every repair7 ownership boundary intact and changes only delivery behavior:

- **Luna/Jarvis Core still owns the exact words.**
- **Fact guards still protect authoritative names, times, dates, numbers, recipients, and other application data.**
- **Realtime remains the listening/live-session/interruption layer.**
- **Cedar TTS remains the mouth and still may not add, remove, paraphrase, reinterpret, or substitute words.**

The TTS delivery prompt now explicitly asks for:

- noticeable but believable human pitch variation;
- changing rhythm instead of evenly spaced timing;
- meaning-driven emphasis;
- natural micro-pauses at thought boundaries;
- smooth sentence endings rather than repeated sentence melody;
- conversational energy instead of narrator/IVR delivery;
- short-answer prosody so replies such as **“2 PM.”** do not sound clipped or deadpan.

## Personality-specific delivery

Repair8 separates **wording personality** from **speech delivery personality**. `Classic`, `Casual`, `Warm`, `Direct`, and `Witty` now each have a dedicated prosody profile.

For example, `Classic` remains composed and intelligent but is no longer instructed to sound vocally restrained. `Direct` can stay brief without becoming flat. `Warm` can sound more engaged without becoming theatrical.

Personality still cannot change facts or override response length.

## Turn-aware delivery

The desktop now passes limited conversational delivery context to the speech endpoint:

- the user's current utterance;
- the response purpose;
- the selected personality;
- the response mode.

This context is used only to choose **how** the exact script should sound. It is not permission for TTS to change **what** Jarvis says.

Examples:

- A very short factual answer gets a small natural pitch contour and emphasis instead of a one-note readout.
- A written question receives a natural question contour.
- A written exclamation can carry a little more energy.
- A connected-action fact can sound confident and conversational rather than like a status report.

## Response modes

`Test / Short / Normal / High / Full` remain speech-depth ceilings, not emotional settings. A short answer in Full mode should still sound alive; Full mode does not make Jarvis slower or flatter.

## Cost and model

Repair8 does not add another model call and does not change the speech model or voice. It still uses `gpt-4o-mini-tts` with `cedar`; the additional context is only a small amount of text in the existing speech request.

## Acceptance target

The repair7 functional behavior must remain unchanged, while Cedar should sound noticeably less monotone and more like a natural conversational speaker.
