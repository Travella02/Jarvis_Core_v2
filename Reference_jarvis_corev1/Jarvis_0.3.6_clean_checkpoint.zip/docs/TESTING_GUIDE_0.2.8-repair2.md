# 0.2.8-repair2 — Live Test

1. Start Jarvis, wake it, and say **“Open Rocket League.”**
   - Rocket League should open and Game Mode should activate normally.

2. With Rocket League still running, say **“Can you also open Snipping Tool, please?”**
   - Snipping Tool should open.
   - Jarvis should give the grounded open confirmation.
   - Game Mode should remain active for Rocket League.

3. Say **“Could you also close Snipping Tool?”**
   - Snipping Tool should close normally.

4. Optional routing variants:
   - **“And can you open Snipping Tool too?”**
   - **“Then can you close Snipping Tool as well?”**
   - Both should execute as direct Computer Actions.

5. Privacy test: activate/touch the microphone several times without intentionally saying anything useful.
   - No bubble should ever display `Personal assistant conversation...` or any substantial fragment of the private transcription guidance.
   - A no-speech turn should disappear rather than becoming fake user history.

6. Speak one normal sentence after the silence test.
   - The completed user transcript should still appear normally.
   - Jarvis should continue responding normally.

7. Press **Sleep**, wait briefly, wake Jarvis again, then say **“Close Rocket League.”**
   - The core should remain stable.
   - Rocket League should close and Game Mode should clear after its real process disappears.
