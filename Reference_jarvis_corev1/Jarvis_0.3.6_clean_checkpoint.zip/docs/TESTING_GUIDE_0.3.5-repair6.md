# Testing Guide — 0.3.5-repair6

## Apply

Close Jarvis completely. Extract the repair ZIP into the Jarvis project root and run:

```powershell
python .\apply_0_3_5_repair6_patch.py
```

Do **not** start `python -m apps.core` separately. Start Jarvis through Electron with `npm run desktop`.

Repair6 does not change Browser Bridge extension files, so an extension reload is not required if repair5 was already reloaded correctly.

## Automated validation

```powershell
python -m pytest -q tests/test_browser_access.py tests/test_game_mode.py tests/test_voice_lab_client.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

The dependency-installed Windows environment should report the complete Node suite with no failures. Do not run `npm audit fix --force` as part of this repair.

## Live test A — native fullscreen now dispatches

1. Start Jarvis with `npm run desktop`.
2. Open/play the same YouTube video used during repair5 acceptance.
3. Leave Game Mode inactive.
4. Say `Fullscreen YouTube.`
5. YouTube should enter its real native player fullscreen state.
6. Say `Minimize YouTube.` and verify it exits normally.
7. Repeat fullscreen/minimize at least five times.
8. Pause/resume once while fullscreen.

Successful visible fullscreen/minimize actions remain silent. If native dispatch fails, preserve the terminal/UI result; the native result now retains a Win32 error code internally for diagnosis.

## Live test B — natural closest-match playback remains fixed

1. Search YouTube for Sidemen.
2. Say `Play Sidemen Sleepover.`
3. Jarvis should select the closest confident grounded result without requiring the exact title or `play the first result`.

## Live test C — competitive Game Mode remains fail-closed

1. Launch a known competitive game such as Rocket League and wait for Game Mode protection to become active.
2. Alt+Tab to Edge/YouTube while leaving the protected game running.
3. Say `Fullscreen YouTube.`
4. Jarvis must refuse the native shortcut and send no keyboard input.
5. Structural controls such as pause/play/seek/volume remain available through Browser Bridge.
6. Close the game, wait for Game Mode to deactivate, and confirm fullscreen works again.

Any native shortcut reaching a protected game is an immediate release blocker.

Do not commit yet. Repairs remain `0.3.5-repairN` until the complete 0.3.5 live acceptance suite passes and the user explicitly accepts the release. No Git tag.
