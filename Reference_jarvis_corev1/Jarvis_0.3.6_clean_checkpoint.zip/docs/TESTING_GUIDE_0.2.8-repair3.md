# 0.2.8-repair3 — Safety Probe Live Test

The Safety Probe is diagnostic only. It never sends keyboard or mouse input.

## A. Protected game running in background

1. Start Jarvis and say **“Open Rocket League.”**
2. Wait for **GAME MODE · Rocket League**.
3. Alt-Tab back to Jarvis/PowerShell so Rocket League is still running but not foreground.
4. From the project root run:

   `py -3.12 .\tools\game_mode_safety_probe.py`

Expected:

- `Input emitted: False`
- process memory / injection / input hooks: `BLOCK`
- keyboard/mouse/vision/macro targeting Rocket League: `BLOCK`
- normal OS app-close: `ALLOW`
- explicit non-game target while Rocket League is background: `ALLOW`
- overall result: `PASS`

## B. Foreground race guard

1. Keep Rocket League running.
2. From PowerShell run:

   `py -3.12 .\tools\game_mode_safety_probe.py --delay 5`

3. As soon as the countdown starts, Alt-Tab into Rocket League and leave it foreground.

Expected:

- `Foreground game: Rocket League`
- the probe's explicit Chrome-target keyboard request: `BLOCK (protected_game_foreground)`
- untargeted mouse input: `BLOCK (protected_game_foreground)`
- `Input emitted: False`
- overall result: `PASS`

This proves that if a future browser/desktop action planned for Chrome loses focus to the game before dispatch, the same production firewall refuses the input.

## C. Regression sanity

After the probes:

1. Alt-Tab out of Rocket League.
2. Ask Jarvis to open and close Snipping Tool.
3. Sleep and wake Jarvis.
4. Ask Jarvis to close Rocket League.

Expected: ordinary Computer Actions remain functional, the core stays stable, and Game Mode clears after the real game process exits.

## D. Anti-cheat-only state

After Rocket League is fully closed, run the probe once more:

`py -3.12 .\tools\game_mode_safety_probe.py`

Expected:

- `Game Mode active: False`
- if an anti-cheat/helper process happens to remain, `Anti-cheat present` may be `True`, but it still must not activate Game Mode;
- the probe may report `SAFE, but not acceptance-ready` because no protected game is currently running. That is expected.
