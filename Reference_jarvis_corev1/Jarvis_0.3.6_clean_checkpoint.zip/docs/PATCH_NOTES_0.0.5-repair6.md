# 0.0.5 — Electron Shell Repair 6

## Summary

Improves the local Windows lifecycle recognizer after live testing showed that the process could remain ready while generic dictation failed to recognize the uncommon proper noun “Jarvis.”

## Changes

- Added high-priority exact wake grammars for “Jarvis,” “Hey Jarvis,” “Yo Jarvis,” “Okay Jarvis,” and “OK Jarvis.”
- Added a wake-plus-dictation grammar so phrases such as “Jarvis, tell me a joke” preserve the complete opening request.
- Added a dedicated local grammar for supported spoken sleep phrases.
- Retained lower-weight general dictation for normal local transcript assistance.
- Added microphone audio-level diagnostics that distinguish no signal from speech that failed to match.
- Added Electron terminal logs for recognized phrase, grammar, and confidence.
- Added recruiter-friendly issue record `ISSUE_027_WINDOWS_DICTATION_MISSED_JARVIS.md`.

## Security and privacy

Recognition remains local to the Windows speech engine. The patch does not expose `.env`, API keys, raw provider credentials, or private configuration to Electron renderer code.
