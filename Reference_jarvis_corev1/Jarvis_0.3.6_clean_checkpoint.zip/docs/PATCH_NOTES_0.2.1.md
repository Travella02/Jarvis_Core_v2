# 0.2.1 — Action Intelligence

Jarvis can now turn a connected Google request into a coherent multi-step assistant workflow instead of treating each Gmail or Calendar API call as an isolated command.

## Luna remains the action brain

- `gpt-5.6-luna` interprets the complete user request, resolves action intent, selects operations, extracts arguments, reasons across provider results, prepares confirmations, and writes the action result.
- OpenAI Realtime remains the live voice layer only: capture/transcription, interruption, and speaking concise prepared text.
- Connected-action provider results are returned to Luna before Realtime speaks. Realtime does not independently choose Gmail, Contacts, or Calendar operations.

## Google Contacts and person resolution

- Added read-only Google Contacts lookup through the People API.
- Natural requests such as “email Kenleigh” can resolve a saved contact instead of requiring the user to dictate an email address.
- Direct email addresses still work without Contacts lookup.
- Ambiguous contact matches produce a clarification instead of guessing.
- Existing 0.2.0 Google connections can remain usable for Gmail/Calendar, but must reconnect once to grant the new Contacts scope before name-to-address resolution is available.

## Gmail thread intelligence

- Added full Gmail thread retrieval with normalized sender, recipients, subject, headers, snippet, and decoded text body.
- Jarvis can find a relevant thread, let Luna understand the conversation, and create a contextual reply draft in that same Gmail thread.
- Reply drafts preserve Gmail threading metadata (`threadId`, `In-Reply-To`, and `References`).
- Existing drafts can be revised rather than creating a new duplicate draft for every edit request.
- “Send it” can send the latest created, replied-to, or revised draft once the user explicitly requests sending.

## Cross-service workflows

- Added a combined Google brief that can satisfy one request spanning Gmail and Calendar.
- Added email-to-calendar extraction: Luna can read a relevant email/thread, extract a proposed event, and hand it to the normal confirmation-protected Calendar create path.
- Added Google Calendar free/busy lookup for availability reasoning across one or more calendars.

## Visible Pending Actions

- Connected Apps now shows a dedicated Pending Action card for confirmation-required operations.
- Users can review the proposed action, confirm it, cancel it, or move the action back into chat for edits.
- Editing the same pending operation updates the existing pending action instead of stacking duplicate pending records.
- Confirm and Cancel have dedicated trusted local endpoints and update the audit ledger immediately.

## Capability truth

- The live capability registry now exposes Google Contacts separately from Gmail and Calendar.
- The Connected Apps panel reports whether Contacts access is available or whether the account needs a one-time reconnect for the new scope.
- Jarvis continues to report live provider availability rather than assuming a service is connected.

## Safety

- Gmail reads, thread reads, contact reads, free/busy reads, and draft creation/revision are non-sending operations.
- Sending email remains an explicit separate user action.
- Calendar create/update/delete remains confirmation protected.
- Provider success is required before Jarvis reports an external action as completed.
- The local action audit ledger continues to preserve pending, completed, cancelled, and failed outcomes.
