# Testing Guide — 0.2.1-repair4 Draft Editing

Use a disposable recipient/message for any test that reaches the final send confirmation. Draft creation, editing, and cancellation themselves must not send email.

## Install and start

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair4_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```

## 1. Nonblank intent-only draft

Say exactly:

> Draft an email to Tanner asking how he's doing.

Expected:

- Tanner resolves through the existing recipient-resolution path.
- Gmail creates a real draft.
- The `EMAIL DRAFT` card contains a nonblank natural message asking how Tanner is doing.
- The card remains `Draft saved · Not sent`.
- Jarvis does not hand the request to ordinary Realtime conversation.

## 2. Manual editor — compact view

On that draft, click **Edit**.

Expected editor fields:

- From — read-only
- To
- Cc
- Bcc
- Subject
- Message
- Cancel
- Save changes

Set Subject to:

> Checking in

Change the Message to any safe test text, then click **Save changes**.

Expected:

- The exact Gmail draft is updated in place.
- No email is sent.
- The same draft card returns with the updated subject/message.
- Status still reads `Draft saved · Not sent`.

## 3. Manual editor — Fullscreen

Open that draft in **Fullscreen** and click **Edit** there.

Change the subject or message again and save.

Expected:

- Fullscreen keeps the structured email layout.
- The editor is usable in Fullscreen.
- Saving updates the exact same Gmail draft.
- Closing/reopening Fullscreen shows the new values.
- The compact conversation card is also synchronized.

## 4. Voice/typed subject edit

While the draft is still pending, say:

> Change the subject to Today.

Expected:

- Connected Actions/Luna handles the instruction.
- The same Gmail draft ID is updated.
- Subject becomes `Today`.
- Recipient and message stay unchanged.
- Nothing is sent.

## 5. Voice/typed message edit

Say:

> Make the message a little friendlier.

Expected:

- Luna rewrites the existing draft body rather than creating a new draft.
- The full revised body is written back to Gmail.
- Subject/recipients remain unchanged unless explicitly requested.
- The preview updates and remains unsent.

Also try a direct replacement command such as:

> Replace the message with: Thank you for coming. I really appreciate it. Talk to you soon.

Expected: the body becomes the requested text and remains unsent.

## 6. Negative send cancellation

Say exactly:

> No, don't send.

Expected:

- Jarvis replies naturally that it will leave the message saved as a draft.
- No generic `I recognized that as a Gmail request...` routing failure appears.
- Gmail does not send the message.
- The Gmail draft remains saved.

Repeat later with a new draft using one variant such as:

> Please don't send it.

or

> No, do not send.

## 7. Send after editing

Create one more disposable draft, edit it manually or by voice, review the final card, then say:

> Yes, please go ahead and send it.

Expected:

- The exact edited draft sends once on that first explicit confirmation.
- Jarvis does not ask for a second confirmation.
- The sent presentation reflects the edited subject/body.

## 8. Continue 0.2.1 acceptance

If these checks pass, resume the remaining flow in `docs/TESTING_GUIDE_0.2.1.md`. Do not begin 0.2.2 until the complete 0.2.1 acceptance flow passes.
