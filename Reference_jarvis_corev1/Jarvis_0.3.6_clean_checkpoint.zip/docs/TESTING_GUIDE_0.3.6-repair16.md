# 0.3.6-repair16 Live Testing — Permission & Action Confirmation Separation

Do not make the final 0.3.6 acceptance commit or clean patch artifacts yet. Apply Repair16 only over the exact `0.3.6-repair15` candidate.

## Automated checks

1. Run the Repair16 Calendar/permission security tests.
2. Run Connected Action confirmation-security and authenticated-reauth regression tests.
3. Run the Repair16 Electron source-contract tests.
4. Run `npm run desktop:check`.
5. Run the normal 0.3.6 Python regression group and full Electron suite before final acceptance.

## Live test A — Always ask exposes a real user choice

1. Set **Calendar Actions** to `Always ask`.
2. Create a disposable event such as `0.3.6 repair16 allow once test`.
3. Ask Jarvis to delete it and answer `Yes` to Jarvis's exact event review.

**Pass:** the trusted native prompt offers **Cancel**, **Allow once**, and **Always allow**. Choose **Allow once**. The exact event is deleted once, and the Calendar permission remains `Always ask`.

Repeat with another disposable event.

**Pass:** Jarvis asks through the trusted native permission surface again, proving `Allow once` did not persist.

## Live test B — Always allow persists capability permission, not action authority

1. Keep Calendar on `Always ask` and create another disposable event.
2. Ask Jarvis to delete it and answer `Yes` to the exact event review.
3. In the trusted native prompt choose **Always allow**.

**Pass:** the exact event is deleted, and Calendar permission becomes `Always allow`.

4. Create another disposable event and ask Jarvis to delete it.

**Pass:** Jarvis still shows/reviews the exact event and asks whether to remove it. After the conversational `Yes`, the event deletes with **no native permission popup**. `Always allow` removed capability-permission friction; it did not remove the consequential Calendar action review.

## Live test C — Cancel is terminal

1. Set a persistable capability to `Always ask`.
2. Reach its trusted permission prompt.
3. Click **Cancel**.

**Pass:** the exact pending provider action does not execute, the stored permission remains unchanged, and Jarvis does not reinterpret the cancellation as a new action.

## Live test D — Gmail send separation

1. Set Gmail send permission to `Always ask`.
2. Draft a disposable email and approve Jarvis's exact send review.
3. Verify the trusted prompt has all three choices.
4. Choose **Allow once** for one send and confirm a later send asks again.
5. On a subsequent send choose **Always allow**.
6. Draft one more email.

**Pass:** Jarvis still asks its normal exact `Want me to send it?` review, but after the user confirms, no native permission popup appears.

## Live test E — routine capability regression

For a routine/reversible persistable permission such as ordinary Browser Control, select `Always allow` and repeat a matching action.

**Pass:** future matching actions execute without a native permission prompt and without an unnecessary action-level confirmation unless that action has its own consequential-action policy.

## Live test F — Block and non-persistable safety boundaries

1. Set a tested capability to `Block` and attempt the action.
2. Exercise a permission whose policy does not support persistent authority (for example force termination if testing that feature separately).

**Pass:** Block cannot be bypassed by the native prompt. Non-persistable permissions never offer **Always allow**. Authenticated/restricted/forbidden/system-safety boundaries remain unchanged.

## Security invariant

The native permission choice and exact challenge ID are HMAC-bound by Electron main. The renderer may relay `allow_once` or `always_allow`, but cannot change one into the other without invalidating the attestation. `Always allow` persists capability permission only; the exact action-review contract remains independently authoritative for consequential work.
