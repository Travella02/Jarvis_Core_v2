# 0.0.3 — Wake Turn Repair

## Summary

Fixes an intermittent duplicate first turn after a natural wake phrase.

## Changed

- Added a temporary wake-input gate when the wake phrase already contains an opening request.
- Prevents the WebRTC microphone from creating a second provider VAD turn while the queued wake request owns the conversation.
- Suppresses and clears unexpected input-audio events during that gate.
- Releases the microphone after the opening response and audible Jarvis output finish.
- Preserves normal microphone behavior when Tanner says only “Jarvis” and then speaks after connection.
- Keeps manual mute, sleep, cleanup, error recovery, and timeout behavior compatible with the gate.

## Issue record

- `issues/ISSUE_014_WAKE_FIRST_TURN_DUPLICATION.md`

## Validation

- Full automated suite passed.
- JavaScript syntax passed.
- Doctor and safe diagnostic passed.
- Installer succeeded from the exact repair2 baseline and on an idempotent rerun.
- Test `.env` remained byte-for-byte unchanged.
