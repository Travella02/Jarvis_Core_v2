# 0.3.0-repair9 — Web Experience Polish

This repair keeps the fresh first-party intelligence from repair8 while reducing redundant search cost, completing ordinal Browser Control follow-ups, and polishing Web Intelligence cards.

- Recency-sensitive searches now use adaptive freshness verification. A first pass may finish in one grounded Responses request only when it explicitly proves first-party chronology freshness; uncertain results retain the domain-constrained second challenge pass.
- Exact recent grounded queries are cached for a short bounded TTL, avoiding repeated API/search cost for identical follow-up checks.
- `Play/open/click the first/second/... result` now has a deterministic Browser Control continuation path. YouTube continuation selects grounded watch-result links and skips a Luna planning round trip.
- Desktop browser-context routing now recognizes `play` follow-ups.
- Web Intelligence answers render with lead paragraphs, section headings, structured bullet lists, emphasized `Label:` prefixes, larger fullscreen typography, and clearer source rows.
- Clamped chat previews hide the source inventory and show a cleaner `View full result` affordance.

Accuracy remains authoritative: when first-pass recency evidence is not conclusive, Jarvis still performs the same first-party freshness challenge introduced in repair8.

VERSION and release metadata remain unchanged until 0.3.0 live acceptance passes.
