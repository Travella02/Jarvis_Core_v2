# 0.2.4 — Tasks & Reminders

0.2.4 adds a durable local task and reminder system to Jarvis. Luna remains the action planner; Realtime remains the speech/conversation layer. Tasks are stored locally, scoped by tenant and actor, and do not require Google to be connected.

## What changed

- Natural task creation, listing, updating, completion, reopening, removal, postponing, priorities, due dates, and recurrence.
- Natural reminders such as “remind me tomorrow at 2 PM to call Tanner” and recurring reminder-only items such as weekdays.
- Persistent SQLite task storage under Jarvis's local data directory, surviving sleep, app restarts, and computer restarts.
- Actor-scoped task ownership. Recognized speakers get their own task set; one actor's reminder claim does not surface another actor's reminders.
- Reminder delivery while the desktop app is running: Jarvis surfaces a reminder card in the conversation and can raise a native desktop notification. If Jarvis was closed when a reminder became due, it is surfaced after the app starts again.
- Reminder-only recurring items automatically advance after firing. Recurring to-dos with due dates advance when the user completes them, so unfinished work is not silently hidden.
- New Tasks workspace with open, overdue, and completed counts plus quick Complete, Reopen, and Remove controls.
- Task cards and fullscreen task presentation consistent with Gmail and Calendar action cards.
- Task follow-up continuity for phrases such as “mark that done,” “move that to Friday,” and “remind me at 6.”
- Local task actions use Connected Actions ownership before ordinary Realtime, preventing false capability denials.

## Important behavior

- Task changes are local and reversible enough to run immediately; they do not use the external-write confirmation gate required for Gmail sending or Google Calendar changes.
- Desktop reminders require Jarvis to be running. 0.2.4 does not wake a powered-off computer or depend on an external notification service.
- Reminder notifications are visual/native by default rather than unsolicited Realtime speech, reducing interruptions and voice API cost.
- Tasks remain local-first and are not synchronized to Google Tasks, Microsoft To Do, or another provider in this release.
