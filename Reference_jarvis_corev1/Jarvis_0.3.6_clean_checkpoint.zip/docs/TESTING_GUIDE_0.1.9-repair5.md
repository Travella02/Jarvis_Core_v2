# Testing Guide — 0.1.9-repair5

## 1. Ordinary relationship recall

Ask:

> What do you remember about my fiancée?

Expected:

- Jarvis states the remembered relationship naturally, for example: “Your fiancée is Kenleigh Yarman.”
- He does not mention a voice note, conversation date, source type, confidence, evidence, or verification disclaimer.
- No detailed companion or Fullscreen control appears for the short answer.

## 2. Provenance on demand

Immediately ask:

> How do you know that?

Expected:

- Jarvis gives one short natural source answer, for example: “You told me in a voice conversation on August 3, 2026.”
- He does not add “that’s the evidence,” “not a guess,” or “I can’t verify.”

## 3. Date-specific source question

Ask:

> When did I tell you about Kenleigh?

Expected:

- Jarvis includes the remembered date when available.
- The date appears because the user explicitly requested provenance.

## 4. Regression checks

Confirm these still work:

- “What are we still working on for the business?” resolves ORVEX once.
- “What did we decide about the company?” returns decisions only.
- “What was the old value before I corrected it?” asks only which correction you mean.
- Short answers do not show Fullscreen.
- A genuinely clipped detailed answer still shows the fade and Fullscreen reader.
