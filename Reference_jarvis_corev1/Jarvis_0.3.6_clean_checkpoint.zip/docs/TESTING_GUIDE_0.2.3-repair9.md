# Testing Guide — 0.2.3-repair9 Action Ownership

## Primary live test — only one meeting
Make sure tomorrow contains only the meeting you have been testing with Tanner.

1. Ask Jarvis: **“Can you add Austin to that meeting tomorrow?”**
2. Expected: Jarvis must not ask which meeting. Because there is only one matching Calendar event, he should bind it automatically.
3. If Austin still has no known email, expected response is naturally equivalent to: **“I couldn’t find Austin’s email address. What’s Austin’s email?”**
4. Jarvis must not say that he cannot update Google Calendar and must not tell you to add Austin manually in a calendar app.
5. Reply with an address, for example: **“His email is austin@example.com.”**
6. Expected: the same meeting remains selected, its correct local time and duration stay unchanged, Tanner remains an attendee, Austin is added to the proposal, and Jarvis asks once for confirmation.
7. Say: **“Yes, update it.”**
8. Verify Austin was actually added to that exact Google Calendar event.

## Selection-continuity regression
If you temporarily create a second event tomorrow so a clarification is genuinely required:

1. Ask Jarvis to add Austin to a meeting tomorrow.
2. When Jarvis asks which meeting, say: **“The one with Tanner.”**
3. That reply must remain in Connected Actions. Jarvis must not produce a Realtime capability denial such as “I can’t directly update your calendar.”

## Google capability truth regression
While Google is connected and Connected Apps reports Gmail/Calendar available, try a supported Google action in natural wording. Acceptance criterion: Jarvis never claims that he cannot access or control a capability that the live registry says is available, and never redirects the user to perform that supported action manually. Actual writes still require the existing confirmations.

## No-regression checks
- The repair7 local-time system must remain intact.
- No Google reconnect is required for this repair.
- `.env` must remain untouched.
