# 0.3.6-repair5 — Trusted Executor Confirmation

**Date:** 2026-09-03  
**Required previous release:** 0.3.6-repair4  
**VERSION remains:** 0.3.6  
**Status:** Live acceptance repair candidate

## Why this repair exists

Live Permissions & Security testing exposed a real problem in the Browser/Computer **Always ask** path. A safe Browser action could produce awkward conversational confirmation wording, cancellation could fall through into another capability router, and the permission engine could create a one-use grant that the user-raised `ASK` branch never consumed.

## What changed

- User-raised `ASK` on otherwise automatic permissions now consumes the exact matching one-use confirmation grant at the real permission check.
- Browser Control and Computer Actions no longer ask for device-policy permission through ordinary chat. They surface the exact challenge directly in Jarvis's trusted native confirmation UI.
- Browser prompts are action-specific and natural, such as **"Allow Jarvis to open a new browser tab?"**
- Approving retries the exact stored/requested action with trusted desktop attestation; the executor itself still consumes the grant before execution.
- Cancelling the native permission prompt terminates the action as handled, so it cannot fall through and be reinterpreted as a Computer Action, Luna request, or another capability.
- Browser/Computer permission challenges bind to the live speaker lane (`session_speaker_id`) rather than a cosmetic attribution label or local-owner fallback. Short recognition uncertainty can keep the same lane, but another speaker lane cannot reuse the challenge.
- Stale/wrong/replayed challenge retries fail closed and never silently mint a new challenge in the same attempt.

## Security boundary

Repair5 does not weaken Phase 3/5 confirmation security. A challenge ID is not approval. Trusted Electron-main-process user presence (or purpose-bound authenticated reauthentication where policy requires it) remains mandatory, and the transaction stays:

`exact challenge -> trusted approval -> one-use grant -> executor permission check consumes grant -> execution`

## Issue

See ISSUE-328.

## Commit rule

Do not commit yet. Apply repair5 over the exact repair4 live candidate, rerun automated/live tests, and keep all patch/repair/backups until Tanner explicitly accepts the complete 0.3.6 release. No Git tag.
