# 0.2.3-repair11 — Response Lock

## User-visible change
A grounded Gmail or Calendar action now owns its entire response from planning through speech. Realtime can no longer replace a correct Connected Actions confirmation with a second generic answer.

## What was fixed
During a Calendar write such as “cancel that meeting,” the Connected Actions layer could correctly prepare a pending delete and render its confirmation immediately. A separate or stale Realtime response could then arrive and become the spoken summary for the same hybrid bubble. The UI combined that ungrounded summary with the correct Calendar card/prompt, which looked like two contradictory Jarvis answers and let the wrong one appear to take priority.

Connected Action turns now claim a short-lived response-ownership window. The authorized Realtime speech request carries a unique Connected Action token. Any other Realtime response created during that owned window is cancelled before its audio or transcript can replace the grounded result.

The hybrid written-answer renderer also treats the provider-grounded Connected Action text as authoritative, so a Realtime paraphrase cannot be concatenated above or replace the Calendar/Gmail confirmation even if a provider event arrives out of order.

## Expected Calendar cancel flow
For “Jarvis, can you actually cancel that meeting?” after discussing one event, Jarvis should produce one response such as:

> “Want me to cancel Meeting with Tanner?”

The Calendar removal card remains visible and the event stays on Google Calendar until the user explicitly confirms.

## Scope
This repair does not change the working local-time architecture, attendee lookup, Google permissions, or Calendar write semantics. It only locks response ownership and presentation to the grounded Connected Action result.
