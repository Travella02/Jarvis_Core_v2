# Patch Notes — 0.0.1-dev1-realtime-repair2

- **Project:** Jarvis_Real_Time
- **Project version:** 0.0.1-dev1
- **Repair ID:** 0.0.1-dev1-realtime-repair2
- **Date:** 2026-07-26
- **Required installed version:** 0.0.1-dev1
- **Purpose:** Preserve the Realtime SDP handshake repair and make installer validation safe and deterministic when a real ignored `.env` already exists.

## Observed failure

The first Realtime repair installed its source changes and began validation, but two tests failed because Tanner had correctly created a real `.env` containing `OPENAI_API_KEY`:

1. `test_missing_api_key_has_actionable_error` loaded the active project root and therefore found the configured key instead of exercising the intended missing-key path.
2. `test_documented_direct_script_command_can_import_project` expected only the missing-key warning even though the doctor correctly reported a configured key as hidden.

The repair1 installer then restored the project files automatically. The private `.env` was not modified or exposed.

## Root cause

The tests were written against a clean development repository but were run during installation inside a configured user repository. Passing `environment={}` intentionally suppresses process environment variables, but the configuration loader still reads the repository's local `.env`. The tests therefore depended on a machine-specific secret state.

## Changes

- Preserve all Realtime SDP fixes from repair1:
  - exact browser SDP preservation;
  - typed `application/sdp` and `application/json` multipart parts;
  - final `peer.localDescription.sdp` after bounded ICE gathering;
  - safe redacted upstream error details.
- Run default and missing-key configuration tests in isolated temporary project roots with no `.env`.
- Allow the doctor regression test to accept either:
  - a missing-key warning; or
  - a configured-key status that explicitly hides the value.
- Continue asserting that Authorization data and `OPENAI_API_KEY=` are never printed.
- Update the handoff and architecture decision record to require environment-independent tests.
- Keep `VERSION` at `0.0.1-dev1`.

## Files changed

- `apps/core/server.py`
- `apps/desktop/lab/app.js`
- `jarvis/intelligence/realtime.py`
- `tests/test_config.py`
- `tests/test_doctor_script.py`
- `tests/test_realtime_provider.py`
- `tests/test_server.py`
- `docs/ARCHITECTURE_DECISIONS.md`
- `docs/JARVIS_CORE_HANDOFF_INSTRUCTIONS.md`

## Files added

- `tests/test_voice_lab_client.py`
- `docs/PATCH_NOTES_0.0.1-dev1-realtime-repair2.md`
- `docs/TESTING_GUIDE_0.0.1-dev1-realtime-repair2.md`

## Automated validation

- `python -m unittest discover -s tests -v`
- Result: **29 tests passed**.
- The full suite was run with a valid fake `.env` present at the project root to reproduce Tanner's configured environment safely.
- `node --check apps/desktop/lab/app.js` passed.
- Doctor and core diagnostic both passed with the key reported only as configured and hidden.
- Provider traffic remained mocked; no paid API call was made during automated testing.

## Compatibility and rollback

The repair accepts either the original dev1 files or the repair1 file hashes, allowing safe recovery whether repair1 rolled back completely or some matching repair files are already present. The installer verifies checksums, backs up replaced files, and restores them automatically if validation fails. It never copies, backs up, reads into output, deletes, or replaces `.env`.
