# 0.3.6-repair11 — Conversation Continuity

Repair11 fixes a live multi-turn Connected Actions regression discovered on both development machines.

## What changed

- A transient `Unknown speaker` result no longer destroys an active Gmail/Calendar/Task clarification session.
- Non-executing clarification text such as `Say hi.`, `Tomorrow at 3.`, and pending edit language can reuse the existing Connected Action session while recognition is temporarily uncertain.
- A positively identified different speaker still resets the action context.
- Unknown speech cannot confirm/execute an attributed owner's pending action. Final execution still requires the original speaker or trusted on-screen controls.
- Trusted permission dialogs are now completely voice-inert. Repair9's experimental vocal denial path was removed: prompt-time speech is discarded wholesale.

## Why

Voice attribution is useful security evidence, but ordinary multi-turn drafting cannot depend on perfect biometric attribution for every short phrase. Conversation continuity and execution authorization are now treated as separate concerns.

## Unchanged security boundary

`exact action -> permission policy -> trusted approval when required -> one-use grant -> executor consumes grant -> execution`

Repair11 does not allow Unknown speech to authorize a consequential action and does not weaken executor permission checks.
