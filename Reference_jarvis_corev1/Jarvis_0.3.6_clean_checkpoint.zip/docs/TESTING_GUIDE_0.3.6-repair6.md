# 0.3.6-repair6 — Steam Isolation Testing

## Apply

Close Jarvis completely. Extract the repair ZIP into the project root and run:

```powershell
python .\apply_0_3_6_repair6_patch.py
```

Expected release label: `0.3.6-repair6 — Steam Isolation`.

## Targeted regression

First prove the Windows-host-dependent failure is gone:

```powershell
python -m pytest -q tests/test_computer_apps.py::test_steam_manifest_becomes_reliable_uri_launch_target
```

Expected: **1 passed** even on a Windows machine with a real Steam installation and populated Steam library.

## Repair5/Repair6 regression group

Then rerun the exact group that previously produced 198 passed / 1 failed:

```powershell
python -m pytest -q tests/test_permission_confirmation_security.py tests/test_browser_confirmation_security.py tests/test_permission_executor_enforcement.py tests/test_phase5_adversarial_security.py tests/test_permission_confirmation_api.py tests/test_permissions_api.py tests/test_authenticated_reauth_security.py tests/test_browser_access.py tests/test_computer_apps.py tests/test_server.py tests/test_release_consistency.py
```

Expected: the former Steam host-state failure is gone and the complete Python group passes.

Then run:

```powershell
npm run desktop:check
npm run desktop:test
```

The known source-only `@electron/packager` environment gap remains non-product behavior if and only if it is the same four packaging-module failures previously observed; do not install/change dependencies solely to hide a new or different failure.

## Production behavior sanity check

Repair6 does not modify `jarvis/computer/apps.py`. No new live Steam behavior is expected. If desired after the automated suite, a normal `Open Rocket League`/installed-Steam-game check should behave exactly as before Repair6.

## Failure conditions

Stop if the targeted Steam test still sees real host games, if any production Computer Actions source file changed as part of Repair6, or if the Repair5 confirmation/security regressions newly fail. Do not weaken Steam discovery or executor/security checks to make tests pass.

Do not commit or delete patch/backups until complete 0.3.6 live acceptance.
