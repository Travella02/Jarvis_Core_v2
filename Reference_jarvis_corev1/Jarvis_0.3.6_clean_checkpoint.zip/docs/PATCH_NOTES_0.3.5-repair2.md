# 0.3.5-repair2 — Silent Browser Media Continuity

**Date:** 2026-09-01  
**Required previous release:** `0.3.5-repair1`  
**Application version remains:** `0.3.5`  
**Status:** Live-acceptance repair candidate

## Purpose
Repair the Browser/YouTube behavior found during the second 0.3.5 live-acceptance pass without changing Billing authority or provider-security boundaries.

## What changed
- Natural `Full screen YouTube` / `Fullscreen the video` phrasing now uses the deterministic verified `media_fullscreen` lane.
- In established YouTube/media context, `Minimize YouTube`/`shrink` maps to verified fullscreen exit rather than an unnecessary planner dialogue turn.
- Successful visible media actions stay silent even when Luna Browser planning was required for an unusual wording variant.
- A verified media operation no longer gets followed by a spoken “already fullscreen/paused” completion message.
- Failures and verification failures still speak.

## Google reconnection note
The live Calendar failure was an expected expired/revoked Google OAuth state, not a Billing failure. Google remains reconnectable from **Controls → Connected apps → Google Workspace → Reconnect Google**. OAuth credentials/tokens remain outside Billing and are not included in this patch.

## Files materially changed
- `jarvis/browser/service.py`
- `apps/desktop/lab/app.js`
- `tests/test_browser_access.py`
- repair notes/testing/handoff/manifest
- ISSUE-313 documentation/index

## Rollback
The repair installer backs up every replaced file before changing it. Restore the reported `0.3.5-repair2_<timestamp>` backup if repair2 fails acceptance. Do not delete Billing/account/OAuth data as part of source rollback.

## Acceptance state
Do not commit yet. Continue 0.3.5 live acceptance after applying repair2. Any further fixes remain `0.3.5-repair3`, etc. No Git tag.
