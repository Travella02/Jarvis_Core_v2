# Testing Guide — 0.1.2-repair6 Grounded Visual Narration

1. Start from Home and say: `Jarvis, show me everything about ORVEX.`
   - Memory Explorer opens.
   - Jarvis does not speak and no Jarvis bubble remains.
2. Return Home and say: `Jarvis, show me everything about ORVEX and give me a short summary.`
   - Memory Explorer opens to ORVEX.
   - Jarvis gives a short summary after the display is ready.
   - Jarvis does not say he cannot open or display memory.
3. Say: `Jarvis, show me and tell me about ORVEX.`
   - The entity remains visible.
   - Jarvis explains only the exact displayed evidence.
4. Say: `Jarvis, what do you know about ORVEX?`
   - Jarvis answers verbally without switching workspaces.
5. Repeat steps 1–3 using typed chat.
6. Sleep Jarvis, then wake with: `Jarvis, show me everything about ORVEX and give me a short summary.`
   - The preserved opening request performs both actions once.

Automated validation expects 195 passing Python tests and 36 passing Node tests.
