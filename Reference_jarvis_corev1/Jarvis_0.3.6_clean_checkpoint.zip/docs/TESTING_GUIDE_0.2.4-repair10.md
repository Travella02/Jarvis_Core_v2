# Testing 0.2.4-repair10 — Human Voice

## 1. Grounded time regression — must still pass

Say:

`Is there anything I need to do tomorrow?`

Then:

`What time?`

Expected: **2 PM**. It must never become 8 PM.

Then ask:

`When will you remind me?`

Expected: still **2 PM**.

## 2. Gmail body-only continuation — critical regression

Say:

`Can you draft an email to Tanner?`

When Jarvis asks what it should say, answer naturally without repeating `email`, `draft`, or `Gmail`, for example:

`Say hi, I was just wondering how you're doing. Please get back to me ASAP.`

Expected:

- Jarvis stays in the Gmail workflow.
- The real Gmail draft is created.
- The email draft card appears with recipient/content preview and the existing edit/send controls.
- Nothing is sent until you explicitly approve sending it.
- Jarvis must not say that it lost or could not safely route the request.

## 3. Stuck-state regression

Immediately after the Gmail flow, ask an unrelated conversational question such as:

`How's your day going?`

Then ask another normal question.

Expected: Jarvis answers both normally. The orb/state must not remain trapped in Working/Thinking, and a failed action must not hijack later conversation.

If an external action ever stalls, the desktop should recover to Listening rather than waiting forever.

## 4. Human voice — primary acceptance test

Have a normal back-and-forth conversation for several minutes. Include short acknowledgements, casual questions, a joke/light comment, and a longer explanation request.

Expected for ordinary dialogue:

- the voice should sound like the earlier natural Realtime Cedar rather than the dedicated TTS readout;
- noticeable pitch movement, timing variation, emphasis, and emotional tone should return;
- Jarvis should sound like he is responding in the moment rather than reading a prepared script;
- wording remains Luna-authored and response modes remain respected.

Strict grounded fact replies such as task/reminder times may still use the protected exact-speech path. Those replies prioritize factual immutability over maximum vocal freedom.

## 5. Personality and response modes

Compare **Classic**, **Casual**, and **Warm** during ordinary conversation. Then try Short, Normal, High, and Full.

Expected: personality changes style/tone; response mode changes maximum depth. Neither should change authoritative facts.

## 6. Interruption

Interrupt Jarvis in the middle of a longer ordinary response, then interrupt a longer fact-grounded response if available.

Expected: speech stops promptly and Jarvis returns to Listening without replaying or duplicating the interrupted answer.
