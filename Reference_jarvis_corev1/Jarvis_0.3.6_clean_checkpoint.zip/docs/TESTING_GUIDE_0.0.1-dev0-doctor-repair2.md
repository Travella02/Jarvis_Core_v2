# Testing Guide — 0.0.1-dev0 Doctor Repair 2

## Install

Extract this repair ZIP into the existing `Jarvis_Real_Time` project root. Allow Windows to merge and replace matching package files. Open PowerShell in that folder and run:

```powershell
py -3.12 apply_0_0_1_dev0_doctor_repair2_patch.py
```

Do not rerun the original bootstrap or repair1 installer.

The repair2 installer:

- Requires `VERSION` to contain `0.0.1-dev0`.
- Verifies the checksum of every file listed by its active manifest.
- Ignores unrelated files left in the merged local `patch_files/` directory.
- Copies only manifest-listed files into the project.
- Creates timestamped backups before replacement.
- Runs the complete unit suite and the direct doctor command.
- Automatically restores changed project files if validation fails.

A notice about ignored unrelated payload files is expected in this specific merged-folder scenario and is not an error.

## Automated tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Expected result:

```text
Ran 8 tests
OK
```

## Environment doctor

```powershell
.\.venv\Scripts\python.exe scripts\doctor.py
```

Expected result: four `PASS` lines followed by the project name, version `0.0.1-dev0`, and the absolute project root. There should be no `ModuleNotFoundError`.

## Current Jarvis start command

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

Expected result:

```text
Jarvis_Real_Time 0.0.1-dev0
Core state: sleeping
Status: clean-core foundation is ready; Realtime voice is not implemented yet.
```

## Git check and first commit

```powershell
git status
git add .
git commit -m "0.0.1-dev0: initialize Jarvis Real Time clean core"
```

The extracted installers, `patch_files/`, `.venv/`, backups, ZIP archives, and local runtime data should remain ignored.

## Common failures

- `expected VERSION 0.0.1-dev0`: the installer is being run in the wrong folder or against a different project state.
- `checksum mismatch`: the active repair payload file was altered or did not overwrite an older same-named file during extraction; extract repair2 again and allow replacement.
- `Git available` reports `FAIL`: Git is unavailable on `PATH`; reopen PowerShell or repair the Git installation.
- Permission or rename errors under OneDrive: close editors using the affected file, then rerun repair2.
- Unit tests pass but the doctor fails: preserve the complete output and generated backup path; do not begin `dev1`.

## Logs and privacy

This repair does not use an API key, network connection, microphone, or cloud provider. Do not share `.env` or credential files when reporting a failure; the installer output and traceback are sufficient.
