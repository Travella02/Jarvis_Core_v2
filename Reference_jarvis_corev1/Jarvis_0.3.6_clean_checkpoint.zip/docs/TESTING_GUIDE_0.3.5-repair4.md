# Testing Guide — 0.3.5-repair4

## Apply

Close Jarvis completely. Extract the repair ZIP into the Jarvis project root, replacing the repair payload files when Windows asks, then run:

```powershell
python .\apply_0_3_5_repair4_patch.py
```

Do **not** start `python -m apps.core` separately. Electron owns Core in this source checkout.

## Automated validation

```powershell
python -m pytest -q tests/test_browser_access.py tests/test_voice_lab_client.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

The local Windows dependency-installed environment should have no Browser Bridge failures. Do not run `npm audit fix --force` as part of this repair.

## Live fullscreen acceptance

Start Jarvis with:

```powershell
npm run desktop
```

Open the same YouTube watch page used during the failure and play the video.

Repeat this sequence **at least five times**:

1. Say `Fullscreen YouTube.`
2. Confirm browser chrome disappears and the **video/player is the only page content visible**. YouTube description/comments/recommendations, vidIQ panels, and other watch-page UI must not remain visible.
3. Pause and resume once during one fullscreen cycle.
4. Say `Minimize YouTube.`
5. Confirm the original normal YouTube page and browser-window state are restored.

Also leave fullscreen active for at least 10 seconds on one cycle so dynamically inserted page/extension UI has time to attempt to render. It still must remain isolated.

## Failure interpretation

- If the browser window goes fullscreen but normal YouTube page UI remains visible, repair4 has **not** passed live acceptance.
- If Jarvis automatically rolls the browser back to normal and reports fullscreen failure, the fail-closed rollback worked but fullscreen reliability still needs another repair.
- If minimize fails to restore the original page/window state, stop testing and preserve screenshots/logs.

Do not commit yet. Repairs remain `0.3.5-repairN` until the full 0.3.5 live acceptance suite passes and Tanner explicitly accepts the release. No Git tag.
