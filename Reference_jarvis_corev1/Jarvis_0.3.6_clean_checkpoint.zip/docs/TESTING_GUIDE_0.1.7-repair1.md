# Testing Guide — 0.1.7-repair1

## Acceptance flow

1. Start Jarvis and choose **Test** or **Short** response mode.
2. Ask: “Who are you?”
3. Confirm Jarvis speaks a short summary and only one `JARVIS` card appears.
4. Confirm that same card updates to the complete written answer rather than creating a second card.
5. Confirm the final answer describes Jarvis in first person, such as “I am…” and “I can…”, never “You are a local-first assistant.”
6. Ask: “Explain your complete architecture and capabilities in detail.”
7. Confirm speech remains within the selected response mode while the final written answer can be detailed.
8. Change the response mode and repeat to confirm only spoken length changes.
9. Open the local capability endpoint or ask what Jarvis can and cannot do. Confirm unsupported email, calendar, files, web, messaging, camera, and autonomous actions remain honestly unavailable.
10. Run Local simulation and confirm it also uses one response card.

## Capability-provider contract

A future feature module should expose `provide_capabilities(settings, runtime)` from a module under `jarvis.capabilities.providers`, or register an equivalent provider with the registry. The registry recomputes provider results on each snapshot and session-profile refresh.

Jarvis must not claim a new feature merely because code with a similar name exists. The feature must explicitly report its availability, limitations, and requirements.
