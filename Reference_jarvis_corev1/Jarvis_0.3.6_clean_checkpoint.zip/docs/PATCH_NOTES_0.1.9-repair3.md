# 0.1.9-repair3 — Typed Context & Reader Gating

This live-acceptance repair tightens generic-reference resolution and keeps the fullscreen reader limited to answers that actually need it.

## Changes

- Generic references now constrain candidates to the requested entity type before recency and activity scoring are compared.
- Phrases such as `the business` and `that company` can resolve only to business-like entities unless the user explicitly names another subject.
- Person placeholders such as `Local Owner` no longer compete with ORVEX for a business reference.
- Genuine ambiguity between two actual businesses still produces one short clarification question.
- Ambiguous clarification turns skip the detailed companion model, preventing a second paraphrased clarification from being appended to the same card.
- The Fullscreen action now appears only when an answer exceeds the reader character threshold or the compact preview is genuinely overflowing.
- Short hybrid messages and short clarification questions remain ordinary cards without an unnecessary Fullscreen control.

## Safety

- No entity is deleted or merged by this repair.
- Existing timeline events, facts, relationships, and person profiles remain unchanged.
- Type filtering is generalized and does not hardcode ORVEX, Tanner, or Local Owner into product behavior.
