# Testing Guide — 0.2.1-repair2 Draft Continuity

Use a disposable recipient/message for the send test because the final confirmation intentionally sends real email through the connected Google account.

## Install and start

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair2_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```

## 1. Draft preview + Gmail-history recipient regression

Use the same acceptance case that exposed repair1:

> Draft an email to Tanner saying thank you, I appreciate it, I will talk to you soon.

Expected:

- If Tanner is not in Contacts but is an unambiguous recent Gmail correspondent, repair1 recipient resolution still finds the correct address.
- Gmail creates a real draft, but does not send it.
- The Jarvis conversation shows a structured email preview rather than a loose paragraph.
- The preview is labeled `EMAIL DRAFT` and shows `Draft saved · Not sent`.
- The preview includes From (when available), To, Subject, and the exact body. Cc/Bcc appear only when present.
- The body text in Jarvis matches the body stored in Gmail.

Before continuing, verify the recipient and body are safe to send.

## 2. Natural send confirmation

Say exactly:

> Yes, send it, please.

Expected:

- Jarvis does not ask for a draft ID.
- Jarvis does not ask for permission to locate the draft.
- The already-reviewed draft ID is used directly.
- Gmail sends that draft exactly once.
- Jarvis reports success only after Gmail confirms the send.
- The same preview is labeled `EMAIL SENT` with `Sent` status so it is visually obvious that the message left the draft state.

## 3. Short confirmation variants

Create another disposable draft and test one of these:

> Yes, please.

or:

> Send it.

Expected: the waiting draft sends once without replanning for a draft ID.

## 4. Cancel safety

Create another draft, verify its preview, then say:

> Cancel it.

Expected:

- The send confirmation is cancelled.
- The Gmail draft remains saved.
- No email is sent.

## 5. Reply draft preview

Ask Jarvis to find a harmless recent email and draft a reply.

Expected:

- The reply remains in the correct Gmail thread.
- Jarvis shows the reply recipient, reply subject, and exact reply body in the structured preview.
- Nothing sends until a separate explicit confirmation.

## 6. Continue 0.2.1 acceptance

If all repair checks pass, resume the remaining flow in `docs/TESTING_GUIDE_0.2.1.md`. Do not begin 0.2.2 until the complete 0.2.1 acceptance flow passes.


## Automated validation

Before packaging this repair, the source workspace must satisfy:

- Python suite: **350/350 passing**.
- Desktop JavaScript syntax check: **passing**.
- Connected Actions frontend contract test: **passing**.
- Node desktop suite: **86/90 passing, 4 blocked** only because the uploaded source workspace does not include `node_modules`; those four unchanged Electron packaging tests require Electron Packager development dependencies.
- Fresh overlay/install test: installer applies over `0.2.1-repair1`, payload hashes match, and `.env` remains unchanged.
