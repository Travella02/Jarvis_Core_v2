# 0.3.4-repair2 — Verification UX Testing Guide

## Goal

Confirm that browser authentication is forgiving for legitimate users without weakening code verification or exposing secrets.

## Signup mismatch

1. Start Jarvis signed out and choose **Create account**.
2. Fill Name and at least one contact method.
3. Enter two different passwords.
4. Submit.
5. Expected:
   - the page does not navigate/reload when client-side validation is available;
   - Name, Email, and Phone remain exactly as entered;
   - both password boxes are cleared;
   - both password controls are outlined red;
   - `Passwords don't match.` appears inline and in the top error banner;
   - no password value appears in returned HTML/logs.
6. Use the eye control on each password field repeatedly. It must remain visible and continue toggling show/hide.

## Verification challenge

1. Submit matching valid signup credentials.
2. In development, confirm the page clearly says the displayed code is development-only and that the local relay does not send email/SMS.
3. Confirm `Code expires in 10:00` begins counting down.
4. Confirm **Resend code** is disabled for about 60 seconds and the page shows the resend countdown.
5. After the cooldown, resend the code.
6. Expected:
   - a new six-digit development code appears;
   - expiry returns to about 10 minutes;
   - the old code is rejected;
   - the new code verifies the account.
7. Try incorrect codes. After five failed attempts, a fresh code/challenge is required.

## Recovery challenge

1. Sign out and choose **Forgot email or password?**.
2. Enter a verified contact.
3. Confirm the same 10-minute expiry and 60-second resend behavior.
4. Resend after the cooldown and verify that the previous recovery code is rejected.
5. Verify with the new code and reset the password.
6. Try to reuse the same recovery verification challenge. It must not issue a second reset authorization.
7. Sign in with the new password and confirm Jarvis unlocks normally.

## Production boundary

The development relay intentionally displays codes for local testing and does not send them. Before external beta, the hosted Jarvis/ORVEX auth service must have a configured email/SMS verification provider. Production must never return verification or recovery codes to the browser client/API response.

## Regression checks

- Account gate still hides normal Jarvis tabs while signed out.
- Successful browser authentication still unlocks Jarvis automatically.
- Cloud Sync remains tasks/reminders-only.
- Account/tenant/device identity is preserved during legacy upgrade.
- Browser Control and microphone continuity from 0.3.3 still work after sign-in.
- Visible product version remains `0.3.4 · Cloud Sync`.
