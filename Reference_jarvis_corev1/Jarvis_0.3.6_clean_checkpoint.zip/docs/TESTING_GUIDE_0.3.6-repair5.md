# 0.3.6-repair5 — Trusted Executor Confirmation Testing

## Apply

Close Jarvis completely. Extract the repair ZIP into the project root and run:

```powershell
python .\apply_0_3_6_repair5_patch.py
```

Expected release label: `0.3.6-repair5 — Trusted Executor Confirmation`.

## Automated checks

```powershell
python -m pytest -q tests/test_permission_confirmation_security.py tests/test_browser_confirmation_security.py tests/test_permission_executor_enforcement.py tests/test_phase5_adversarial_security.py tests/test_permission_confirmation_api.py tests/test_permissions_api.py tests/test_authenticated_reauth_security.py tests/test_browser_access.py tests/test_computer_apps.py tests/test_server.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

On the dependency-complete Windows checkout, the two new Repair5 Electron/renderer regressions increase the expected desktop suite from 156 to **158 passed**.

## Live check — Browser Always ask

1. Launch Jarvis and open Controls -> Permissions & Security.
2. Set Browser Control / browser navigation to **Always ask** (or the equivalent confirmation-required preference).
3. Ask: `Jarvis, open a new tab.`
4. Jarvis must open its trusted native confirmation directly. The prompt should be natural and action-specific, e.g. **"Allow Jarvis to open a new browser tab?"**
5. Choose **Cancel**. No tab may open, Jarvis must not try to open `a new browser` as an application, and the request must not fall through to another capability.
6. Ask the same request again. A fresh native confirmation must appear.
7. Approve. Exactly one new tab should open.
8. Ask again. Because this is Always ask, a fresh confirmation must be required again.

## Live check — speaker binding

Use normal enrolled voice recognition where available. The confirmation is bound to the live speaker lane, not the cosmetic label. A short reply that temporarily displays as `Unknown speaker` may proceed only if recognition preserved the same `session_speaker_id`; a different live speaker lane must never be able to reuse the pending challenge. If the speaker lane is unavailable/mismatched, the action must require a new valid authorization rather than treating the local owner label as authority.

## Live check — Computer Actions

1. Configure a harmless Computer Action such as opening Calculator for **Always ask**.
2. Ask Jarvis to open Calculator.
3. Cancel the native prompt: Calculator must not open and the request must not fall through.
4. Repeat and approve: Calculator should open exactly once.
5. Repeat: a fresh prompt must appear.

## Failure conditions

Stop acceptance if a cancelled action reaches another router, a spoken/model-generated `Yes` bypasses trusted native confirmation, a challenge crosses speaker/session/account/device scope, an approval executes more than the exact reviewed action, or `Always ask` loops back into another confirmation after a valid exact grant.

Do not commit or delete patch/backups until complete 0.3.6 live acceptance.
