# 0.1.3 — Memory Consolidation

Jarvis now reviews and organizes durable memory autonomously while preserving the exact event ledger as the source of truth.

## Added

- SQLite schema version 3 with consolidated entity profiles, run history, and a review queue.
- Periodic local consolidation after a configurable number of new events or time interval.
- Deterministic entity profiles containing key facts, open items, decisions, goals, event counts, and confidence.
- Conservative duplicate handling:
  - exact same-event duplicates are hidden reversibly;
  - punctuation/spacing-only entity duplicates are merged reversibly;
  - uncertain spellings such as ORVEX/ORVIX are flagged instead of silently merged.
- Explicit correction handling for single-value facts while retaining historical evidence.
- Contradiction findings when Jarvis cannot safely decide which fact is current.
- Category and importance refinement for generic memories, commitments, goals, decisions, and corrections.
- Consolidation Center in Memory Explorer with recent runs and unresolved findings.
- Entity pages now show Jarvis's consolidated understanding and pending project/business items.
- Local configuration for interval, event threshold, startup delay, scan size, and safe auto-apply behavior.

## Safety contract

Consolidation never rewrites the original content, actor, source, provider event ID, or timestamp. Autonomous changes affect derived organization only and are recorded in the operation ledger. Uncertain changes become review findings rather than guesses.

## Default schedule

Jarvis waits 45 seconds after startup, then consolidates when at least 10 new events exist or 30 minutes have passed since the previous run. The work is local and does not call an AI model, so it adds no OpenAI usage cost.
