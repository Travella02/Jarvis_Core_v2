# 0.1.2-repair4 — Validation Isolation Repair

Repairs the four false validation failures from `0.1.2-repair3` and ensures old generated response defaults do not override the newly accepted Test, Short, Normal, High, and Full policy.

## Changes

- Isolated Realtime provider and server tests from the user's private `.env`.
- Added a regression test using the exact previous 25/60/140/300 word and 512/1024/2048/4096 token defaults.
- Recognizes a complete legacy response-profile block and upgrades only its exact historical defaults.
- Preserves non-default legacy values as intentional custom settings.
- Leaves `.env`, API keys, and unrelated preferences untouched.
- Carries forward deterministic local Memory Explorer navigation from repair3.
- Cache-busts the Memory Explorer renderer as `0.1.2-repair4`.

## Accepted response defaults

| Profile | Sentence default | Word default | Provider ceiling |
|---|---:|---:|---:|
| Test | 1 | 25 | Model maximum |
| Short | 3 | 50 | Model maximum |
| Normal | Adaptive | 100 | Model maximum |
| High | Adaptive | 200 | Model maximum |
| Full | Uncapped | Uncapped | Model maximum |

The sentence and word limits remain strong prompt-level defaults with the explicit long-form exception requested by Tanner. The provider ceiling remains at model maximum so audio is not cut off mid-sentence.
