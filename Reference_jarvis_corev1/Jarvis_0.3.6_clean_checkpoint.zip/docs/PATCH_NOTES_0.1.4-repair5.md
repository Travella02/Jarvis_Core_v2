# 0.1.4-repair5 — Audio Resume

This repair preserves the accepted response-scoped interruption behavior while ensuring the next response is spoken as well as displayed.

## Fixed

- Interruption mute state is now owned by the specific interrupted provider response.
- A distinct new `response.created` event immediately restores the WebRTC audio element.
- `output_audio_buffer.started` provides a second safe playback-restoration boundary for provider event-order differences.
- Interrupted response IDs cannot accidentally unmute their own stale audio.
- The existing media element is explicitly resumed after unmuting, without reconnecting the Realtime session.
- Connection cleanup clears any remaining interruption mute owner.

## Preserved

- Late audio and transcript events from cancelled responses remain ignored.
- Interrupted bubbles remain marked without appending unsaid text.
- Authoritative proactive corrections and automatic refresh remain unchanged.
- No new OpenAI calls, external authority, or recurring cost are introduced.
