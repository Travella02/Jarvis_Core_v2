# 0.3.5-repair4 — Post-Transition Fullscreen Verification

**Date:** 2026-09-01  
**Required installed release:** 0.3.5-repair3  
**Version remains:** 0.3.5

## Purpose

Repair an intermittent YouTube live-acceptance failure where the browser window entered fullscreen but the ordinary YouTube watch-page UI could remain rendered around/over the video.

## What changed

- Replaced inherited `visibility`-based page isolation with reversible top-level `display: none !important` suppression.
- Added mutation observation so newly inserted/restyled top-level page UI cannot appear over the immersive player.
- Added internal content-script fullscreen verification and bounded reconciliation operations.
- After the Chromium window enters fullscreen, Browser Bridge now re-verifies that the Jarvis player still covers/owns the viewport.
- If the post-transition verification fails, Browser Bridge rebuilds the immersive player once under the final viewport.
- If the repair still cannot be verified, Browser Bridge restores the prior browser-window state and reports failure instead of leaving a half-fullscreen page.
- Preserved repair2 silent success semantics and repair3 no-synthetic-YouTube-fullscreen-click rule.

## Security / authority impact

None. This repair changes only local Browser Bridge rendering/control behavior. Billing, entitlement, provider, payment, OAuth, Realtime, account, and Cloud authority boundaries are unchanged.

## Compatibility / migration

No data migration. Apply only over the tested 0.3.5-repair3 candidate. User data, `.env`, Billing/Cloud databases, OAuth/provider tokens, memory, browser state, and Git history remain untouched.

## Known limitations

This is still an emulated voice-driven fullscreen lane because Chromium's native Fullscreen API requires trusted user activation. Final acceptance therefore requires repeated live Windows/Edge testing.

## Rollback

The installer creates timestamped backups under `.patch_backups/0.3.5-repair4_*`. Do not manually clean patch/backups until 0.3.5 is accepted.
