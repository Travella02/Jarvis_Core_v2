# Testing 0.2.6-repair5 — Launch Diagnostics

## Install

1. Fully close Jarvis.
2. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root and allow merge/overwrite.
3. Run:

   `py -3.12 .\apply_0_2_6_repair5_patch.py`

4. Start Jarvis with:

   `npm run desktop`

## Primary live test

Fully close Discord, then say:

> Open Discord.

Pass if the actual Discord window appears. Jarvis must not claim verified success merely because Windows accepted a shell request.

If Discord still does not appear, **do not change paths manually**. Open:

**Memory → Apps → Discord → Last launch**

The diagnostic should show the exact route, strategy, target, resolved command/arguments (when available), handoff state, observation state, and error. Capture that section for the next repair so the Windows-specific failure can be fixed from evidence rather than another guessed route.

## Regression tests

- Put another app in front of Discord and say `Open Discord` again.
- Say `Close Discord`.
- Teach `Group chat is another name for Discord`, then `Open group chat`.
- Forget it with `I no longer want group chat as a nickname for Discord`.
- Verify Memory → Apps still shows one logical Discord record and the alias is removed.
