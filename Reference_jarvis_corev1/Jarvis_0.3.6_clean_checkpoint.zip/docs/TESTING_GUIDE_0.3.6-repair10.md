# 0.3.6-repair10 — Regression Alignment Testing

Apply only over the exact verified `0.3.6-repair9` live candidate. This repair changes regression tests/documentation only; production runtime behavior must remain byte-identical to Repair9.

## Targeted checks

Run the two files that previously contained all three failures:

```powershell
node --test --test-reporter=tap .\tests_js\realtime_interruption_sync.test.cjs .\tests_js\account_foundation.test.cjs
```

Expected:

- all tests in both files pass;
- zero `not ok` results.

Then run:

```powershell
npm run desktop:check
```

Then rerun the complete Electron suite while preserving output:

```powershell
npm run desktop:test 2>&1 | Tee-Object .\repair10_desktop_test.log
```

Expected on the current dependency-complete Windows checkout:

- **164/164** tests pass;
- zero failures.

If anything fails, extract it without relying on terminal scrollback:

```powershell
Select-String -Path .\repair10_desktop_test.log -Pattern "not ok|AssertionError|ERR_ASSERTION|# fail" -Context 3,12
```

## Security sanity

After automated tests are green, resume the Repair9 live checks rather than inventing a new authorization flow:

1. Trigger a trusted permission prompt.
2. Say `Yes, allow it.` — it must not approve, render as a normal chat turn, or receive a normal Jarvis response.
3. Say `Cancel it.` — it may deny the exact active prompt and must not execute the action.
4. Verify the Gmail draft/card Fullscreen control opens the shared fullscreen reader.

Repair10 is test alignment only. Any change in live runtime behavior compared with Repair9 is a failure.
