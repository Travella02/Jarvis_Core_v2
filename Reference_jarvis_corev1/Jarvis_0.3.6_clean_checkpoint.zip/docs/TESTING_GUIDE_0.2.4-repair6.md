# Testing Guide — 0.2.4-repair6 Grounded Speech

## Install

1. Extract the repair ZIP directly into the existing `Jarvis_Real_Time` project root.
2. Allow Windows to merge folders and overwrite matching repair files.
3. Open PowerShell in the project root and run:

```powershell
python .\apply_0_2_4_repair6_patch.py
```

The installer will close any running development Jarvis instance from this project before applying the repair. After a successful install it removes the obsolete 0.2.4 repair installers and temporary `patch_files` payload automatically.

Then start Jarvis:

```powershell
npm run desktop
```

No Google reconnect and no task recreation are required.

## Primary live acceptance test

Use the existing task already shown in the Tasks workspace:

**Call Tanner — Reminder Thu, Aug 13, 2:00 PM**

Say these in order:

1. **“Is there anything I need to do tomorrow?”**
   - Expected: Jarvis names **Call Tanner**.
2. **“What time?”**
   - Expected: **“Call Tanner is set for 2 PM tomorrow.”**
   - Failure: any **8 PM** answer or another timezone-shifted value.
3. **“When will you remind me?”**
   - Expected: the reminder is **2 PM tomorrow**.
4. **“What time is it?”**
   - Expected: the actual Windows-local clock time.
   - Failure: Jarvis says he cannot see the clock or gives UTC instead.

## Interruption regression check

While Jarvis is speaking a grounded task/action reply, interrupt him naturally. He should stop speaking promptly and return to listening without continuing the isolated response afterward.

## Restart check

Quit Jarvis completely, run `npm run desktop` again, and repeat **“What time?”** after restoring task context. The answer must remain **2 PM**, confirming a clean fresh core is running rather than a stale pre-repair process.
