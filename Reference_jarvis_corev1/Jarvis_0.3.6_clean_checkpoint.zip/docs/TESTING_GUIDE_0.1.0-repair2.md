# Testing Guide — 0.1.0 Packaging Stall Repair

## Stop the stalled build

If the earlier Electron Forge build is still running, press `Ctrl+C` once and wait for the PowerShell prompt. Then remove only the incomplete installer output:

```powershell
Remove-Item -Recurse -Force .\out -ErrorAction SilentlyContinue
```

Do not delete `build`, `build\python`, `build\cache`, or `.venv`.

## Apply the repair

Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, approve merging/replacing the patch package files, and run:

```powershell
py -3.12 apply_0_1_0_repair2_patch.py
```

## Verify the packaging scope

The patch installer runs this automatically. It can also be run directly:

```powershell
npm run alpha:scope
```

Expected output includes:

```text
Electron source scope verified: ... files, ... MiB
Bundled Python and desktop runtime will be copied once through extraResource.
```

## Retry the Windows installer build

```powershell
npm run alpha:make
npm run alpha:verify
```

The existing verified Python 3.12.10 runtime should be detected and reused immediately. Electron should then package only the compact Electron source and copy each external runtime once.

Expected installer:

```text
out\make\squirrel.windows\x64\Jarvis_Real_Time_Setup.exe
```

`alpha:verify` should also report the packaged `app.asar` size. It must remain below 25 MiB.

## Full validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
node --check scripts\packaging_scope.cjs
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

Expected automated result:

```text
Python tests: 154 passed
Node tests: 13 passed
```

## Installed-alpha acceptance

After verification passes, run the generated setup executable and test first-run setup, wake and opening-request preservation, Cedar speech, interruption, sleep, full process shutdown, relaunch, and settings retention.
