# 0.0.2 — Voice Control

> **Live-acceptance correction:** `0.0.2-repair1` supersedes the forced low semantic-VAD default and fixes duplicate typed-message rendering. Current behavior uses provider-default turn detection with optional semantic profiles. See `PATCH_NOTES_0.0.2-repair1.md`.

**Natural pause handling, interruption control, manual sleep/wake, reconnect hardening, Cedar defaults, live timing, and recruiter-ready issue records.**

- **Release date:** 2026-07-26
- **Required previous internal version:** `0.0.1-dev1`
- **Installed version:** `0.0.2`
- **Repository:** `Jarvis_Real_Time`

## Purpose

The first live Realtime WebRTC path is working. This update hardens the interaction itself without introducing the final Electron interface, wake-word engine, permanent memory, tools, or vision. It also begins a permanent issue portfolio containing the real failures and repairs encountered during development.

## User-visible changes

- Cedar is the project’s default Jarvis voice.
- Semantic VAD defaults to `low` eagerness so Tanner can pause naturally without being cut off as quickly.
- The lab now uses explicit **Wake Jarvis** and **Sleep Jarvis** controls.
- Sleeping closes the WebRTC session and releases the microphone, so no API audio continues while asleep.
- Speaking over Jarvis clears unplayed WebRTC output and marks the interrupted response in the transcript.
- A manual **Stop Jarvis speaking** control sends a response cancellation and clears buffered output.
- One bounded automatic reconnect attempt follows a sustained connection failure; reconnect loops are forbidden.
- A 55-minute safety timer warns five minutes early, then sleeps before the provider’s session boundary.
- Audio-device, voice, VAD, and speaker choices persist locally in the browser.
- Live metrics now show handshake, speech duration, turn decision, first audible audio, total response time, and interruption count.
- First-audio timing uses a local analyser on the remote media stream, with provider-event fallback.
- The UI presents the release as `0.0.2 — Voice Control`.

## Local-core changes

- Added typed conversation-waking, sleeping, interruption, latency, and timeout events.
- Expanded the authoritative state mapping so user speech can interrupt `thinking` or `speaking` and return Jarvis to `listening`.
- Added provider-independent validation of voice and semantic-VAD controls at the local FastAPI boundary.
- Added centralized settings for VAD eagerness and the session safety limit.
- Realtime session configuration explicitly sets `semantic_vad`, `create_response=true`, and `interrupt_response=true`.
- Health, doctor, and safe diagnostics expose configuration names but never secret values.

## Issue portfolio

A new project-root `issues/` directory records real problems, root causes, debugging steps, fixes, regression tests, lessons, and recruiter talking points. This release includes the complete history from the initial bootstrap through `0.0.2` development:

- Doctor import path failure.
- Merged patch-payload validation failure.
- Tests depending on the real `.env`.
- Empty SDP offer caused by untyped multipart fields.
- Chromium SDP answer framing failure.
- Release version-label drift.
- VAD validation coupled to a concrete provider test double.
- Partial test overlays inheriting customized private `.env` values.

## Files added

- `issues/ISSUE_INDEX.md`
- `issues/ISSUE_001_DOCTOR_IMPORT_PATH.md`
- `issues/ISSUE_002_MERGED_PATCH_PAYLOAD.md`
- `issues/ISSUE_003_ENV_SENSITIVE_TESTS.md`
- `issues/ISSUE_004_EMPTY_SDP_OFFER.md`
- `issues/ISSUE_005_SDP_ANSWER_FRAMING.md`
- `issues/ISSUE_006_VERSION_LABEL_DRIFT.md`
- `issues/ISSUE_007_API_BOUNDARY_VALIDATION.md`
- `issues/ISSUE_008_PARTIAL_ENV_OVERRIDE.md`
- `docs/PATCH_NOTES_0.0.2.md`
- `docs/TESTING_GUIDE_0.0.2.md`
- `tests/test_issue_documentation.py`
- `tests/test_release_consistency.py`

## Files changed

- `VERSION` — normalized to `0.0.2`.
- `pyproject.toml` — normalized package version and milestone.
- `.env.example` — Cedar, low semantic VAD, and 55-minute session safety defaults.
- `apps/core/server.py` — safe configuration, boundary validation, and VAD forwarding.
- `apps/core/__main__.py` — expanded secret-safe diagnostics.
- `apps/desktop/lab/index.html` — sleep/wake controls, timing panel, VAD selection, and release title.
- `apps/desktop/lab/styles.css` — states, controls, metrics, and interruption markers.
- `apps/desktop/lab/app.js` — interruption, audio-buffer clearing, bounded reconnect, session timer, preferences, and audible-output timing.
- `jarvis/core/config.py` — centralized voice-control settings and validation.
- `jarvis/core/events.py` — new typed event categories.
- `jarvis/core/runtime.py` — state transitions and event journaling for voice control.
- `jarvis/intelligence/realtime.py` — explicit semantic-VAD configuration and validated overrides.
- `prompts/realtime_voice_lab.txt` — interruption and concise spoken-behavior guidance.
- `scripts/doctor.py` — VAD and session-limit checks.
- Existing focused tests — updated for `0.0.2` contracts.
- `docs/ARCHITECTURE_DECISIONS.md` — appended release decisions.
- `docs/JARVIS_CORE_HANDOFF_INSTRUCTIONS.md` — current state and next milestone.
- `RELEASE_MANIFEST.json` — release checksums and installation contract.

## Existing `.env` behavior

The installer does not read, print, replace, or delete the private `.env`. Existing values remain authoritative. If an older `.env` contains `JARVIS_REALTIME_VOICE=marin`, either change that line locally to `cedar` or keep Cedar selected in the lab; browser preferences are retained locally. Do not commit `.env`.

## Known limitations and deferred work

- This is still the temporary Chromium engineering lab, not the final Electron/React body.
- Wake and sleep are manual; local wake-word detection is not included.
- Automatic reconnect is intentionally limited to one attempt and does not transfer a compact session summary.
- The 55-minute timeout begins a fresh session after the next wake; session rollover with context transfer is deferred.
- Audible-output detection is a local engineering measurement, not a provider billing metric.
- Interruption quality must be live-tested with Tanner’s microphone, room noise, and normal conversational pauses.
- Permanent memory, tools, approvals, vision, and legacy migration remain excluded.

## Compatibility and migration

- Requires the working `0.0.1-dev1` installation after Realtime repair 3.
- Preserves `.env`, `.venv`, `data/`, `logs/`, Git history, and `.patch_backups/`.
- Does not perform database or legacy-memory migration.
- Existing ignored browser preferences are automatically read where available.

## Rollback

The installer creates a timestamped backup under:

```text
.patch_backups/0.0.2_<timestamp>/
```

If installation validation fails, rollback is automatic. For a manual rollback, stop Jarvis, copy the backed-up files to their original project-relative locations, and restore the prior `RELEASE_MANIFEST.json` and `VERSION`.

## Automated validation before delivery

- `python -m unittest discover -s tests -v` — **43 tests passed**.
- JavaScript syntax: `node --check apps/desktop/lab/app.js`
- Direct doctor command.
- Safe diagnostic command.
- Fresh patch installation against the reconstructed accepted `0.0.1-dev1` state.
- Repeat installation check for idempotency.
- Verification with a fake ignored `.env` present and unchanged.
- No paid OpenAI call and no private key included.
