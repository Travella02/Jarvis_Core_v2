# Architecture Decisions

This file is append-only. New decisions are added; earlier decisions are not silently rewritten.

## ADR-0001 — Clean-core rebuild

- **Status:** Accepted
- **Date:** 2026-07-26
- **Decision:** Build a new event-driven core instead of transplanting the legacy conversation loop.
- **Reason:** The legacy voice loop, UI state, memory extraction, panel layout, and tool routing became too tightly coupled. Proven assets and behavioral lessons remain migration sources, not the new runtime foundation.

## ADR-0002 — Repository name override

- **Status:** Accepted
- **Date:** 2026-07-26
- **Decision:** Use `Jarvis_Real_Time` as the repository/project name.
- **Reason:** Tanner explicitly created the clean project with this name. The canonical architecture document's working name `Jarvis_Core` is superseded only for naming; its architecture and safety rules remain authoritative.

## ADR-0003 — Python runtime baseline

- **Status:** Accepted
- **Date:** 2026-07-26
- **Decision:** Require Python 3.12 or newer for the local core.
- **Reason:** The new codebase can use modern typing and asyncio features without carrying legacy Python compatibility constraints.

## ADR-0004 — Development version before completed milestone

- **Status:** Accepted
- **Date:** 2026-07-26
- **Decision:** Begin at `0.0.1-dev0`; promote to `0.0.1` only after the complete Realtime Voice Lab acceptance test passes.
- **Reason:** The repository needs a truthful version while the first milestone is under construction.

## ADR-0005 — Git before environment-generated files

- **Status:** Accepted
- **Date:** 2026-07-26
- **Decision:** Install `.gitignore` and `.gitattributes`, create the virtual environment, run tests, then initialize Git and make the first commit.
- **Reason:** This prevents `.venv`, secrets, logs, databases, caches, and generated media from entering source control while preserving a clean first snapshot.

## ADR-002 — Validate Realtime WebRTC in a browser lab before Electron packaging

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

Implement `0.0.1-dev1` as a loopback-only static Chromium/browser client served by the independent Python core. Use OpenAI's Realtime WebRTC unified interface: the client sends SDP to the local backend, and only the backend attaches the permanent API key and server-owned session configuration. Package the tested client inside Electron later rather than introducing Electron during the transport proof.

### Rationale

- Browser WebRTC APIs are the same Chromium foundation Electron will use.
- A small lab isolates microphone, speaker, SDP, provider events, transcripts, and disconnect behavior from final UI complexity.
- The unified interface prevents the permanent API key from entering client JavaScript.
- Keeping Python authoritative preserves the rule that UI windows cannot own conversation state.
- Delaying Electron avoids mixing transport proof, desktop packaging, layout, and state synchronization in one patch.

### Consequences

- The dev1 interface opens in a normal browser and is explicitly temporary.
- The final product remains an Electron desktop application.
- The local server is loopback-only and requires a trusted local request header for session/event writes.
- The current slice has no tools, memory writes, wake word, or final desktop panels.

## ADR-003 — Use typed multipart parts for Realtime unified WebRTC calls

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

When the local Python backend calls `/v1/realtime/calls` with both an SDP offer and a session configuration, encode both values as bytes and assign explicit multipart media types: `application/sdp` for the `sdp` part and `application/json` for the `session` part. Request `application/sdp` in the response. The browser posts the final `RTCPeerConnection.localDescription.sdp` after a bounded ICE-gathering wait.

### Rationale

The first paid dev1 connection reached OpenAI but the provider parsed the untyped multipart SDP field as empty and returned `invalid_offer` with `failed to unmarshal SDP: EOF`. OpenAI's official Python SDK uses typed byte parts for this endpoint. Matching that wire format removes parser ambiguity while preserving the unified backend-owned handshake and keeping the permanent API key local.

### Consequences

- The provider gateway has a regression test for multipart media types and exact SDP preservation.
- The client validates and logs the byte size of the final local SDP offer before posting it.
- Safe upstream error details may be shown in the loopback-only lab, but secrets remain redacted.
- Project version remains `0.0.1-dev1`; this is a focused repair, not a new capability milestone.

## ADR-004 — Automated tests must not depend on a developer's private `.env`

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

Tests for missing secrets and default configuration must use isolated temporary project roots rather than the active repository root. Diagnostics that intentionally inspect the active project may accept either a safely hidden configured-key status or a missing-key warning. No test may require Tanner to remove, rename, expose, or replace his ignored `.env`.

### Rationale

The first SDP repair passed in a clean test repository but its installation validation failed on Tanner's machine because two tests assumed that the project root had no `.env`. A real developer environment is expected to contain local secrets and settings after dev1 installation. Tests must remain deterministic while respecting that local configuration.

### Consequences

- Negative-path configuration tests create temporary roots with no `.env`.
- Default-value tests also use temporary roots so local model, voice, port, or browser preferences cannot alter expectations.
- The doctor test verifies safe status wording without assuming whether a key is configured.
- Installer validation can run after `.env` creation while keeping the key hidden and untouched.
- The project version remains `0.0.1-dev1`; this is a repair, not a new capability milestone.


## ADR-005 — Preserve and canonicalize SDP framing across the local bridge

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

Treat WebRTC SDP as a byte-oriented line protocol at the provider boundary. Decode the OpenAI answer exactly once, reject invalid control characters or malformed internal blank lines, canonicalize all line endings to CRLF, require a final CRLF, and return raw UTF-8 bytes from FastAPI. The Chromium client performs the same defensive CRLF normalization before calling `setRemoteDescription` and records only answer byte/line counts, never ICE credentials or SDP content.

### Rationale

After the typed multipart repair, OpenAI accepted the offer and returned an SDP answer, but Chromium rejected the relayed answer at an `a=ice-pwd` line. This proved authentication, model access, offer upload, and provider session creation were working; the remaining failure was in answer framing at the local HTTP/JavaScript boundary. SDP is defined as a line-oriented protocol and browser parsers are strict about framing. Preserving raw bytes and canonical CRLF removes newline conversion and missing-terminal-line ambiguity without exposing ephemeral ICE values.

### Consequences

- The provider gateway no longer uses `.text.strip()` for successful SDP answers.
- Both backend and client reject malformed SDP before WebRTC state is mutated.
- FastAPI returns exact `application/sdp` bytes instead of a text response abstraction.
- Diagnostics show only answer size and line count.
- Regression tests cover BOM removal, LF-to-CRLF conversion, terminal CRLF, byte-preserving HTTP response, and client-side normalization.
- Project version remains `0.0.1-dev1`; this is the third focused live-handshake repair.

## ADR-006 — Accepted updates use normal patch increments and short release titles

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

After the first working Realtime Voice Lab was accepted, normalize the project to `0.0.2` and use ordinary patch increments for accepted releases. Present each release as `Version — one- or two-word title`, followed by one brief sentence describing the update. Reserve repair labels for corrections made before an update is accepted.

### Rationale

The `-dev` and repair labels were useful while the first live transport was unstable, but retaining them after acceptance made the visible product history harder to understand. A clean release sequence is easier to communicate, tag, review, and present in a portfolio.

### Consequences

- `0.0.2 — Voice Control` is the first normalized release.
- The prior installed development baseline remains `0.0.1-dev1` for installer compatibility.
- Future accepted updates progress as `0.0.3`, `0.0.4`, and so on.
- Focused fixes to an unaccepted release may still use repair suffixes until acceptance.

## ADR-007 — Cedar is the default voice and low semantic VAD is the starting pause profile

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

Use `cedar` as Tanner's default Realtime voice. Start semantic voice activity detection at `low` eagerness, with provider response creation and interruption enabled. Keep both choices configurable in local settings and the Voice Lab.

### Rationale

Tanner auditioned the available voices in a live session and selected Cedar as the best fit for Jarvis. Low semantic-VAD eagerness is the least aggressive starting point for natural mid-thought pauses and can be tuned from measured live behavior rather than guesses.

### Consequences

- `.env.example` and server defaults use Cedar.
- Existing private `.env` values are preserved and may override the example.
- The active VAD choice is visible in the UI and doctor output.
- Live acceptance must still verify pause handling with Tanner's microphone and environment.

## ADR-008 — Manual sleep closes the cloud session and reconnect is bounded

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

Treat manual Sleep as a privacy and cost boundary: stop local media tracks, close the data channel and peer connection, release the microphone, cancel pending reconnects, and return the authoritative state to sleeping. Permit at most one automatic reconnect attempt after a short unexpected-disconnect grace period.

### Rationale

Sleeping must mean no API audio is active. Unbounded reconnect loops can create confusing state, repeated sessions, and unnecessary cost. A single attempt recovers ordinary network blips while preserving predictable user control.

### Consequences

- Manual Wake opens a fresh Realtime session.
- Manual Sleep always overrides reconnect behavior.
- A 55-minute safety timer warns before closing the current session.
- Context-preserving session rollover remains a later milestone.

## ADR-009 — Interruption uses provider VAD plus explicit local playback control

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

When provider VAD reports that Tanner began speaking over an active response, immediately mute local output, clear queued WebRTC output audio, mark the transcript as interrupted, and return the local state to listening. The explicit Stop control additionally requests response cancellation. Record only safe event and latency metadata.

### Rationale

Natural barge-in requires both conversation-state handling and immediate local audio behavior. Waiting for a completed response or relying only on UI state makes Jarvis feel unresponsive. Explicit playback clearing gives the local client a deterministic stop path while the provider handles the new turn.

### Consequences

- Interruption is visible in the transcript and metrics.
- Regression tests verify event wiring and required client controls.
- Raw audio, SDP, credentials, and ephemeral ICE values are never written to the event journal.
- Live testing remains required to measure perceived stop latency and tune VAD behavior.

## ADR-010 — Every repaired release contributes to a recruiter-friendly issue portfolio

**Date:** 2026-07-26  
**Status:** Accepted

### Decision

Maintain a project-root `issues/` directory. Each meaningful development or release issue receives a structured Markdown record containing its symptom, impact, root cause, investigation, final fix, regression protection, result, engineering lesson, and a truthful recruiter talking point. Maintain an index and test the documentation contract.

### Rationale

The issue history is valuable engineering evidence, not disposable troubleshooting. Preserving it demonstrates diagnosis, safe rollback, test design, API-boundary reasoning, and iterative delivery while preventing later retellings from becoming inaccurate.

### Consequences

- `0.0.2` retroactively documents the bootstrap and Realtime handshake issues.
- Future patch payloads place new or updated issue records under `patch_files/issues/`.
- Patch notes and the handoff reference issue records when repairs occur.
- Issue documentation must not expose secrets, raw authorization data, or private `.env` contents.

## ADR-009 — Reconcile optimistic typed input with provider conversation events

**Status:** Accepted during `0.0.2` live acceptance

Typed input is rendered optimistically for immediate feedback, but provider conversation events remain authoritative. The client must track pending typed messages and consume the matching provider echo into the original UI record. It must not render the echo as a second user turn.

This keeps the interface responsive while preserving one conversation identity across typed and spoken input.

## ADR-010 — Preserve provider-default turn detection until measurements justify an override

**Status:** Accepted during `0.0.2` live acceptance

Jarvis will omit Realtime `turn_detection` configuration by default and allow the selected provider/model to apply its supported default. Optional semantic profiles remain explicit user choices.

The initial low semantic-VAD default waited too long in Tanner's real environment. Provider defaults should not be replaced globally based on theory alone; overrides require measured improvement and must remain configurable.

## ADR — Local usage accounting and provider-free simulation

**Decision:** Jarvis owns a privacy-safe local usage ledger and a deterministic simulation provider. Browser UI code is not the billing source of truth, and routine UI/lifecycle validation does not require a paid Realtime session.

**Rationale:** Realtime provider metadata arrives at the client, but durable accounting, deduplication, period summaries, and budget enforcement belong in the independent local core. Simulation allows wake, sleep, transcript, timer, and interruption work to be repeated freely while reserving live calls for final audio/provider acceptance.

**Consequences:**

- `data/realtime_usage.jsonl` is local runtime data and remains ignored by Git.
- Usage records contain no transcript or audio content.
- Pricing profiles are centralized and versioned.
- Daily and monthly hard limits may block new live sessions locally.
- Simulation is explicitly labeled and must never be mistaken for a real provider response.
