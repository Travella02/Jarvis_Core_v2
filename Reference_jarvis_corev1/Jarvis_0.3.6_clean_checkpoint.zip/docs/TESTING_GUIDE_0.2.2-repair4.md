# Testing Guide — 0.2.2-repair4 Gmail Humanization

## Test 1 — Humanized unread overview

Say:

> Do I have any unread emails?

Expected:
- Jarvis gives the unread inbox count.
- He may mention the most important sender/subject naturally.
- He does not read raw email addresses aloud.
- He does not say `Re:` or `Fwd:` aloud.
- He does not dump every unread message card.

Then say:

> Can you show me those emails?

Expected:
- Gmail-style cards appear.
- Jarvis gives only a short spoken orientation instead of reading the cards/body aloud.

## Test 2 — Reply target safety

Use a thread where the external person emailed the connected account and the connected account has also sent a message in that same thread.

Say:

> Respond to Tanner's SUPPORT email and say thank you so much, I really appreciate it. I'm super excited too.

Expected:
- Jarvis finds the correct thread.
- The draft `To` field is Tanner/the external sender, never the connected account itself.
- Jarvis says a short acknowledgement such as “I drafted the reply to Tanner. Want me to send it?”
- He does not read the entire reply body aloud.

## Test 3 — Sleep/wake continuity regression

Leave the reply draft pending, let Jarvis sleep, wake him as the same recognized user, then say:

> Go ahead and send it.

Expected:
- Jarvis resumes the exact pending draft and sends it once after confirmation.
