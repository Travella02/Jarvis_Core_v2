# 0.1.7-repair5 — Clear Continuations

This repair makes long written answers unmistakably incomplete previews instead of appearing abruptly cut off.

## Changes

- Long hybrid-answer cards now use a compact preview capped at 44% of the conversation viewport, with a hard maximum of 330 pixels.
- The visible words progressively fade near the lower edge instead of ending at a hard clip line.
- A clear **Answer continues — open Fullscreen** cue appears over the faded edge whenever more text exists.
- Overflow detection now checks the internally clipped answer content, so the fade and continuation cue remain reliable after resizing.
- The full answer remains unchanged and available through the existing **Fullscreen** reader.
- Short answers and Full-mode Realtime answers retain their existing behavior.

## Compatibility

- Version remains `0.1.7` because this repairs the current unaccepted Self Awareness update.
- No model routing, speech, memory, capability, private configuration, or cost-accounting behavior changed.

## Validation

- 282 Python tests passed.
- 73 source-available Node tests passed.
- Four unchanged Electron packaging tests require the complete project dependency tree; the installer requires all 77 Node tests on the complete project.
- Desktop JavaScript syntax, diagnostic startup, staged-runtime behavior, and rollback were validated.
