# 0.3.2-repair1 — Git-Aware Checkpoint Verification

This repair fixes the Account Foundation patch installer after the first 0.3.2 candidate incorrectly treated a normal Git text representation difference as a source-code edit. The product version remains `0.3.2`; this is an unaccepted-candidate repair, not a new product version.

## What changed

- The installer still requires the accepted 0.3.1 Git foundation and still refuses genuine tracked source edits.
- When a raw SHA-256 differs from the archived baseline, the installer now requires Git to report that path clean in both the working tree and index, then hashes the committed `HEAD` blob and requires that blob to match the exact uploaded 0.3.1 baseline.
- This handles Git-clean LF/CRLF worktree representations without weakening source protection.
- Payload SHA-256 validation, automatic backups, atomic replacement, post-install verification, `.env` isolation, and local-data isolation remain unchanged.

## Why the first candidate failed

The uploaded checkpoint came from `git archive`, which contains the committed blob representation. A Git worktree can legitimately use different line-ending bytes while still representing exactly the same tracked content. The first installer compared raw working-tree SHA-256 values directly with archive SHA-256 values, so clean `app.js`, `index.html`, `styles.css`, and CommonJS test files looked modified even though `git diff` was empty.

## Acceptance target

The accepted 0.3.1 checkout must pass checkpoint validation when Git says the protected paths are unchanged and their committed blobs match the uploaded baseline, while any real tracked content edit must still be rejected. Account Foundation then proceeds through the normal automated and live acceptance tests before commit.
