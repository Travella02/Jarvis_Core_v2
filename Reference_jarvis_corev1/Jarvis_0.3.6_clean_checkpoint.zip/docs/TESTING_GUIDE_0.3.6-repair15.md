# 0.3.6-repair15 Live Testing — Calendar Single-Confirmation Authority

Do not make the final 0.3.6 acceptance commit or clean patch artifacts yet. Apply Repair15 only over the exact committed `0.3.6-repair14` checkpoint.

## Automated checks

1. Run the Calendar single-confirmation API/security tests.
2. Run the Connected Action confirmation-security regression tests.
3. Run the single-confirmation Electron/Node source-contract test.
4. Run `npm run desktop:check`.
5. Run the normal 0.3.6 Python regression group and full Electron suite before final acceptance.

## Live test A — Default Calendar delete uses one confirmation

1. Set **Calendar Actions** to `Default`.
2. Create a disposable event, for example `0.3.6 permission test`, tomorrow at 3 PM for 15 minutes.
3. Ask Jarvis to delete/cancel that exact event.
4. Jarvis must identify/show the exact target and ask one natural confirmation, for example `Want me to remove 0.3.6 Permission test from your calendar?`.
5. Say `Yes.`

**Pass:** Google deletes exactly that event once. No second native permission popup appears. Temporary `Unknown speaker` attribution on the short affirmative must not destroy the pending action context.

## Live test B — Always ask remains stricter

1. Recreate the disposable event.
2. Set the Calendar delete permission to `Always ask`.
3. Ask Jarvis to delete the event and answer `Yes` to Jarvis's exact natural review.

**Pass:** the trusted native permission window appears and its positive action is **Allow once**, not **Always allow**. Approval executes exactly that delete once. A second distinct delete under `Always ask` requires a fresh trusted prompt.

## Live test C — Block remains terminal

1. Recreate the disposable event.
2. Set Calendar deletion to `Block`.
3. Ask Jarvis to delete it.

**Pass:** the provider deletion does not occur, the setting does not silently change, and Jarvis does not route the request into another capability.

## Live test D — create/update regression

Return Calendar Actions to `Default`, then create and move/edit a disposable event.

**Pass:** each exact reviewed Calendar write uses only Jarvis's natural confirmation under Default, with no stacked native permission popup.

## Security invariant

The convenience change is presentation authority only. The user-facing natural `Yes` does not bypass executor enforcement: the exact challenge still materializes a one-use grant, and the real Calendar executor is still the component that consumes it.
