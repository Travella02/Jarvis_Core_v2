# 0.2.0-repair1 — Google OAuth Exchange

Repairs the Google desktop OAuth callback used by Connected Actions.

- Replaces the path-based loopback redirect with `http://127.0.0.1:<Jarvis port>`.
- Handles Google's authorization response on the local root route.
- Retains the previous callback route for compatibility with an already-open sign-in attempt.
- Shows Google's safe OAuth error code and description when the token exchange fails.
- Does not change Gmail, Calendar, Luna planning, confirmation, token protection, or Realtime speech behavior.

After applying the repair, close any old Google sign-in tab and begin a completely new **Connect Google** attempt because authorization codes are one-time values.
