# 0.2.2-repair4 — Gmail Humanization

This repair keeps the accepted 0.2.2 Action Speed work while fixing two live Gmail issues found during acceptance testing.

## What changed

- Gmail speech is now intentionally lighter than the visual card. Jarvis no longer reads raw email addresses aloud when a sender name is available, does not pronounce `Re:`/`Fwd:` subject prefixes, and does not read message bodies back just because they are visible on screen.
- Visual requests such as “show me those emails” use a short spoken orientation while the full Gmail cards carry the exact sender, recipient, subject, and message.
- Broad unread overviews remain bounded, but now sound conversational instead of reciting raw Gmail headers.
- Gmail summaries that still use Luna inherit the same humanized speech rules.
- Reply drafts no longer assume the newest thread message is the person to reply to. Jarvis now identifies the connected Gmail account locally and replies to the newest external sender in the thread.
- If a thread contains only the connected account, Jarvis refuses to create a self-addressed reply instead of guessing.
- Reply-draft acknowledgements are shorter: Jarvis confirms that the reply is drafted and asks whether to send it while the exact wording remains visible in the email card.
- Sleep/wake pending-draft continuity from repair3 is preserved unchanged.

## Safety

This repair does not weaken send confirmation. Drafting and editing still do not send anything, and the final Gmail send still requires explicit confirmation.
