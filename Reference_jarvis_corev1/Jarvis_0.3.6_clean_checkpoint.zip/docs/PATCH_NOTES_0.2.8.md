# 0.2.8 — Game Mode

This development build adds the protection layer required before Jarvis receives deeper browser, mouse, keyboard, and vision-driven computer access.

## What changed

- Game Mode now identifies the actual running game instead of treating anti-cheat software as the game detector.
- Anti-cheat presence is diagnostic/supporting information only and can never activate Game Mode by itself.
- Jarvis-launched games are armed immediately, while manually launched installed games are detected from the persistent app/game catalog.
- Protected state follows the real game process for the lifetime of the game and survives short launcher/process handoffs.
- Alt-tabbing does not disable protection; Jarvis may continue using ordinary non-game applications while the game remains protected.
- A code-level executor firewall blocks future synthetic keyboard/mouse, vision-click, macro, and gameplay automation when they target a protected game. Process-memory access, process injection, and input hooks are hard-disabled entirely.
- OS-level application launch/close remains allowed, including closing the protected game normally.
- Unknown fullscreen targets fail closed for future synthetic input unless the target is positively recognized as an ordinary indexed application.
- The desktop shows `GAME MODE · <game>` while protection is active and `GAME MODE · ARMING <game>` while waiting for a launched game process.

## Important safety invariant

Game Mode is enforced in code, not by asking Luna to remember not to cheat. Future computer-control executors must call the Game Mode authorization gate before sending risky input.

## Versioning

The installed release remains 0.2.7 during live acceptance testing. Promote release metadata to 0.2.8 only after the Game Mode live tests pass.
