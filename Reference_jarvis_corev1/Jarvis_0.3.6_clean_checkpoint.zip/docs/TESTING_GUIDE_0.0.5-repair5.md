# Testing Guide — 0.0.5 Electron Shell Repair 5

## Install

```powershell
py -3.12 apply_0_0_5_repair5_patch.py
```

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Native acceptance

1. Run `npm run desktop`.
2. Confirm the native Jarvis window opens and the terminal does not repeat Chromium `chunked_data_pipe_upload_data_stream` errors.
3. Confirm the wake-listener label reports a local Windows listener instead of rapidly alternating between listening and restarting.
4. While sleeping, say only **“Jarvis.”** Confirm one acknowledgement.
5. Sleep Jarvis, then say **“Jarvis, tell me a joke.”** Confirm one opening request and one response.
6. Repeat with **“Hey Jarvis, what time is it?”**
7. During a normal awake conversation, say **“That’s all, Jarvis.”** Confirm the paid session closes and the local wake listener remains ready.
8. Confirm manual tray Wake and Sleep still work.
9. Quit from the tray and confirm both the Python core and Windows speech listener exit.

## Failure diagnostics

If the local listener reports unavailable, verify Windows has an installed English speech recognizer and that the Windows default recording device is the microphone intended for wake and sleep commands.
