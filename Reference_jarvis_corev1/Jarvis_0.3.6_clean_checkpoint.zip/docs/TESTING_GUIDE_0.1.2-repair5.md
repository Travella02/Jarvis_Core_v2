# Testing Guide — 0.1.2-repair5 Silent Visual Commands

## Automated validation

- 193 Python tests
- 36 Node tests
- Desktop JavaScript syntax checks
- Doctor and core diagnostics
- Desktop runtime staging

## Acceptance tests

1. From Home, say `Jarvis, show me everything about ORVEX.`
   - Memory Explorer opens.
   - ORVEX is displayed.
   - Jarvis does not speak and no Jarvis response bubble remains.
2. Type `Show me everything about ORVEX.`
   - The same silent visual behavior occurs.
3. Say `Jarvis, show me everything about ORVEX and give me a short summary.`
   - Memory Explorer opens.
   - Jarvis gives the requested short summary.
4. Say `Jarvis, show me and tell me about ORVEX.`
   - Memory Explorer opens.
   - Jarvis narrates because narration was explicitly requested.
5. Ask `What do you know about ORVEX?`
   - Jarvis answers normally without forcing the Memory workspace open.
