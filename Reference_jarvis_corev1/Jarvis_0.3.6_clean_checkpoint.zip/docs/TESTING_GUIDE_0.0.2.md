# Testing Guide — 0.0.2 Voice Control

## Install

Stop the running core with `Ctrl+C`. Extract the patch ZIP into the existing `Jarvis_Real_Time` project root, allow Windows to merge `patch_files`, then run:

```powershell
py -3.12 apply_0_0_2_patch.py
```

Do not rerun an earlier bootstrap or repair installer.

## Automated tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Expected result:

```text
Ran 43 tests
OK
```

The exact count must match the release manifest and installer output.

## Doctor

```powershell
.\.venv\Scripts\python.exe scripts\doctor.py
```

Expected key lines:

```text
Project: Jarvis_Real_Time
Version: 0.0.2
Voice: cedar
VAD eagerness: low
Session safety limit: 55 minutes
```

If the private `.env` explicitly overrides voice or VAD, the doctor correctly shows that override instead of the example default. The API key status must say either safely configured or missing; its value must never appear.

## Start command

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

Open the local lab if it does not open automatically:

```text
http://127.0.0.1:8765
```

## Manual acceptance sequence

### 1. Default controls

- Confirm the page displays `0.0.2 — Voice Control`.
- Confirm Cedar is selected unless your private `.env` or saved local preference intentionally overrides it.
- Confirm pause sensitivity is `low` unless intentionally overridden.
- Confirm status begins at **Sleeping** and the microphone indicator is not active.

### 2. Wake and basic conversation

- Press **Wake Jarvis**.
- Allow microphone permission.
- Confirm status progresses through waking to listening.
- Hold a two- to five-minute conversation with several follow-up questions.
- Expected: no wake word is required while the session is awake, and Jarvis addresses you naturally as “sir” without repeating it excessively.

### 3. Natural pauses

Say a sentence with a deliberate mid-thought pause of roughly one second, such as:

> “Jarvis, I want you to compare two ideas... the first is working locally, and the second is using a cloud service.”

Repeat at least five times with different pauses.

Expected: low semantic VAD should usually let you continue. Record any premature answer in the provider-events panel and note the room noise and microphone used.

### 4. Voice interruption

While Jarvis is speaking, begin a new sentence. Repeat at least five times.

Expected:

- Jarvis audio stops immediately or nearly immediately.
- The transcript marks the prior response as interrupted.
- The interruption counter increments once.
- Jarvis listens to and answers the new turn.
- The provider panel must not enter a repeating error loop.

### 5. Manual stop

While Jarvis is speaking, press **Stop Jarvis speaking**.

Expected: output stops, the transcript is marked, and Jarvis returns to listening without closing the session.

### 6. Typed parity

Send one typed message in the conversation input.

Expected: it uses the same active Realtime conversation, Jarvis answers aloud, and the transcript stays in sequence.

### 7. Sleep privacy and cost boundary

Press **Sleep Jarvis**.

Expected:

- Status returns to Sleeping.
- Browser microphone use ends.
- Typed input, mute, sleep, and stop controls become disabled as appropriate.
- No cloud audio session remains active.

Speak near the microphone while sleeping. Jarvis must not answer. Press Wake Jarvis and verify a fresh session connects.

### 8. Reconnect

With Jarvis awake, briefly interrupt the network or force a temporary WebRTC disconnect if practical, then restore it.

Expected: Jarvis waits through a short grace period and makes at most one automatic reconnect attempt. It must not create an endless reconnect loop. Manual Sleep must always stop further attempts.

### 9. Timing metrics

Complete at least ten turns and review:

- Speech length.
- Turn decision.
- First audio.
- Total response.
- Handshake.

Expected: values are non-negative, update once per turn, and latency records appear in `logs/realtime_events.jsonl` without audio or secrets.

## Configuration note for an existing `.env`

The patch preserves your `.env`. To make Cedar the backend default, edit only this local line if necessary:

```env
JARVIS_REALTIME_VOICE=cedar
```

Recommended voice settings:

```env
JARVIS_VAD_EAGERNESS=low
JARVIS_SESSION_MAX_MINUTES=55
```

Never send, screenshot, or commit the API key.

## Common failure symptoms

### Wake button disabled

The local core reports that `OPENAI_API_KEY` is missing. Confirm `.env` exists in the project root, then restart the core.

### Jarvis answers too early

Confirm pause sensitivity is `low`. Try a quieter microphone input and verify noise suppression is enabled. Preserve the safe event log for the next tuning update.

### Jarvis does not stop when interrupted

Confirm `input_audio_buffer.speech_started` appears when you speak over him. If it does not, the provider did not detect the interruption; capture the microphone type, room noise, selected VAD setting, and safe event names.

### Provider reports an event error after manual stop

Record the event type, event ID, safe message, and sequence around `response.cancel` and `output_audio_buffer.clear`. Do not share raw SDP or the `.env`.

### Reconnect repeats

Press Sleep Jarvis. This release is designed to allow only one automatic attempt; preserve safe logs if more appear.

## Safe log collection

Stop Jarvis, then copy only these files for debugging:

```text
logs/core.log
logs/realtime_events.jsonl
```

Review them before sharing. Never include `.env`, raw network captures containing Authorization headers, or raw SDP.

## Commit after acceptance

Delete temporary patch artifacts after all checks pass:

```powershell
Remove-Item apply_*.py -Force
Remove-Item patch_files -Recurse -Force
```

Then:

```powershell
git status
git add .
git commit -m "0.0.2: add voice control and issue documentation"
git push
```
