# Testing 0.2.4-repair2 — Voice-First Tasks

## Primary live test

1. Keep the existing task **Finish the ORVEX website**.
2. Ask: **“What do I need to get done today?”**
3. Jarvis should say the actual task name aloud, not only the number of tasks.
4. For this short/simple question, Jarvis should not need to show a task card.

## Follow-up ownership test

Immediately ask: **“What task is that?”**

Jarvis should answer something like **“It’s Finish the ORVEX website.”** He must not claim that he does not know your tasks or offer to invent/draft tasks.

## Visual request test

Ask: **“Show me what I need to get done today.”**

Jarvis should give a short spoken orientation and render the task card(s) on screen.
