# 0.2.8-repair1 — Live Test

1. Start Jarvis and wake it. Say **“Open Rocket League.”**
   - Rocket League should open with normal Computer Actions responsiveness.
   - Jarvis should speak **“Opening Rocket League.”**
   - Game Mode should appear shortly after the real game process is detected.

2. With Rocket League still running, say **“Open Snipping Tool.”**
   - Snipping Tool should open promptly.
   - Jarvis should speak **“Opening Snipping Tool.”**
   - Jarvis should return to Listening instead of remaining in Thinking.

3. Say **“Close Snipping Tool.”**
   - It should close normally while Game Mode stays active for Rocket League.

4. Press **Sleep** while Rocket League is still running. Wait 15–20 seconds.
   - Jarvis should enter Sleeping normally.
   - The local core process should not restart.
   - Wake Jarvis again and confirm the session reconnects normally.

5. Say **“Close Rocket League.”**
   - The close should work normally.
   - Game Mode should remain protective until Windows confirms the game process is gone, then turn off.

6. Optional regression: manually launch Rocket League and confirm Game Mode still activates from positive game identity without Jarvis launching it.
