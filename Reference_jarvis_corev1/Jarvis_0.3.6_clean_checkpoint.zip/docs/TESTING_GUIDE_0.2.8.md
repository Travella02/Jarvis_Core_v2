# 0.2.8 Game Mode — Live Acceptance Guide

The goal of this pass is to prove that Game Mode protects an actual game without poisoning ordinary computer actions.

## Test 1 — Jarvis-launched game

1. Start Jarvis normally.
2. Say `Open Rocket League.`
3. Confirm Rocket League launches normally.
4. Within a few seconds, confirm the header shows `GAME MODE · Rocket League`.
5. Alt-tab back to Jarvis. The Game Mode badge should remain active while Rocket League is still running.

## Test 2 — Ordinary applications remain usable

With Rocket League still running:

1. Say `Open Snipping Tool.`
2. Confirm Snipping Tool opens normally.
3. Say `Close Snipping Tool.`
4. Confirm it closes normally.
5. Game Mode should still show Rocket League as protected.

## Test 3 — Anti-cheat is not the trigger

1. Close Rocket League through Jarvis or Windows.
2. Give the monitor a few seconds to observe the game process disappearing.
3. Confirm the Game Mode badge disappears even if an anti-cheat/helper process remains resident in the background.
4. Open Snipping Tool again and confirm it behaves like an ordinary application.

## Test 4 — Manual game launch

1. With Game Mode currently inactive, launch Rocket League yourself from Steam/Epic/Windows instead of asking Jarvis.
2. Confirm `GAME MODE · Rocket League` appears once the actual game process/window is detected.
3. Close the game manually and confirm Game Mode clears after the bounded shutdown grace period.

## Expected result

Game Mode should follow the actual game process, not background anti-cheat, launcher, or fullscreen state. Normal app launch/close actions must remain available while a game is protected.
