# 0.1.0 — Packaging Stall Repair

## Summary

This repair prevents the Windows Desktop Alpha build from spending an unbounded amount of time copying the entire development repository into Electron's packaged application.

## Fixed

- Electron Packager now excludes development-only trees from `app.asar`, including `.venv`, `.patch_backups`, `build`, `out`, source tests, logs, private data, documentation, patch payloads, Python source, and build scripts.
- The staged Python runtime and staged desktop runtime are no longer copied into both `app.asar` and `resources`; each is included once through `extraResource`.
- When the application has no production Node dependencies, the full development `node_modules` tree is rejected at the copy filter instead of being traversed and pruned.
- If production Node dependencies are added later, normal Electron Packager pruning automatically resumes.
- `alpha:prepare` now runs a packaging-scope preflight before Electron Forge starts.
- The preflight confirms required Electron entrypoints remain included, required external resources exist, and the packaged source scope stays below a conservative size limit.
- `alpha:verify` now rejects an unexpectedly large `app.asar`, guarding against accidental inclusion of duplicate runtimes or development files.

## Preserved

- A valid completed Python 3.12.10 runtime under `build\python` is detected and reused automatically, avoiding another dependency installation on retry.
- The installed application still contains the complete Python core and desktop interface through external resources.
- First-run setup, encrypted API-key storage, Realtime behavior, diagnostics, shortcuts, and update visibility are unchanged.
- The release remains `0.1.0` because this is a pre-acceptance repair.

## Validation

- 154 Python unit tests passed.
- 13 Node desktop tests passed.
- Electron and packaging-scope syntax checks passed.
- Packaging-scope preflight passed against the prepared test fixture.
- Doctor, diagnostic startup, runtime-plan validation, and desktop-runtime staging passed.
- The final native Squirrel build still requires 64-bit Windows.
