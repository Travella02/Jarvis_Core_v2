# 0.2.6-repair2 — Fast App Control

## What changed

The first successful Computer Actions launch proved that discovery worked, but it also exposed the wrong latency model: Jarvis could synchronously rebuild the Windows app index before honoring an obvious request. That made a simple `Open Discord` request take roughly 20 seconds even after Jarvis already knew how to launch it.

This repair makes the learned app catalog the first authority. Exact known names and person-specific aliases are resolved from the local catalog before any Windows refresh or filesystem search. A learned target therefore goes straight to the operating system launch call. Cheap registry/shortcut/launcher discovery is used for first-use requests, while slower `Get-StartApps` enumeration is prewarmed in the background at core startup instead of blocking speech.

Computer Actions now also owns explicit app closing. Requests such as `Close Discord` resolve the same known app identity and close the matching Windows application processes locally. Jarvis protects its own runtime and critical Windows process names from this generic close path.

A new **Memory → Apps** view exposes the local learned computer map: application/game name, stored target/path or launcher URI, source, usage, and aliases. Users can add another alias from the UI, and natural phrases such as `Group chat is another name for Discord` or `From now on I want to call Discord as group chat` save the alias to that recognized person's app memory. Explicit aliases can be reassigned, preventing one user alias from silently pointing at multiple apps.

## Performance model

1. Learned exact app/alias → local catalog lookup → OS launch immediately.
2. New common app → cheap local App Paths/shortcut/PATH/game-manifest discovery.
3. Slower Windows Start Apps inventory → background prewarm, persisted for future turns.
4. Only genuinely unresolved apps fall back to common-folder and bounded fixed-drive search.

The goal is that familiar applications feel immediate; the operating system/application's own startup time is separate from Jarvis routing latency.

## Preserved behavior

- App discovery remains local-first and tenant-aware.
- Person-specific learned aliases remain separate from another person's aliases.
- True ambiguity still asks rather than guessing.
- Deep search still exists for obscure/portable apps and does not require the user to provide a path.
- Arbitrary discovered `.bat`/`.cmd` files are still not treated as applications.
- Existing `.env`, Google OAuth, durable memory, Voice Profiles, tasks/reminders, and learned app catalog are not replaced by the repair.
