# Testing Guide — 0.0.5 Model Wake Repair

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Native live acceptance

Start Jarvis:

```powershell
npm run desktop
```

Use **Live OpenAI** mode for wake testing. Free simulation deliberately uses manual wake so it remains provider-free.

1. Confirm the wake status says it is listening locally for Jarvis and no Windows `System.Speech` or Chromium speech-recognition restart errors appear in the terminal.
2. Say only **“Jarvis.”** Confirm one short acknowledgement.
3. Return Jarvis to sleep, then say **“Hey Jarvis, tell me a joke.”** Confirm the complete request is preserved and answered once.
4. Repeat with **“Yo Jarvis, what time is it?”**
5. While awake, continue talking normally without repeating Jarvis. Confirm OpenAI Realtime handles the conversation directly.
6. End naturally with **“That’s all, Jarvis.”** Confirm the model calls the local sleep action, Jarvis displays “Of course, sir.”, closes the Realtime session, and returns to the wake listener.
7. Test a natural equivalent such as **“Thanks, you can go back to sleep now.”**
8. Confirm the Usage & budget panel shows Wake transcription separately and the session total includes it.
9. Speak without saying Jarvis while asleep. Confirm no Realtime session opens.
10. Select **Local simulation — free**. Confirm its wake status explains that manual wake is used and no transcription cost is added.
11. Confirm manual Wake, manual Sleep, and tray Wake/Sleep still work.

## Sensitivity tuning

Raise `JARVIS_WAKE_VAD_THRESHOLD` if room noise triggers captures. Lower it slightly if normal speech does not begin capture. Change one setting at a time and keep the default values as the known baseline.

Do not commit `0.0.5` until wake-only, wake-plus-request, natural model-decided sleep, and cost recording all pass in the Electron window.
