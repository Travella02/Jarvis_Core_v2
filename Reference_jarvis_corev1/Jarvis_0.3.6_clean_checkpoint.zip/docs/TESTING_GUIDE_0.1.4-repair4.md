# 0.1.4-repair4 — Authoritative Corrections & Auto Refresh Testing Guide

## Automated validation

The patch installer runs:

- 228 Python tests
- 49 Node tests
- Desktop syntax checks
- Doctor diagnostics
- Core diagnostics
- Desktop-runtime staging
- Private `.env` preservation verification

## Rock → Brock acceptance flow

1. Start Jarvis with `npm run desktop`.
2. Say: “I need to follow up with Rock tomorrow.”
3. Correct it: “Oh, sorry, Jarvis, I actually meant Brock.”
4. Wait briefly; do not press **Refresh locally**.
5. Open **Memory → Proactive**.
6. Confirm there is one current item: **follow up with Brock tomorrow**.
7. Confirm there is no open Rock item.
8. Open **Why this?** and confirm both the original Rock statement and Brock correction remain visible.
9. Close and reopen Jarvis; confirm Brock remains current.

## Existing malformed cleanup

1. Open **Memory → Proactive** after installation.
2. Wait for the automatic refresh or use the manual button once for immediate diagnostics.
3. Confirm `follow up with meant Austin tomorrow` is gone.
4. Confirm the clean Austin item remains once, with all evidence preserved.

## Automatic refresh acceptance

1. Add a new commitment while the Memory workspace is closed.
2. Wait approximately one to two seconds.
3. Open Proactive memory and confirm the item is already present.
4. Correct the item and confirm the displayed list updates without pressing the manual refresh button.
5. Leave Jarvis running and verify the periodic fallback continues updating stats.

## Interruption regression

Repeat one interrupted spoken response and confirm the next response remains audible and late cancelled text does not appear. This repair must preserve the accepted repair3 interruption behavior.
