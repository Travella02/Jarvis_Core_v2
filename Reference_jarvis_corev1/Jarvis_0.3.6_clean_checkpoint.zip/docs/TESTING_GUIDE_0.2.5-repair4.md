# Testing Guide — 0.2.5-repair4 Calendar Ownership

## Primary regression

Wake Jarvis and ask:

> What do I have tomorrow?

Expected:

- Jarvis returns the actual Google Calendar result in the same turn.
- If the day is empty, Jarvis says that nothing is on the calendar tomorrow.
- If events exist, Jarvis names the actual event(s) and their local time(s).
- Jarvis must not say that it is “checking”, “waiting”, or that the results “aren’t back yet”.

Repeat the same question once. It should perform another grounded read or answer from the normal action path; it must not report a fake pending lookup.

## Calendar noun variants

Also try:

- What’s on my schedule tomorrow?
- Do I have anything going on today?
- Is there anything scheduled Friday?

Each should stay in Calendar.

## Task ownership regression

Ask:

> Is there anything I need to do tomorrow?

Expected: the existing Tasks/Reminders behavior remains intact.

If you naturally use:

> What do I have to do tomorrow?

Jarvis must not force that wording into Calendar merely because it contains `tomorrow`.

## Multi-speaker continuation

Continue the 0.2.5 speaker-recognition tests afterward. Calendar context is still speaker-scoped, so switching to another recognized speaker must not reuse the previous speaker’s Calendar clarification/focus state.
