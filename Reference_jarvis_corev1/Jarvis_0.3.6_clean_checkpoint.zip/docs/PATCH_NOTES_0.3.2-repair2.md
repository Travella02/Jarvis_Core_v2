# 0.3.2-repair2 — Canonical Checkpoint Verification

This repair keeps the full 0.3.2 Account Foundation candidate and replaces repair1's Git-blob fallback with representation-safe text verification.

## What changed

- Protected text files now carry both strict raw SHA-256 hashes and canonical CRLF-to-LF SHA-256 hashes.
- A clean baseline may differ only by line-ending representation; any other byte/content edit is still rejected.
- Target-state recognition is canonical-aware so an already-applied candidate remains idempotent after normal Git checkout EOL conversion.
- Accepted 0.3.1 `HEAD`, payload integrity, backups, rollback, and strict post-copy verification remain enforced.
- ISSUE-297 records the repair1 failure and the corrected cross-platform rule.

## Version

The application version remains **0.3.2**. `repair2` is only the pre-acceptance installer repair label. All current version/release surfaces stay promoted to 0.3.2.
