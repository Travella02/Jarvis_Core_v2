# 0.3.6-repair4 — Clean Reauth Completion

**Date:** 2026-09-03  
**Required previous release:** 0.3.6-repair3  
**VERSION remains:** 0.3.6  
**Status:** Live acceptance repair candidate

## Why this repair exists

Repair3 worked correctly, and live testing confirmed Edge may intentionally refuse `window.close()` for a security tab opened by the desktop application. The remaining page then used diagnostic wording ("Your browser prevented automatic tab closing"), which made a normal browser security policy feel like an error after authentication had already succeeded.

## What changed

- The successful reauthentication page now leads with **"Authentication approved."**
- The always-visible completion text simply says Jarvis is continuing the exact approval in the desktop app.
- Jarvis still makes the same safe best-effort `window.close()` attempt after successful password proof.
- If the tab remains open, the fallback says **"Authentication approved. You may now safely close this browser tab and return to Jarvis."**
- The user-facing page no longer reports expected browser close policy as an error.
- No Browser Control, browser extension, OS automation, native input, or security bypass is introduced.

## Security boundary

Unchanged from repair3: browser reauthentication establishes only recent identity assurance. The exact trusted Jarvis confirmation still authorizes the specific setting/action, and tab closure is UX-only.

## Issue

See ISSUE-327.

## Commit rule

Do not commit yet. Continue 0.3.6 live acceptance. Keep repair4 and all previous patch/repair artifacts until Tanner explicitly accepts the complete 0.3.6 release. No Git tag.
