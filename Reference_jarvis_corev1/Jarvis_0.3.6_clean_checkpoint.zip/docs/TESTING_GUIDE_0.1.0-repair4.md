# Testing Guide — 0.1.0 Windows Finalization Repair

## Apply

Extract the repair ZIP directly into the `Jarvis_Real_Time` project root, allow Windows to merge/replace files, then run:

```powershell
py -3.12 apply_0_1_0_repair4_patch.py
```

## Clear only failed Forge output

```powershell
Remove-Item -Recurse -Force .\out -ErrorAction SilentlyContinue
```

Do not delete `.venv`, `build\python`, `build\cache`, `build\desktop_runtime`, or `build\runtime_bundle.zip`.

## Build

```powershell
npm run alpha:make
```

Expected new output includes timestamped lines such as:

```text
START initialize
DONE  initialize
START renameElectron
DONE  renameElectron
START copyExtraResources
DONE  copyExtraResources
SKIP  runResedit
DONE  move
```

A heartbeat appears every minute while Forge remains active. The complete trace is always written to:

```text
build\alpha-packaging-diagnostic.log
```

## Time boundary

The compact package should normally pass finalization in a few minutes. If one method remains active for 15 minutes with negligible CPU/disk activity, cancel once with `Ctrl+C` and preserve the diagnostic log. Do not rerun before reviewing the last `START`, `DONE`, `SKIP`, or `FAIL` entry.

## Verify

After the build returns successfully:

```powershell
npm run alpha:verify
```

Expected Setup executable:

```text
out\make\squirrel.windows\x64\Jarvis_Real_Time_Setup.exe
```

## Acceptance note

The application executable may temporarily retain Electron's default icon/metadata because resource editing is intentionally bypassed. The Squirrel installer icon should still be present. Functionality, runtime extraction, first-run setup, wake/conversation/sleep, restart, and shutdown remain the acceptance priorities.
