# Jarvis_Real_Time Handoff Instructions

## Canonical direction

The architecture PDF at `docs/reference/Jarvis_Core_1.0_Master_Architecture_and_Project_Handoff.pdf` remains canonical. Tanner renamed the repository to **Jarvis_Real_Time**. Preserve local ownership, provider replaceability, safety boundaries, downloadable patch delivery, automated validation, issue documentation, and secret isolation unless Tanner explicitly changes them.

## Current 0.3.6 development state

- **Accepted/committed baseline:** `0.3.5` — Billing & Entitlements.
- **Working candidate:** `0.3.6` — Permissions & Security. This version is **not committed or accepted yet**.
- **Completed:** Phase 1 Permission Foundation, Phase 2 Executor Enforcement, Phase 3 Confirmation Security, Phase 4 Sensitive Data Hygiene, and Phase 5 Adversarial Security Testing.
- **Phase 5 checkpoint:** hostile-client testing now requires trusted desktop user-presence attestation for native confirmations, invalidates runtime grants/challenges on Core restart and permission-policy changes, authenticates protection downgrades, preserves Game Mode/Cloud/system supremacy over forged grants, and guarantees complete exact-action review or fails closed. See `docs/0.3.6_PHASE5_RECOVERY_CHECKPOINT.md` and ISSUE-322.
- **Patch reconstruction:** the real 0.3.6 patch was independently applied over the clean accepted 0.3.5 baseline and validated. See `docs/0.3.6_PATCH_RECONSTRUCTION_VALIDATION.md`.
- **Live repair1:** the first real Windows launch exposed a `WinError 5` ordering bug because `logging.FileHandler` opened `logs/core.log` before the Phase 4 one-time atomic legacy cleanup. `0.3.6-repair1 — Windows Hygiene Startup` moves that migration before durable Core logging while preserving alternate-entry cleanup and atomic retry semantics. See ISSUE-323 and `docs/TESTING_GUIDE_0.3.6-repair1.md`.
- **Current live candidate:** `0.3.6-repair10 — Regression Alignment`. Repair9 added trusted-prompt voice quarantine, denial-only vocal cancellation, and working structured-card Fullscreen. The first full real-checkout Electron rerun then exposed ISSUE-334: three historical source-shape assertions still required the pre-Repair9 implementation. Repair10 updates those tests only; production Repair9 runtime code is unchanged.
- **Next:** apply repair10 over the exact repair9 live candidate, run the two targeted Electron files, `desktop:check`, and the full Electron suite with output captured to a log. If green, resume the Repair9 live checks for prompt-time speech quarantine, vocal denial, and Gmail/structured-card Fullscreen. Any further pre-acceptance fix remains `0.3.6-repairN`.
- **Confirmation invariant:** `consume exact challenge -> materialize one-use grant -> real executor permission check consumes grant -> provider/executor executes`. Never consume the new grant in the confirmation helper and never bypass the executor check.
- **Sensitive-data invariant:** credential/payment values do not become conversation/memory/log/diagnostic/audit/sync/task storage. Exact sensitive pending transactions remain process-memory-only and expire after restart rather than being reconstructed from redacted state. Legitimate encrypted/authoritative secret stores remain preserved.
- **Patch workflow:** patch ZIP only; apply from project root; verify expected 0.3.5 baseline and hashes; back up replaced files; preserve `.env`, OAuth/provider secrets/tokens, local DBs, memories, voice profiles, browser state, user data, and Git history; keep VERSION at 0.3.6 during candidate testing; no commit until live testing passes and Tanner explicitly accepts; after acceptance remove temporary apply/patch/staging/backup artifacts before the focused commit; no Git tag unless explicitly requested.

The historical 0.3.5 release section below describes the accepted baseline and remains useful when building/testing the eventual 0.3.6 patch.

## Current release

- **Current working candidate:** `0.3.6` — Permissions & Security.
- **Release status:** Automated Phase 1–5 implementation/security validation and clean-0.3.5 patch reconstruction are complete. Repairs 1–9 have advanced live acceptance through Windows hygiene, trusted reauth, executor-owned confirmation, test isolation, consumer confirmation UX/focus, explicit URL routing, prompt-time voice quarantine, denial-only vocal cancellation, and structured-card Fullscreen. `0.3.6-repair10 — Regression Alignment` is the current live-acceptance test-tooling candidate and changes no production runtime code. The release is **not committed or accepted yet**.
- **Required previous version:** accepted clean `0.3.5` — Billing & Entitlements.
- **Release date:** 2026-09-02 candidate.
- **Permission boundary:** centralized seven-level policy with executor enforcement, exact challenge-bound confirmations, purpose-bound authenticated reauthentication, device-scoped preferences, runtime-only grants/challenges, and Game Mode/Cloud/system safety supremacy.
- **Trusted confirmation boundary:** a challenge ID is not approval. Native confirmation requires trusted Electron-main-process user presence bound to the exact challenge; authenticated confirmation uses the browser Account reauthentication flow. Exact review must be complete or the action fails closed.
- **Sensitive-data boundary:** credentials/payment values are sanitized/rejected before accidental conversation, Memory, log, diagnostic, audit, task, or sync persistence. Exact sensitive pending transactions remain process-memory-only and expire after restart. Intended encrypted/authoritative secret stores are preserved.
- **Adversarial result:** Phase 5 attacks cover forged/replayed/stale/cross-scope confirmations, model/self-authorization, hacked settings/renderer paths, grant forgery, restart reuse, protection downgrade, Game Mode bypass, Cloud-authority loss, exact-action truncation, and sensitive-data leakage.
- **Node source environment:** product behavior tests pass; four packaging-only tests remain blocked here by missing `@electron/packager/dist/unzip` / `dist/win32` modules and must be rerun in the dependency-complete Windows checkout.
- **Patch/live acceptance:** build only the manifest-verified patch ZIP over accepted clean 0.3.5. Do not commit until Tanner applies it to the real project, completes the live guide, and explicitly accepts it. Repairs before acceptance remain `0.3.6-repairN`.
- **Cleanup after acceptance:** remove temporary `apply_*`, `patch_files/`, patch ZIPs/loaders/staging/backups inside the repository before the focused commit; keep permanent source/config/tests/docs/issues/manifest.
- **Git:** no tag.

### Accepted baseline retained for patch/recovery context

`0.3.5 — Billing & Entitlements` is the committed baseline that 0.3.6 must patch over. Its Cloud-authoritative commercial/provider boundary remains in force: customer-paid/provider-backed privileges are server authoritative, monthly included allowance does not roll over, local client state cannot mint paid privileges, and provider/payment production gates remain separate from the 0.3.6 permission/security work. Historical 0.3.5 notes, testing guides, repair records, and ISSUE-310 through ISSUE-318 remain permanent project history.

## Current architecture

### 0.3.5 commercial/provider authority overlay

```text
Desktop / Browser (untrusted for paid authority)
    -> authenticated Jarvis Cloud operation
        -> authoritative account + tenant + plan + device state
        -> capability grant check
        -> server-owned operation/model/tools/schema
        -> conservative maximum provider exposure
        -> atomic Billing reservation + execution claim
        -> ORVEX-owned provider execution
        -> provider/server-native usage evidence
        -> authoritative settlement / uncertain reconciliation

Hosted Realtime media:
Browser --audio-only WebRTC--> provider
Browser --safe local control--> Core --authenticated--> Jarvis Cloud --private sideband/hangup--> provider
```

The older implementation context below remains useful for established local modules, memory, tools, and desktop lifecycle, but any older wording that implies the desktop is financial authority, that Jarvis is an offline product, or that customer provider keys authorize hosted subscription use is superseded by the 0.3.5 boundary above.

```text
Jarvis_Real_Time_Setup.exe
    -> Squirrel per-user Windows installation and shortcuts
    -> packaged Electron 43 desktop process
        -> context-isolated and sandboxed renderer
        -> OS-encrypted safeStorage API key
        -> Desktop Presence supervision and tray lifecycle
        -> secret-redacted diagnostics and release check
    -> checksum-verified one-file runtime payload
        -> first-launch extraction to versioned per-user runtime
        -> bundled private Python 3.12.10 runtime
        -> import-level runtime health probe before reuse
        -> automatic re-extraction when a packaged runtime is incomplete
        -> development .venv creation/dependency repair before core start
        -> loopback-only FastAPI core
        -> verified Online Account Foundation
            -> cloud-authoritative account + tenant membership identity
            -> installation + per-device identity
            -> verified email address or phone number before normal use unlocks
            -> salted scrypt password verification
            -> opaque HttpOnly device session plus protected cloud access token
            -> explicit account-tenant to existing device data-namespace binding
        -> Cloud Sync platform
            -> portable task/reminder records only in 0.3.4
            -> monotonic server revisions and paginated change cursors
            -> conflict preservation instead of device-clock last-write-wins
            -> cancellation/deletion tombstones and retry-safe mutation ids
            -> per-device authorization, session rotation, and remote revocation
            -> sensitive credentials, memory, voice data, browser state, usage, and diagnostics excluded
        -> per-user data and rotating logs outside app resources
        -> provider/purpose-attributed usage ledger
            -> Realtime and Responses/Luna priced in separate lanes
            -> session paid-call counts by provider/purpose
        -> server-owned prompts, tools, budgets, and OpenAI key
    -> local VAD + short wake transcription
    -> WebRTC Realtime listening / turn-detection session
    -> Luna-owned response scripting + provider-independent speech
    -> local Computer Actions
        -> person-scoped learned app aliases and cached launch targets
        -> Windows App Paths + Start Apps + Start Menu/Desktop shortcuts + PATH
        -> Steam/Epic launcher-aware game discovery
        -> common-root then fixed-drive fallback search
        -> safe non-destructive open for apps, games, files, folders, and projects
    -> Total Recall local memory
        -> append-only exact event ledger
        -> autonomous categories and entity graph
        -> provenance-linked facts and evidence
        -> bounded recall context for new sessions
        -> scheduled deterministic consolidation
        -> entity profiles with facts, goals, decisions, and open items
        -> reversible safe maintenance and uncertain-review findings
        -> evidence-linked proactive commitments and pending replies
        -> relevance, priority, cooldown, snooze, completion, and explanations
        -> source-event correction lineage and server-owned automatic refresh
        -> lifecycle-aware current truth separated from preserved exact history
        -> deterministic remember, forget, correct, complete, dismiss, reopen, and cleanup commands
        -> reversible event, fact, relationship, and linked proactive lifecycle operations
        -> per-turn query-specific subject resolution and ranked recall
        -> clarification-first ambiguity handling and source-grounded explanations
        -> same-session reference continuity with cross-session durable context
```

OpenAI remains a replaceable intelligence provider. Core Jarvis intelligence is online-only. Cloud account, tenant, device authorization, and sync revisions are authoritative across devices; sensitive provider credentials and device-specific execution state remain device-resident and outside Cloud Sync.

## Implemented through 0.1.9

- Secure Realtime WebRTC voice transport with Cedar as the default voice.
- Fast model-based wake flow, complete opening-request preservation, interruption, and silent model-confirmed sleep.
- Free local simulation, response modes, usage ledger, and budget safeguards.
- Electron window/tray lifecycle, process supervision, login startup, suspend/resume recovery, screen-safe bounds, and single-instance control.
- Product interface with stabilized orb states, responsive workspaces, smart transcript following, and internally scrolling conversation history.
- Desktop Alpha distribution foundation:
  - Squirrel.Windows Setup executable
  - Start Menu and desktop shortcuts
  - Bundled official 64-bit Python 3.12.10 embeddable runtime
  - Official archive SHA-256 verification and corrupt-cache recovery
  - No system Python, `.venv`, Node.js, npm, or repository required after installation
  - First-run setup for key and primary voice preferences
  - OS-encrypted API key that is never returned to the renderer
  - Per-user data and logs outside read-only installation resources
  - Rotating core-process log and secret-redacted diagnostic export
  - Runtime and path visibility in System
  - Read-only GitHub release check
  - Local Squirrel install/update/uninstall event handling
  - Bounded Electron packaging scope that excludes development trees
  - One-file runtime bundle with content fingerprint, SHA-256 manifest, cache reuse, and visible creation progress
  - Atomic first-launch extraction into a versioned per-user runtime directory
  - Preflight source-size/runtime-payload verification and final `app.asar` size guard
  - Method-level Windows Packager timestamps and persistent `build/alpha-packaging-diagnostic.log`
  - Supervised Python extraction of the cached Electron Windows archive
  - Artifact-level success guards that reject empty package or installer output
  - Temporary executable-resource-editor bypass while Windows packaging is certified
- Self Awareness foundation:
  - Core-owned live registry for Jarvis identity, version, purpose, internal architecture, runtime configuration, feature availability, requirements, and limitations
  - Honest separation between language help and implemented external execution
  - Inspectable local `/api/capabilities` snapshot without API-key exposure
  - Realtime session grounding for capability, limitation, version, connection, and architecture questions
  - Long-form intent routing into a response-mode-sized spoken summary and separate silent detailed written answer
  - Purpose-scoped response metadata, transcript presentation, memory provenance, interruption cleanup, and usage accounting
  - Local simulation coverage for both presentation channels
- Conversation continuity repair:
  - Reconciles late input-transcription events into the original user bubble
  - Delays transcript-unavailable placeholders and uses the neutral `Voice message` fallback
  - Suppresses the private transcription guidance artifact before UI, memory, or lifecycle processing
  - Deduplicates provider transcript events by item ID
  - Separates approximate conversational word targets from hard provider token ceilings
  - Provides Test, Short, Normal, High, and Full modes configurable through private `.env` values
  - Uses exact sentence/word policy values with an explicit long-form-request exception
  - Uses `0` as no fixed sentence/word cap or the model-supported maximum token ceiling
- Total Recall memory foundation:
  - Exact local events with actor, source, session, local timestamp, local date, timezone, confidence, privacy, and metadata
  - Shared sources for voice, wake voice, typed chat, Jarvis responses, vision, web, app activity, tools, files, email, calendar, system events, and imports
  - Autonomous category hierarchy and first-pass entity creation for businesses, projects, organizations, teams, meals, preferences, relationships, and named concepts
  - Entity aliases and fact-to-evidence provenance links
  - Provider-event idempotency and conservative exact-duplicate consolidation
  - Repeated fact support without erasing original events
  - Optional Realtime input transcription for exact ordinary voice turns
  - Bounded facts and recent events injected into new Realtime sessions
  - Memory workspace with statistics, manual capture, search, date/category filtering, timeline browsing, and safe consolidation
- Memory Explorer and voice-navigation acceptance repair:
  - Date-grouped exact-event timeline with provenance detail, corrections, privacy/status controls, soft deletion, and undo
  - Entity pages with aliases, relationships, evidence counts, related timelines, merge, split, and recovery
  - Deterministic natural-language search, daily summaries, and filtered JSON/Markdown exports
  - Local visual-intent parser for “show,” “open,” “pull up,” “bring up,” and equivalent memory display requests
  - Shared navigation across typed turns, ordinary voice transcripts, and preserved wake prompts
  - Exact entity-page resolution with timeline fallback for broad, speaker, or temporal requests
  - Deliberate distinction between visual requests and verbal questions such as “What do you know about…”
  - Realtime guidance that the desktop handles visual display while Jarvis provides a concise spoken overview
  - Single-owner local visual navigation with no competing Realtime display tool or follow-up response lifecycle
  - Synchronous Memory workspace activation with Focus clearing, explicit visibility state, and a bounded guard while results load
  - Conservative typo-tolerant entity resolution for speech variants such as `Orvix` → `ORVEX`
  - Content-level transcript and command idempotency for provider event variants
  - Cache-busted renderer assets and no-cache loopback headers so accepted UI repairs cannot remain stale
  - Five response profiles published through the local configuration API and labeled with effective sentence and word caps
  - Silent visual memory commands: show/open/display requests navigate locally without narration unless the user explicitly asks for a summary, explanation, or spoken walkthrough


- Proactive Memory:
  - Confirmed commitments, possible tasks, pending replies, goals, decisions, deadlines, and tentative patterns
  - Local priority and relevance scoring with configurable thresholds and cooldowns
  - Exact evidence explanations and explicit inference labels
  - Complete, reopen, snooze, and dismiss lifecycle with audit history
  - Subject-aware context injection without autonomous external actions
  - Background refresh plus Home and Memory inbox views

## Visual memory command contract

- Display-only phrases such as `show me everything about ORVEX`, `open my memories`, and `pull up what I said yesterday` are local interface actions.
- These commands must open Memory Explorer without spoken acknowledgement, text filler, or a retained Jarvis response bubble.
- Typed and wake-preserved display-only commands do not enter the Realtime response path.
- Live voice display commands cancel the provider-created response and clear queued audio as soon as partial or completed transcription establishes silent visual intent.
- Narration is allowed only when explicitly requested, such as `give me a short summary`, `tell me about it`, `explain it`, or `show me and tell me about ORVEX`.
- Verbal recall questions such as `What do you know about ORVEX?` remain normal conversational requests and do not force the interface to navigate.

## Stable lifecycle rules

- Saying “Jarvis” wakes through short model transcription after local VAD.
- While awake, the Realtime model owns speech understanding.
- Model-confirmed sleep intent closes silently to avoid playback races and extra output cost.
- Clicking X fully quits Electron and the Python process tree.
- Hide Jarvis keeps wake monitoring active in the tray.
- Startup can run hidden through the Windows login item.
- Automatic recovery is bounded and cannot restart forever.

## Desktop Alpha security contracts

- Renderer security remains `contextIsolation: true`, `nodeIntegration: false`, and `sandbox: true`.
- The renderer may submit a replacement key but can never request the decrypted stored key.
- Electron `safeStorage` encryption and decryption occur only in the main process after app readiness.
- The decrypted key is passed only in the child-process environment of the loopback Python core.
- Diagnostics must be recursively redacted before writing to a user-selected file.
- External release URLs must remain HTTPS and GitHub-hosted.
- Packaged data and logs must remain outside `resources`, `app.asar`, and the install directory.

## Embedded runtime build contract

Python 3.12.10 is deliberately pinned because it is the final Python 3.12 release with official Windows binary artifacts. The archive must match the official SHA-256 before extraction. Build the runtime with 64-bit Python 3.12 so compiled wheels installed by pip match the bundled interpreter ABI. A matching validated `build\python` runtime is reused automatically unless `--force` is supplied.

## Electron packaging scope contract

The packaged Electron source must remain limited to `package.json` and the Electron main/preload/recovery assets. Python source, staged runtimes, tests, logs, private data, documentation, patch payloads, `.venv`, backups, and development dependencies must not enter `app.asar`. `build\python` and `build\desktop_runtime` are fingerprinted and archived into `build\runtime_bundle.zip`; Electron receives only that archive and its manifest through `extraResource`. The installed app verifies the bundle SHA-256, extracts through a version-specific staging directory, checks required files, and atomically promotes the runtime. Run `npm run alpha:scope` before Forge; final verification rejects an `app.asar` larger than 25 MiB, a damaged bundle, or loose packaged runtime directories. The diagnostic alpha replaces Electron Packager's ZIP extraction with a supervised Python extractor, uses standard temporary staging, records every hidden Windows finalization method, rejects false zero exits when expected artifacts are missing, and skips executable icon/version resource editing unless `JARVIS_ALPHA_ENABLE_RESEDIT=1` is explicitly set.

## Development and installed configuration

Development launches may continue using the ignored source-root `.env`. Installed builds store the API key in `jarvis-data/secure-settings.json` as OS-encrypted bytes. Nonsecret alpha preferences are stored alongside it and passed to the Python core as validated environment values.

Response length is a product configuration contract. `JARVIS_RESPONSE_MODE` selects Test, Short, Normal, High, or Full. Every profile has `JARVIS_RESPONSE_<MODE>_MAX_SENTENCES`, `JARVIS_RESPONSE_<MODE>_MAX_WORDS`, and `JARVIS_RESPONSE_<MODE>_MAX_OUTPUT_TOKENS`. Accepted defaults are Test 1/25, Short 3/50, Normal adaptive/100, High adaptive/200, and Full uncapped. Sentence and word values are hard defaults unless the user explicitly requests longer-form output. Provider token ceilings default to `0` (model maximum) so Cedar is not cut off mid-sentence; owners may set a separate safety ceiling. Legacy Medium and Target Words values migrate to High and Max Words. A complete legacy block that exactly matches the former generated defaults is interpreted as an old product preset and upgraded in memory to Test 25, Short 50, Normal 100, High 200, and model-maximum transport ceilings; non-default legacy values remain custom settings. Do not overwrite a user's private `.env`; add new defaults only to `.env.example` and let the loader provide backward compatibility. Release tests must explicitly isolate their env-file source so private response settings cannot contaminate validation. A profile change updates the active Realtime session immediately. For hybrid long-form turns, the profile caps the single Realtime spoken summary while a separately configured Responses API text model fills one stable card with the complete written answer. New text defaults belong in `.env.example`, never in the private `.env`.

## Exact commands

Apply the current update:

```powershell
py -3.12 apply_0_1_7_patch.py
```

Validate source:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

Start the development desktop:

```powershell
npm run desktop
```

Build the Windows installer:

```powershell
npm run alpha:scope
npm run alpha:make
# Extraction/finalization trace: build\alpha-packaging-diagnostic.log
npm run alpha:verify
```

Expected setup output:

```text
out\make\squirrel.windows\x64\Jarvis_Real_Time_Setup.exe
```

## Memory architecture contract

The exact event ledger is the source of truth. Derived categories, entities, aliases, facts, summaries, patterns, and future predictions may be reorganized or rebuilt, but must retain provenance to original evidence. Distinct episodic events must not be merged merely because their text is similar. Source/provider event IDs are idempotent. Every future producer—voice identity, vision, web, app activity, email, calendar, files, tools, sensors, and connected services—must use the shared memory event contract rather than creating an isolated history silo.

The current deterministic analyzer is a safe foundation, not the final intelligence layer. Model-assisted classification, contradiction handling, salience, causal links, background consolidation, and autonomous prospective memory should build on the existing schema while preserving exact source events.

## 0.1.3 autonomous consolidation contract

- The exact memory event ledger remains immutable evidence except for explicit user corrections/deletions.
- Scheduled consolidation runs locally and incurs no model/API usage.
- Safe automatic changes are deterministic and reversible.
- Punctuation/spacing-equivalent entities may merge automatically; fuzzy aliases remain review findings.
- Explicit correction language may supersede older single-value facts while preserving valid-time history.
- Ambiguous contradictions remain visible rather than being guessed.
- Entity profiles summarize key facts, open items, decisions, and goals with provenance-linked source events.
- Consolidation timing and safe auto-apply behavior remain configurable in the private `.env`.

## Deliberately not included yet

- Separate memory-database encryption at rest and speaker-authenticated retrieval enforcement.
- Active voice or face enrollment, matching, and diarization.
- Automatic vision, web-history, app-activity, email, calendar, file, or tool memory producers.
- Model-assisted contradiction resolution, causal graphs, deeper salience scoring, and routine learning.
- Spoken natural-language execution of every explorer correction and graph-maintenance action.
- Semantic vector embeddings and automated backup scheduling.
- Code signing and trusted-publisher reputation.
- Automatic download and installation of updates.
- Arbitrary drag/resize/pop-out panel system.
- Full multi-day installed-build soak certification.

## Next recommended milestone

### `0.3.5-repair3 — Isolated YouTube Fullscreen`

Live acceptance found that voice-driven YouTube fullscreen could intermittently show the normal watch page, recommendations, comments, or third-party overlays on top of the video. The Browser Bridge had been synthetically clicking YouTube's fullscreen button even though the voice/runtime message was not a trusted browser user gesture. Chromium could reject the native Fullscreen API while YouTube still changed its own fullscreen/layout CSS, leaving a half-entered state. The fallback also treated an internal immersive flag as success without proving the rendered player covered the viewport.

Repair3 removes synthetic fullscreen-button clicks. Native element fullscreen is attempted only with active trusted user activation; otherwise Jarvis moves the live player container into a reversible top-level immersive host, verifies host/player viewport geometry, requests browser-window fullscreen through the existing extension service worker, and restores the exact player DOM/style position on exit. Successful visible fullscreen/minimize actions remain silent. See ISSUE-314.

### `0.3.5-repair2 — Silent Browser Media Continuity`
- Natural fullscreen/minimize YouTube phrasing remains in deterministic structural Browser Control.
- Verified visible media actions are silent on success even when Luna Browser planning handled the wording; failures still speak.
- Google OAuth reconnect remains under Controls → Connected apps and is independent of Billing authority.

### `0.3.5 — Billing & Entitlements`

Build billing and configurable entitlement enforcement on top of the verified online account and Cloud Sync foundation. Plans, quotas, device limits, storage/usage allowances, integrations, and premium capabilities must remain configuration-driven rather than hardcoded into feature logic.

## 0.1.2 repair6 visual narration contract

Display-only memory commands are silent local UI actions. If the same request explicitly asks for narration, the renderer must retain the local navigation promise, cancel any premature provider response, wait for the visual entity or timeline result, and create a fresh response with exact displayed evidence. The response must treat Memory Explorer as already open and visible, must never deny that Jarvis can display memory, and must not claim the result is still loading. Partial transcript suppression must be reversible when the completed transcript adds a summary or explanation request.

## 0.1.2 repair7 single-summary contract

Narrated visual-memory commands must produce one coherent response only. A short-summary directive is one paragraph, at most two sentences and 50 spoken words. Every displayed fact may be stated once; Jarvis must not give an overview and then repeat it as a recap, and must not use filler labels such as “Quick note,” “Short summary,” or “In summary.” Standard and detailed narration may be longer but must still avoid a duplicate closing summary unless the user explicitly requests multiple formats.


## 0.1.2 repair8 one-pass short-summary contract

When a visual-memory command explicitly asks for a short summary, Jarvis must speak exactly one sentence of at most 40 words. Every clause must introduce a distinct fact from the displayed evidence. The response must end immediately after the useful sentence and must not restate the entity type, category, event, date, or absence of additional information as a closing recap. Standard and detailed narration remain flexible but still cannot append a duplicate summary.

## 0.1.3 repair1 source-aware consolidation contract

- Entity profiles must derive facts, goals, decisions, commitments, and event counts from authoritative source events, not Jarvis responses.
- `assistant/response` events remain preserved and searchable but appear under a separate Jarvis conversation-mentions section.
- Consolidation must re-link existing ledger events to established entities using exact aliases first and conservative unambiguous fuzzy references second.
- Explicit declarations of a new business, project, organization, brand, or team must create a distinct exact entity even if a similar alias already exists.
- Goals, decisions, and open tasks are structured as provenance-backed `has_goal`, `decided_to`, and `open_task` facts.
- Existing databases request a one-time source-aware rebuild without requiring the user to repeat stored information.

## 0.1.4 repair1 corrective follow-through contract

- Exact source events remain immutable even when a user corrects a name, date, subject, or task wording.
- Corrections update derived proactive titles, fingerprints, recall text, and evidence links.
- The corrected item must include both the original event and the corrective event in its provenance.
- Repeated refreshes must not recreate the superseded spelling or produce duplicate open items.
- Contextual short corrections may apply only when the preceding commitment reference is recent and unambiguous.
- Declarative needs, plans, goals, deadlines, and follow-ups are memory inputs rather than execution commands.
- Capability disclaimers are reserved for direct requests to perform an unavailable external action immediately.
- The base Realtime prompt must acknowledge durable local memory while remaining honest that external computer-control tools are not yet available.


## 0.1.4 repair2 contextual-correction contract

- Realtime speech may transcribe “I meant” as “I met” and may split a single spoken name into multiple words.
- The local correction engine may accept that homophone only when explicit correction context, recency, and an unambiguous proactive target agree.
- Contextual corrections update derived proactive titles, fingerprints, recall text, and future refresh results without rewriting the exact source ledger.
- The original misheard event and the later corrective event must both remain visible as evidence.
- Existing stored correction events must be reprocessable after an update so the user is not forced to repeat a correction.
- Repeated proactive refreshes must remain idempotent and must not restore the superseded spelling or create a second open item.

## 0.1.4 repair3 correction and interruption contract

- Correction cue language and corrected values are separate. Derived proactive titles must never retain leading words such as `meant`, `met`, `actually`, or `sorry`.
- Existing malformed derived items must self-repair from preserved correction evidence during the next proactive refresh.
- Realtime interruption state is scoped to the provider `response_id` and output `item_id`; a global cancelled flag must not affect a later response.
- Late audio, transcript, and completion events from an interrupted response are ignored for chat, memory, and active-state transitions.
- A stale cancelled `response.done` cannot clear, mute, or detach the newer response.
- Interrupted bubbles remain visibly marked, but text generated after cancellation is not appended or remembered as delivered speech.
- The next user turn after an interruption must be able to produce normal audible and visible output without a manual reconnect.


## 0.1.4 repair4 authoritative-correction and automatic-refresh contract

- A correction evolves one derived proactive item identified by its source-event lineage; it is not a global text replacement.
- The original statement and corrective statement remain immutable, separately timestamped evidence.
- The active title, fingerprint, due date, priority, lifecycle state, and future recall use the latest authoritative wording.
- Malformed and clean variants with the same canonical commitment merge into one current item; stale variants remain superseded tombstones and cannot be regenerated as open items.
- Contextual corrections target only a recent unambiguous commitment. Ambiguous corrections must remain unresolved rather than modifying the wrong item.
- User-authored memory events signal a server-owned proactive refresh after a configurable debounce.
- Periodic proactive refresh remains a fallback, and the desktop reloads results without owning analysis.
- The manual Refresh locally control is diagnostic/recovery-only and is not required for normal operation.


## 0.1.4 repair5 interruption-audio contract

- Interrupting a response may mute and clear only the cancelled response’s queued WebRTC playback.
- The local mute is owned by the interrupted provider `response_id`, not by the overall session.
- A distinct new `response.created` event must restore and resume the existing remote audio element before its output begins.
- `output_audio_buffer.started` is a second restoration boundary for valid provider event-order variations.
- Events belonging to an interrupted response may never restore playback or append unsaid transcript text.
- The next response after barge-in must be both visible and audible without reconnecting, sleeping, or manually toggling audio.

## 0.1.5 identity foundations contract

- Every remembered person has a durable identity profile distinct from generic entity facts.
- Tanner is the protected local owner with owner scope, permanent retention, trust, and manage permissions.
- Names, preferred names, aliases, roles, relationships, privacy scope, retention, and permissions remain independently editable and auditable.
- Speaker corrections change current attribution while preserving the previous actor, reason, exact correction evidence, confidence, and timestamp.
- Similar names are never silently merged as people; explicit user equivalence or a reviewed merge is required.
- Recognition is not authorization. Future voice or face matching cannot reveal memory beyond the person’s configured boundary.
- General memory APIs expose voice/face enrollment status but never raw recordings, embeddings, templates, or protected profile references.
- Identity edits, aliases, permissions, relationships, attribution, merge, and split actions remain reversible wherever their data contract supports undo.


## 0.1.6 speaker-recognition contract

- Voice enrollment is explicit, consented, and attached to an existing arbitrary person profile.
- Uploaded and live audio is converted locally to a bounded mono 16 kHz sample; raw enrollment audio is discarded after protected feature extraction.
- Windows protects local signature files with the current OS account through DPAPI; protected references never appear in general memory APIs.
- Every profile and recognition query includes a tenant ID. The desktop currently supplies one local tenant; hosted SaaS must derive tenant identity from authenticated server context rather than trusting a client-provided value.
- Recognition has recognized, likely, unknown, disabled, and insufficient-audio states. It never forces a match below the threshold or when the runner-up is too close.
- Recognition is an attribution aid, not identity authentication, and cannot grant memory access or bypass privacy permissions.
- Multiple enrollment samples, quality scores, thresholds, sample deletion, disablement, reassignment through person merging, and full voice-profile deletion remain manageable.
- The live speaker result is stored as provenance metadata with confidence and model information while ordinary raw conversation audio is not retained by the memory system.
- All logic is generalized for arbitrary SaaS tenants, people, aliases, and relationships; current names may appear only as test fixtures.

## 0.1.6 repair3 human-addressing contract

- Canonical identity, aliases, preferred display names, and conversational forms of address are distinct data concepts.
- Each person may have several active forms of address. The first active value is the primary choice, while all active values remain available for natural variation.
- Forms of address are durable, locally stored, person-scoped, independently revocable, visible in identity details, and included in reversible operation history.
- Natural commands support add, remove, replace, and clear behavior. A user can stop one title without deleting the rest, or return to the canonical name without losing identity history.
- Typed preference commands apply to the protected local user. Voice preference commands require a confident recognized-person result; likely and unknown candidates may not modify another profile.
- Confident identity answers are direct, such as `You’re Tanner.` Likely matches use human uncertainty, such as `You sound like Tanner, but I’m not completely sure.`
- Jarvis must not narrate recognizer matches, confidence scores, attribution internals, privacy mechanics, or system guesses unless the user explicitly asks for technical detail.
- Simple acknowledgements, preference changes, and corrections should use the shortest complete natural response, normally two to six words.
- Active forms of address may be used occasionally when natural, but never forced into every reply and never treated as proof of identity or authorization.
- Each completed turn has one response owner. Speaker-aware context and exact local replies replace older generic response creation rather than running beside it.

## 0.1.6 repair4 live-profile and lifecycle contract

- Forms of address remain person-scoped conversational preferences, not identity aliases. Generic person entity details must display both concepts separately.
- Deterministic add, replace, remove, and clear commands must accept ordinary punctuation around introductory phrases such as `from now on`.
- A preference write is not complete until storage, renderer recognition context, server-owned Realtime context, and the visible person detail agree.
- When no form of address is active, the next model turn must not reuse a revoked title from conversation history or fall back to `sir`.
- Test, Short, Normal, High, and Full are live response policies. The selector remains available while awake and the next response must use the newly selected policy without reconnecting.
- Response-specific speaker guidance extends the complete server-owned profile through `session.update`; it must never replace the profile through per-response instructions.
- Exact source events remain immutable provenance, while entity `Open items` represent only currently active lifecycle state.
- Completing or dismissing proactive work must immediately remove it from entity open items; reopening must restore it. Later consolidation may not silently reactivate terminal facts.
- Startup migration/repair behavior must be best-effort and must never prevent Jarvis from opening.


## 0.1.6 repair5 actionable-identity and confirmed-wake contract

- A displayed memory permission level is an actionable control. Selecting it opens the in-app editor for that exact person, scope, and current access level.
- Permission edits continue through the trusted local memory API and refresh the person detail after persistence; the renderer does not maintain a separate permission truth.
- Sleeping voice activity may start hidden speculative network preparation to reduce confirmed wake latency.
- Hidden preparation is not a lifecycle transition. The orb, desktop presence, visible status, and user controls remain Sleeping until the configured Jarvis keyword is confirmed.
- A speculative connection that becomes ready before transcription confirmation remains inactive from the user's perspective and may not publish visible Listening or Waking state.
- Keyword confirmation promotes the current speculative connection exactly once, announces Waking, and then activates the connected session when ready.
- Rejected candidates and unconfirmed preconnect failures remain or return to Sleeping without flashing Waking, Listening, degraded, or error presentation.
- Manual wake, confirmed wake, reconnection, and failures after confirmation retain honest visible lifecycle states.


## 0.1.7 self-awareness and unified-answer contract

- Jarvis identity, version, architecture, implemented features, disabled features, missing integrations, and execution boundaries come from a core-owned registry rather than model assumptions.
- The registry is recomputed whenever a capability snapshot or Realtime session profile is requested. Existing feature states therefore reflect current settings and runtime state rather than old conversation claims.
- New feature modules must publish a trusted capability provider. Provider modules placed under `jarvis.capabilities.providers` are discovered automatically; Jarvis never guesses capabilities from arbitrary source code.
- The registry must remain generalized and configuration-aware; no user, business, or test-fixture name may be hardcoded as product logic.
- Language generation is not an external action. Jarvis may help draft, explain, compare, plan, and reason, but may only claim an external action succeeded after a real tool returns auditable success.
- Simple turns remain single responses. Substantial questions may use one capped audio summary followed by one silent text-only generation, but the interface presents both stages as one Jarvis response card.
- Test, Short, Normal, and High constrain hybrid speech. Full is a Realtime-only complete response and must not start the companion text provider.
- On hybrid turns, the exact spoken transcript is prepended to the complete written answer after both branches settle. The text continuation begins directly with deeper detail rather than duplicating the opening.
- Capped speech ends with a natural within-limit handoff to the written detail. Full responses do not mention a continuation.
- Long Jarvis messages expose a safe app-local fullscreen reader; generated content remains text-only and is never inserted as executable HTML.
- The final answer must be first-person when Jarvis describes himself and must not refer to internal routing, another model, or token caps.
- Interrupt, sleep, disconnect, provider failure, and new-turn cleanup must prevent stale detailed output from leaking into later turns.
- The next milestone returns to memory architecture after this capability and presentation foundation is accepted.
- `0.1.7-repair4 — Focused Previews`: long hybrid answers align to their beginning and stay clipped to the conversation viewport; the exact complete text remains available through the fullscreen reader.

## 0.1.7 repair5 long-answer preview contract

- Hybrid written answers remain complete in memory and in the fullscreen reader; the conversation card is only a visual preview.
- The preview should show the beginning of the answer, occupy no more than 44% of the transcript viewport, and never exceed 330 pixels.
- When hidden content remains, the visible words must progressively fade and an explicit Fullscreen continuation cue must be shown.
- Overflow detection must inspect the clipped content element so layout changes cannot silently remove the cue.
- Short answers and Full-mode Realtime responses must not be clamped by the hybrid preview behavior.


### `0.1.9 — Context Intelligence`

## 0.1.9 context-intelligence contract

- Resolve each ordinary typed, wake-voice, and voice turn against durable memory before creating the paid Realtime response.
- Prefer explicitly named entities, then current-session subjects, then unique durable entity types.
- Resolve relationship phrases such as “my fiancée” from current relationship facts rather than textual guesswork.
- Rank current facts and open proactive items by subject match, semantic overlap, recency, confidence, and lifecycle state.
- Do not surface terminal lifecycle states as current truth. Include them only for explicit history or change-lineage questions.
- When two entities are similarly plausible, ask one short clarification question and do not guess.
- For source questions, state the remembered speaker, time, source, and direct-versus-inferred status naturally.
- Use the same resolved context package for the spoken Realtime summary and the low-cost detailed written answer.
- Keep the resolver deterministic, local, read-only, bounded, tenant-aware, and conservative about private memory.

## 0.1.8 memory-intelligence contract

- Exact source events and present understanding are separate layers. Historical evidence remains attributable and timestamped, while only active evidence may contribute to current facts, model context, entity summaries, relationships, goals, decisions, and open items.
- Explicit natural memory controls are deterministic local actions, not promises made by the general response model. A command is acknowledged only after the trusted local memory API reports success.
- Supported control families include remember, forget, correct, mark incorrect, complete, dismiss, reopen, and clear completed items. Ordinary questions such as `Do you remember…?` remain conversation, not mutations.
- Command events remain exact history but are terminal records rather than current world knowledge. They may not pollute later recall.
- Explicit remember creates a durable assertion even when the deterministic analyzer does not yet recognize a narrower predicate. The exact event remains its evidence.
- A correction creates a new corrected assertion and moves the prior event or fact out of current truth. It must preserve old content, actor, source, timestamp, correction command, and lineage.
- Forgetting removes information from current recall but preserves an auditable historical source. Permanent deletion is a separate explicit operation.
- Event, fact, relationship, proactive-item, and entity-profile lifecycle states must remain synchronized. Completed or dismissed work cannot remain in `Open items`; reopening must restore it without duplication.
- Lifecycle changes are reversible. Operation snapshots must include dependent facts and linked proactive state so Undo restores the complete user-visible graph.
- Reopen matching may inspect only explicitly terminal states. Destructive and corrective commands use conservative actor, session, recency, and similarity constraints and may not guess across unrelated records or tenants.
- Memory Explorer exposes lifecycle filters, event actions, fact actions, exact history, and reversible controls. Generated or stored content remains safely rendered as text.
- Jarvis’s live capability registry must describe the running memory lifecycle truth and its limits. New memory behavior must update that registry rather than relying on stale prompt prose.
- All memory, identity, correction, relationship, merge, privacy, and attribution rules remain generalized multi-user SaaS behavior. Tanner, ORVEX, and other current names are test fixtures only.

## 0.1.8 repair1 memory-hygiene contract

- Exact assistant responses are durable conversation history but are not authoritative sources for creating new semantic entities, facts, preferences, relationships, or tasks.
- An assistant event may link to an entity that is already independently established; it may not establish that entity by wording alone.
- Startup graph hygiene may remove only generic assistant-only derived nodes with no user evidence, facts, relationships, proactive items, or actor history. Exact source events must remain intact.
- User-established knowledge always takes precedence over cleanup heuristics, and later user evidence may recreate a previously removed generic concept.
- Natural memory controls must tolerate bounded conversational fillers and self-correction preambles while preserving question-versus-command safety.
- Renderer and core command normalization must stay behaviorally aligned so a locally detected command cannot fall through to a contradictory general-model response.
- Memory Explorer filters must remain contained and actionable across supported window sizes and workspace layouts.

## 0.1.8 repair2 grounded-memory and duplicate-identity contract

- An informational user question is not authority to promote every uppercase token into a durable entity. Named-token extraction must consider speech act, explicit naming context, and generic acronym exclusions.
- Automatic weak-entity cleanup may remove only generic concept nodes supported by mention-only links and having no facts, person relationships, proactive items, aliases, or actor history. Exact source events remain immutable.
- Durable local memory is a running application capability. Realtime responses must never claim that no database or memory tool exists or that memory is session-only when the trusted local service is enabled.
- Ordinary voice and typed turns must await the current memory-write result before response creation so the model receives truthful turn-specific grounding.
- A failed memory write must remain visible as a failure; response grounding may not fabricate persistence.
- Duplicate-person recovery must be directly discoverable from person cards and must use the existing trusted merge preview, confirmation, audit, and undo path.
- Same-tenant local-owner placeholder profiles may be merged into the canonical local-user person. Cross-tenant or unrelated protected-user merges remain prohibited.
- Merge and cleanup behavior remains generalized multi-user SaaS logic; current names are fixtures, never product rules.

## 0.1.9 repair3 typed-context and reader-gating contract

- A generic noun phrase such as `the business`, `that project`, or `my fiancée` must constrain candidate resolution to compatible entity types before recency, activity, and confidence scores are compared.
- A person profile may not compete for a business reference merely because it is recent or has many events. Explicitly named subjects and resolved relationship targets remain valid exceptions.
- Ambiguity is valid only between similarly plausible compatible subjects. An ambiguous turn asks one short clarification and must not start the detailed companion text model.
- The fullscreen reader is an overflow and long-content affordance, not a marker for every hybrid message. It appears only when the answer exceeds the configured character threshold or the compact preview actually hides content.
- Short responses and clarification questions must remain ordinary conversation cards without reader controls.

## 0.1.9 repair4 natural-recall and reader-accuracy contract

- Memory-grounded answers must sound like a personal assistant, not a provenance report. State the useful remembered fact or decision first.
- Provenance remains authoritative internally, but confidence, evidence labels, verification language, and capability disclaimers are not volunteered unless the user asks about reliability or execution.
- A source question should normally be answered in one natural sentence naming who told Jarvis, when, and the medium. Avoid phrases such as `that is the evidence`, `not a guess`, or `I cannot verify` by default.
- Decision intent is distinct from goals, tasks, and plans. A decision query returns only decision facts unless broader context is explicitly requested.
- An underspecified correction-history reference asks one short clarification and exposes no competing fact or event context until the subject is identified.
- Ordinary recall, source, history, open-work, relationship, and decision turns stay on the single Realtime path unless the user explicitly requests a detailed explanation.
- Detailed written answers are plain text because the current reader does not render Markdown syntax.
- Fullscreen eligibility is based on actual hidden content or substantial rendered height, never character count alone.


## 0.1.9 repair5 fact-first recall contract

- Ordinary recall answers state the remembered information only.
- Do not volunteer source medium, timestamp, actor, confidence, evidence labels, or verification language unless the user asks how, where, or when Jarvis learned it, asks for history, or asks about reliability.
- Preserve complete provenance internally and expose it through explicit source questions and Memory Explorer.
- Query-specific context for ordinary recall should omit provenance metadata when structured current facts are available.
- If only an exact remembered statement is available, provide its content without audit metadata.

## 0.1.9 repair6 answer-only recall contract

- A simple high-confidence memory question that can be fully answered by one current relationship fact should use a deterministic exact reply rather than open-ended model generation.
- The answer contains only the requested fact and stops. It does not say `I remember`, `main detail`, `on record`, offer to track more, suggest next steps, or explain storage.
- An explicit source question uses one natural source/date sentence when direct evidence is available, then stops. It does not explain why Jarvis retained the memory or offer additional context.
- Deterministic reply generation remains intentionally narrow. Multi-fact, ambiguous, historical, decision, open-work, and detailed requests continue through the grounded model path.
- Voice and typed turns share the same exact-reply contract so behavior and API cost remain consistent.

## 0.1.9 repair7 guided-conversational-recall contract

- Query-specific memory constrains and informs the Realtime model; it does not replace the user's complete utterance with an exact answer.
- The `direct_reply` interception introduced in repair6 is superseded. Ordinary typed and voice memory questions continue through the standard Realtime response path.
- Private answer guidance may suggest concise wording, but it is never an exact-response override and may not cause Jarvis to ignore another part of the user's request.
- A compound request that asks for both remembered information and provenance must answer every requested part in order: fact first, source/date second.
- A source-only follow-up remains one concise provenance sentence. Ordinary recall remains fact-first and does not volunteer provenance or follow-up offers.
- Source guidance prefers provenance attached to the current fact. A newer recall question or conversational mention may not replace the original evidence source.
- Ordinary recall, relationship, decision, history, source, and open-work questions remain single-Realtime responses unless the user explicitly asks for a detailed answer.

### `0.2.0-repair1 — Google OAuth Exchange`

- Desktop Google OAuth uses the supported origin-only loopback redirect (`http://127.0.0.1:<port>`).
- The app root route handles the authorization callback while the prior callback path remains backward compatible.
- Google token exchange errors expose only safe OAuth error identifiers and descriptions.

### `0.2.0 — Connected Actions`

## 0.2.0 connected-actions contract

- Realtime is the live voice transport only. It listens, supports interruption, and speaks concise text already prepared for it.
- `gpt-5.6-luna` is the connected-action planner and response writer. It interprets Gmail and Calendar requests, selects operations, extracts arguments, decides whether clarification or confirmation is required, and grounds the final response in tool results.
- Google accounts connect through installed-app OAuth with PKCE and a loopback callback. Users never enter personal Gmail or Calendar API keys.
- Windows builds protect OAuth tokens with current-user DPAPI. Runtime data, tokens, audit databases, and `.env` remain excluded from source control.
- Gmail reads and draft creation can execute immediately. Sending a draft requires a separate explicit user instruction after the draft is shown.
- Calendar reads can execute immediately. Calendar create, update, and delete operations always require a separate confirmation.
- Every action is recorded locally with actor, provider, operation, arguments, status, result/error, and timestamps.
- Jarvis never claims success until Google confirms the operation.
- The capability registry reports Gmail and Calendar as unavailable, disconnected, or available from live runtime state.

## 0.2.0 repair2 stable-action-delivery contract

- Luna and the connected provider produce the authoritative action result before Realtime speaks.
- A prepared connected-action answer is rendered into one stable conversation card before speech delivery begins. It may not depend on provider metadata arriving in a particular event order.
- Realtime exact-speech delivery uses response-level instructions with tool selection disabled. It must not independently call sleep or another tool while reading a Luna-prepared result.
- Client-side response-purpose binding must survive delayed or missing response metadata and must be cleared on connection cleanup.
- Empty or untranscribed VAD artifacts are removed after the reconciliation grace period. They must not become permanent `Voice message` transcript entries.
- Connected-action planning, provider execution, detailed writing, and active speech count as session activity and must prevent idle sleep while work is unfinished.
- Read-action speech contains the useful result itself. Generic acknowledgements such as `Sure` or `Okay` are not valid standalone connected-action responses.
- The written result remains visible after interruption, Test-mode auto-sleep, or later session shutdown.

## 0.2.0 repair3 reliable-action-routing contract

- Connected-action pre-routing must recognize natural singular and plural Gmail/Calendar wording (`email/emails`, `message/messages`, `event/events`, `meeting/meetings`, and equivalent supported terms).
- A trusted local route hint only selects the connected service boundary; Luna remains responsible for interpreting the complete request, choosing the operation, extracting arguments, and applying confirmation rules.
- Once a user turn is positively routed as Gmail or Calendar intent, it may not silently fall through to ordinary Realtime conversation. Routing/provider/model failures remain inside the connected-action path and produce a truthful connected-action failure response.
- If the provider action has already completed, a later Luna response-writer failure must not discard the provider result. Use the bounded deterministic emergency formatter to preserve the useful result and then let Realtime speak that prepared text.
- Explicit disconnected Google turns should be rejected before planner spend when local connection state already proves the account is unavailable.


### `0.2.1 — Action Intelligence`

## 0.2.1 Action Intelligence contract

- Luna remains the connected-action brain. It receives the complete user request, provider evidence, memory/contact context, and pending-action state; it selects operations, reasons across multi-step workflows, and writes the prepared result.
- Realtime remains the live voice layer only. It may transcribe/listen, support interruption, and speak Luna-prepared concise text, but it may not independently select or execute Gmail, Contacts, or Calendar operations.
- Google Contacts is a provider-backed identity resolver, not a replacement for Jarvis memory identity. Named recipients resolve Contacts-first, then trusted local recipient identity history, then recent/broader Gmail correspondence when Contacts has no usable match. Ambiguous matches require clarification.
- Gmail fallback may use sender/recipient header metadata to associate a person name with an address; it must exclude the connected account itself and must not guess when equally strong same-name candidates remain. Successful unambiguous mappings are cached locally for reuse.
- Contacts access uses a separate live capability state. Existing Google connections that lack the new scope remain truthful and may request a one-time incremental reconnect.
- Gmail thread reads normalize message metadata and bodies for Luna. Reply drafts preserve the Gmail thread, subject/reply headers, and intended recipient.
- Draft revision updates an existing draft when the user changes the pending/latest draft instead of creating duplicate drafts.
- Every successfully created, replied, or revised Gmail draft keeps a pending-send reference to the exact provider `draft_id` and a user-visible snapshot of the exact From/To/Cc/Bcc/Subject/body. The draft operation can be complete while the separate send remains pending confirmation.
- Natural send confirmations such as `Send it`, `Yes, send it, please`, and `Yes, please` use that exact pending draft without asking the user for internal provider IDs. A planner-generated send with no ID may resolve only the latest valid Jarvis-created draft in the current session.
- Draft and sent states must be visually distinct in the written conversation using deterministic email previews; provider completion remains the source of truth for `Sent`.
- Confirmation and cancellation grammar must be disjoint. `Cancel it`, `No thanks`, and equivalent supported negative phrases may never execute a pending external write.
- Sending may not send the same completed draft twice.
- Combined Google reads may query Gmail and Calendar in one Luna workflow. Email-to-calendar workflows extract a proposed event from thread evidence, then enter the normal confirmation-protected Calendar create path.
- Calendar free/busy is a read-only scheduling primitive and does not itself create or modify events.
- Confirmation-required actions are visible in the desktop Pending Actions UI with Review, Edit in chat, Confirm, and Cancel controls.
- Editing the same pending operation updates that pending record; it must not stack duplicate pending writes.
- Provider completion remains the source of truth for external success. Audit records remain local and preserve pending, completed, cancelled, and failed states.

## 0.2.1 repair2 draft-continuity contract

- A successful Gmail create/reply/update draft result must establish an explicit pending send confirmation bound to that exact provider `draft_id` before Jarvis asks whether to send it.
- Natural confirmation language such as `Yes`, `Yes, please`, `Send it`, and `Yes, send it, please` must execute the waiting send directly; it must not ask the user for provider IDs or require Luna to rediscover the draft.
- A waiting send stores the reviewed recipient/subject/body preview alongside the draft ID so confirmation semantics are tied to the exact content shown to the user.
- Draft creation remains non-executing. Gmail send remains an external write and still requires a separate explicit confirmation.
- Cancelling the pending send leaves the provider draft saved and must never send it later unless a new explicit send request is established.
- The desktop conversation presents Gmail drafts as structured email previews with saved/not-sent state, recipient fields, subject, and exact body. Provider-confirmed sends may reuse the same preview with sent state.
- Realtime remains speech-only for Connected Actions; it speaks the prepared result and does not reconstruct or choose draft IDs.

## 0.2.1 repair3 email-review contract

- Pending external-write confirmation must recognize explicit natural compound approvals such as `Yes, please go ahead and send it`, `Yes, go ahead and send it`, `Please go ahead and send it`, and `Go ahead and send it` as confirmation of the existing pending action.
- When such a phrase confirms a pending Gmail send, the service executes the exact already-reviewed draft directly before Luna planning. It must not ask for a second confirmation or rediscover the draft.
- Confirmation expansion must not weaken cancel safety; cancellation and negative language remain disjoint from approval.
- A Gmail email preview opened in Fullscreen must preserve the same structured email presentation used in the conversation, including state, From, To, Cc/Bcc, Subject, and exact body. It must not degrade into a plain-text field dump.
- Non-email Fullscreen behavior remains on the generic reader path.

### 0.2.1-repair4 — Draft Editing contract

- A newly created Gmail draft must never be silently accepted with a blank body when the user's request contains enough intent to compose one. Luna owns grounded email composition; Realtime remains speech-only.
- An unsent reviewed Gmail draft is a first-class editable object. The compact and Fullscreen email cards must expose manual editing for To, Cc, Bcc, Subject, and Message while From remains read-only.
- Manual Save changes must persist to the exact provider `draft_id` tied to the pending `gmail_send_draft` action. Saving an edit must not send email or create an unrelated replacement draft.
- Natural voice/typed draft edits must route to Connected Actions/Luna while a Gmail send is pending. The exact pending draft is the source of truth; unchanged fields are preserved and body rewrites must return/write the complete revised body.
- Natural negative send language such as `No, don't send` must be resolved locally as cancellation before planning and must leave the Gmail draft saved.
- Every actual send still requires a separate explicit confirmation after the final reviewed/edited draft is visible.

### 0.2.1-repair5 — Draft Stability contract

- Manual compact editing must temporarily escape the generic long-answer clamp. The email editor owns its own bounded scrolling region and may not hide its Cancel/Save controls behind the answer-preview fade.
- Fullscreen manual editing must remain viewport-bounded with the editable fields scrolling independently from a stable action footer. Save and Cancel must remain reachable for long messages.
- Saving from either compact or Fullscreen must update the same exact provider draft and refresh both representations; it must not send.
- While a Connected Action is pending, matching confirmation, cancellation, or draft-edit language must take precedence over generic memory-control parsing. `Change the subject to Today` must therefore reach Connected Actions/Luna rather than memory correction.
- When there is no matching pending Connected Action, ordinary memory correction behavior remains unchanged.
- Send confirmation requirements remain unchanged after manual or spoken edits.
### 0.2.1-repair6 — Natural Confirmation contract

- Pending Connected Actions may ignore only bounded benign conversational prefaces (for example `Perfect`, `Thanks`, `Looks good`, plus an optional `Jarvis` vocative) before evaluating the final decision clause.
- The final clause must still independently satisfy the strict confirmation or cancellation grammar. Praise/thanks alone never confirm an external write.
- Frontend continuation routing and backend execution must agree on the normalized decision so a natural approval does not fall back into Luna planning and trigger a second confirmation.
- `Perfect, thanks, Jarvis. Go ahead and send it.` must confirm the existing exact pending Gmail draft on the first try.
- `Perfect, thanks, Jarvis. Don't send it.` must cancel and leave the draft saved.
- Negative or uncertain final language must never be converted into approval by the preamble normalization.

### `0.2.2 — Action Speed`

## 0.2.2 Action Speed contract

- Luna remains the connected-action reasoning brain, but it is not a mandatory formatter after every provider call. When the result is deterministic and already grounded in provider/local action state, Jarvis may generate a bounded local completion sentence instead of paying for and waiting on a second Luna response-writing request.
- Read summarization, thread understanding, natural email composition/rewrite, ambiguous interpretation, calendar extraction, and multi-step orchestration still use Luna. Realtime remains speech-only for connected actions.
- Provider success remains the source of truth. The local completion fast path may never claim an email was sent or Calendar state changed before Google confirms success.
- Pending confirmation prompts for external writes may be rendered locally from the exact stored proposed action; confirmation requirements themselves are unchanged.
- Gmail message-list hydration must use bounded concurrency rather than a serial metadata waterfall. The concurrency window stays limited and returned message order remains identical to the provider list order.
- A recipient that was unambiguously and safely resolved during the current running app session may be reused from a short in-memory cache for the same normalized name. The cache is not durable identity truth, expires quickly, and may never collapse an ambiguous match.
- Durable recipient evidence continues to use tenant-scoped ActionStore records; the session cache is only a latency optimization.
- Connected-action endpoints expose local end-to-end action latency, and the Connected Apps UI shows the latest measured action time for live regression testing.
- Speed changes must not weaken 0.2.1 draft editing, exact-draft continuity, duplicate-send prevention, cancellation safety, or natural confirmation behavior.



### `0.2.2-repair1 — Gmail Polish`

## 0.2.2 repair1 contract

- Explicit send/cancel decisions must survive harmless conversational lead-ins and a misheard assistant vocative before the final command.
- A trailing explicit send phrase may only confirm when no earlier negation/uncertainty makes the decision unsafe; praise or thanks alone never confirms.
- `gmail_search` and `gmail_read_thread` results render as structured Gmail-style read cards using the same From/To/Subject/Message visual language as draft/sent previews.
- Multiple search results render as multiple cards; fullscreen preserves the card structure.
- When the user explicitly asks to show/open/read/view one specific email, a metadata-only `gmail_search` plan is locally upgraded to `gmail_read_thread` so the full body is retrieved when available.
- Multi-message searches remain on the 0.2.2 concurrent metadata path to preserve speed.


### `0.2.3 — Calendar Intelligence`

## 0.2.3 Calendar Intelligence contract

- Realtime remains the voice/speech interface. Luna remains the Connected Actions planner/interpreter. Calendar provider data remains the source of truth.
- Calendar reads may return structured event cards and may use deterministic grounded spoken summaries to avoid unnecessary model latency.
- `calendar_freebusy` is a read-only provider operation. It may calculate open slots but may never create or modify an event by itself.
- `calendar_schedule` interprets a scheduling window and duration, queries live provider free/busy data, selects only a provider-grounded open slot, and then converts that proposal into the normal confirmation-protected `calendar_create` path.
- Mutual availability is checked only when the user explicitly asks for both/all people to be free. If an attendee calendar cannot expose free/busy data, Jarvis must say availability is unavailable and may not assume or guess that attendee is free.
- 0.2.3 requests the Calendar event free/busy OAuth permission. Existing users may need a one-time Google reconnect for live availability; fixed-time Calendar operations remain available independently where their existing grant permits them.
- Fixed-time create/update operations check the primary calendar for overlaps before confirmation. A conflict is presented to the user before the write; conflict detection does not silently override the user's choice.
- Creating, moving, updating, or deleting Calendar state always requires a separate explicit confirmation. A preview/proposal is never treated as execution.
- A single recently displayed Calendar event may be retained as a short-lived exact referent for natural follow-ups such as `Move that`, `Make it 30 minutes`, or `Add Austin too`. Multiple possible referents require clarification rather than guessing.
- Moving an event preserves its original duration unless the user explicitly changes duration/end time. Existing attendees remain unless the user explicitly changes them.
- Natural attendee names resolve through the generalized person/contact resolution layer. Added attendees append to existing attendees instead of replacing them.
- Calendar writes involving attendees use provider-native attendee update delivery after user confirmation.
- Pending Calendar create/update/delete actions survive Realtime sleep/wake and may be rebound only for the same recognized actor. A different actor may never inherit another person's pending write.
- Calendar event/list/availability presentations remain structured in compact and Fullscreen views and include available title, date/time, timezone, location, attendees, notes, conflicts, and action status.
- Jarvis may only report a Calendar create/update/delete as successful after Google confirms the provider operation.


### `0.2.4 — Tasks & Reminders`

## 0.2.4 Tasks & Reminders contract

- Luna plans task/reminder intent while Realtime remains speech-only.
- Tasks are persisted locally in an actor-scoped SQLite store and do not require Google.
- Supported task lifecycle: create, list, update, complete, reopen, remove, due dates, priorities, and recurrence.
- Reminder delivery persists across Jarvis restarts and surfaces shortly after startup if a reminder became due while Jarvis was closed.
- Reminder-only recurring items advance when fired; recurring due tasks advance when completed.
- The desktop Tasks workspace shows open, overdue, and completed items and allows direct Complete/Reopen/Remove controls.
- Reminders can use native desktop notifications while the application is running; 0.2.4 does not wake a powered-off computer.
- Task ownership follows the same generalized multi-user tenant/actor isolation rules as memory and connected actions.

## 0.3.4-repair2 — Verification UX

Live browser-auth acceptance refined the account challenge boundary without changing the 0.3.4 product version. Signup now preserves only non-secret identity/contact values after validation errors, password mismatch clears only the secret fields with inline/top errors, and all password fields use persistent explicit show/hide controls. Verification and recovery challenges use 10-minute one-time codes with five wrong-attempt limits, a 60-second resend cooldown, visible expiry/resend countdowns, and code rotation that invalidates the prior code. Recovery-code exchange is one-time. The development relay continues to display codes locally for testing and now states explicitly that it does not send email/SMS; production still requires a deployment-owned verification sender and never exposes codes in API responses. See ISSUE-309.

## 0.3.6-repair2 — Trusted Security Session

Live Permissions & Security testing proved Block enforcement but exposed excessive reauthentication friction: lowering/restoring several permissions forced a browser email/password flow for every single setting. Repair2 separates account proof from action authority. Successful password proof now creates only a 60–900 second (default 300) process-memory recent-auth identity window bound to account/tenant/device/installation/actor; it dies on Core restart and clears on logout/new account session. The browser uses the already-bound account identifier, so normal reauthentication asks only for the password. Every authenticated action still requires a complete Core-derived trusted Electron confirmation and challenge-specific HMAC attestation before the exact challenge can materialize its grant. Recent-auth is never itself a permission grant and a compromised renderer cannot silently lower protections during the window. See ISSUE-324 and `docs/PATCH_NOTES_0.3.6-repair2.md`.

## 0.3.6-repair3 — Reauth Handoff

Live repair2 testing passed the trusted security-session flow and then identified two acceptance polish items. Successful purpose-bound browser reauthentication now makes a standards-based best-effort attempt to close the verified tab; if Chromium/browser policy rejects closing a tab opened by Electron/external application, the page remains a harmless verified fallback. Do not use Browser Control/native automation to bypass that browser policy. The exact trusted Jarvis confirmation remains the authorization boundary. The source project also declares `pytest` + `pytest-asyncio` under the optional `test` dependency extra so separate developer `.venv` environments have a canonical way to run all async security tests without adding test tooling to the consumer runtime. See ISSUE-325/326 and `docs/TESTING_GUIDE_0.3.6-repair3.md`.


## 0.3.6-repair4 — Clean Reauth Completion

Live repair3 testing confirmed the security architecture worked, but Edge's expected refusal to script-close an externally opened tab left a completion page whose diagnostic wording felt like an error. Repair4 keeps the safe `window.close()` best-effort behavior and the external-browser trust boundary, but makes the remaining page a neutral successful state: authentication is approved, Jarvis continues the exact desktop approval, and the user may safely close the browser tab. Do not add Browser Control/native automation to force browser closure. Exact trusted Jarvis confirmation remains mandatory. See ISSUE-327 and `docs/TESTING_GUIDE_0.3.6-repair4.md`.

## 0.3.6-repair5 — Trusted Executor Confirmation

Live repair4 testing reached the Browser `Always ask` acceptance case and exposed a real executor-confirmation integration bug. User-raised ASK on otherwise automatic permissions could create an exact one-use grant but the safe-action evaluation branch never consumed it; Browser/Computer converted the gate into ordinary conversation, which produced mechanical wording and allowed cancellation/interruption to re-enter normal action routing. Repair5 makes these device-policy confirmations executor-owned: Core creates the exact challenge, Electron main displays the complete natural action review, the renderer retries the same request only with trusted attestation, and the real executor permission check consumes the grant. Cancellation is a handled terminal result and cannot fall through. Voice challenge scope follows the live speaker lane (`session_speaker_id`) instead of a cosmetic `Unknown speaker`/owner display fallback; another lane cannot reuse the challenge. See ISSUE-328 and `docs/TESTING_GUIDE_0.3.6-repair5.md`.

## 0.3.6-repair6 — Steam Isolation

The first automated rerun after Repair5 passed 198 Python tests and failed only the legacy Steam-manifest fixture. The fixture injected a temporary Program Files Steam tree but, because it deliberately ran the Windows discovery provider, also inherited the real developer machine's `HKCU\Software\Valve\Steam` path. Repair6 masks `winreg` only inside that unit test so `assert len(games) == 1` measures the one synthetic manifest it created. `jarvis/computer/apps.py` is not changed; real Jarvis continues discovering Steam libraries from the registry. Apply over exact repair5, rerun the targeted test and full regression group, and do not resume live confirmation acceptance until automated tests are clean. See ISSUE-329 and `docs/TESTING_GUIDE_0.3.6-repair6.md`.

### 0.3.6-repair7 live candidate — Friendly Confirmation

Repair7 follows successful Repair6 automated validation and the first Browser `Always ask` live checks. The Repair5 security architecture remains authoritative: exact challenge, trusted desktop approval, actor/session/action binding, one-use grant, and executor consumption are unchanged. Repair7 changes only the trusted confirmation presentation/focus path so ordinary users see short natural action-specific copy instead of raw executor/JSON detail. Electron restores and foregrounds Jarvis before showing the native modal and refocuses Jarvis after close/cancel. Continue 0.3.6 live testing; do not commit or delete patch/backups until explicit acceptance. See ISSUE-330 and `docs/TESTING_GUIDE_0.3.6-repair7.md`.

### 0.3.6-repair8 — URL Routing (live acceptance candidate)

Repair7 confirmation UX/focus live checks passed, then explicit-domain testing exposed a routing defect: `Open example.com/YouTube.com in a new tab` could fail Browser Control or fall through to Computer Actions. Repair8 adds deterministic direct URL/domain Browser ownership before generic app launch routing, normalizes bare domains to HTTPS, prevents explicit web targets from degrading into local app/file discovery, and retains the exact trusted permission/executor boundary. Resume 0.3.6 live testing from the Repair8 explicit URL check before continuing the remaining confirmation-boundary batches.

### 0.3.6-repair9 — Trusted Interaction (live acceptance candidate)

Repair8 explicit URL routing passed live testing. The next Gmail confirmation test confirmed the trusted native buttons still controlled authorization, but one Windows machine continued processing ordinary Realtime speech behind the modal and the clipped email-card footer looked clickable even though it was only CSS decoration. Repair9 keeps the microphone transport available but quarantines all prompt-time speech before normal chat/memory/routing/response generation. Only a narrow denial grammar can abort the exact active native dialog as Cancel; voice has no approval/attestation path. The same repair turns `Answer continues — Open fullscreen` into a real button and makes structured Jarvis cards always eligible for the shared fullscreen reader. Preserve the Repair5 exact-challenge/one-use/executor-consumption invariant and do not commit until full 0.3.6 live acceptance. See ISSUE-332/333 and `docs/TESTING_GUIDE_0.3.6-repair9.md`.

### 0.3.6-repair10 — Regression Alignment (live acceptance candidate)

Repair9's first full real Windows Electron rerun reported 161/164. Inspection showed all three failures were historical exact-source regexes: two interruption/transcript tests did not know about `permissionQuarantined`, and the account reauth test still expected a direct `confirmPermission(challengeId)` call instead of the trusted prompt wrapper. Repair10 updates those test contracts to require the stronger Repair9 invariants while leaving production runtime code byte-identical to Repair9. Apply only over exact repair9, rerun the two targeted files and full Electron suite, then resume Repair9 live interaction checks. See ISSUE-334 and `docs/TESTING_GUIDE_0.3.6-repair10.md`.


### 0.3.6-repair11 — Conversation Continuity

A live short follow-up may temporarily fall from a known speaker to `Unknown speaker`. Do not destroy an already-active Connected Action clarification solely for that uncertainty. Reuse the current action session only for non-executing clarification/edit continuity. A positively attributed different speaker still resets context, and Unknown speech must never authorize an attributed owner's pending execution. Trusted permission dialogs are voice-inert: prompt-time speech is discarded; only the trusted UI can Allow/Cancel.


### 0.3.6 Repair12 — Default Autonomy & Turn Stability

- `Default` is the product policy, not a blanket confirmation mode: routine/reversible actions should run automatically while consequential/security-sensitive permissions keep their stronger policy.
- Speaker recognition must not be a brittle prerequisite for conversational drafting/decision continuity. Temporary Unknown attribution may continue the active action session, while positively recognized speaker switches remain isolated and trusted permission/executor checks remain authoritative for consequential execution.
- Voice transcript dedupe is per microphone turn; identical words spoken in a new turn are a new request and must not be discarded.
- A user clicking Cancel on a trusted native permission modal receives no redundant spoken refusal.


### 0.3.6 Repair13 — Action Context & False VAD Stability

Live acceptance showed two remaining voice-flow defects. Unknown attribution on a short pending-action decision was still causing the renderer to switch Connected Action sessions even though Repair12 intended to allow continuity; Repair13 makes that reuse real for yes/no/send/cancel and edit/clarification turns. This is conversational continuity only: a positively recognized different person still resets context and consequential execution still reaches the trusted native permission/executor boundary.

Realtime barge-in is now two-stage. A provider `speech_started` edge arms a 180 ms candidate instead of immediately interrupting. Meaningful transcript evidence can confirm sooner. Short transcript-less VAD turns receive a 900 ms cleanup/recovery path that removes placeholder turns and restores Speaking, Thinking, or Listening from actual runtime state. This prevents ambient mic noise from stranding Jarvis in Thinking while preserving fast deliberate barge-in.

### 0.3.6 Repair14 — Single Confirmation & VAD Recovery

The product confirmation rule is now **one routine action -> at most one meaningful user confirmation**. For selected common Connected Actions such as Gmail send and Calendar write, Default uses Jarvis's exact natural review question as that confirmation; the exact challenge/grant/executor security chain remains underneath. `Always ask` is an explicit stricter preference and still opens the trusted native prompt. When policy marks a permission persistable, that trusted prompt's positive button is explicitly **Always allow** and a successful trusted attestation persists `PreferenceMode.ALLOW`; future permission popups remain suppressed until the user changes the preference. Non-persistable dangerous actions use **Allow once** or stronger controls. Persistence must be inferred from the trusted challenge/policy, never from renderer-controlled request data.

Repair15 extends that single-confirmation rule to **exact reviewed Calendar deletion/cancellation** after live acceptance showed a duplicate native popup following Jarvis's own `Want me to remove ... from your calendar?` review. Under `Default`, the user's affirmative answer is the one user-facing confirmation for the exact pending event; the challenge still becomes a one-use grant that the Calendar executor consumes. `calendar.delete` remains `confirm_every_time`, sensitive, and non-persistable (`user_can_always_allow=false`). `Always ask` still requires the trusted native **Allow once** surface, and the conversational bridge is eligible only for the exact `Default` preference. See ISSUE-340 and `docs/TESTING_GUIDE_0.3.6-repair15.md`.

False-VAD recovery also covers longer transcript-less VAD turns that crossed the initial debounce. Meaningful transcript evidence preserves real barge-in; no-transcript turns are bounded and restore the real Speaking/Thinking/Listening state rather than stranding Jarvis in Thinking. See ISSUE-338/339 and `docs/TESTING_GUIDE_0.3.6-repair14.md`.

## 0.3.6-repair16 handoff — Permission & Action Confirmation Separation

Do not conflate a user's capability preference with approval of a consequential transaction.

- `Always allow` means Jarvis may use that capability without repeated native permission popups.
- It does **not** mean every consequential action inside the capability executes autonomously.
- Exact Connected Action review remains a separate authority (`Want me to send it?`, `Want me to remove it?`, future purchase-total review, etc.).
- Persistable trusted native prompts use **Cancel / Allow once / Always allow**. Non-persistable prompts use **Cancel / Allow once**.
- Electron main HMAC-binds both challenge ID and choice with `jarvis-permission-confirm-v2`; renderer input must never be trusted to widen one-use authority into persistent authority.
- `Allow once` never changes the stored preference. `Always allow` may persist only after trusted verification and normal executor permission enforcement.
- A persistable `confirm_every_time` definition must declare both `conversation_confirmation_allowed` and `action_confirmation_required` or the catalog must reject it.
- Block/authenticated/restricted/forbidden/system-safety/Game Mode remain stronger than device preference.

For live acceptance, verify Calendar and Gmail under Always ask with both Allow once and Always allow, then prove that persistent capability permission removes only the native permission popup while the separate exact action review still occurs.

## 0.3.6-repair17 handoff — Blocked Action Preflight & Error Fidelity

Repair17 builds directly on the live-passed Repair16 permission/action separation. It adds a side-effect-free hard-denial preflight so explicit Block/system denials stop before unnecessary Connected Action clarification/provider work, rechecks pending actions, and preserves the exact Permissions & Security blocked result instead of generic Google failure wording. Executor permission enforcement remains authoritative. Live acceptance begins by repeating the Calendar Block request that exposed ISSUE-342.
