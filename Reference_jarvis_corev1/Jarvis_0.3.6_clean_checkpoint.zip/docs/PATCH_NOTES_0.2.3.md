# 0.2.3 — Calendar Intelligence

Jarvis gives Google Calendar the same connected-action treatment already established for Gmail: Luna interprets and plans the work, Google remains the source of truth, Realtime only speaks the prepared result, and the desktop shows a structured Calendar preview before any external write.

## Smart scheduling and availability

- Added a dedicated `calendar_schedule` workflow for requests such as finding an open time in a window and proposing a meeting of a requested duration.
- Live availability uses Google Calendar free/busy data rather than guessing from natural-language assumptions.
- Jarvis can calculate provider-grounded open slots, present the useful options, and turn the selected slot into the normal confirmation-protected Calendar create path.
- Mutual availability is attempted only when the user explicitly asks for it. If Google cannot expose another attendee's free/busy data, Jarvis says so and does not invent their availability.
- Calendar list/free-busy reads use grounded local result phrasing where possible to avoid an unnecessary second Luna round trip.

## Conflict-aware event changes

- Fixed-time create and update requests check the primary calendar for overlapping events before Jarvis asks for confirmation.
- Conflict information is visible in the proposed Calendar card and is included in the confirmation prompt rather than silently creating a collision.
- Moving an existing event preserves its original duration unless the user explicitly changes the duration/end time.
- Provider-confirmed create, update, and delete operations remain the only source of truth for success.

## Contact-aware attendees

- Natural attendee names can resolve through the existing generalized Contacts/recipient-resolution layer.
- Existing attendees are preserved during contextual updates; requests such as `Add Austin too` append the resolved attendee instead of replacing everyone already invited.
- Calendar writes with attendees ask Google to send the appropriate event updates after the user confirms the write.

## Conversation continuity

- Showing one specific event grounds that exact event for natural follow-ups such as `Move that to Friday at 2`, `Make it 30 minutes`, or `Add Austin too`.
- Jarvis asks for clarification instead of guessing when more than one recent event could satisfy an underspecified follow-up.
- Pending Calendar create/update/delete confirmations can survive sleep/wake and be reclaimed only by the same recognized actor, matching the accepted Gmail continuity boundary.

## Calendar presentation

- Calendar reads, availability results, and proposed/completed writes have dedicated structured desktop presentations.
- Event cards show title, date, time range, timezone, location, attendees, notes, status, conflicts, and availability context when applicable.
- Fullscreen preserves the structured Calendar card instead of flattening it into generic text.
- The desktop retains a short-lived grounded event context after showing a Calendar card so immediate natural follow-ups stay in Connected Actions.

## Google permission change

- 0.2.3 requests the Calendar free/busy permission needed for live open-slot scheduling.
- Existing users may need to reconnect Google once from Connected Apps to grant Calendar availability access; existing OAuth client credentials do not change.
- Fixed-time Calendar operations remain separate from free/busy readiness, and capability self-knowledge reports the limitation truthfully if the new availability permission has not been granted.

## Safety and architecture

- Calendar reads and availability checks are non-writing actions and can run immediately.
- Creating, moving, updating, or deleting an event still requires a separate explicit confirmation.
- A scheduling proposal is not an external write until the user confirms it.
- Realtime remains the speech interface. Luna remains the connected-action reasoning/planning model.
- Jarvis never claims a Calendar write succeeded until Google confirms it.
