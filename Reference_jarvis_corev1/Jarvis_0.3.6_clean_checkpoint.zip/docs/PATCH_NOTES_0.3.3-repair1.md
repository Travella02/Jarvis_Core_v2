# 0.3.3-repair1 — Live Turn Continuity

This repair keeps the product version at **0.3.3 — Runtime Reliability** while correcting three live-acceptance regressions found on 2026-08-25.

## What changed

- Silent Browser Control, Computer Actions, Web Intelligence, and suppressed Connected Action turns now explicitly return Realtime microphone ownership to the user. A successful hidden action can no longer leave the UI saying **Listening** while the physical microphone track remains disabled behind the wake-input gate.
- Speaker onboarding no longer treats ordinary conversational phrases such as **“I’m doing pretty good”** as a person's name. `I'm` / `I am` introductions still work for actual names, but state/activity fragments are rejected as identity evidence.
- Browser, Web Intelligence, and speaker-scoped Connected Actions keep their own continuity/session lanes while reporting paid usage into the parent live Jarvis session. The visible session cost is also monotonic for the life of the session, so an action response cannot reset the counter to `$0.0000`.

## Versioning

`VERSION`, package metadata, Browser Bridge metadata, and the visible product version remain **0.3.3**. `repair1` is only the unaccepted repair label.

## Safety

The installer is hash-gated against the exact delivered 0.3.3 Runtime Reliability candidate and only normalizes CRLF/LF representation. It does not touch `.env`, `data/`, `.venv`, credentials, caches, or account databases.
