# 0.2.4-repair5 — Universal Time Authority live test

## 1. Existing reminder regression

Keep the existing reminder that visibly shows **Call Tanner — Reminder Thu, Aug 13, 2:00 PM** in the Tasks workspace.

Ask:

> Is there anything I need to do tomorrow?

Then ask only:

> What time?

Expected:

> Call Tanner is set for 2 PM tomorrow.

The spoken answer must match the Tasks workspace. It must not say 8 PM because the stored record was historically stamped with UTC metadata.

## 2. Reminder follow-up

Immediately ask:

> When will you remind me?

Expected: Jarvis says the same **2 PM tomorrow** reminder time.

## 3. Current local clock

Ask:

> What time is it?

Expected: Jarvis states the computer's actual current local time. It must not say that it cannot see the real-time clock, and it must not answer in UTC when the Windows wall clock is local.

Also try:

> What's today's date?

Expected: the local calendar date shown by the computer.

## 4. New reminder write

Create a fresh disposable reminder using a local wall-clock time, for example:

> Remind me tomorrow at 3 PM to test local time.

Then ask what you need to do tomorrow and follow with:

> What time?

Expected: spoken time, task card/dashboard time, and reminder delivery schedule all agree on **3 PM local**.

## 5. Task/current-clock disambiguation

After discussing that task, ask:

> What time?

Expected: the task/reminder time.

Then ask:

> What time is it?

Expected: the current computer clock, not the task time.

## 6. Regression checks

- Calendar events should continue to speak and display the same local time Google Calendar uses.
- Existing contextual task reasoning and working-memory follow-ups should still work.
- Gmail/Calendar Connected Actions should remain routed normally.
- Realtime sleep/wake must not erase or change task schedule truth.

## Acceptance criteria

- Existing UTC-stamped reminders are spoken in the user's actual local time without migration.
- Newly created/edited tasks use the same local-time authority.
- Reminder polling/recurrence uses current user-local timezone truth.
- Direct current-time/date questions are exact and deterministic.
- Realtime never falsely claims that Jarvis cannot access the current local clock when the desktop has supplied it.
- No six-hour UTC/local mismatch appears between speech, cards, task workspace, Calendar, and reminder delivery.
