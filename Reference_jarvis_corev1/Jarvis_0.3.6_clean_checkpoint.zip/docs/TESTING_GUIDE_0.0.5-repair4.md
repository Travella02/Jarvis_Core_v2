# Testing Guide — 0.0.5 Electron Shell Repair 4

## Install

Run from the Jarvis_Real_Time project root:

```powershell
py -3.12 apply_0_0_5_repair4_patch.py
```

The installer should show a Node version and then invoke a path ending in `npm.cmd` for npm commands on Windows.

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

Expected automated test count: **82**.

## Desktop acceptance

```powershell
npm run desktop
```

Confirm:

1. A native Jarvis window opens without a normal browser tab.
2. The Python core starts automatically.
3. Wake, simulation, and Live OpenAI modes remain available.
4. Closing the window minimizes to the tray.
5. Tray Open, Wake, Sleep, Restart core, and Quit work.
6. Spoken sleep commands return Jarvis to local sleep.
7. Date and time responses match the computer.
8. Quitting from the tray leaves no Jarvis Electron or Python process running.
