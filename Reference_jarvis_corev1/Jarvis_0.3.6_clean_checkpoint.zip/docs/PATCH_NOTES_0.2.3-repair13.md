# 0.2.3-repair13 — Gmail Follow-up Ownership

This live-acceptance repair closes two Gmail polish regressions found during the final 0.2.3 acceptance sweep.

## What changed

- A single unread email is described directly instead of using priority language such as “I’d start with…”.
- Natural follow-ups such as “mark that as read” are now classified as Connected Actions before ordinary Realtime can answer.
- Gmail mark-read follow-ups claim the same response-ownership lock used by other Google actions, preventing a stale Realtime capability denial from speaking first.
- The existing recent Gmail selection is reused, so “that” refers to the exact unread message Jarvis just surfaced.
- Gmail modify safety remains unchanged: Jarvis only marks the bounded selected message(s) as read and never treats a broad unread count as permission to clear an entire mailbox.

## Expected behavior

If there is exactly one unread message, Jarvis should say something like:

> You have 1 unread inbox email from Google Cloud: Launch and learn with interactive, prebuilt solutions.

Then:

> Can you mark that as read, please?

should produce one grounded response:

> Done. I marked 1 message as read.

No second Realtime answer should be spoken or replace the Connected Actions result.
