# Patch Notes — 0.0.1-dev1-realtime-repair3

- **Date:** 2026-07-26
- **Project version:** `0.0.1-dev1` (unchanged)
- **Required prior version:** `0.0.1-dev1`
- **Purpose:** Repair browser rejection of the OpenAI SDP answer after the unified Realtime call succeeds.

## User-visible change

The Realtime Voice Lab now preserves and canonicalizes SDP answer framing before Chromium parses it. The expected result is that Connect proceeds beyond `setRemoteDescription` instead of failing on an `a=ice-pwd` line.

The provider-events panel now reports a privacy-safe event such as:

```text
webrtc.answer.ready — 1180 bytes, 35 lines
```

It never prints the SDP answer, ICE username, ICE password, API key, or other session credentials.

## Files changed

- `jarvis/intelligence/realtime.py` — reads successful provider SDP as raw bytes; validates and canonicalizes CRLF framing with a final CRLF.
- `apps/core/server.py` — returns exact UTF-8 SDP bytes with `application/sdp`.
- `apps/desktop/lab/app.js` — defensively normalizes the answer before `setRemoteDescription` and adds size/line-count diagnostics.
- `tests/test_realtime_provider.py` — covers raw bytes, UTF-8 BOM removal, line-ending normalization, final CRLF, and malformed lines.
- `tests/test_server.py` — verifies byte-exact SDP response framing.
- `tests/test_voice_lab_client.py` — verifies client normalization and safe diagnostics.
- `docs/ARCHITECTURE_DECISIONS.md` — records the byte/framing boundary decision.
- `docs/JARVIS_CORE_HANDOFF_INSTRUCTIONS.md` — records current live-test state and next action.

## Compatibility and migration

- `.env` is untouched.
- No database or schema migration is required.
- No dependency changes are required.
- The patch may be rerun safely.
- The installer accepts the known repair2 baseline and refuses unexpected local edits to changed files.

## Tests run before delivery

```text
python -m unittest discover -s tests -v
Ran 32 tests
OK
```

JavaScript syntax validation also passed with `node --check`.

## Known limitations

This repair was validated with mocked provider responses and exact HTTP/SDP framing tests. A live paid OpenAI connection still requires Tanner's private API key and therefore must be accepted on his machine. Wake word, final Electron UI, complete barge-in handling, session rollover, memory, and tools remain outside dev1.

## Rollback

The installer creates a timestamped backup under `.patch_backups/0.0.1-dev1-realtime-repair3_<timestamp>`. If validation fails, it restores project files automatically. Manual rollback can copy the backed-up files to their original project-relative locations.
