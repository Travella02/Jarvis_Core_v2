# 0.1.8-repair1 — Memory Hygiene Testing Guide

## Install

1. Close Jarvis completely.
2. Extract the repair ZIP directly into the `Jarvis_Real_Time` project root and allow files to merge.
3. Run `py -3.12 apply_0_1_8_repair1_patch.py`.
4. Start Jarvis with `npm run desktop`.

## Acceptance flow

### 1. Assistant-only graph cleanup

Restart Jarvis, open Memory, and inspect **Entities & relationships**.

Expected:

- False standalone concepts created only by Jarvis's technical answers, such as `AND`, `OR`, `XOR`, `CPU`, `GPU`, `HTTP`, `TCP`, and similar tokens, disappear.
- Genuine user-established entities such as people, businesses, projects, and ORVEX remain.
- The original Jarvis response messages remain available in the event timeline.

### 2. New assistant answers do not repopulate the graph

Ask Jarvis a detailed technical question that causes him to mention several acronyms, for example:

`Explain CPU, GPU, RAM, TCP, HTTP, and XOR in detail.`

Then refresh Memory.

Expected:

- The exact conversation is recorded.
- Those terms do not become new standalone entities merely because Jarvis used them.
- A term already established by the user may still appear in its existing entity timeline.

### 3. Natural forget command

Say or type:

1. `My temporary repair-test code is 4821.`
2. `Um, actually, forget that.`
3. `What is my temporary repair-test code?`

Expected:

- Jarvis gives a short successful confirmation such as `Okay, I forgot that.`
- He does not claim that forgetting is unavailable or tell the user to use Memory Explorer.
- The code is excluded from current recall.
- The source statement remains visible as forgotten historical evidence and can still be restored.

### 4. Question safety

Ask:

`Do you remember my temporary repair-test code?`

Expected: Jarvis treats it as a question, not as a new remember or forget mutation.

### 5. Responsive Memory Explorer filters

Open the Memory timeline at the same window size that previously showed the overflow. Resize the window and switch workspace balance modes.

Expected:

- Query, date, category, source, status, importance, Search, and Clear controls stay inside the timeline panel.
- Controls wrap cleanly rather than overlapping or extending beyond the card.
- Search remains clickable at every supported width.

### 6. Regression checks

- Remember, correct, complete, dismiss, restore, clear completed, and Undo still work.
- Entity profiles continue to show current facts and preserved history correctly.
- Voice attribution and preferred forms of address still work.
- Sleeping audio does not flash Waking without a confirmed Jarvis wake phrase.
- Response modes and hybrid long answers retain their accepted behavior.
