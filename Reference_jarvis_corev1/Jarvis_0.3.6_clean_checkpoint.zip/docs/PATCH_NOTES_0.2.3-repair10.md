# 0.2.3-repair10 — Attendee Lookup Safety

## User-visible change
Calendar attendee resolution no longer crashes when an unknown person has no matching Gmail history. Jarvis can now continue to the intended clarification and ask for the person's email address.

## What was fixed
The Gmail API can return a successful message-list response with an empty/null `messages` collection. Recipient resolution treated that value as iterable, which caused `TypeError: 'NoneType' object is not iterable` while Calendar was trying to resolve a new attendee.

`GoogleWorkspaceGateway.search_gmail()` now normalizes a null/missing Gmail message collection to an empty list. That lets Connected Actions finish the normal resolution chain and say something like:

> “I couldn't find Austin's email address. What's Austin's email?”

The existing exact-event continuity from repair8/repair9 remains intact, so after the user supplies the email Jarvis resumes the same Calendar update rather than starting over.

## Scope
This is a narrow reliability repair. It does not change the working local-time architecture, Calendar confirmation behavior, or action-ownership routing.
