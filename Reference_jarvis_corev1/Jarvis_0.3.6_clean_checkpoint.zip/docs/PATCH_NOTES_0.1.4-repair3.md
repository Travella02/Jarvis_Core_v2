# 0.1.4-repair3 — Clean Corrections & Interruption Sync

This repair closes the final two live-acceptance gaps in Proactive Memory: correction cue words leaking into derived commitments, and cancelled Realtime responses interfering with the turn that follows an interruption.

## Fixed

- Spoken corrections such as “Hey, sorry, Jarvis, I actually meant Austin” now extract only **Austin** as the replacement value.
- Existing malformed correction metadata such as `meant Austin` is cleaned during the next proactive refresh, so current databases repair themselves without deleting evidence.
- Correction filler such as `meant`, `met`, `actually`, `sorry`, and `Jarvis` cannot become part of a proactive title.
- Original statements and corrective statements remain immutable evidence; only derived proactive wording and fingerprints change.
- Realtime response state is now tracked by provider `response_id` and output `item_id` instead of one global interruption flag.
- Late audio and transcript events belonging to a cancelled response are ignored.
- A stale `response.done` from an interrupted response can no longer clear, mute, or detach the newer response.
- The next user turn can receive normal text and audible speech immediately after an interruption.
- Interrupted bubbles remain visibly marked, while text generated after cancellation is not appended or stored as if it had been spoken.

## Safety and scope

- This repair does not rewrite source memory events.
- It does not add external action permissions.
- It does not change the provider VAD policy; it only makes the desktop client correctly separate old and new provider responses.
