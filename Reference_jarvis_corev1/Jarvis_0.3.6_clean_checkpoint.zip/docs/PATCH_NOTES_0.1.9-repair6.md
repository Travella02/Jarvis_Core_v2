# 0.1.9-repair6 — Answer-Only Recall

This repair makes simple memory questions stop after the requested answer.

## Changes

- One-fact relationship recall uses a deterministic exact reply.
- Explicit source questions use one deterministic source/date sentence when evidence is available.
- Voice and typed turns share the same exact-reply path.
- Ordinary recall no longer adds offers to track more, build context, help later, or explain storage.
- Source answers no longer explain why Jarvis retained the memory or append follow-up suggestions.
- Multi-fact, ambiguous, historical, decision, and detailed questions continue using the grounded model path.

## Examples

- “What do you remember about my fiancée?” → “Your fiancée is Kenleigh Yarman.”
- “How do you know that?” → “You told me in a voice conversation on August 3, 2026.”
