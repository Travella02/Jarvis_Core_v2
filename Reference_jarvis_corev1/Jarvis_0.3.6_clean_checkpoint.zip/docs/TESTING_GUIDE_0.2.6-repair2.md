# Testing Guide — 0.2.6-repair2 Fast App Control

## 1. Learned launch speed

With Discord closed, say:

`Open Discord.`

Expected: Jarvis should answer almost immediately and Windows should begin opening Discord without a long discovery pause. Because Discord was already learned during the previous live test, this request should use the local cached target and should not rebuild the Windows app inventory first.

Close Discord manually once if necessary, then repeat `Open Discord.` The routing portion should remain immediate.

## 2. Close an application

Say:

`Close Discord.`

Expected: Discord closes and Jarvis says `Closed Discord.` If it is already closed, Jarvis should truthfully say it is not running rather than claiming success.

## 3. Teach a natural alias

Say:

`Group chat is another name for Discord.`

Expected: Jarvis confirms that it will remember `group chat` as Discord.

Then say:

`Open group chat.`

Expected: Discord opens from the learned alias without another PC search.

Then say:

`Close group chat.`

Expected: Discord closes using the same resolved app identity.

## 4. Inspect Apps memory

Open **Memory → Apps**.

Expected: Discord appears with its stored target/path or Windows launcher identifier, launch source, usage information, and learned aliases. `group chat` should appear as a learned alias for the local person who taught it.

Use the **Add alias** box on the Discord card to add another alias such as `chat`, then say `Open chat.` Expected: Discord opens.

## 5. Persistence

Fully quit Jarvis and start it again. Say:

`Open group chat.`

Expected: the alias and launch target survive restart and resolve without rediscovery.

## 6. First-use application

Choose another installed application Jarvis has not opened before and say `Open <app name>.`

Expected: common installed apps should resolve from the startup/quick local index without the previous ~20-second synchronous Start Apps delay. An obscure portable executable may still require bounded deep discovery the first time; once found, its learned path should be fast on later requests.
