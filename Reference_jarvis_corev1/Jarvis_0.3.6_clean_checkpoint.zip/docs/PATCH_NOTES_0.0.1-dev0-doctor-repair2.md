# Patch Notes — 0.0.1-dev0 Doctor Repair 2

- **Date:** 2026-07-26
- **Required installed version:** `0.0.1-dev0`
- **Installed version after repair:** `0.0.1-dev0` (unchanged)
- **Supersedes:** the unsuccessful `doctor-repair1` installer attempt
- **Purpose:** Install the direct doctor-command repair even when prior ZIP extraction has merged older files into the local `patch_files/` directory.

## What happened

The bootstrap and repair ZIPs both use the required `patch_files/` package folder. Windows correctly merged those folders when they were extracted into the existing project. The repair1 installer then compared the entire merged directory against only its five-file manifest and rejected the older bootstrap payload as unexpected extras.

The rejection happened before any project files were changed, so the installed `0.0.1-dev0` foundation remained intact.

## User-visible changes

1. The installer now checksum-verifies every file named by the active repair manifest and safely ignores unrelated files left from earlier extracted packages.
2. The environment doctor now runs through the documented direct command without `ModuleNotFoundError`:

```powershell
.\.venv\Scripts\python.exe scripts\doctor.py
```

## Files added or changed

- `scripts/doctor.py` — anchors direct-script imports and project discovery to the repository root.
- `tests/test_doctor_script.py` — launches the documented command in a subprocess without `PYTHONPATH` and verifies project imports.
- `docs/JARVIS_CORE_HANDOFF_INSTRUCTIONS.md` — records repair2, the installer collision cause, and current state.
- `docs/PATCH_NOTES_0.0.1-dev0-doctor-repair2.md` — this change record.
- `docs/TESTING_GUIDE_0.0.1-dev0-doctor-repair2.md` — exact installation and validation procedure.
- `RELEASE_MANIFEST.json` — repair2 checksums and validation evidence.

## Safety and compatibility

- No dependencies, schemas, configuration formats, runtime state, provider behavior, or product capabilities changed.
- The virtual environment does not need to be recreated.
- Only files listed by the active manifest are copied into the project.
- Unrelated files in the extracted `patch_files/` directory are never installed.
- Every replaced project file receives a timestamped backup before replacement.
- Failed post-install tests trigger automatic rollback.

## Tests run before delivery

The exact user scenario was reproduced:

1. Bootstrap extracted and installed.
2. Repair1 extracted into the same project root, merging `patch_files/`.
3. Repair1 failed with the same extra-file mismatch before modifying the project.
4. Repair2 was extracted into that same merged directory and installed successfully.

Validation result:

```text
python -m unittest discover -s tests -v
Ran 8 tests
OK
```

The direct doctor command returned four `PASS` checks, and the current headless start command also completed successfully.

## Rollback

The installer stores replaced files in `.patch_backups/0.0.1-dev0-doctor-repair2_<timestamp>/`. It automatically restores them if validation fails. A successful installation may be manually rolled back by restoring the files from that directory.

## Deferred work

OpenAI Realtime, WebRTC, audio devices, interruption, and the visual client remain intentionally deferred to `0.0.1-dev1`.
