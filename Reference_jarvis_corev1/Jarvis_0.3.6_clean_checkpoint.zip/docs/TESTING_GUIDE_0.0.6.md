# Testing Guide — 0.0.6 Desktop Presence

## Automated validation

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
.\.venv\Scripts\python.exe scripts\stage_desktop_runtime.py
```

Expected automated result before live acceptance: **108 Python tests and 6 Node tests pass**.

## Start command

```powershell
npm run desktop
```

## Live acceptance checklist

### Normal launch and status

1. Confirm Jarvis opens at the accepted single-monitor size.
2. Confirm the **Desktop presence** panel changes from Starting to Healthy.
3. Confirm App uptime and Core uptime increase.
4. Confirm Last heartbeat updates approximately every five seconds.
5. Confirm wake, conversation, Cost Control, interruption, spoken sleep, and X-to-quit still work.

### Windows startup control

1. Enable **Start Jarvis with Windows** in the interface.
2. Confirm the matching tray checkbox becomes checked.
3. Quit and relaunch Jarvis; confirm the setting remains checked.
4. Inspect Windows Startup Apps and confirm Jarvis/Electron is registered.
5. Disable the setting and confirm the registration is removed.
6. A real Windows sign-out/sign-in test may be completed after packaging; development mode registers Electron with the project path and `--background`.

### Hidden background operation

1. Choose **Hide Jarvis** from the tray.
2. Confirm the window disappears but wake monitoring remains active.
3. Say a wake request and confirm Jarvis responds.
4. Click the tray icon and confirm the existing window returns.
5. Click X and confirm Jarvis and the Python core fully exit.

### Core recovery

1. Launch Jarvis and note the current Core restarts value.
2. Use **Restart local core** in the Desktop Presence panel.
3. Confirm the interface reloads, returns to Healthy, and restart/recovery status updates.
4. Use **Restart core** from the tray and repeat.
5. Confirm one optional recovery notification appears when notifications are enabled.
6. Confirm no duplicate Electron window is created.

### Renderer recovery

1. Open Electron DevTools only for this engineering test.
2. Reload or terminate the renderer process once.
3. Confirm Jarvis reloads the interface and increments Renderer recoveries.
4. Do not repeatedly crash the renderer beyond the bounded recovery limit.

### Suspend and resume

1. Put the laptop to sleep while Jarvis is open or hidden.
2. Resume Windows.
3. Confirm Jarvis restarts the local core, returns to a sleeping wake-ready state, and reports Healthy.
4. Confirm a stale paid Realtime session was not silently preserved across suspend.

### Wake latency diagnostics

1. Say: **"Jarvis, give me a one-sentence greeting."**
2. Review Wake transcription, Wake preconnect, and Wake → first audio.
3. Repeat at least five times and record which stage accounts for most remaining delay.
4. Confirm ordinary follow-up timing metrics still work independently.

## Acceptance boundary

Commit `0.0.6` only after normal launch, hidden wake monitoring, X-to-quit, manual core restart, presence heartbeat, and one suspend/resume cycle pass on Windows.
