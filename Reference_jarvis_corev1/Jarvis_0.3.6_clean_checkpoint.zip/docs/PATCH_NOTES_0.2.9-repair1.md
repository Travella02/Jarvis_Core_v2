# 0.2.9-repair1 — Wake Barge-In

## Why this repair exists

The first 0.2.9 build correctly taught the interruption state machine to cancel dedicated/local speech when Realtime VAD reported new user speech. Live testing exposed a deeper wake-pipeline conflict: the wake first-turn gate still disabled the WebRTC microphone until the first dedicated response finished. The interruption event therefore could not occur on the first answer after waking.

The same fast speculative-wake path could also transition from Waking to Listening before the renderer had a chance to paint the Waking state.

## Changes

- Re-arm the Realtime microphone as soon as dedicated speech becomes the authoritative owner of the opening wake turn.
- Clear stale input before re-arming and retain manual mute/sleep checks.
- Keep the older audio-complete gate path for non-dedicated provider-output fallbacks.
- Preserve 0.2.9 voice-turn epochs and stale async response suppression.
- Present Waking immediately on confirmed wake and hold that state visually for a short minimum interval without delaying connection, routing, actions, or TTS work.

## Safety / scope

This repair does not change Game Mode, Computer Actions authorization, browser access, mouse/keyboard execution, memory, connected accounts, data storage, release version metadata, or user configuration.

## Acceptance focus

The critical live test is the first response after wake: speak over Jarvis while he is audibly answering. He must stop, capture the full interruption, answer the new turn, and never resume the old response. Repeated interruption on later turns must continue to work normally.
