# 0.0.3 — Wake Acknowledgement Repair

## Summary

Makes Jarvis respond naturally when Tanner says only the wake keyword.

## Changed

- Added a dedicated wake-only acknowledgement path.
- Saying only **“Jarvis”** now requests a short natural response such as **“Yes, sir?”** after the Realtime data channel opens.
- Keeps the internal acknowledgement instruction out of the visible user transcript.
- Applies the first-turn microphone gate to the acknowledgement so startup audio cannot create a competing provider VAD turn.
- Preserves full-request wake phrases such as **“Hey Jarvis, tell me a joke.”**
- Resets acknowledgement state during timeout, sleep, and cleanup paths.

## Issue record

- `issues/ISSUE_015_WAKE_ONLY_SILENT_START.md`

## Validation

- Full automated suite passed.
- JavaScript syntax validation passed.
- Doctor and safe diagnostic passed.
- Installer succeeded from the exact repair3 baseline.
- Idempotent rerun changed zero files.
- Test `.env` remained byte-for-byte unchanged.
