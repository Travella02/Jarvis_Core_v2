# 0.3.6-repair8 — URL Routing

**Date:** 2026-09-03  
**Required previous release:** 0.3.6-repair7  
**Status:** Live acceptance repair candidate

## Fix

Live Browser Control testing found that explicit web-address requests such as `Open YouTube.com in a new tab` and `Open example.com in a new tab` could be interpreted as a named browser-result continuation or fall through to Computer Actions as a local app/file request.

Repair8 gives explicit HTTP(S), bare-domain, `www.` and localhost navigation deterministic Browser Control ownership before generic `open X` Computer Actions routing. Browser Core now normalizes bare web addresses to HTTPS and executes direct `navigate` / `tab_new` operations without a planner round-trip. If Browser Control owns an explicit web address, a browser failure cannot degrade into a local app/file lookup.

The trusted Repair7 permission boundary is preserved. Direct new-tab URLs remain exact permission resources, and the consumer prompt names only the destination host rather than exposing query strings or secret-bearing URL details.

Local app launching remains broad, while common file-like names such as `README.md` and `report.pdf` are not promoted into web navigation merely because they contain a dot.

See ISSUE-331.
