# Testing Guide — 0.0.3 Wake Turn Repair

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Start Jarvis and hard-refresh the lab once.
2. Put Jarvis to sleep.
3. Say **“Hey Jarvis, tell me a joke.”**
4. Confirm the transcript shows exactly one user request and one Jarvis answer.
5. Repeat that test at least five times.
6. Repeat with **“Yo Jarvis, what can you help me with?”**
7. Confirm no extra `Processing speech...` bubble appears after the opening answer.
8. Say only **“Jarvis”**, wait for connection, then speak a new request. Confirm this wake-only flow still works.
9. Confirm manual mute, interruption, Sleep, and the Jarvis-speaking timer still work.
10. Confirm response count and estimated cost increase only once per opening request.

Do not commit `0.0.3` until the duplicate first turn cannot be reproduced across repeated wake tests.
