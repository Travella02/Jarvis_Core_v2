# 0.3.2 — Account Foundation Testing Guide

## Automated validation

Run from the Jarvis project root after applying the patch:

```powershell
py -3.12 -m pytest -q
```

```powershell
npm run desktop:check
```

```powershell
npm run desktop:test
```

```powershell
node --check extensions/jarvis_browser_bridge/service_worker.js
node --check extensions/jarvis_browser_bridge/content.js
```

## Version sanity check

Confirm these report `0.3.2`:

```powershell
Get-Content .\VERSION
node -p "require('./package.json').version"
node -p "require('./package-lock.json').version"
Select-String -Path .\pyproject.toml -Pattern 'version = "0.3.2"'
node -p "require('./extensions/jarvis_browser_bridge/manifest.json').version"
```

## Live account test

1. Launch Jarvis and open the new **Account** workspace.
2. Confirm Jarvis still works normally while signed out; 0.3.2 must not turn the local-first assistant into an account-gated product.
3. Create an account with your name, email, and a password of at least 12 characters.
4. Confirm the Account page changes to **Signed in** and shows account, tenant, device, session-expiry, and local data-namespace information.
5. Close and reopen the Jarvis window normally. Confirm the account session is still recognized.
6. Change the account display name and confirm the tenant display name follows it.
7. Sign out. Confirm the page says the installation remains linked and does not erase local Jarvis data.
8. Try signing in with the wrong password. Confirm it is rejected without creating or switching a tenant.
9. Sign in with the correct password. Confirm the same tenant identity returns.
10. Run one previously accepted Jarvis workflow (for example a Browser Control pause/resume or a normal memory/task query) to confirm Account Foundation did not regress existing functionality.

## Data safety check

Do not delete or relocate `.env`, `data/`, or existing local databases. This update creates only the new account database under `data/accounts/` at runtime. The patch installer itself must not modify local data.

## Commit rule

Do not commit until the automated tests and live test above pass. After acceptance, remove the patch installer/payload from the project root, inspect `git status --short`, then commit the accepted 0.3.2 source as the exact baseline for 0.3.3 Cloud Sync.
