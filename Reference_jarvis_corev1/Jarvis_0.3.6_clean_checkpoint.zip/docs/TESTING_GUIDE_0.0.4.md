# Testing Guide — 0.0.4 Cost Control

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
node --check apps\desktop\lab\app.js
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Free simulation acceptance

Start Jarvis:

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

Select **Local simulation — free** and complete these checks without API spend:

1. Wake Jarvis manually.
2. Send a typed message and confirm one user bubble and one simulated response.
3. Put Jarvis to sleep and say **“Jarvis”**; confirm the wake acknowledgement path runs.
4. Say **“Hey Jarvis, test the cost panel”**; confirm the complete wake request is preserved.
5. Select Test mode and enable **Sleep after one Test response**.
6. Confirm the response is brief and Jarvis returns to sleep.
7. Select Normal and Full modes and compare the deterministic simulated responses.
8. Interrupt a simulated response with **Stop Jarvis speaking**.
9. Confirm all simulation cost fields remain `$0.0000`.
10. Confirm the idle countdown and auto-sleep still work.

## Minimal paid live acceptance

Switch to **Live OpenAI** only after simulation passes:

1. Use **Test mode**.
2. Wake Jarvis with **“Jarvis, confirm live mode.”**
3. Confirm one brief Cedar response.
4. Confirm the latest response, session, and today totals increase.
5. Repeat one typed Test-mode turn.
6. Confirm Test auto-sleep works after audible playback completes.
7. Review the OpenAI billing dashboard separately as the final account record.

Two or three brief live responses should be enough for acceptance. Do not repeat UI-only tests in live mode.

## Budget validation without meaningful spend

Use a temporary local `.env` threshold just above the existing local ledger total, or validate the budget logic through automated tests. Avoid intentionally spending up to a hard limit merely to test it live.
