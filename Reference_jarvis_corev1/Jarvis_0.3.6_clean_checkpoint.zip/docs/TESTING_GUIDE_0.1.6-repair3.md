# Testing Guide — 0.1.6-repair3

## Apply

1. Close Jarvis.
2. Extract the repair ZIP directly into the project root and approve file replacement.
3. Run `py -3.12 apply_0_1_6_repair3_patch.py`.
4. Start the development app with `npm run desktop`.

## Test a short preference confirmation

1. Wake Jarvis with a recognized voice.
2. Say: **“Jarvis, from now on refer to me as boss.”**
3. Jarvis should answer only: **“Got it, boss.”**
4. Continue talking and confirm that Jarvis may naturally use **boss**, but does not force it into every response.
5. Put Jarvis to sleep, wake him again, and confirm the preference remains active.

## Test several names

1. Say: **“You can also call me Chief or Captain.”**
2. Jarvis should give one short confirmation that mentions the added choices.
3. Open **Memory → People**, select your profile, and confirm all active forms appear under **Preferred forms of address**.
4. Use **Manage forms of address** to replace the list and confirm the saved values remain after reopening the profile.

## Test removal and reset

1. Say: **“Don’t call me Chief anymore.”**
2. Jarvis should answer: **“I won’t call you Chief anymore.”**
3. Confirm Chief is inactive while the other choices remain available.
4. Say: **“Just use my real name.”**
5. Jarvis should answer briefly and stop using all special names or titles.

## Test identity phrasing

1. With a confidently enrolled voice, ask: **“Who am I?”**
2. Expected form: **“You’re Tanner.”** It should not mention a recognizer, confidence score, local analysis, or system guess.
3. Temporarily raise the recognition threshold so the same voice is only a likely match, then ask again.
4. Expected form: **“You sound like Tanner, but I’m not completely sure.”**
5. Ask: **“How do you know?”** Jarvis may briefly mention the saved voice profile, but should still avoid a long technical explanation unless you explicitly request one.

## Test identity boundaries

1. Use an unknown or only-likely voice and say: **“Call me Boss.”**
2. Jarvis should not modify another person’s profile; it should say it needs to know which voice profile is yours first.
3. Type the same command in the composer.
4. The typed command should update the protected local-user profile.
5. Confirm that **Boss** appears as a form of address, not as an identity alias or canonical name.

## Regression checks

- Unknown-speaker enrollment offers still open **Memory → Voice Profiles** after an affirmative reply.
- Silent sleep commands still produce no assistant text or audio.
- Interruption still cancels only the old response and the next response remains audible.
- Exact Event & Provenance controls and person merge/undo remain functional.
- No private `.env` values are changed by the installer.
