# Testing Guide — 0.2.0-repair3 Reliable Action Routing

Use the already connected Google test account.

## Primary regression

Say exactly:

`Summarize my five most recent unread emails.`

Expected:

- The request remains one user transcript.
- Jarvis does not say that he lacks inbox access.
- Gmail is actually queried.
- Jarvis speaks a useful summary prepared from the connected-action result.
- The written result remains visible.
- Realtime does not independently answer the request.

Repeat with:

- `Find my recent emails from Google.`
- `Do I have any unread messages?`
- `What meetings do I have tomorrow?`
- `Show me my calendar events for tomorrow.`

Plural and singular wording should behave the same.

## Failure-boundary check

Temporarily disconnect Google and ask for unread emails.

Expected: Jarvis says Google is not connected and directs you to Connected Apps. He must not claim that inbox access is fundamentally unsupported.

Reconnect Google afterward.

## Non-action regression

Ask:

`Explain thermodynamics.`

Expected: normal conversation path; no Gmail/Calendar action or Connected Actions error.

## Existing 0.2.0 checks

After the primary regression passes, continue the existing Gmail draft/send and Calendar read/create/update/delete confirmation tests from `docs/TESTING_GUIDE_0.2.0.md`.
