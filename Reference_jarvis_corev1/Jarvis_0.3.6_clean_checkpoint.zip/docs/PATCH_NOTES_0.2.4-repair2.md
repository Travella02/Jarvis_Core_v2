# 0.2.4-repair2 — Voice-First Tasks

This repair makes task answers useful when the user is listening instead of watching the Jarvis window, and keeps short task follow-ups owned by Connected Actions.

## What changed

- Natural task questions now speak the actual task names instead of only announcing a count.
- With one task today, Jarvis says the task directly, for example: “You have one task today: Finish the ORVEX website.”
- Normal task questions are voice-first and do not force a visual card for a short/simple result.
- Explicit visual requests such as “Show me what I need to get done today” still render task cards while Jarvis gives a short spoken orientation.
- Follow-ups such as “What task is that?” remain inside the grounded local task system instead of falling through to ordinary Realtime.
- A single recent grounded task can be answered deterministically without another Luna planning call.
- Spoken output remains subject to the configured response-mode ceiling.

## Safety and persistence

No task data is migrated or deleted. Existing tasks, reminders, local memory, Google credentials, and `.env` are untouched.
