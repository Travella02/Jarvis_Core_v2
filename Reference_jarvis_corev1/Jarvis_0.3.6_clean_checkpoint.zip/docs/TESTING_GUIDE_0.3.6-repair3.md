# 0.3.6-repair3 — Reauth Handoff Testing

## Apply

Close Jarvis completely. Extract the repair ZIP into the project root and run:

```powershell
python .\apply_0_3_6_repair3_patch.py
```

Expected release label: `0.3.6-repair3 — Reauth Handoff`.

## Development test dependency

For a source/development `.venv`, install the canonical test extra once if needed:

```powershell
python -m pip install -e ".[test]"
```

This installs pytest/pytest-asyncio for development tests only; they are not Jarvis consumer runtime dependencies.

## Automated checks

```powershell
python -m pytest -q tests/test_authenticated_reauth_security.py tests/test_config.py tests/test_phase5_adversarial_security.py tests/test_permission_confirmation_security.py tests/test_permission_confirmation_api.py tests/test_permissions_api.py tests/test_browser_confirmation_security.py tests/test_release_consistency.py
npm run desktop:check
npm run desktop:test
```

## Live check

1. Launch Jarvis and open **Controls → Permissions & Security**.
2. Ensure a protection-lowering change requires browser password reauthentication (restart Jarvis first if the recent-auth window is still fresh).
3. Enter the bound account password successfully.
4. The identity-verified page should attempt to close its own tab automatically and Jarvis should continue to the exact native confirmation.
5. Approve or cancel the native prompt and verify the underlying setting follows that exact choice.
6. If the browser refuses automatic closing, verify the tab remains only on the harmless verified-success page with a manual-close fallback; do **not** treat browser close policy as authorization failure.
7. A second security change inside the recent-auth window must still skip password reentry but require its own exact trusted Jarvis confirmation.

## Failure conditions

Stop acceptance if the browser closes before successful password verification, a failed password page closes, browser completion itself changes a permission, the native exact-action confirmation is skipped, or repair3 uses Browser Control/native automation to force a tab close.

Do not commit or delete patch/backups until complete 0.3.6 live acceptance.
