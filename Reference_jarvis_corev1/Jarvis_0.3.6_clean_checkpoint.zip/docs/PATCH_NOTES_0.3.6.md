# 0.3.6 — Permissions & Security

**Date:** 2026-09-02  
**Required previous version:** 0.3.5  
**Status:** Candidate for live acceptance

## Purpose

0.3.6 establishes one coherent authorization and sensitive-data boundary before Jarvis begins Autonomous Tasks work. The language model may request an action, but it cannot grant itself authority, reinterpret a confirmation for a changed action, weaken Game Mode, or turn local UI state into Cloud authority.

## What changed

- Added a configuration-driven seven-level permission model: Observe, Safe automatic, Confirm once, Confirm every time, Authenticated confirmation, Restricted, and Forbidden.
- Added account + tenant + device scoped permission preferences, session grants, one-use grants, and privacy-safe audit records.
- Wired the central permission authority in front of real Browser Control, Computer Actions, Gmail, Calendar/Contacts, local file/folder, Memory, and Voice Profile/enrollment executors.
- Kept Game Mode as a separate non-overridable executor safety boundary and preserved Cloud-authoritative fail-closed checks.
- Replaced generic confirmations with exact challenge-bound confirmation. Challenges bind account, tenant, device, actor, session, permission, and action/resource fingerprint; they expire and are single-use.
- Preserved the executor transaction invariant: `consume exact challenge -> materialize one-use grant -> executor permission check consumes grant -> provider/executor executes`.
- Added purpose-bound authenticated reauthentication through the existing browser Account flow for authenticated confirmations and protection-lowering changes.
- Migrated consequential Browser, Gmail/Calendar Connected Actions, Memory deletion/protection, Voice enrollment, and Voice Profile deletion to exact confirmation.
- Added trusted desktop user-presence confirmation for native non-authenticated confirmations. Possessing a challenge ID or generating affirmative model text is not enough to authorize an action.
- Added complete trusted review of consequential actions. Long actions use a sandboxed scrollable Electron review window; actions too large to review safely fail closed rather than being truncated.
- Made runtime confirmation grants/challenges die on Core restart and on device-permission preference changes. Lowering protection requires the separate authenticated `security.change_protection` boundary.
- Hardened against forged local grants, replay, cross-account/tenant/device/actor/session reuse, Cloud-authority loss, autonomous/model self-authorization, and Game Mode bypass attempts.
- Added centralized sensitive-data hygiene for accidental persistence sinks: conversation/event JSONL, Memory-derived records/history, Core/Electron logs, diagnostics, Connected Actions durable state, Billing evidence, Cloud Sync/audit, tasks, and other content-bearing durable lanes.
- Passwords/passphrases, verification/recovery codes, API/OAuth/authentication secrets, private keys, payment-card/bank values, and similar credentials are sanitized or rejected before accidental persistence.
- Sensitive pending Connected Action arguments remain exact only in process memory. Durable SQLite receives a redacted marker; restart expires the action rather than reconstructing a changed transaction.
- Added bounded one-time cleanup for known legacy accidental sensitive artifacts, including secure SQLite deletion/WAL cleanup/compaction where appropriate. Intended secret authorities such as `.env`, encrypted secret stores, OAuth/provider stores, password hashes, browser state, and protected voice embeddings are preserved.
- Hardened Cloud/task protocol identifiers so caller-controlled opaque IDs are structurally constrained or stored as non-reversible references rather than being treated like ordinary secret-bearing content.
- Added the Controls → Permissions & Security workspace and current 0.3.6 release surfaces.

## Security guarantees targeted by this candidate

- The model, renderer, and ordinary local client cannot grant themselves consequential permissions.
- A confirmation for action A cannot authorize a modified action B.
- Stale, replayed, cross-scope, cross-session, and cross-device challenges fail closed.
- Challenge possession is not human confirmation; native confirmation requires trusted desktop user presence and authenticated confirmation requires purpose-bound account reauthentication.
- Confirm-once and one-use runtime capabilities do not survive Core restart or a relevant policy change.
- Restricted/Forbidden policy, Game Mode, Cloud authority, and autonomous restrictions remain stronger than any local grant.
- Lowering an existing protection setting requires authenticated authorization.
- Sensitive credential/payment values do not become ordinary conversation, Memory, log, diagnostic, audit, sync, or task storage.
- Secret authorities and user data are preserved rather than wiped by the hygiene migration or patch installer.

## Threat-model boundary

The trusted Electron-main-process attestation protects against a compromised renderer, model-generated continuation, or ordinary local HTTP client. It is not claimed to withstand a fully compromised operating system, administrator/debugger, or malicious replacement desktop binary. Cloud-authoritative operations continue to rely on server/account authority, and system-safety operations continue to fail closed independently of local UI state.

## Automated validation before packaging

Phase 5 adversarial security passed **23/23**. Permission/confirmation security passed **89/89** during hardening. Grouped Python validation passed across Accounts/Billing/Cloud/Permissions, Browser/Computer/Game Mode/Desktop, Connected Actions/Google/Tasks/Time/Web, Memory/context, Realtime/Speech/Text/Transcription/Voice response, runtime/build/interface, and all 14 Speaker Recognition cases. `npm run desktop:check` passed. The Node/Electron source suite passed **151/155**; the same four packaging-only tests are blocked in this source environment by missing `@electron/packager/dist/unzip` / `dist/win32` modules before Jarvis logic executes.

The final patch was independently reconstructed over the accepted clean 0.3.5 baseline and retested before live handoff. The reconstructed tree passed all 906 collected Python tests in bounded groups (plus 9 subtests), `desktop:check`, and 151/155 Node tests; the same four packaging-only Node cases are blocked by missing Electron Packager internal modules before Jarvis product logic. See `docs/0.3.6_PATCH_RECONSTRUCTION_VALIDATION.md`.

## Compatibility / preserved data

The patch overlays only manifest-listed source/config/test/documentation files. It does not replace `.env`, OAuth/provider secrets or tokens, local account/Cloud/Billing/task databases, Memory, Voice Profiles/embeddings, browser state, logs, user data, `.git`, or unrelated files. A timestamped rollback backup is created for every replaced source file.

## Live acceptance requirement

0.3.6 remains unaccepted until the verified patch is applied to the real project, live Permissions & Security workflows pass, and Tanner explicitly accepts it. Any fix before acceptance remains `0.3.6-repairN`.

## Live-acceptance repair history

- **0.3.6-repair1 — Windows Hygiene Startup:** the first real Windows launch found that `logging.FileHandler` could lock `logs/core.log` before the one-time legacy hygiene migration attempted its atomic rewrite. Repair1 runs that migration before durable Core logging, preserves retry/fail-safe behavior, and keeps alternate `create_app()` entry points protected. See ISSUE-323.

## Commit / tag rule

Do not commit merely because automated tests pass. After explicit live acceptance, remove temporary `apply_*`, `patch_files/`, patch loaders/ZIPs/staging/backups from inside the repository, retain permanent source/config/tests/docs/issues/manifest, inspect the final diff for secrets/generated files, and make the focused accepted commit. Do **not** create a Git tag.

- **0.3.6-repair2 — Trusted Security Session:** live testing showed that restoring several blocked permissions required full browser email/password reauthentication for every individual setting. Repair2 separates short-lived process-memory identity assurance from exact action authority: the signed-in identifier is pre-bound, one password proof can be reused for up to the configured short window, but every sensitive change still requires its own complete trusted Electron review and challenge-specific attestation. Recent-auth dies on Core restart/logout and never becomes a reusable permission grant. See ISSUE-324.
- **0.3.6-repair3 — Reauth Handoff:** live testing confirmed repair2's security-session behavior but found that the successful browser password page stayed open. Repair3 adds a safe best-effort standards-based close only after successful purpose-bound reauthentication, with a browser-policy fallback and no Browser Control/native automation bypass. It also declares pytest/pytest-asyncio as development-only test extras after the real checkout exposed the previously undeclared async-test plugin. See ISSUE-325 and ISSUE-326.

## Live acceptance repair — 0.3.6-repair4

- **0.3.6-repair4 — Clean Reauth Completion:** live repair3 testing confirmed Edge can intentionally keep an externally opened verified security tab alive. Repair4 keeps the safe best-effort close attempt but replaces diagnostic browser-policy wording with a normal success state: "Authentication approved. You may now safely close this browser tab and return to Jarvis." Exact trusted Jarvis approval remains the authorization boundary. See ISSUE-327.

## Live acceptance repair — 0.3.6-repair5

- **0.3.6-repair5 — Trusted Executor Confirmation:** live Browser `Always ask` testing found that user-raised ASK could mint an exact one-use grant that the automatic-level evaluation branch never consumed; safe Browser/Computer permission gates were also being rendered as ordinary conversation, so cancellation could fall through to another capability and prompts were mechanical. Repair5 resolves Browser/Computer device-policy confirmation directly through trusted native exact-action review, retries only the identical request, lets the real executor check consume the grant, terminates cancellation, and binds voice challenge scope to the live speaker lane instead of a cosmetic owner/Unknown label. See ISSUE-328.

## 0.3.6-repair6 — Steam Isolation

The first Repair5 Windows regression rerun found one host-dependent legacy Computer Actions test: a synthetic one-game Steam fixture also read the developer machine's real Steam registry/library and therefore returned 16 games. Repair6 isolates only that unit test from `winreg`; production Steam discovery remains unchanged and continues using the registry. See ISSUE-329 and `docs/TESTING_GUIDE_0.3.6-repair6.md`.


## 0.3.6-repair7 — Friendly Confirmation

Live Repair6 testing confirmed the Repair5 trusted executor boundary and one-use behavior, then exposed two consumer UX defects in the native permission surface: developer-style operation/argument detail was shown to ordinary users, and a voice-triggered prompt could leave an unrelated File Explorer/application window in foreground ownership. Repair7 keeps the exact challenge, trusted HMAC attestation, one-use grant, actor/session binding, and executor-owned consumption unchanged while rendering only short natural copy such as `Permission required. Allow Jarvis to open a new browser tab?`. Electron explicitly restores/foregrounds Jarvis before the native modal and returns focus to Jarvis after it closes. See ISSUE-330 and `docs/TESTING_GUIDE_0.3.6-repair7.md`.

## Live acceptance repair — 0.3.6-repair8

- **0.3.6-repair8 — URL Routing:** Repair7 live testing found that explicit web addresses such as `Open YouTube.com in a new tab` could be treated as named browser-result continuations or fall through to Computer Actions as local app/file requests. Repair8 gives explicit domains/URLs deterministic Browser Control ownership, direct HTTPS-normalized `navigate`/`tab_new` execution, and a defensive no-fall-through boundary while preserving trusted exact-action permission enforcement. See ISSUE-331.

### 0.3.6-repair9 — Trusted Interaction (live acceptance candidate)

Repair8 URL routing passed live testing. The next Gmail confirmation test showed that one desktop still transcribed and answered ordinary speech behind the trusted native permission modal even though spoken approval correctly could not authorize the send. Repair9 turns the native prompt lifetime into a conversation quarantine: prompt-time speech is discarded before normal chat, memory, routing, or response generation, while a narrow denial-only grammar can close the exact active prompt as Cancel through Electron's native dialog AbortSignal. Voice never receives an Allow/attestation path. Repair9 also replaces the decorative bottom `Answer continues — open Fullscreen` fade text with a real button and makes structured Jarvis result cards always eligible for the shared fullscreen reader. See ISSUE-332/333 and `docs/TESTING_GUIDE_0.3.6-repair9.md`.

### 0.3.6-repair10 — Regression Alignment (live acceptance candidate)

The first full real-checkout Electron rerun after Repair9 produced 161/164 because three historical regex/source-contract tests still required the pre-quarantine implementation shape. Repair10 changes only regression tests and documentation: barge-in assertions now require `!permissionQuarantined`, voice-turn assertions require quarantine-aware transcript registration, and authenticated reauth assertions require the trusted permission wrapper while still verifying Electron main owns native confirmation. Production Repair9 runtime code is unchanged. See ISSUE-334 and `docs/TESTING_GUIDE_0.3.6-repair10.md`.


## Repair11 — Conversation Continuity

Live testing on both laptop and desktop showed that a short follow-up could be labeled `Unknown speaker` and destroy an active Connected Action clarification. Repair11 preserves the existing action session for temporary Unknown clarification/edit turns while retaining strict reset on positively identified speaker changes. Unknown speech cannot authorize an attributed owner's pending execution. Trusted permission prompts are now completely voice-inert; Repair9's vocal-denial experiment was removed.


## Repair12 — Default Autonomy & Turn Stability

Permission labels are simplified, routine Default behavior remains autonomous while consequential actions retain stronger review, trusted-modal cancellation is silent, transient Unknown attribution may continue pending conversational decisions, and duplicate transcript suppression is scoped to a microphone turn so deliberate repeated phrases are preserved.


## Repair13 — Action Context & False VAD Stability

- Fixed transient `Unknown speaker` yes/no/send/cancel decisions incorrectly switching away from the active Connected Action session.
- Preserved strict reset for a positively recognized different speaker and kept trusted permissions as the final execution boundary.
- Debounced provider VAD before barge-in so a lone microphone-noise edge cannot immediately interrupt Jarvis.
- Added bounded transcript-less VAD recovery so noise cannot strand the UI in Thinking.
- See ISSUE-337.

## Repair14 — Single Confirmation & VAD Recovery

Live Repair13 testing showed two remaining acceptance defects. Routine Connected Actions could stack a native permission popup after Jarvis had already shown the exact action and received an explicit conversational `Yes`; and longer transcript-less VAD/noise could still survive the short debounce and strand the UI in Thinking. Repair14 makes the exact natural review the single confirmation for selected common Connected Actions under Default, lets trusted native approval persist **Always allow** only for policy-approved capabilities, keeps dangerous actions one-action-only/stronger, and derives persistence from trusted native attestation rather than renderer input. It also applies bounded no-transcript recovery to committed VAD turns. See ISSUE-338/339.


### 0.3.6-repair15 — Calendar Single-Confirmation Authority

Live Repair14 acceptance showed that Calendar deletion still stacked a native permission popup after Jarvis had already selected the exact event, displayed it, asked whether to remove it, and received an explicit `Yes`. Repair15 marks exact reviewed `calendar.delete` transactions as eligible for the same Default conversational confirmation bridge already used by Gmail send and Calendar write. Calendar delete remains non-persistable and `confirm_every_time`; `Always ask` still requires a trusted **Allow once** prompt, while Block remains fail-closed. Exact challenge, actor/session/action binding, one-use grant creation, and executor consumption are unchanged. See ISSUE-340.

### 0.3.6 Repair16 — Permission & Action Confirmation Separation

Repair16 separates capability permission from consequential-action approval. Persistable native permission prompts now expose **Cancel / Allow once / Always allow**. The Electron main process HMAC-binds both the exact challenge ID and exact choice, so renderer-controlled input cannot widen one-use authority into persistent authority. `Allow once` leaves the stored preference unchanged; `Always allow` persists capability permission only after the trusted/executor permission boundary succeeds.

`gmail.send`, `calendar.write`, and `calendar.delete` may be persistently allowed because their workflows retain a separate exact conversational action review. Consequently, `Always allow` removes repeated permission popups but does not remove Jarvis's `Want me to send it?`, `Want me to remove it?`, or equivalent exact review for consequential work. The policy catalog now rejects persistable `confirm_every_time` definitions unless this separate action-confirmation contract is declared. Stronger Block/authenticated/restricted/forbidden/system-safety/Game Mode boundaries remain unchanged. See ISSUE-341 and `docs/TESTING_GUIDE_0.3.6-repair16.md`.

## Repair17 — Blocked Action Preflight & Error Fidelity

An explicit `Block` now stops Connected Actions before unnecessary clarification/provider work whenever the operation is known. Planner-selected operations are rechecked before clarification, pending actions are rechecked before confirmation, and hard permission denials preserve the exact Permissions & Security message rather than degrading into generic Google/provider failures. The side-effect-free preflight never consumes grants; executor enforcement remains authoritative. See ISSUE-342 and `docs/TESTING_GUIDE_0.3.6-repair17.md`.
