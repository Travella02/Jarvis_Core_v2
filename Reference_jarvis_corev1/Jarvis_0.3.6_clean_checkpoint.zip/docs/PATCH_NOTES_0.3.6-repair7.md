# 0.3.6-repair7 — Friendly Confirmation

Repair7 is a live-acceptance UX/focus repair on top of the accepted Repair5 security architecture and Repair6 test isolation.

The permission dialog now shows short natural copy such as:

> Permission required. Allow Jarvis to open a new browser tab?

It no longer exposes operation tokens, JSON/serialized arguments, permission keys, or the long developer-style exact-action review during ordinary confirmation. The complete action remains exact-challenge-bound underneath and Core retains bounded review detail internally.

On Windows, Electron now explicitly restores, shows, foregrounds, and focuses the Jarvis main window before opening the native permission modal, then returns focus to Jarvis after the modal closes. This prevents an unrelated File Explorer/application window from becoming the accidental foreground owner of a voice-triggered confirmation.

Security behavior is intentionally unchanged: exact challenge → trusted desktop approval → one-use grant → executor consumes grant → execution. Cancel remains terminal, actor/action mismatch fails closed, and Cancel remains the default button.

See ISSUE-330.
