# Testing Guide — Jarvis_Real_Time 0.0.1-dev0

## Install

1. Keep the old `Jarvis Ultimate` project untouched.
2. Extract this patch package into the empty `Jarvis_Real_Time` folder Tanner already created.
3. Open PowerShell in that folder.
4. Run:

```powershell
py -3.12 apply_0_0_1_dev0_bootstrap.py
```

The installer verifies payload checksums, tests a staged copy, installs the files, creates `.venv`, reruns tests inside the virtual environment, and initializes a new Git repository on branch `main`.

## Automated test command

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Expected summary:

```text
Ran 7 tests
OK
```

The elapsed time may differ.

## Manual checks

1. Run the environment doctor:

```powershell
.\.venv\Scripts\python.exe scripts\doctor.py
```

Expected: every check reports `PASS`, the project is `Jarvis_Real_Time`, and the version is `0.0.1-dev0`.

2. Start the headless diagnostic:

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

Expected output includes:

```text
Jarvis_Real_Time 0.0.1-dev0
Core state: sleeping
Status: clean-core foundation is ready; Realtime voice is not implemented yet.
```

3. Inspect Git:

```powershell
git status
```

Expected: a new repository on branch `main` with the project files untracked and `.venv`, `.env`, patch payload, runtime data, logs, and ZIP files excluded.

4. Make the first accepted commit only after the tests above pass:

```powershell
git add .
git commit -m "0.0.1-dev0: initialize Jarvis Real Time clean core"
```

## Common failure symptoms

- **`Requested Python 3.12 was not found`:** Install Python 3.12+ and ensure the Python launcher is enabled.
- **Git check fails:** Install Git for Windows, reopen PowerShell, and rerun the installer.
- **A checksum error appears:** Re-extract a fresh copy of the ZIP; do not edit files inside `patch_files`.
- **Tests cannot import `jarvis`:** Run the command from the `Jarvis_Real_Time` project root.
- **A secret appears in Git status:** Stop before committing, remove it, and confirm it is covered by `.gitignore`. Never commit `.env`.

## Logs for support

This bootstrap does not create application logs. Copy only the terminal test output when reporting a failure. Do not send `.env`, credentials, private legacy memory, conversation logs, or raw audio.
