# 0.0.5 — Model Wake Repair

## Summary

This repair removes the inaccurate Windows speech-recognition path from the active Electron runtime. Jarvis now uses local voice-activity detection while sleeping, sends only a completed short utterance through the secure Python core for model transcription, and lets the Realtime model decide natural sleep intent through a local function tool.

## Changes

- Retired active Electron `System.Speech` process launch and local-speech IPC.
- Added local sleeping-state microphone VAD, pre-roll buffering, silence completion, duration limits, and PCM WAV encoding.
- Added `POST /api/wake/transcribe`, protected by the trusted loopback client header and server-owned API key.
- Added `gpt-4o-mini-transcribe` as the default wake transcription model.
- Preserved complete wake requests such as “Hey Jarvis, tell me a joke.”
- Added Realtime `sleep_jarvis` function calling for natural endings such as “That’s all, Jarvis” or equivalent unambiguous intent.
- Added a local “Of course, sir.” acknowledgement without requesting an additional provider response.
- Added wake-transcription cost accounting to the authoritative usage ledger and UI.
- Free simulation now uses manual Wake and Sleep so it remains provider-free.
- Browser speech recognition remains only as a non-Electron development fallback.

## Privacy and cost boundary

Silence is not continuously transmitted to OpenAI. The Electron renderer performs a simple local volume threshold and buffers audio only after speech begins. After speech ends, that bounded utterance is sent to the loopback Python core, which performs the authenticated transcription request. Utterances that do not contain Jarvis are discarded after transcription and do not open a Realtime session.

## Configuration

New optional `.env` settings:

```env
JARVIS_WAKE_TRANSCRIPTION_MODEL=gpt-4o-mini-transcribe
JARVIS_WAKE_VAD_THRESHOLD=0.018
JARVIS_WAKE_VAD_SILENCE_MS=750
JARVIS_WAKE_VAD_MIN_SPEECH_MS=250
JARVIS_WAKE_VAD_MAX_SPEECH_MS=12000
JARVIS_WAKE_VAD_PREROLL_MS=350
```

## Issue documentation

- `issues/ISSUE_028_WINDOWS_SPEECH_RECOGNITION_ACCURACY.md`

## Validation

- 92 Python tests passed.
- Electron main, preload, and Voice Lab JavaScript syntax checks passed.
- Doctor and secret-safe diagnostic passed.
- Wake transcription gateway, server endpoint, cost ledger, tool configuration, and active-runtime retirement tests passed.
- Installer rerun and private `.env` preservation were validated before delivery.
