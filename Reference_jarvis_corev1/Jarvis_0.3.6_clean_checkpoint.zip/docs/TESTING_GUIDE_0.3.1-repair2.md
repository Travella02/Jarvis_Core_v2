# 0.3.1-repair2 Live Testing

1. Search YouTube and play a result.
2. Say “Pause YouTube.” then “Keep playing.” then “Play YouTube.” — all should control the same video silently; “Play YouTube” must resume, not select/open another video.
3. Say “Put YouTube at half volume”, “Turn YouTube up to 75%”, then “Turn YouTube down to 5%”. The audible volume and YouTube’s own slider should agree and remain at that value through Jarvis sleep/wake.
4. Say “Go forward half a minute”, “Rewind the video ten seconds”, and “Start it over”. Each must affect only the remembered video tab; no other user tab may navigate or start the video.
5. Verify ordinary Web Intelligence with “What are the latest updates in Rocket League?”

Expected: successful observable media controls are silent; failures are spoken. No looping restart and no cross-tab media spillover.
