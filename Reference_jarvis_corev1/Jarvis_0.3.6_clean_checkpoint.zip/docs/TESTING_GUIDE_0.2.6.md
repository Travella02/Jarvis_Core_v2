# 0.2.6 — Computer Actions Testing Guide

## Install

Extract the 0.2.6 ZIP directly into the current Jarvis project root, allow Windows to merge/replace files, then run:

```powershell
py -3.12 .\apply_0_2_6_patch.py
```

Start Jarvis:

```powershell
npm run desktop
```

No Google reconnect, voice reenrollment, `.env` replacement, or manual executable-path configuration is required.

## Acceptance flow

### 1. Known Windows app

Say:

> Jarvis, open Discord.

Expected:

- Discord opens.
- Jarvis says a short confirmation such as `Opening Discord.`
- Jarvis does **not** ask where Discord is installed.

Repeat the request. The second launch should use the cached target and be faster.

### 2. App alias learning

Pick an installed application with more than one natural name. For example:

> Open Visual Studio Code.

Then later:

> Open VS Code.

Expected: both open the same application. The successful requested name is remembered locally for the recognized speaker.

### 3. Game discovery

Test at least one installed game from Steam or Epic, for example:

> Open Rocket League.

If the game is installed through Steam, Jarvis should prefer the Steam app manifest/launch URI rather than guessing at a buried game executable. Then try:

> Open RL.

Expected: the alias resolves to the same game after it has been learned (and common acronyms may work on the first request as well).

### 4. App Jarvis has never opened

Choose an installed application you have never asked Jarvis to launch.

> Open <application name>.

Expected: Jarvis searches Windows registrations/shortcuts/launchers first and, if needed, searches local drives. It should find and launch the app without asking you for the executable path.

### 5. File opening

Place a recognizable document in Documents or Downloads, then say something like:

> Open the Budget file.

Expected: the file opens in its Windows default application. Jarvis does not claim to edit or modify it.

### 6. Folder/project opening

Say:

> Open the ORVEX project.

Expected: if an ORVEX project/folder can be found, Windows opens the directory. Jarvis searches common user locations first, then fixed drives if necessary.

### 7. Ambiguous match safety

If the machine contains two similarly named apps, use a deliberately vague name.

Expected: Jarvis asks which one you mean instead of choosing an updater/helper or making an unsafe guess. Reply with the candidate name and it should open that one.

### 8. Unrelated conversation after clarification

After Jarvis asks which application you meant, ask an unrelated question such as:

> What is the meaning of life?

Expected: the app clarification must not hijack an obvious unrelated question.

### 9. Persistence

Close Jarvis completely and restart it. Repeat one or more aliases used earlier.

Expected: successful aliases and targets persist after restart.

### 10. Regression

Recheck the accepted high-value flows:

- `What do I have tomorrow?` still combines Calendar + Tasks/Reminders.
- Task/reminder times preserve the correct local wall clock.
- Gmail drafting still creates the real draft card.
- Speaker labels/identity still use the recognized person's name.
- Short/Normal/High/Full still act as spoken-length ceilings.
