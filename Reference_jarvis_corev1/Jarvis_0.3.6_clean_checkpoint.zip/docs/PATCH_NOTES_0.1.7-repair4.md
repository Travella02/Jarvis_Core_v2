# 0.1.7-repair4 — Focused Previews

This repair keeps long written answers compact inside the conversation while preserving the complete response in the fullscreen reader.

## Changes

- Detailed hybrid-answer cards are capped to the usable height of the conversation transcript instead of expanding across multiple chat viewports.
- When a complete written answer arrives, Jarvis aligns the beginning of that answer near the top of the transcript rather than jumping to its final paragraph.
- Overflow is hidden behind a subtle bottom fade, making it clear that more content is available without adding another internal scrollbar.
- The existing **Fullscreen** action still opens the exact complete answer, including all text hidden from the compact preview.
- Preview height recalculates when the window, workspace layout, navigation rail, or conversation-focus layout changes.
- Short responses and Full-mode Realtime answers retain the existing normal chat behavior.

## Compatibility

- Version remains `0.1.7` because this repairs the current unaccepted Self Awareness update.
- No API, model-routing, memory, voice-profile, private configuration, or cost-accounting behavior changed.

## Validation

- 282 Python tests passed.
- 73 source-available Node tests passed.
- Four unchanged Electron packaging tests require the complete project dependency tree; all 77 Node tests passed with that tree available.
- Desktop JavaScript syntax, doctor, diagnostic startup, and staged-runtime behavior were validated.
