# 0.3.0-repair3 — Autonomous Browser Continuation

The Browser Bridge transport and simple navigation were working, but advanced one-command research could stop after search because exact official URLs observed in page text were not accepted by the executor's navigation-grounding boundary. The extension also sometimes needed a manual reload after the Jarvis core restarted because Manifest V3 could suspend its reconnect timer.

This repair adds bounded observed-URL grounding, page-wide rendered links, authoritative-source continuation rules for current/latest research, post-click navigation settling, and a persistent extension reconnect backstop. It does not add synthetic mouse/keyboard control or weaken Game Mode.
