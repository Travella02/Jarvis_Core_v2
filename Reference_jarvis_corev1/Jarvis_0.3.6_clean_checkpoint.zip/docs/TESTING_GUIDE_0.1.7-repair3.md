# Testing Guide — 0.1.7-repair3

## Hybrid continuity

1. Select **Test**, **Short**, **Normal**, or **High**.
2. Ask: “Explain your complete architecture and capabilities in detail.”
3. Confirm Jarvis speaks one capped summary and naturally indicates that the full details are in the written answer.
4. Confirm the completed answer card begins with the exact words Jarvis spoke.
5. Confirm the detailed continuation follows after a paragraph break and does not restart with a duplicate overview.
6. Confirm no second Realtime voice answer begins.

## Full mode routing

1. Select **Full** while Jarvis is awake.
2. Ask the same detailed question.
3. Confirm Jarvis speaks the complete answer through Realtime.
4. Confirm no “Preparing the complete answer…” hybrid card appears, no separate text request is started, and Jarvis does not mention a written continuation.

## Fullscreen reader

1. Generate a detailed answer or any Jarvis message longer than the reader threshold.
2. Confirm a **Fullscreen** action appears on the answer card.
3. Open it and confirm the exact answer appears in a focused, viewport-filling, independently scrollable reader.
4. Close it using the close button, reopen it, then close using Escape.
5. Reopen it and close by clicking the backdrop.
6. Confirm returning to the conversation preserves the original card and scroll position.

## Failure fallback

Temporarily make the configured text model unavailable in a test environment. In a capped mode, Jarvis should keep the exact spoken summary as the written answer, without issuing a second Realtime response.
