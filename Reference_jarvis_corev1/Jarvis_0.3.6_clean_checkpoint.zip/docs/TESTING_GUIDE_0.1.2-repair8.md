# Testing Guide — 0.1.2-repair8 One-Pass Summary

1. Close Jarvis and apply the patch.
2. Start the development desktop with `npm run desktop`.
3. Say: `Jarvis, show me everything about ORVEX and give me a short summary.`
4. Confirm Memory Explorer opens and displays ORVEX.
5. Confirm Jarvis speaks exactly one concise sentence.
6. Confirm every clause adds a new detail.
7. Confirm Jarvis does not end by restating that ORVEX is a business, repeating the category, repeating the date, or repeating that no other details exist.
8. Say: `Jarvis, show me everything about ORVEX.` Confirm the display-only command remains silent.
9. Say: `Jarvis, show me and tell me about ORVEX.` Confirm standard narration remains grounded and does not add a duplicate closing recap.

Automated validation: 195 passing Python tests and 37 passing Node tests.
