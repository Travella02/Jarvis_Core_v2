# 0.3.5 — Billing & Entitlements Testing Guide

**Do not commit 0.3.5 until this live acceptance passes and the update is explicitly accepted.**

## Apply from the project root

Extract the patch ZIP into the committed clean 0.3.4 project root, then run:

```powershell
python .\apply_0_3_5_patch.py
```

The installer must report that the expected baseline is 0.3.4, create a timestamped backup for replaced files, verify the patch manifest, and finish with VERSION 0.3.5.

## Automated validation

Security-critical group:

```powershell
python -m pytest -q tests/test_billing_foundation.py tests/test_billing_cloud_authority.py tests/test_billing_metering.py tests/test_provider_gateway_security.py tests/test_realtime_cloud_security.py tests/test_payment_security.py
```

Computer/Game Mode regression:

```powershell
python -m pytest -q tests/test_computer_apps.py tests/test_game_mode.py
```

Release consistency:

```powershell
python -m pytest -q tests/test_release_consistency.py
```

Full Python suite (may be run in smaller deterministic groups if the environment has a command timeout):

```powershell
python -m pytest -q tests
```

Desktop validation:

```powershell
npm install
npm run desktop:check
npm run desktop:test
```

If exactly four `tests_js/alpha.test.cjs` packaging tests fail because `@electron/packager/dist/unzip` or `@electron/packager/dist/win32` is missing, restore/install the project Node dependencies and rerun before accepting the release. Do not reinterpret product-test failures as dependency failures.

## Start Jarvis

From a source checkout, start Jarvis with the desktop command only:

```powershell
npm run desktop
```

The Electron desktop prepares the development runtime and starts/supervises the local Core automatically. **Do not run `python -m apps.core` in a second terminal before `npm run desktop`**; both processes would compete for loopback port `8765`. If port `8765` is already occupied, stop the manually started Core/conflicting process and restart the desktop. Packaged customer builds likewise supervise their private Core automatically.

## Live acceptance

1. **Version / account gate** — Start signed out. Confirm the dedicated account gate appears and visible release surfaces show `0.3.5 · Billing & Entitlements`.
2. **Account continuity** — Sign in through the browser-managed flow. Confirm existing local data remains present and Account stays available after authentication.
3. **Device authority** — Confirm authorized devices render correctly. In development test configuration, prove the server-side device limit rejects a new device before issuing a session and that revoking a device frees the slot.
4. **Cloud Sync** — Sync Tasks & Reminders. Confirm normal 0.3.4 revision/conflict/tombstone behavior still works and forged local entitlement state cannot unlock Cloud Sync server-side.
5. **Normal voice lifecycle** — Wake with a natural phrase containing “Jarvis,” speak at least two follow-ups, sleep, wake again, and confirm context/lifecycle remain correct.
6. **Interruption** — Interrupt Jarvis during speech several times. Audio must stop promptly and the new turn must be understood.
7. **Luna / typed reasoning** — Send a normal typed request and confirm hosted-mode reasoning works without requiring a customer OpenAI API key.
8. **Web Intelligence** — Ask a current-information question. Confirm answer/source behavior remains grounded and the hosted route does not expose provider IDs, pricing, reservations, or credentials.
9. **Wake transcription** — Exercise a wake phrase. Confirm hosted mode does not require a desktop OpenAI key and wake transcription failures are surfaced rather than silently bypassing Cloud authority.
10. **Speech** — Exercise configured hosted speech. Confirm the customer desktop does not need an ElevenLabs key. If hosted speech settlement evidence is unavailable, the request must fail closed rather than inventing cost.
11. **Connected Actions** — Exercise an existing Gmail/Calendar planning flow. Confirm AI planning remains available through the Cloud-authoritative intelligence capability and external writes still retain their established confirmation requirements.
12. **Browser planning/control** — Exercise an accepted media or browser command plus one planner-driven browser action. Existing local execution remains functional while paid planning remains Cloud-authorized.
13. **Usage exhaustion hard stop** — In development billing configuration, exhaust available metered allowance. Repeat a provider-backed request and confirm it is rejected **before provider execution**.
14. **Top-up order/resume** — With test-only billing fixtures, confirm monthly allowance spends first, purchased top-up persists, and adding authorized test top-up allowance resumes permitted provider-backed work.
15. **Entitlement vs balance** — Give the test account abundant top-up allowance but remove the required plan capability. The operation must remain blocked.
16. **Subscription expiry** — Expire the authoritative paid period without verified renewal. Paid/cloud capability must fail closed; it must not silently create a new monthly period.
17. **Realtime forced hangup** — Start a hosted Realtime test session, remove trusted control, and verify Cloud requests hangup. If termination is ambiguous, the reservation must stay held/uncertain.
18. **Realtime restart recovery** — With an active durable test session, restart the Cloud process and verify startup recovery handles the lingering session before normal provider work is served.
19. **No local provider-key bypass** — Place plausible OpenAI/ElevenLabs keys in local development settings while running hosted customer mode. They must not grant paid/provider privileges or bypass authoritative balance/entitlement checks.
20. **Regression check** — Re-test at least one accepted Computer Action, one Browser media action, one Memory workflow, one task/reminder, and one speaker-recognition flow.

## Customer-facing billing truthfulness

The Account panel may show plan, subscription state, monthly usage percentage, reset/renewal date, device allowance, and neutral additional-usage availability. It must **not** display internal provider-cost micro-units, provider pricing/margins, reservation IDs, settlement evidence, ORVEX provider credentials, or synthetic development balances as customer dollars.

## Production-boundary reminder

0.3.5 does not connect real checkout or finalize commercial pricing. Do not live-test development payment simulation as though it charges a real customer. Production payment provider/webhook work and live Realtime failure validation remain separate gates before external production rollout.

## Before commit after acceptance

Delete the extracted `apply_0_3_5_patch.py`, `patch_files/`, the downloaded patch ZIP if it is inside the repository, and any other temporary patch loader/staging artifacts. Remove installer backups from the repository if they were created inside it. Keep permanent installed docs/issues/manifest. Then inspect `git status` and the staged diff for secrets/generated files before making the single accepted 0.3.5 commit. Do **not** create a Git tag.
