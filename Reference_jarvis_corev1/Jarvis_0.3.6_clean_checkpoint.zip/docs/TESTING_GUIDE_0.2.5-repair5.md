# 0.2.5-repair5 — Unified Agenda Testing Guide

## Primary live test — Calendar + Tasks/Reminders

Create or keep at least one Calendar event and one Task/Reminder on the same day. Ideally give both a time.

Ask:

> What do I have tomorrow?

Expected: Jarvis checks **both Calendar and Tasks/Reminders** and gives one combined answer. For example, if there is a 10 AM meeting and a 2 PM reminder, both should be mentioned in chronological order.

Repeat with:

> Do I have anything tomorrow?

Expected: the same unified behavior.

## Provider-specific regression tests

Ask:

> What’s on my calendar tomorrow?

Expected: Calendar only.

Then ask:

> What do I have to do tomorrow?

Expected: Tasks/Reminders only.

## Time regression

If `Call Tanner` is still set for 2 PM, confirm any unified agenda response also says **2 PM**, never 8 PM.

## Empty day

Use a day with no Calendar events and no Tasks/Reminders.

Expected: Jarvis naturally says you do not have anything that day.

## Calendar unavailable behavior

If Google is intentionally disconnected, a broad agenda question should still report verified local tasks and clearly say Calendar could not be included. It should not pretend the whole day is empty.
