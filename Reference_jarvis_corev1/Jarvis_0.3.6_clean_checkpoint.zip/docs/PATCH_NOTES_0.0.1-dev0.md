# Jarvis_Real_Time 0.0.1-dev0 — Clean-Core Bootstrap

- **Date:** 2026-07-26
- **Required previous version:** None; install into the new empty `Jarvis_Real_Time` project folder.
- **Purpose:** Freeze the legacy source, establish the clean repository, and create the smallest tested event/state foundation for the 0.0.1 Realtime Voice Lab.

## User-visible change

The new project now has a runnable headless diagnostic that reports the project version and authoritative sleeping state. It does not yet provide voice conversation.

## Added

- Clean Python package and proposed module boundaries.
- Core event contract and state machine foundation.
- Python 3.12+ configuration and environment template.
- Git and secret exclusions.
- Automated unit tests.
- Legacy migration inventory with frozen commit evidence.
- Architecture decision log and updated project handoff.
- Canonical architecture PDF under `docs/reference/`.

## Legacy archive findings

- Frozen commit: `7b7cc995628a70220745e1a820c9651444af06b1`.
- No substantive tracked working-tree changes were detected after CRLF/LF normalization.
- The archive contains a real `.env`, legacy `.venv`, logs, audio, runtime memories, and Git history. None of those private/generated artifacts are copied into the new repository.

## Known limitations and deferred work

- No OpenAI Realtime connection, WebRTC, audio devices, VAD, interruption, or voice selection yet.
- No UI, memory, tools, vision, or capability migration.
- `0.0.1-dev0` is a development checkpoint, not the completed 0.0.1 milestone.

## Rollback

This is an initial install. To roll back, delete the new `Jarvis_Real_Time` folder only. Do not delete or modify the frozen legacy `Jarvis Ultimate` project/archive.

## Tests run before delivery

```text
python -m unittest discover -s tests -v
```

The exact result is recorded in the release manifest after package validation.
