# 0.3.0-repair1 — Browser Access Installer

Repairs the 0.3.0 candidate installer so a legitimate committed `.env.example` difference does not block Browser Access. Runtime/source foundation hashes remain strict. The installer now backs up and idempotently merges only the Browser Access example keys while preserving all existing template content. The real `.env` and all user data remain untouched.
