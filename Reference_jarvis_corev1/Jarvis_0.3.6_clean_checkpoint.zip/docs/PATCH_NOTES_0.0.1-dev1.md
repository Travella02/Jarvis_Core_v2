# Patch Notes — 0.0.1-dev1

- **Project:** Jarvis_Real_Time
- **Version:** 0.0.1-dev1
- **Date:** 2026-07-26
- **Required previous version:** 0.0.1-dev0
- **Purpose:** Establish the first secure OpenAI Realtime WebRTC voice path without exposing the permanent API key to the browser client.

## User-visible change

Jarvis now has an isolated Realtime Voice Lab. Starting the Python core opens a local interface at `http://127.0.0.1:8765` where Tanner can choose a microphone, speaker, and built-in voice, connect through WebRTC, speak with Jarvis, send a typed test message, view streaming transcripts/provider events, mute the microphone, disconnect cleanly, and review basic handshake/turn latency.

This lab is intentionally not the final Jarvis desktop body. The interface uses browser technologies because OpenAI Realtime uses browser/Chromium WebRTC APIs. The production interface will still be an Electron desktop application; Electron embeds Chromium and can reuse this tested WebRTC client while the Python core remains a separate local service.

## Security and architecture

- The permanent `OPENAI_API_KEY` remains only in the local Python process and `.env`.
- The browser sends its SDP offer to the loopback-only local server.
- The server combines the SDP with server-owned session configuration and calls OpenAI `/v1/realtime/calls`.
- The backend sends a hashed, privacy-preserving local safety identifier rather than a raw user identifier.
- The server only binds to loopback addresses in dev1.
- Session creation requires a non-simple trusted-local header, reducing cross-site request risk.
- Provider/client events are validated, translated into typed Jarvis events, and written to an append-only local JSONL journal.
- Secrets and sensitive mapping fields are redacted before errors or events are persisted.
- The UI reports provider events; it does not own the authoritative Jarvis state machine.

## Files added

- `apps/core/server.py` — local FastAPI server, safe configuration routes, SDP session bridge, event ingress.
- `apps/desktop/lab/index.html` — temporary Realtime Voice Lab shell.
- `apps/desktop/lab/app.js` — WebRTC, audio devices, transcripts, typed test input, diagnostics, cleanup.
- `apps/desktop/lab/styles.css` — isolated lab styling.
- `jarvis/core/runtime.py` — validated provider-event to core-state bridge.
- `jarvis/intelligence/realtime.py` — provider-neutral session configuration and OpenAI call gateway.
- `jarvis/observability/event_journal.py` — append-only local event journal.
- `jarvis/security/redaction.py` — recursive secret redaction.
- `prompts/realtime_voice_lab.txt` — versioned Jarvis voice-lab persona.
- `tests/test_realtime_provider.py`
- `tests/test_realtime_runtime.py`
- `tests/test_redaction.py`
- `tests/test_server.py`

## Files changed

- `.env.example` — real dev1 settings template; no secret values.
- `VERSION`, `pyproject.toml` — dev1 version and runtime dependencies.
- `apps/core/__main__.py` — secure start command, diagnostic mode, local browser launch.
- `jarvis/core/config.py` — `.env` loading, validation, model/voice settings, secret-safe representation.
- `jarvis/core/events.py` — typed provider and response lifecycle events.
- `jarvis/core/version.py` — root-aware version lookup.
- `scripts/doctor.py` — dependency, prompt, and hidden-key diagnostics.
- Existing tests — dev1 version and direct-entry expectations.
- Project handoff and architecture decisions.

## Dependencies

- FastAPI
- HTTPX
- Uvicorn

The installer installs these into the existing `.venv`. No Node/Electron dependency is introduced yet.

## Automated validation

- `python -m unittest discover -s tests -v`
- Result: **26 tests passed**.
- Provider calls are mocked; no API credit was spent.
- JavaScript syntax checked with Node.
- Local server smoke-tested on loopback with a fake key and `/api/health`.

## Known limitations

- A paid live OpenAI Realtime connection cannot be acceptance-tested without Tanner's private key and account.
- This is a voice laboratory, not the final Electron UI.
- Wake-word detection, automatic sleep, full barge-in accounting, session rollover, permanent memory, tools, vision, and capability agents remain deferred.
- Browser audio-output selection depends on Chromium `setSinkId` support.
- The current transcript parser supports the documented Realtime transcript event families, but live provider event details must be verified during Tanner's first session.
- Event journaling is local JSONL only; rotation and durable database integration come in later core milestones.

## Compatibility and rollback

The patch requires `0.0.1-dev0` and Python 3.12+. The installer creates timestamped backups under `.patch_backups/`. If project validation fails, changed project files are restored automatically. Installed Python dependencies may remain in `.venv`, which is harmless and can be removed by recreating the virtual environment.
