# 0.3.6-repair14 Live Testing — Single Confirmation & VAD Recovery

Do not commit or clean patch artifacts yet. Apply Repair14 only over the exact `0.3.6-repair13` candidate.

## Automated checks

1. Run the Repair14 targeted Python permission/Connected Action tests.
2. Run the Repair14 targeted Electron/Node tests.
3. Run `npm run desktop:check`.
4. Run the normal 0.3.6 Python regression group and the full Electron suite in the real checkout before acceptance.

## Live test A — one natural confirmation under Default

1. Set **Gmail send** to `Default`.
2. Say `Draft an email to Tanner.`
3. Give a harmless body such as `Say hi.`
4. Jarvis must display the exact draft and ask whether to send it.
5. Say `Yes.`

**Pass:** the exact reviewed email sends once. There is no second native permission popup. Temporary `Unknown speaker` attribution on the short `Yes` must not destroy the action context.

## Live test B — Always ask can become Always allow

1. Set **Gmail send** to `Always ask`.
2. Prepare another harmless draft and say `Yes` to Jarvis's natural review.
3. The trusted native permission window must appear because the user explicitly selected the stricter mode.
4. Its positive button must read **Always allow**.
5. Click **Always allow**.
6. Confirm the email executes once and the Gmail send permission now reports `Always allow`.
7. Prepare/send one more harmless draft.

**Pass:** the later send still receives Jarvis's normal exact conversational review, but no permission popup appears. The popup must remain absent until the user changes the permission preference.

## Live test C — dangerous actions do not become persistent

Use a safe test path for a non-persistable permission such as a destructive/system-sensitive capability without actually destroying important data.

**Pass:** the native positive action is **Allow once** (or the stronger authenticated/restricted boundary), and no persistent `Always allow` preference is created.

## Live test D — renderer cannot request persistence

The real server must derive persistence from a valid trusted native attestation plus policy. There must be no `X-Permission-Persist-Allow` client/header path that lets renderer code upgrade approval scope.

## Live test E — false VAD cannot strand Thinking

1. Let Jarvis return to Listening, then exercise normal Speaking/Thinking behavior.
2. Create ordinary room/microphone noise without intentionally speaking. Include a noise event longer than the short Repair13 debounce if practical.
3. Do not provide a real transcript/utterance.

**Pass:** Jarvis may briefly react to VAD, but a transcript-less turn recovers automatically within the bounded recovery path and does not stay stuck in Thinking.

## Live test F — real barge-in still works

While Jarvis is speaking, deliberately interrupt with a clear request.

**Pass:** meaningful speech still interrupts promptly; Repair14's no-transcript recovery must not swallow a genuine transcript-backed interruption.
