# 0.1.0 — Desktop Alpha

## Summary

Jarvis_Real_Time can now be built as a normal Windows installer with a private bundled Python runtime. Installed users no longer need the source repository, a virtual environment, Node.js, npm, or a separate Python installation to run Jarvis.

## Added

- Squirrel.Windows setup executable configuration with Start Menu and desktop shortcuts.
- A build pipeline that stages the local core and private 64-bit Python 3.12.10 runtime, then converts both runtime trees into one verified archive for Electron packaging.
- First-run setup for the OpenAI API key, voice, wake profile, response mode, devices, budgets, startup, and notifications.
- Operating-system encryption for the stored API key through Electron `safeStorage`.
- Packaged data and log directories outside the read-only installation resources.
- Rotating local core-process diagnostics.
- Secret-redacted diagnostic export from the System workspace and tray.
- Read-only GitHub release checking without automatic installation.
- Installed-build version, runtime, path, and key-status visibility.
- Local Squirrel lifecycle handling for install, update, uninstall, and obsolete events.
- Windows build verification for the generated Setup executable, compact `app.asar`, and checksum-protected runtime bundle.

## Changed

- Version advanced from `0.0.9` to `0.1.0`.
- The packaged Electron process now verifies and extracts the one-file private runtime on first launch, then launches bundled `pythonw.exe` instead of creating a virtual environment on the user's computer.
- Packaged data and logs are stored under Electron's per-user data directory.
- The stale `jarvis.conversation` placeholder now describes its future responsibility accurately.
- Core stdout and stderr are captured to a rotating process log while development launches still mirror output to the terminal.

## Preserved

- Fast model-based wake.
- Natural Realtime conversation and interruption.
- Silent model-confirmed sleep.
- Cost controls and free simulation.
- Desktop Presence supervision, tray lifecycle, and startup controls.
- Orb state smoothing, responsive workspaces, and bounded conversation scrolling.
- Loopback-only local server and isolated Electron renderer.

## Build repair

- The runtime builder is pinned to Python 3.12.10 because later Python 3.12 security releases are source-only and do not publish Windows embeddable packages.
- The official archive SHA-256 is verified before extraction, and invalid cached downloads are discarded.

## Known alpha boundary

- The Windows Setup executable must be built and live-tested on Windows.
- The installer is not code-signed yet, so Windows may display an unknown-publisher warning.
- Update checking is informational only; automatic update installation is deferred.

## Automated validation

- 160 Python unit tests passed.
- 16 Node desktop tests passed.
- Electron, renderer, Python build scripts, doctor, diagnostic, and desktop-runtime staging passed.
- The native Squirrel installer and first-run microphone flow still require Windows acceptance testing.
## Pre-acceptance Windows build repairs

- The embedded runtime is pinned to official Python 3.12.10 with SHA-256 verification because later Python 3.12 security releases do not provide Windows embeddable binaries.
- Electron packaging excludes development-only trees, receives a single runtime archive instead of thousands of loose files, runs source/runtime preflight checks, and verifies that `app.asar` stays below 25 MiB.
- Windows finalization now emits a durable method-level trace, packages directly into `out`, and temporarily bypasses executable resource editing while the installer path is proven.

