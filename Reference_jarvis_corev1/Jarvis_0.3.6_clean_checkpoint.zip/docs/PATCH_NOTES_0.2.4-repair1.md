# 0.2.4-repair1 — Today Task Visibility

This repair fixes task day filtering so Jarvis's spoken task list matches the persistent Tasks workspace.

## What changed

- “What do I need to get done today?” now includes open undated backlog tasks that are available to work on today.
- Future reminder-only items are not incorrectly pulled into today's list.
- Reminder-only tasks are included on their actual reminder day, so “What reminders do I have tomorrow?” can find a reminder that has no separate due date.
- The task cards and spoken count use the same grounded list returned by the local task store.

## Example

With an undated task named “Finish the ORVEX website” and a reminder for tomorrow to call Tanner, asking what needs to get done today returns the website task instead of “You don’t have any matching tasks.”
