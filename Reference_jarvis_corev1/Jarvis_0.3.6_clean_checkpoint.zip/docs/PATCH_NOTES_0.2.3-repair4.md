# 0.2.3-repair4 — Calendar Grounding

This live-acceptance repair closes three Calendar continuity problems found while testing 0.2.3.

## Local-time truth
Jarvis could schedule the right instant in Google while saying and displaying the UTC wall-clock time. Ordinary Calendar requests now prefer the browser-reported user timezone unless the user explicitly requests UTC/GMT. Planner timestamps are converted before Jarvis speaks, renders the Calendar card, stores the pending action, or writes to Google.

## Clarification continuity
A short answer such as `To one hour.` used to fall through to ordinary Realtime after Jarvis asked whether a meeting should be 30 minutes or one hour. Jarvis now keeps a bounded two-minute Calendar clarification context in both the desktop and Connected Actions service. Duration/time/day/email answers return to the same Calendar workflow and still require a separate write confirmation.

## Exact event grounding for attendee edits
A contextual request such as `Add Austin to that meeting tomorrow` now binds the one exact recently grounded Calendar event before considering a fuzzy query produced by Luna. Existing attendees remain intact, the new attendee is resolved through the normal contact/Gmail recipient pipeline, and Jarvis proposes one update for confirmation.

## Humanized proposal wording
Duration clarification answers use the structured duration to say things like `Got it—one hour. Want me to update the meeting?` rather than claiming the provider has already changed.

## Safety
Calendar creates, updates, and deletes still require a separate explicit confirmation. This repair does not loosen the external-write safety boundary.
