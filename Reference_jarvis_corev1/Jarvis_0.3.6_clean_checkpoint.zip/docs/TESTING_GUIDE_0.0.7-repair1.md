# Testing Guide — 0.0.7 Sleep Playback Repair

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
node --check apps\desktop\lab\app.js
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Start Jarvis with `npm run desktop`.
2. Wake Jarvis and begin a normal conversation.
3. Say “That’s all, Jarvis.”
4. Confirm Cedar audibly completes the entire phrase “Of course, sir.”
5. Confirm the Realtime session closes only after the final word is heard.
6. Repeat with “Thanks, you can go back to sleep now.”
7. Repeat at least five times and confirm there are no clipped words or duplicate acknowledgements.
8. Confirm Jarvis returns to Sleeping and can be woken again immediately.
9. Confirm normal response speaking timers still stop promptly after ordinary responses.
