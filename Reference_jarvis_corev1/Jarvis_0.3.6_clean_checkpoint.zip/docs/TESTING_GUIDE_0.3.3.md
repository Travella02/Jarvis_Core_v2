# 0.3.3 — Runtime Reliability Testing Guide

## Automated validation

Run the focused release checks:

```powershell
python -m pytest -q tests/test_runtime_reliability.py tests/test_usage_ledger.py tests/test_environment_bootstrap.py tests/test_browser_websocket_runtime.py tests/test_release_consistency.py
npm run desktop:check
node --test tests_js/runtime_reliability.test.cjs tests_js/browser_access.test.cjs tests_js/account_foundation.test.cjs
```

## Live acceptance

1. Start Jarvis normally with `npm run desktop`.
2. Confirm the desktop reaches Home without asking for package-install commands.
3. Open Edge/Chrome with the Jarvis Browser Bridge already loaded and confirm `/api/browser/status` reports `connected: true` after the extension reconnects.
4. Say “Resume YouTube” and “Pause YouTube” and confirm Browser Control still works.
5. Open Insights → Usage & budget and confirm `Tracked paid calls`, `Text / Luna calls`, and `Realtime calls` are visible.
6. Have one short ordinary conversation and one Browser/Connected Action request. Confirm the counters increase in plausible lanes instead of counting Luna planner work as Realtime.
7. Open Account and confirm the accepted 0.3.2 signup/login/session behavior remains intact.
8. Confirm visible release labels show `0.3.3 · Runtime Reliability`.

## Development self-repair test (optional but valuable)

On a disposable development copy only, remove `websockets` from that copy's `.venv`, then start Jarvis. The desktop should detect the missing dependency and repair it automatically before core startup. Do not perform this destructive test on the only working environment.

## Acceptance boundary

Do not commit until live startup, Browser Bridge/Browser Control, account regression, and usage-attribution checks pass. Runtime Reliability intentionally does not attempt broad performance optimization in this release.
