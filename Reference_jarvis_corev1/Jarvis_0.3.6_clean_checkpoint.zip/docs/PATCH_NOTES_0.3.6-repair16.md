# Jarvis 0.3.6-repair16 — Permission & Action Confirmation Separation

Repair16 generalizes the permission UX discovered during Repair15 Calendar live testing. Capability permission and consequential-action confirmation are now explicitly separate decisions.

## Product rule

A permission answers **whether Jarvis may use a capability**. A separate action review answers **whether Jarvis should perform this exact consequential action**.

Examples:

- Browser navigation with `Always allow` may execute without another native permission popup.
- A reviewed email send can still ask `Want me to send it?` even when Gmail permission is `Always allow`.
- A reviewed Calendar deletion can still ask `Want me to remove it?` even when Calendar permission is `Always allow`.
- Future purchasing may use `Always allow` for shopping capability access while still requiring an exact order review such as total/merchant/item followed by `Want me to purchase it?`.

`Always allow` therefore removes permission friction; it does not become blanket authority to spend money, delete data, send messages, or make commitments without the action policy's own review.

## Trusted native choice

For a permission whose policy supports persistence, the trusted desktop prompt now presents:

- **Cancel** — deny this pending permission decision.
- **Allow once** — authorize only the exact current challenge; stored preference is unchanged.
- **Always allow** — authorize the exact current challenge and persist capability permission after the executor permission boundary succeeds.

A non-persistable permission presents only **Cancel** and **Allow once**.

The selected choice is bound into a new trusted HMAC message:

`jarvis-permission-confirm-v2:<challenge_id>:<choice>`

The renderer relays the choice and attestation, but cannot widen `allow_once` into `always_allow`: changing either value breaks the HMAC and Core rejects the request.

## Consequential Connected Actions

`gmail.send`, `calendar.write`, and `calendar.delete` are now eligible for persistent capability permission because they retain an independent exact action review. Their policy metadata requires both:

- `conversation_confirmation_allowed=true`
- `action_confirmation_required=true`

Under `Always allow`, future native permission prompts are suppressed, but the exact email/calendar action still remains pending until its separate action-level confirmation is satisfied.

The permission catalog rejects a future `confirm_every_time` permission that enables persistent authorization without declaring this separate action-confirmation contract.

## Stronger boundaries remain stronger

Repair16 does not make every permission persistable. Authenticated confirmation, restricted/forbidden operations, system-safety authority, explicit Block, and Game Mode remain fail-closed. `computer.process.force_terminate` and similar destructive system capabilities remain non-persistable until they have an independently designed action-review contract.

Executor-owned permission checks remain authoritative. Trusted UI creates the exact grant; the real executor still consumes the grant. Persistence is applied only after the trusted choice is verified and the permission boundary succeeds.

The Electron permission-modal source-contract test is aligned to the new three-choice trusted UI, and one pre-existing Web Intelligence barge-in source assertion is aligned to the current reason-tagged cancellation calls; these test-only updates do not change those runtime behaviors.

No account data, OAuth/provider secrets, local databases, memories, voice profiles, browser state, or Git history are migrated by this repair.
