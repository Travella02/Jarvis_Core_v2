# Testing Guide — 0.1.7-repair4

## Compact long-answer preview

1. Select Test, Short, Normal, or High.
2. Ask a question that produces a multi-screen written response, such as: “Explain how metals are produced and recycled in detail.”
3. Confirm Jarvis speaks one short summary.
4. When the written answer completes, confirm the transcript shows the **beginning** of the answer rather than jumping to its ending.
5. Confirm the answer card stops near the bottom of the conversation panel and does not make the chat several screens taller.
6. Confirm the lower edge fades out rather than adding a scrollbar inside the message.

## Fullscreen continuity

1. Click **Fullscreen** on the compact answer card.
2. Confirm the complete answer is present, including all content hidden by the chat preview.
3. Close the reader and confirm the compact preview remains at the same place in the conversation.

## Layout resizing

1. Generate a long answer, then resize the app window.
2. Switch among Conversation, Balanced, and Presence workspace layouts.
3. Collapse and expand the navigation rail and toggle conversation focus.
4. Confirm the answer preview continues to fit the available transcript height.

## Regression checks

- Short Jarvis replies should still auto-follow normally.
- Full response mode should still use one complete Realtime answer without the hybrid text companion.
- The fullscreen reader should still close by button, Escape, and backdrop click.
