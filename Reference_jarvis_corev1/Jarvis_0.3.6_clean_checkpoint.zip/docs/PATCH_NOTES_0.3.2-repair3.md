# 0.3.2-repair3 — SQLite Handle Closure

This repair keeps the 0.3.2 Account Foundation feature set and fixes deterministic SQLite connection cleanup on Windows.

## What changed

- `AccountStore` now uses one explicit connection context that commits/rolls back and always closes the SQLite handle in `finally`.
- All Account Foundation database operations use that close-safe context instead of relying on `sqlite3.Connection`'s transaction-only context manager.
- This prevents `accounts.sqlite3` from remaining locked until garbage collection on Windows and avoids handle accumulation in the long-running desktop process.
- Account tests now verify that every SQLite connection opened by the store is explicitly closed after normal signup/status/logout/login/profile/count operations.
- ISSUE-298 records the Windows `WinError 32` symptom, root cause, repair, and regression coverage.

## Version

The application version remains **0.3.2**. `repair3` is only the pre-acceptance repair label. All current version/release surfaces remain 0.3.2.
