# 0.1.6-repair5 — Actionable Identity & Quiet Wake

This acceptance repair makes person-memory permissions directly editable and keeps the sleeping orb visually asleep until the Jarvis wake keyword is actually confirmed.

## Actionable memory permissions

- The access-level pills beside Business, Household, Personal, and Shared are now real buttons rather than decorative status chips.
- Clicking a permission opens the existing in-app permission editor with that exact memory scope and current access level already selected.
- Saving refreshes the person profile immediately, so the displayed permission and stored permission remain aligned.
- The general **Set memory permission** control remains available for adding a new scope.
- Buttons include keyboard focus, hover feedback, titles, and accessible labels.

## Quiet speculative wake

- Sleeping speech detection may still begin a hidden Realtime preconnect to preserve low wake latency.
- The orb, status copy, desktop presence, and controls remain in the gray Sleeping presentation while the transcription is still determining whether the utterance contains “Jarvis.”
- The purple Waking presentation is announced only after the wake keyword is confirmed.
- A connection that becomes ready early remains hidden until confirmation, then promotes cleanly to Waking and Listening.
- Non-wake speech, failed hidden preconnects, and rejected wake candidates return or remain in Sleeping without flashing Waking, Listening, or an error state.
- Actual manual wake, confirmed voice wake, reconnection, and provider failures after confirmation retain their existing visible lifecycle behavior.

## Validation

- 264 Python tests passed in the source validation workspace.
- 67 JavaScript tests passed in the uploaded source-only environment.
- Four unchanged packaging-only JavaScript tests remain blocked because the source ZIP omitted `node_modules`; the installer requires all 71 tests in the complete project.
- JavaScript syntax checks passed.
- Regression coverage verifies both selected-scope permission editing and hidden preconnect presentation.
