# 0.1.9-repair4 — Natural Recall & Accurate Reader

This live-acceptance repair humanizes memory-grounded conversation and removes the remaining false Fullscreen triggers.

## Changes

- Ordinary recall answers state the remembered fact directly instead of sounding like a memory audit.
- Source questions use natural wording such as “You told me in a voice conversation on August 3, 2026.”
- Jarvis no longer volunteers phrases such as “that’s the evidence,” “not a guess,” “I can’t verify,” or unrelated execution limitations.
- Decision questions return actual decisions without mixing in goals, tasks, or broad project plans.
- Generic questions about an old corrected value ask one short clarification when the correction is not identifiable from the turn.
- Recall, source, history, open-work, relationship, and decision queries use one Realtime answer by default. The cheaper detailed companion is reserved for an explicit request for depth.
- Ambiguous memory turns expose only the clarification instruction, not a competing evidence package.
- The lower-cost written-answer model is instructed to produce plain text rather than visible Markdown markers.
- Fullscreen is based on actual preview overflow or substantial rendered height, not character count alone.

## Safety

- No memories, entities, facts, relationships, or source events are deleted.
- Provenance remains available internally and through Memory Explorer.
- Explicitly detailed memory questions can still use the hybrid written-answer path.
- Full-mode Realtime behavior remains unchanged.
