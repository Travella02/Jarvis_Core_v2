# Testing Guide — 0.1.9-repair3

## 1. Unique business resolution

Keep both the named user profile and any older local-owner placeholder profile in memory. Ask:

> What are we still working on for the business?

Expected:

- Jarvis resolves the reference directly to the only actual business.
- A person profile is not offered as another business.
- Jarvis answers once and does not ask an unnecessary clarification.

## 2. Genuine business ambiguity

Create two temporary business entities with similar recency, start a fresh conversation, and ask:

> What are we still doing for the business?

Expected:

- Jarvis asks one short clarification naming the two actual businesses.
- The clarification is spoken once and shown once.
- No detailed companion request, duplicate clarification paragraph, or Fullscreen action appears.

Remove or forget the temporary businesses after the test.

## 3. Short answer reader gating

Ask a question that produces a short answer or short clarification.

Expected:

- No Fullscreen action appears when the complete answer fits normally in the card and is below the reader threshold.

## 4. Long answer regression

Ask:

> Explain thermodynamics in detail.

Expected in Test, Short, Normal, or High mode:

- Jarvis speaks one capped summary.
- The complete written answer appears in one card.
- A faded compact preview and Fullscreen action appear only when more text is hidden.
- Fullscreen shows the exact complete answer.

Expected in Full mode:

- Jarvis uses one complete Realtime response without starting the separate detailed companion.
