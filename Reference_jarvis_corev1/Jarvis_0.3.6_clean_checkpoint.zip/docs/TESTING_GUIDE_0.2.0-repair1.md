# Testing 0.2.0-repair1 — Google OAuth Exchange

1. Close Jarvis and any existing Google authorization tabs.
2. Apply the repair and restart Jarvis.
3. Open **Controls → Connected apps** and click **Connect Google**.
4. Choose an approved Google test-user account and approve the requested access.
5. Expected browser result: **Google connected** with the account email.
6. Return to Jarvis and confirm the Connected Apps panel shows Google as connected.
7. Ask: `What's on my calendar tomorrow?`
8. Ask: `Summarize my most recent unread email.`

If Google still rejects the exchange, the browser page should now include a safe error identifier such as `invalid_client`, `invalid_grant`, or `redirect_uri_mismatch`. Do not reuse an old browser tab; start a new authorization attempt each time.
