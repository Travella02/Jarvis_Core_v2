# 0.0.7 — Sleep Lifecycle Repair

## Summary

This repair fixes the remaining spoken-sleep cutoff by separating sleep intent from final sleep state and using the WebRTC provider output-buffer stop event as the primary playback-completion signal.

## Changes

- Added a non-terminal `client.sleep.acknowledging` lifecycle event.
- Kept the local state machine active while Cedar speaks “Of course, sir.”
- Delayed final `client.sleeping` until playback is confirmed complete.
- Added `output_audio_buffer.started` / `output_audio_buffer.stopped` handling.
- Retained conservative analyser-based completion only as a fallback.
- Delegated live natural sleep intent exclusively to the model `sleep_jarvis` tool.
- Converted out-of-order lifecycle events into safe HTTP 409 responses rather than ASGI tracebacks.

## Validation

- 117 Python tests passed.
- 6 Node desktop tests passed.
- Electron, preload, and renderer syntax validation passed.
- Doctor, diagnostic, runtime staging, idempotence, and `.env` preservation passed.
