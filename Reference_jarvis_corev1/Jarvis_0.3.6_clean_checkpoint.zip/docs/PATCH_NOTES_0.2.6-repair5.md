# 0.2.6-repair5 — Launch Diagnostics

## What changed

This repair changes Windows app control from "launch + strict window proof" into two explicitly separate phases:

1. **Launch contract** — Jarvis executes the strongest Windows launch command it knows.
2. **Observation** — Jarvis watches for the app/process/window and records what actually happened.

A Windows shell handoff is no longer rewritten as a launch failure merely because the observer cannot immediately see a window. Jarvis will still try equivalent routes and a short direct-executable fallback before giving up.

## Exact shortcut execution

Start Menu `.lnk` files are now resolved into their real Windows launch contract: target executable, arguments, and working directory. Jarvis executes that exact contract instead of reducing a shortcut to a bare executable path. This matters for updater-mediated applications such as Squirrel/Electron installs where the shortcut may require arguments like `--processStart`.

## Launch diagnostics

Every application launch route now records a bounded local diagnostic entry containing:

- visible app name and requested alias,
- discovery source and launch kind,
- exact route/target,
- resolved command, arguments, and working directory when available,
- whether Windows accepted the handoff,
- whether a matching app window was observed,
- elapsed time and any local launch/observer error.

Only the newest 200 entries are retained locally. No diagnostic data is uploaded by this feature.

**Memory → Apps** now shows the latest launch diagnostic for each logical app, which gives us a concrete live signal instead of guessing why a specific Windows installation did not surface an app.

## Accuracy behavior

Jarvis only says `Opening <app>` when the app is actually verified (or when using an intentionally handoff-only trusted game/file/folder route). If Windows accepts one or more desktop-app launch commands but no visible window can be confirmed, Jarvis says that it sent the app to Windows but could not confirm it appeared and stores the exact attempts for diagnosis.

## Preserved behavior

- fast learned-app/alias resolution,
- Memory → Apps catalog,
- per-person aliases and alias forgetting,
- safe app closing,
- Steam/Epic URI launch behavior,
- no arbitrary discovered batch/script execution.
