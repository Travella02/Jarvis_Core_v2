# 0.2.9-repair2 Live Testing

1. Ask Jarvis why Game Mode is useful. Interrupt while he is speaking with: “Never mind, open Snipping Tool, please.” Jarvis should stop the old response and open Snipping Tool.
2. Repeat with: “Actually, never mind, Jarvis, sorry. Can you open Snipping Tool, please?” It should open without falling through to generic conversation.
3. While Jarvis is speaking, say: “Please don’t respond.” Jarvis should stop and remain Listening without producing a new reply.
4. Say: “You don’t have to say anything.” Jarvis should remain silent.
5. Say a sleep dismissal that transcription could render as: “That’s it, dervis.” Jarvis should sleep silently.
6. Stronger combined case: “That’s all, dervis. You don’t have to say anything.” Jarvis should sleep silently with no sign-off response.
7. Wake Jarvis again and verify interruption still works normally.
8. Regression: “Can you tell me how to open Discord?” must not open Discord.
