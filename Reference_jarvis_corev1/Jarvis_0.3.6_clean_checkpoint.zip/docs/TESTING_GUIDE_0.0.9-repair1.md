# Testing Guide — 0.0.9 Conversation Viewport Repair

## Automated validation

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Launch Jarvis with `npm run desktop`.
2. Open Home in the Conversation layout.
3. Create enough messages to exceed the visible transcript area.
4. Confirm the conversation card stays the same height while a vertical scrollbar appears inside the transcript.
5. Confirm the composer stays visible and anchored at the bottom of the card.
6. Scroll upward and allow Jarvis to continue streaming. Confirm the viewport does not jump to the bottom.
7. Confirm **Jump to latest** appears and returns to the newest message.
8. Test Balanced and Presence layouts; the transcript must remain internally scrollable.
9. Enter Conversation Focus and confirm the transcript fills the available window while retaining its own scroll behavior.
10. Resize through desktop, laptop, narrow, and compact widths. The panel must remain bounded and usable.
11. Confirm wake, interruption, typed messages, silent spoken sleep, simulation, cost totals, tray behavior, and X-to-quit remain unchanged.

## Acceptance boundary

Do not commit `0.0.9` until a long conversation scrolls inside the conversation card without stretching the Home page.
