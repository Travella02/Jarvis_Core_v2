# 0.2.4-repair6 — Grounded Speech

Repair5 fixed the task-time conversion on disk, but the live acceptance test still spoke **8 PM** for the existing **Call Tanner** reminder that the Tasks workspace correctly shows at **2:00 PM**. The uploaded runtime data proves the task itself is still stored correctly (`2026-08-13T20:00:00+00:00`, `America/Denver`) and that the **“What time?”** turn was routed through local Tasks/Connected Actions. The remaining problem was therefore downstream of task storage and routing.

## What changed

### Connected Action facts are now speech input, not Realtime reasoning input

Luna/local action logic remains responsible for deciding the factual answer. Realtime is only responsible for speaking that already-grounded answer.

For authoritative Connected Action replies, the desktop now creates an isolated Realtime speech response that:

- does **not** reuse the default conversation history;
- starts with an empty per-response context;
- has no tools available;
- requests audio output only;
- receives explicit speech-renderer instructions not to recalculate, reinterpret, or paraphrase dates/times/facts;
- carries metadata identifying the response as authoritative application speech.

This prevents a stale conversational statement such as **8 PM** from competing with the task service's grounded **2 PM** result while Realtime is generating the voice.

The same isolated speech path is used for the desktop's deterministic current-time/current-date answer so the model cannot replace the OS clock value with a capability denial or a different time.

### Interruption still works for isolated speech

Out-of-band speech responses are tracked by response ID. If the user interrupts one, Jarvis explicitly cancels that exact response and clears its audio buffer rather than relying only on default-conversation interruption behavior.

### Repair installation now guarantees a fresh runtime

The repair installer now closes development Jarvis Electron/core processes belonging to this project before replacing files. This removes another way an older Python core could remain bound to port 8765 after a repair and continue serving pre-repair behavior.

After a successful install, the installer also removes obsolete `apply_0_2_4*_patch.py` repair installers and the temporary `patch_files` payload. Historical patch notes/issues remain in the project, and the timestamped safety backup is preserved for rollback.

## What does not change

- The existing **Call Tanner** task/reminder is preserved; no task migration or recreation is required.
- Local memory, `.env`, OAuth tokens, Google connections, and user data are untouched.
- Luna remains the reasoning/action model. Realtime remains the voice layer for these grounded action replies.
- The visible Tasks workspace remains the same.

## Acceptance target

With the existing task still showing **Call Tanner — Thu, Aug 13, 2:00 PM**:

1. Ask: **“Is there anything I need to do tomorrow?”**
2. Jarvis should say: **“You have one task tomorrow: Call Tanner.”**
3. Ask: **“What time?”**
4. Jarvis should say: **“Call Tanner is set for 2 PM tomorrow.”**
5. Ask: **“When will you remind me?”**
6. Jarvis should still say **2 PM tomorrow**.
7. Ask: **“What time is it?”**
8. Jarvis should speak the actual computer-local time and must not claim it cannot see the clock.
