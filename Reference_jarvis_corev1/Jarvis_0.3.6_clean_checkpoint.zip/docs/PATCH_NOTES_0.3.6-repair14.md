# Jarvis 0.3.6-repair14 — Single Confirmation & VAD Recovery

Repair14 resolves two live-acceptance defects that remained after Repair13: routine Connected Actions could ask the user to confirm the same decision twice, and a longer transcript-less microphone/VAD turn could still leave Jarvis stranded in Thinking.

## Single confirmation authority

- `gmail.send` and `calendar.write` remain consequential permissions, but under **Default** Jarvis's exact natural review question is the one confirmation. Example: after Jarvis shows the exact draft and asks `Would you like me to send it?`, the user's `Yes` can authorize that reviewed draft without stacking a second native permission popup.
- **Always ask** remains an explicit stricter user preference. When it is selected, the trusted native prompt is still required.
- For permissions that policy explicitly marks as persistable, the trusted native approval button is labeled **Always allow**. A valid native approval for that exact challenge persists the permission as `Always allow`; future actions for that permission do not show the permission popup unless the user changes the setting again.
- Persistence is derived server-side from the trusted exact challenge and its native attestation. The renderer cannot turn a one-action approval into permanent authority with a header or client-side flag.
- Destructive/system-sensitive permissions such as Calendar delete, file delete, force terminate, authenticated security changes, credential access, financial transactions, and other restricted/forbidden capabilities remain non-persistable. Their trusted approval remains **Allow once** or stronger.
- Executor permission checks are unchanged. For conversationally confirmed routine Connected Actions, the exact challenge is still confirmed and the real executor check consumes the one-use grant. Under an existing `Always allow` preference, the executor evaluates the persisted policy directly.

## Transcript-less VAD recovery

- Repair13's 180 ms false-start debounce remains.
- Repair14 extends bounded recovery to **every VAD turn that produces no meaningful transcript**, including longer noise that survived the initial debounce and provisionally entered barge-in/Thinking.
- Transcript-less VAD state is cleaned up within the bounded recovery window and the UI returns to the real runtime state instead of remaining stuck in Thinking.
- Genuine transcript evidence cancels the false-VAD recovery path, preserving deliberate barge-in.

No account data, OAuth/provider secrets, local databases, memories, voice profiles, browser state, or Git history are migrated by this repair.
