# 0.1.4 — Proactive Memory Testing Guide

## Automated validation

The release installer runs the full Python and Node test suites, syntax checks, diagnostics, and desktop-runtime staging. Final passing counts are recorded in `RELEASE_MANIFEST.json`.

## Acceptance flow

1. Start Jarvis with `npm run desktop`.
2. Tell Jarvis: `We need to file the ORVEX trademark.`
3. Tell Jarvis: `Remind me to follow up with Kenleigh tomorrow.`
4. Open **Memory → Proactive** and select **Refresh now**.
5. Confirm both items appear with source evidence, priority, confidence, and status.
6. Open an item and verify Jarvis can explain the exact originating memory.
7. Snooze one item and confirm it leaves the active inbox.
8. Mark another complete, then reopen it and verify the audit history remains.
9. Ask about ORVEX and confirm relevant pending work is available as context without unrelated reminders.
10. Restart Jarvis and confirm proactive state persists.

## Restraint checks

- Jarvis must not claim an inferred pattern is confirmed.
- A dismissed or snoozed item must not immediately resurface.
- Assistant-authored suggestions must not become user commitments.
- Jarvis must not perform an external action merely because it detected an open item.
