# Jarvis 0.3.6-repair17 — Blocked Action Preflight & Error Fidelity

Repair17 fixes the final Block-path UX regression found during Repair16 live acceptance. An explicit permission denial is now treated as user intent at the earliest safe point, rather than allowing Jarvis to continue collecting action details and later describing the denial as a Google/provider failure.

## Product rule

`Block` is terminal for the matching capability. Jarvis should stop the action immediately, clearly state that Permissions & Security blocked it, and avoid unnecessary provider work. It must not ask follow-up questions for an action the user has already disabled.

## Side-effect-free preflight

`PermissionService.preflight_denial(...)` mirrors only hard denial conditions: explicit user Block, forbidden/restricted policy, cloud-authority verification, Game Mode safety, and autonomous-execution restrictions. It does **not** audit, create challenges, or consume one-use/session grants. The executor still calls the normal authoritative permission check immediately before side effects.

Connected Actions uses this preflight:

- before Google connection/planner work when an explicit Calendar create/update/delete operation is deterministically known;
- immediately after the planner selects any concrete permission-owned Connected Action operation, before returning a clarification;
- on exact pending actions before confirmation/continuation.

`calendar_schedule` also maps to `calendar.write` for preflight so a blocked scheduling request cannot perform availability work merely to discover later that creation is disabled.

## Error fidelity

A hard `PermissionGateError` now returns a `blocked` action result with the real Permissions & Security message. It is not passed through generic provider failure wording. A blocked pending action invalidates its stale challenge and becomes terminal. The desktop also treats `blocked` as a terminal Connected Action state.

## Security invariant

Preflight never grants permission and never weakens Repair16. `Allow once`, `Always allow`, native trusted attestation, separate consequential-action review, and executor-owned enforcement remain unchanged. Preflight can only stop work earlier; it cannot authorize work.

See ISSUE-342 and `docs/TESTING_GUIDE_0.3.6-repair17.md`.
