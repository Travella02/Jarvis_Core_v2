# 0.1.6-repair1 — Speaker-Aware Responses & Event Controls

This acceptance repair connects local speaker recognition to the actual Realtime response boundary, adds recognition to the wake path, and replaces non-working Exact Event & Provenance browser dialogs with working in-app controls.

## Speaker-aware Realtime responses

- Provider-default and semantic VAD still detect speech and interruptions, but the desktop client now owns response creation after each voice turn.
- Local voice recognition resolves before `response.create`, so the model receives the same speaker result that durable memory receives.
- Recognized matches include person name and confidence in response-specific instructions.
- Likely matches are explicitly uncertain; low-confidence speech remains Unknown speaker.
- Voice matching remains attribution only and never grants access or authenticates a user.
- Questions such as “Do you know who I am based on my voice?” can now be answered from the local match rather than contradicted by a generic capability disclaimer.

## Speaker identity from wake

- The bounded wake WAV is recognized locally in parallel with wake transcription.
- The opening wake memory uses the recognized person when confidence passes the profile threshold.
- The first wake response receives the speaker result, including a wake utterance that contains only “Jarvis.”
- Recognition does not add a second always-on recording path and does not retain raw wake audio as an enrollment sample.

## Working Exact Event & Provenance controls

- **Edit exact text** opens an in-app correction form.
- **Correct speaker** selects a person profile and writes structured attribution history.
- **Move category** opens a category-path editor.
- **Set privacy** opens a bounded privacy selector.
- **Delete memory** opens a reversible deletion confirmation form.
- Importance and active/outdated/incorrect controls remain immediate persisted actions.
- Browser `prompt` and `confirm` dialogs are no longer used in the exact-event workflow.

## Validation

- 247 Python tests passed.
- 60 Node tests passed.
- JavaScript and Python syntax checks passed.
- Doctor and core diagnostics passed.
- Desktop-runtime staging passed.
- Private `.env` preservation verified.
