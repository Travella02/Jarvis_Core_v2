# Jarvis 0.3.6-repair15 — Calendar Single-Confirmation Authority

Repair15 resolves the remaining duplicate-confirmation defect found during live Calendar deletion testing on the accepted Repair14 checkpoint.

## Live symptom

Jarvis correctly identified the exact calendar event and asked a natural destructive-action review question such as `Want me to remove 0.3.6 Permission test from your calendar?`. After the user answered `Yes`, the trusted desktop still opened a second `Permission required. Allow Jarvis to delete Calendar events?` prompt.

That duplicated the same user decision and made a normal Calendar workflow feel like two independent assistants were asking for approval.

## Repair

- `calendar.delete` now explicitly opts into Repair14's exact-review conversational confirmation authority under **Default**.
- The user's affirmative answer to Jarvis's exact reviewed delete/cancel proposal is the one user-facing confirmation for that exact pending event.
- The underlying security chain is unchanged: exact pending action -> exact permission challenge -> one-use grant -> real Calendar executor consumes the grant -> provider deletion.
- Calendar deletion remains **non-persistable**. `user_can_always_allow` stays false; this repair does not create an `Always allow` path for event deletion.
- **Always ask** remains stricter than Default and still requires the trusted native permission surface for every Calendar delete action.
- **Block** and policy changes remain fail-closed; conversational confirmation is eligible only while the device preference is exactly `Default`.
- Modified, stale, replayed, wrong-session, wrong-actor, or already-completed pending actions cannot reuse the reviewed confirmation.
- Calendar create/update continue using the already-accepted Repair14 single-confirmation path; this repair does not weaken their executor permission checks.
- Two stale release-consistency text assertions from Repair12/13 are aligned to the already-existing quoted/hyphenated test text; this is test-only and changes no runtime behavior.

No account data, OAuth/provider secrets, local databases, memories, voice profiles, browser state, or Git history are migrated by this repair.
