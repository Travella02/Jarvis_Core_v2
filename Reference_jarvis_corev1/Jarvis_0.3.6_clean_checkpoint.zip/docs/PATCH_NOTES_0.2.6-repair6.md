# 0.2.6-repair6 — Instant App Index

## Why this repair exists

Live Computer Actions testing showed two remaining usability problems:

1. A common request such as **“Open Chrome”** could take roughly twenty seconds because Jarvis rediscovered Windows applications after the request instead of already knowing what was installed.
2. Windows can expose one logical application under several names/routes (for example **Google Chrome** and **chrome**) while a fuzzy neighbor such as Microsoft Edge is also present. That technical duplication could trigger an unnecessary clarification instead of opening the obvious app.

## What changed

### First-run/background app inventory

Jarvis now builds a persistent local application index as soon as Computer Actions starts. Indexing is phased so the useful catalog is published immediately rather than waiting for slower sources:

1. App Paths, installed-program registry metadata, Start Menu/Desktop shortcuts, PATH, Steam, and Epic routes.
2. Windows Start Apps/UWP enumeration in the background.
3. A bounded common-install-root inventory to fill gaps for desktop programs that do not register themselves cleanly.

The foreground conversation never waits for the slow inventory phase. The index is stored locally and reused after restart.

### Incremental refresh instead of repeated full discovery

The cheap Windows sources refresh on startup. The broader common-install inventory is reused for 24 hours and refreshed in the background when stale. If a newly installed or obscure application is not already indexed, the existing targeted/deep discovery path remains a fallback and its successful result becomes part of the catalog.

### Smarter logical-app identity

Vendor-branded and executable-style representations of the same application are collapsed before ambiguity handling. For example, **Google Chrome** and **chrome** resolve as one logical app. Microsoft Edge remains a distinct app.

An exact canonical/automatic alias now beats a merely fuzzy neighboring app. Jarvis should only ask which app the user means when two genuinely distinct logical applications plausibly own the requested name.

### Automatic aliases and typo tolerance

The app catalog now learns additional safe automatic names from:

- canonical display names,
- vendorless names,
- executable names,
- compact names/acronyms where safe,
- resolved launch-command executable names.

Common one- and two-edit misspellings are matched conservatively at request time rather than permanently generating a large collision-prone list of fake aliases. Explicit user-taught aliases remain person-specific, higher priority, and reversible.

### Memory → Apps indexing status

Memory → Apps now reports whether the local app index is ready or which background indexing phase is still running. Known apps can already launch while later phases continue.

## Safety and boundaries

- No arbitrary `.bat`/`.cmd` deep-discovered scripts become apps.
- Deep fixed-drive search remains a fallback for unknown targets, not the normal launch path.
- User-created aliases are not replaced by automatic aliases.
- Ambiguity is still surfaced when genuinely different applications remain plausible.
- Application launch/close behavior and launch diagnostics from repair5 remain intact.
