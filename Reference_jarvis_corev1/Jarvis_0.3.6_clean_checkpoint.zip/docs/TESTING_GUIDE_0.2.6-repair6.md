# 0.2.6-repair6 — Instant App Index — Live Test

## Install

Close Jarvis, extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, choose merge/replace, then run:

```powershell
py -3.12 .\apply_0_2_6_repair6_patch.py
```

Start Jarvis:

```powershell
npm run desktop
```

No Google reconnect, `.env` edit, voice reenrollment, task recreation, or app-alias recreation is required.

## 1. First-run index

Open **Memory → Apps** shortly after Jarvis starts.

Expected:

- Jarvis can show that app indexing is happening in the background.
- The known-app count should grow without blocking the conversation.
- The status eventually reports the local app index as ready.

## 2. Chrome disambiguation

Say:

> **Open Chrome.**

Expected:

- Google Chrome is selected directly.
- Jarvis must not ask whether you meant `Google Chrome`, `chrome`, or Microsoft Edge.
- Jarvis-side resolution should be quick; only Windows/Chrome startup time should remain.

Close Chrome and say **Open Chrome** again. The second request should use the persistent local catalog without a discovery scan.

## 3. Restart persistence

Completely quit Jarvis, start it again, then immediately say:

> **Open Chrome.**

Expected: the already indexed app resolves from local memory immediately while any background refresh continues independently.

## 4. Typo tolerance

Try a small natural misspelling such as:

> **Open Chorme.**

or another one/two-character mistake for an installed app.

Expected: if one indexed app is the clear match, Jarvis opens it without asking. If two genuinely distinct apps are similarly plausible, clarification remains appropriate.

## 5. Existing app controls

Verify:

> **Open Spotify.**

> **Close Spotify.**

Then teach and forget an alias:

> **Music is another name for Spotify.**

> **Open music.**

> **I no longer want music as a nickname for Spotify.**

Explicit user aliases must remain person-scoped and reversible.

## 6. Unknown/obscure app fallback

Ask Jarvis to open an installed app that is not visible in Memory → Apps.

Expected: Jarvis may perform targeted discovery once, stores the successful route, and subsequent requests are fast. It should never ask the user to provide an executable path.
