# 0.0.6 — Desktop Presence Repair 1

## Summary

Repairs Windows Node-test validation for the unaccepted `0.0.6 — Desktop Presence` update. The six Node tests passed, but Node 24 used a reporter format that the installer did not recognize.

## Changes

- Forces `npm run desktop:test` to use the deterministic TAP reporter.
- Parses both TAP and spec reporter summaries.
- Validates total, passed, and failed test counts.
- Decodes subprocess output as UTF-8 to avoid Windows mojibake where possible.
- Retains the complete Desktop Presence update because the original installer rolled it back.
- Adds ISSUE-040 to the recruiter-friendly issue portfolio.

## Safety

- Private `.env` contents remain untouched.
- Installer rollback remains active for genuine test or validation failures.
- No paid OpenAI request is made during installation.
