# 0.1.7 — Self Awareness Testing Guide

## Install

1. Commit the accepted `0.1.6 — Speaker Recognition` state.
2. Close Jarvis completely.
3. Extract the `0.1.7` ZIP directly into the `Jarvis_Real_Time` project root and allow files to merge.
4. Run `py -3.12 apply_0_1_7_patch.py` from the project root.
5. Start Jarvis with `npm run desktop`.

## Acceptance flow

### Self-knowledge

Ask:

- `Who are you?`
- `What version are you running?`
- `How are you built from the inside out?`
- `What can you do for me right now?`
- `What are your limitations?`
- `Can you send an email right now?`
- `Can you search the web right now?`

Expected:

- Jarvis identifies himself and the running version accurately.
- Available features are stated as available.
- Missing integrations are stated plainly without pretending an action occurred.
- Jarvis distinguishes helping draft or plan from actually sending or executing.

### Dual-channel answers

1. Set response mode to **Test**.
2. Ask: `Explain who you are, how your architecture works, everything you can currently do, and your limitations in detail.`
3. Confirm the spoken response is one short summary within the Test limit.
4. Confirm a separate `JARVIS · DETAILED ANSWER` appears with a complete written explanation.
5. Repeat in **Short**, **Normal**, **High**, and **Full**.

Expected:

- Spoken length changes with the selected mode.
- The written answer remains detailed in every mode.
- The written answer is not read aloud.
- The detailed bubble preserves headings and line breaks.

### Short-turn protection

Say:

- `Thanks.`
- `Are you there?`
- `What is my name?`
- `From now on call me Boss.`

Expected: each remains a single short response with no unnecessary detailed companion.

### Interruption and lifecycle

1. Ask a long-form question.
2. Interrupt the spoken summary.
3. Confirm no delayed detailed answer appears for the interrupted turn.
4. Ask again and allow the written answer to begin.
5. Press **Stop** or start speaking while it is writing.
6. Put Jarvis to sleep and wake him again.

Expected: the current response cancels cleanly, no stale text leaks into the next turn, and wake/sleep behavior remains unchanged.

### Simulation

Switch to Local simulation and ask a detailed question. Confirm a simulated spoken-summary bubble and simulated detailed-answer bubble appear with zero API cost.
