# 0.3.5-repair1 — Billing Upgrade Continuity

**Date:** 2026-09-01  
**Required previous version:** `0.3.5` candidate  
**Application version remains:** `0.3.5`  
**Status:** Live-acceptance repair candidate

## Purpose

Repair the two issues found during the first real 0.3.5 live startup without weakening the Cloud-authoritative Billing design:

1. a valid 0.3.4 account/session could survive the upgrade while the new separate Billing database had no authoritative row for that account;
2. the 0.3.5 testing guide instructed developers to start Core manually before Electron even though Electron already owns and supervises Core.

## What changed

### Existing-account Billing reconciliation

- Added an idempotent Cloud-side Billing reconciliation/backfill boundary for authoritative active accounts that predate Billing.
- Existing Billing rows are never reprovisioned by reconciliation, preserving monthly consumption, purchased top-ups, subscription state, reservations, settlement history, and other ledger authority.
- The development Cloud Vault runs reconciliation at startup using only the server-owned synthetic development plan fixture.
- Authenticated local/hosted transport paths also ensure Billing state before Cloud capability/billing work, covering long-lived sessions that cross an upgrade boundary.
- If trusted provisioning is unavailable, Billing fails with a controlled unavailable response rather than an uncaught `KeyError`.
- The desktop still cannot choose account/tenant authority, plan, device limit, billing period, allowance, balance, or settlement state.

### Desktop/Core startup ownership

- Corrected the permanent 0.3.5 testing guide: source checkout startup is `npm run desktop` only.
- Electron now probes loopback port `8765` before spawning its supervised Core.
- If the port is already occupied, Electron records a `core_port_conflict` and stops instead of repeatedly spawning/restarting Core.
- Recovery guidance now explains how to stop a manually started `python -m apps.core` process or other port conflict.

## Files materially changed

- `jarvis/sync/vault.py`
- `jarvis/sync/development.py`
- `jarvis/sync/transport.py`
- `apps/cloud_sync/server.py`
- `apps/desktop/electron/main.cjs`
- `apps/desktop/electron/recovery.html`
- `docs/TESTING_GUIDE_0.3.5.md`
- repair notes/testing/handoff/manifest
- Billing authority and Electron regression tests
- ISSUE-311 and ISSUE-312 documentation/index

## Security notes

This repair does **not** create a client-side default plan or balance. Missing Billing state is repaired only from trusted Cloud/server policy. A modified desktop still cannot manufacture paid privileges, provider allowance, tenant authority, or settlement.

## Rollback

The repair installer backs up every replaced file before changing it. If repair1 fails live acceptance, stop Jarvis and restore the reported `0.3.5-repair1_<timestamp>` backup. Do not delete account/Billing databases as part of source rollback unless a separate, explicit data-migration rollback requires it.

## Acceptance state

Do not commit yet. After applying repair1, rerun the targeted automated checks and continue the 0.3.5 live acceptance sequence. Any further fixes remain `0.3.5-repair2`, `repair3`, etc. until 0.3.5 is accepted. No Git tag.
