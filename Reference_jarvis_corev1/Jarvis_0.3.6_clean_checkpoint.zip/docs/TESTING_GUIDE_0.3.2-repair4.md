# 0.3.2-repair4 — Account Navigation Testing Guide

## Automated check

Run:

```powershell
node --test tests_js/account_foundation.test.cjs
npm run desktop:check
python -m pytest -q tests/test_accounts.py tests/test_account_api.py tests/test_release_consistency.py
```

Expected: Account Foundation Node navigation tests pass, desktop syntax validation passes, and the focused Python account/release suite remains green.

## Live acceptance

1. Start Jarvis with `npm run desktop`.
2. Click **Account** in the left rail.
3. Confirm the Account workspace remains visible and does not return to Home.
4. Click Home, Controls, Tasks, Insights, Memory, System, then Account again and confirm each tab selects normally.
5. Continue the Account Foundation signup/login acceptance sequence.

Do not commit 0.3.2 until live acceptance passes.
