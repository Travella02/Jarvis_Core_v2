# 0.2.4 — Tasks & Reminders Testing

## Apply

Extract the release ZIP directly into the project root, then run:

```powershell
py -3.12 apply_0_2_4_patch.py
```

Start Jarvis:

```powershell
npm run desktop
```

No Google reconnect is required for Tasks & Reminders.

## Acceptance flow

1. Say: **“Jarvis, remind me tomorrow at 2 PM to call Tanner.”**
   - Jarvis should create a reminder immediately and show a reminder/task card.
   - It should persist after Jarvis sleeps and after the desktop app restarts.

2. Say: **“Add finishing the ORVEX website to my tasks.”**
   - A local task should be created without Google and without a confirmation prompt.

3. Say: **“What do I need to get done today?”**
   - Jarvis should list due/overdue tasks for the current actor and show task cards.

4. Say: **“Mark finishing the ORVEX website as done.”**
   - It should move to Completed in the Tasks workspace.
   - Then say **“Reopen that task.”** and verify it returns to Open.

5. Say: **“Remind me every weekday at 9 AM to check support.”**
   - Verify recurrence is shown on the reminder card.

6. Create a reminder one or two minutes in the future.
   - Keep the desktop app running; Jarvis may be asleep.
   - At the reminder time, a reminder card should appear and a native desktop notification should be raised when desktop notifications are enabled.
   - Jarvis should not start an unsolicited paid voice response.

7. Restart Jarvis with an already-overdue, not-yet-surfaced reminder.
   - The reminder should surface shortly after startup.

8. Speaker isolation check when multiple voice profiles are available:
   - Create a task as one recognized person.
   - Switch to another recognized person and ask for tasks.
   - The first person's private task should not appear in the second person's task list.

## Expected limitations

- Jarvis must be running to deliver a desktop reminder.
- No external task provider synchronization is included in 0.2.4.
- A powered-off or sleeping PC is not awakened by the local reminder engine.
