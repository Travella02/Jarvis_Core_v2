# 0.1.8-repair3 — Clean Entities & Single Wake Testing Guide

## Install

1. Close Jarvis completely.
2. Extract the repair ZIP directly into the `Jarvis_Real_Time` project root and allow files to merge.
3. Run `py -3.12 apply_0_1_8_repair3_patch.py`.
4. Start Jarvis with `npm run desktop`.

## Acceptance flow

### 1. Existing value cards are removed

After startup, open **Memory → Entities & relationships** and refresh.

Expected:

- Temporary meal cards and simple color/preference value cards no longer appear.
- The original timeline statements remain available.
- The related facts remain attached to the person and retain their historical or current lifecycle state.
- Durable profiles such as people, businesses, projects, and explicitly tracked subjects remain.

### 2. Future meals stay out of the entity graph

Say or type:

`I'm eating a temporary test snack.`

Expected:

- The exact event appears in the timeline under the food/activity category.
- The person's history can show that they ate the test snack.
- `temporary test snack` does not appear as a standalone entity card.

### 3. Future preference values stay out of the entity graph

Say or type:

`My favorite temporary test color is amber.`

Expected:

- The person receives a `favorite_temporary_test_color = amber` fact.
- `amber` does not become a standalone entity card.
- Correcting the value later preserves the old value as history without creating cards for either value.

### 4. Wake-only acknowledgement is exactly once

Put Jarvis to sleep, then say only:

`Hey Jarvis.`

Repeat this test at least five times.

Expected each time:

- Jarvis speaks one brief acknowledgement, such as `Yes?`.
- Only one Jarvis response appears in the transcript.
- Session cost increases for one response, not two.
- Jarvis remains awake and ready for the next request.

### 5. Wake with a complete request remains single-turn

Put Jarvis to sleep, then say:

`Hey Jarvis, what time is it?`

Expected:

- Jarvis does not say `Yes?` first.
- He answers the preserved request once.
- The full opening request appears once in the conversation and memory timeline.

### 6. Regression checks

- Remember, correct, forget, complete, dismiss, restore, clear completed, and Undo still work.
- Person merging, voice attribution, and preferred forms of address still work.
- Generic acronyms from technical questions do not become entities.
- Memory search controls stay inside their panel.
- Response modes and hybrid long answers retain their accepted behavior.
