# Testing 0.2.6-repair4 — Verified Launch

## Primary Discord regression

1. Fully close Discord, including its visible window.
2. Wake Jarvis and say: **“Open Discord.”**
3. Pass only if the Discord application window actually appears. Jarvis must not merely say “Opening Discord.”
4. Say: **“Close Discord.”** Confirm Discord closes.
5. Say **“Open Discord.”** again. The verified route should now be remembered and should resolve quickly on later launches.

## Existing-running-window test

1. Open Discord normally.
2. Minimize it or leave another application in front.
3. Say: **“Open Discord.”**
4. Jarvis should restore/bring the Discord window forward instead of launching duplicate processes or claiming success while nothing changes.

## Alias regression

1. Say: **“Group chat is another name for Discord.”**
2. Say: **“Open group chat.”** Discord must actually appear.
3. Say: **“I no longer want group chat as a nickname for Discord.”**
4. Confirm Memory → Apps no longer shows `group chat`, while **“Open Discord”** still works.

## Failure honesty

For a deliberately broken/stale application target, Jarvis must say that Windows could not bring the app up. It must not return **“Opening <app>”** unless launch verification passed.
