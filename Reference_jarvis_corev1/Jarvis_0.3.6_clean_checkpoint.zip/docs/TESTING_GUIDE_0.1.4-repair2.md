# 0.1.4-repair2 — Contextual Corrections Testing Guide

## Automated validation

The patch installer runs:

- 223 Python tests
- 46 Node tests
- Desktop syntax checks
- Doctor diagnostics
- Core diagnostics
- Desktop-runtime staging
- Private `.env` preservation verification

## Acceptance flow

1. Start Jarvis with `npm run desktop`.
2. Say: “I need to follow up with Chemly tomorrow.”
3. Correct it naturally: “Well, actually, sorry, Jarvis, I meant Kenley.”
4. A transcription such as “I met Ken Lee” is acceptable for this test.
5. Wait briefly for the automatic local proactive refresh, or open **Memory → Proactive** and select **Refresh locally** once.
6. Confirm there is one open commitment and its title says **Kenley**, not Chemly or Ken Lee.
7. Select **Why this?** and confirm the original statement and corrective statement are both listed as exact evidence.
8. Refresh again and confirm the corrected title remains and no duplicate commitment appears.
9. Restart Jarvis and confirm the corrected proactive item persists.

## Existing failed-test recovery

If the Chemly commitment and the contextual correction were already stored before this repair, install the repair and select **Refresh locally**. The backend reprocesses the existing correction event and updates the active item without requiring Tanner to repeat it.
