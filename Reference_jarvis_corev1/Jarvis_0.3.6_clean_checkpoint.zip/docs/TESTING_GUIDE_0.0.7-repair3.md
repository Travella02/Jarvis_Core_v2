# Testing Guide — 0.0.7 Sleep Response Correlation Repair

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Start Jarvis with `npm run desktop`.
2. Wake Jarvis and hold a short normal conversation.
3. Say **“That's all, Jarvis.”**
4. Confirm Cedar audibly completes **“Of course, sir.”** before the interface changes to Sleeping.
5. Repeat with **“Go back to sleep, Jarvis.”** and **“Thanks, that's everything.”**
6. Repeat at least five sleep cycles to exercise delayed-event ordering.
7. Confirm no partial acknowledgement bubble remains.
8. Confirm no `sleeping -> speaking` traceback appears.
9. Confirm Jarvis can wake again immediately after each completed sign-off.

## Provider-event diagnostics

During a correct sleep sequence, the event panel may show:

```text
sleep.acknowledgement.response_created
sleep.acknowledgement.buffer_started
sleep.acknowledgement.buffer_stopped
sleep.acknowledgement.complete
```

A delayed event from an earlier response is expected to be logged as:

```text
sleep.acknowledgement.stale_buffer_ignored
```

That event must not change Jarvis to Sleeping.
