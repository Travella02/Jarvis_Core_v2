# 0.1.8-repair2 — Grounded Memory Identity

This live-acceptance repair removes remaining mention-only acronym clutter, makes Jarvis describe his durable memory truthfully on ordinary turns, and exposes a safe manual merge path for duplicate local-owner profiles.

## What changed

- User questions no longer promote isolated acronyms and logical operators into durable entities merely because the terms appeared in the question.
- A conservative one-time startup repair removes legacy generic `concept` and `named_concept` nodes that are supported only by weak `mentioned` links and have no facts, relationships, proactive work, aliases, or actor history.
- Exact source events remain intact when a weak derived entity is removed.
- Every ordinary Realtime turn now receives response-specific grounding that durable local memory is active and whether the current user turn was stored successfully.
- Jarvis may no longer claim that he lacks a database, requires a separate memory tool, or can remember only for the current session when the local memory service is enabled.
- After a successful forget operation, later recall answers remain honest and natural without offering session-only tracking.
- Person cards in **Entities & relationships** now expose a visible **Merge duplicate** action.
- The identity merge editor now permits the canonical local user to select another local-owner placeholder profile, while still preventing unsafe merges between unrelated protected local-user identities.
- Merge candidates clearly identify local-owner placeholder profiles before confirmation.

## Entity expectations

- People, businesses, projects, foods, preferences, and other concepts established by user evidence remain.
- Historical values such as an old favorite color may remain as superseded evidence rather than current truth.
- Jarvis may remain as an assistant actor profile because his exact responses are part of the attributed conversation timeline.
- Generic mention-only nodes such as `AND`, `NOT`, `LLC`, `HTTP`, or similar vocabulary are removed when they have no independent durable evidence.

## Data-safety contract

- Automatic cleanup never deletes exact source events.
- Automatic cleanup never removes an entity with facts, person relationships, proactive items, aliases, actor history, or evidence stronger than a weak mention.
- Person merges remain explicit, previewed, auditable, and reversible through the existing memory operation history.
- No current test name is hardcoded as product logic; all cleanup and merge behavior is tenant-scoped and generalized.

## Validation

Automated coverage verifies question-safe acronym extraction, legacy mention-only cleanup, durable-memory response grounding, local-owner duplicate merge availability, and all previously accepted Speaker Recognition, Self Awareness, and Memory Intelligence behavior.
