# Testing Guide — 0.0.8 Orb State Repair

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live acceptance

1. Start Jarvis with `npm run desktop`.
2. Ask for a response lasting at least 15 seconds.
3. Watch the orb during normal pauses in Cedar's speech.
4. Confirm the orb remains Speaking and does not flash to Listening between phrases.
5. Confirm the orb gradually settles to Listening after audible playback ends.
6. Interrupt Cedar once and confirm the orb switches to Listening immediately.
7. Exercise Sleeping, Waking, Thinking, Speaking, Listening, and Degraded states and confirm each transition fades smoothly.
8. Enable Windows reduced-motion preference if available and confirm the interface remains functional without animated transitions.
