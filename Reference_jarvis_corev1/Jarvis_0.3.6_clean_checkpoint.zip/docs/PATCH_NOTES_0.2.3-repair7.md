# 0.2.3-repair7 — Local Time

## Why this repair exists
Repeated timezone repairs were still attacking the wrong layer. Google was creating the event at the correct local instant, but Jarvis could say and display the UTC wall clock because the desktop reported `UTC` as its timezone name.

## New authority model
This repair stops trying to make Google Calendar metadata fix an unreliable desktop timezone name.

For ordinary local Calendar requests, Jarvis now uses this order:

1. An explicitly requested UTC/GMT timezone, if the user actually asked for one.
2. A trustworthy non-UTC desktop IANA timezone.
3. **The UTC offset embedded in the desktop's real local ISO clock.**
4. Google Calendar timezone metadata only as a fallback.

That means a desktop clock of `2026-08-11T01:08:00-06:00` is enough to establish the local wall clock even if the environment calls its timezone `UTC`.

## Google write boundary
Fixed-offset local proposals are stored as RFC3339 timestamps such as `2026-08-12T15:00:00-06:00`. For these proposals Jarvis does not send a synthetic `UTC-06:00` value as Google's `timeZone`; the explicit offset in `dateTime` carries the instant.

## UI
Calendar cards no longer show a misleading `UTC` label for this fallback. Fixed-offset proposals are shown as **Local time**.

## Safety
- Explicit UTC/GMT requests still stay UTC.
- Existing IANA timezone behavior remains available when the desktop reports it correctly.
- Google timezone metadata remains a fallback for environments whose local clock has no useful offset.
- Confirmation and conflict behavior are unchanged.

## Validation
- Python suite: 415 passed.
- Desktop JavaScript syntax: passed.
- Connected Actions frontend contract: passed.
- Regression reproduces the live `timezone_name=UTC` + `client_local_now=-06:00` mismatch and verifies a 3 PM proposal remains 3 PM through the Google write payload.
