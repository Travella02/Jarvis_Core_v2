# 0.1.6 — Speaker Recognition

Jarvis now has a consent-based, local-first voice-profile system backed by SQLite memory schema version 6. Users can upload recordings or record enrollment samples, attach them to any person profile, and use confidence-aware local matching to attribute future speech.

## Voice Profiles workspace

- A dedicated **Memory → Voice profiles** area lists enrolled voices and available people.
- Users can upload WAV, MP3, M4A, FLAC, OGG, or WebM through the desktop; Chromium decodes and converts enrollment audio to mono 16 kHz PCM locally.
- Users can record live enrollment samples through the selected microphone.
- Every enrollment requires an explicit consent checkbox.
- Multiple samples improve the profile and expose sample count, enrollment quality, threshold, last match, and status.
- Samples can be removed, profiles can be enabled or disabled, thresholds can be adjusted, and a voice identity can be deleted without deleting the person or their memories.

## Local recognition and protected storage

- Enrollment and matching use a deterministic local speaker-feature baseline with no model download or network request.
- Raw enrollment audio is discarded after the protected voice signature is created.
- On Windows, protected signature files use Windows DPAPI under the current operating-system account. Non-Windows development uses restrictive filesystem permissions and is explicitly identified as a development fallback.
- Voice-profile files are scoped under a tenant-specific directory and every database query filters by tenant ID.
- Speaker matching is an attribution aid, not authentication; recognition never grants access to private memories.

## Confidence-aware attribution

- Strong matches attach the recognized person to the voice memory with confidence, model, source, and timestamp metadata.
- Moderate matches remain **Likely** for review.
- Low-confidence or ambiguous speech remains **Unknown speaker** rather than forcing a person match.
- Recognition evidence is recorded separately so future corrections retain why Jarvis chose a speaker.
- Live utterance capture is bounded to the provider speech window and does not retain ordinary conversation audio as enrollment material.

## Generalized SaaS boundary

No person, business, or account is hardcoded. Voice profiles attach to arbitrary person entities and are separated by `JARVIS_LOCAL_TENANT_ID`. The current desktop is a single local tenant; a hosted SaaS deployment must derive that tenant ID from an authenticated account and keep storage roots, databases, encryption keys, and authorization isolated per tenant.

## Validation

- 247 Python tests passed.
- 58 Node tests passed.
- Python and JavaScript syntax checks passed.
- Doctor and core diagnostics passed.
- Desktop-runtime staging passed.
- Fresh `0.1.5 → 0.1.6` installation and safe reapplication passed.
- Private `.env` preservation verified.
