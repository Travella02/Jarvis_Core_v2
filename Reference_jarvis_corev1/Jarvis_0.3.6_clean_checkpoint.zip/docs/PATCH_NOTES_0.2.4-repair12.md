# 0.2.4-repair12 — Context Separation

Repair11 restored the stable Luna-owned response architecture, fixed the stuck/Attention-needed regression, preserved the grounded `2 PM` reminder value, and restored the real Gmail draft card. Live testing then exposed a different problem: Jarvis could confuse **content the user wanted placed inside an action artifact** with **content addressed conversationally to Jarvis**.

The clearest failure was a Gmail body clarification such as `Say hi, I was just wondering how you're doing...`. The draft was created correctly, but the post-action Luna naturalizer was also given that literal user turn, so it could answer the email body itself (`Hi, I'm doing well`) before acknowledging the draft. Normal open-ended conversation was also being compressed so aggressively that some answers sounded like slogans instead of natural thoughts.

Repair12 separates those semantic roles instead of adding another action-specific phrase patch.

## Typed action-response boundary

Completed Connected Actions now give Luna a typed **action response envelope** containing only:

- the completed operation,
- the fact that the application already interpreted/executed the request,
- the grounded Jarvis wording produced from provider/application state.

The literal user clarification is intentionally omitted from this post-action wording pass. This is important because the turn may contain an email body, reply body, note text, task text, calendar text, form content, or another artifact payload that should be acted on—not answered.

For example, after:

`Can you draft an email to Tanner?`

and then:

`Say hi, I was just wondering how you're doing. Please get back to me ASAP.`

Luna receives the completed Gmail result and draft acknowledgement, not the literal email body as a new conversational prompt. Jarvis may naturally say `Done—the draft's ready. Want me to send it?`, but must not say `Hi, I'm doing well` in response to text meant for Tanner.

This rule is generalized across artifact/action content rather than hardcoded to Tanner or this specific sentence.

## Current-turn authority for ordinary conversation

The Luna voice prompt now explicitly distinguishes:

- **CURRENT USER TURN** — the only turn Jarvis is answering now;
- **RECENT CONVERSATION** — reference-only context used to resolve pronouns, continuity, and prior decisions.

Older user lines are not treated as a queue of unanswered messages. If an earlier line contains email/message/note/task/calendar payload, Luna must not suddenly answer that payload on a later unrelated turn.

The desktop also removes a duplicate copy of the current user turn from the recent-history block before requesting a normal Luna reply. This reduces role ambiguity while preserving conversational continuity.

## Natural completeness instead of slogan compression

Response modes remain hard ceilings on spoken length, but Luna is no longer told to optimize for the shortest possible human phrase in every situation.

- Direct factual follow-ups can still be extremely short: `2 PM.`
- Simple confirmations can still be fragments: `Done.` or `Got it.`
- Open-ended, subjective, philosophical, or explanatory questions should use enough connective language to sound like a coherent thought.
- Luna is specifically told to avoid circular definitions, motto-like phrasing, and compressed stacks of advice merely to make the answer shorter.

Short / Normal / High / Full still control how much Jarvis speaks, not how deeply he reasons. Personality and speech-provider selection remain independent.

## Preserved architecture

Repair12 does **not** undo repair11:

- Luna/Jarvis Core still owns reasoning and the exact words Jarvis says.
- Realtime remains ears/turn detection/interruption only for now.
- OpenAI and optional ElevenLabs remain replaceable synthesis-only voice providers.
- Fact guards still protect authoritative times, dates, names, and application values.
- Gmail drafts still remain unsent until explicit approval.
- The one-shot Connected Action clarification route remains in place so failed action continuations cannot hijack later conversation.

## Installation/data safety

The repair does not replace `.env`, OAuth credentials, memory, voice profiles, tasks, reminders, connected-action databases, or user-selected speech-provider configuration. The installer creates a rollback backup, validates the patch payload, overlays only changed files, and removes obsolete `apply_0_2_4...` repair installers and temporary `patch_files` after successful installation.
