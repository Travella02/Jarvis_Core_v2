# Testing Guide — 0.0.5 Electron Shell Repair 6

## Install

```powershell
py -3.12 apply_0_0_5_repair6_patch.py
```

## Start

```powershell
npm run desktop
```

## Live wake tests

1. Confirm the native Jarvis window opens and the wake status says the local listener is ready.
2. Say **“Jarvis.”** Confirm Jarvis wakes and acknowledges you once.
3. Return him to sleep and say **“Hey Jarvis, tell me a joke.”** Confirm the full request is preserved and answered once.
4. Repeat with **“Yo Jarvis, what time is it?”**
5. While awake, say **“That’s all, Jarvis.”** Confirm the Realtime session closes and local sleep resumes.
6. Watch the terminal for a safe line such as:

```text
[local-speech] recognized (jarvis_wake_request, 0.91): Jarvis tell me a joke
```

## Diagnostic outcomes

- `no_audio_signal` means Windows is not receiving audio from its default recording device. Set the intended microphone as the Windows default input and relaunch Jarvis.
- `heard_audio_no_match` means microphone audio arrived but no lifecycle grammar matched. Speak the phrase clearly and review the safe grammar/confidence log.

## Automated validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
npm run desktop:check
```
