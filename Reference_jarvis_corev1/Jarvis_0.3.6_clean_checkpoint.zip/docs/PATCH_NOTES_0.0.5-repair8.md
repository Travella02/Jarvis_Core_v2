# 0.0.5 — Desktop Stability Repair

## Summary

This repair stabilizes the first native Electron experience after live testing exposed four related desktop problems: duplicate opening turns, false wakes from background noise, close-to-tray behavior that left Jarvis running, and oversized first-run window bounds.

## Changes

- Serialized the sleeping wake microphone and Realtime microphone handoff.
- Applied the first-turn microphone gate before Realtime media acquisition.
- Added adaptive local wake-noise calibration, multi-frame speech confirmation, voiced-duration and peak checks, and a negative-result cooldown.
- Removed wake-keyword bias from the transcription prompt.
- Increased the default wake end-of-utterance silence window from 750 ms to 1,200 ms.
- Changed the normal window close button to quit Electron and the Python core.
- Added an explicit **Hide Jarvis** tray command for intentional background operation.
- Added defensive core cleanup on Electron quit and process exit.
- Clamped saved and default window bounds to the active display work area.
- Reduced the default window size to 1280×800 and responsive minimums to 760×560.

## Issue records

- `ISSUE_029_WAKE_OPENING_RESPONSE_DUPLICATION.md`
- `ISSUE_030_FALSE_WAKE_NOISE_TRANSCRIPTION.md`
- `ISSUE_031_WINDOW_CLOSE_LEFT_CORE_RUNNING.md`
- `ISSUE_032_WINDOW_BOUNDS_EXCEED_SCREEN.md`

## Privacy and cost

Background audio remains local until a capture passes the speech-evidence checks. Weak/noisy captures are discarded before a paid transcription request. The API key remains in the Python core.
