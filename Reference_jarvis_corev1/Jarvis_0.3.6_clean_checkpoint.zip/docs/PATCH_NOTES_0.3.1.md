# 0.3.1 — Browser Control (candidate)

Browser Control expands the accepted 0.3.0 Web Intelligence foundation with fast structural browser/media operations while leaving current web research, freshness verification, grounded sources, and Game Mode unchanged.

## Candidate scope
- Reliable Browser Bridge capability negotiation and explicit `0.3.1` extension revision.
- Session-scoped media target continuity after Jarvis opens/plays a grounded browser result.
- Structural video controls: pause/resume, volume, mute/unmute, seek, restart, playback speed, and fullscreen enter/exit.
- Faster grounded tab switching and simple page scrolling without a Luna planning round trip.
- Clear extension-update feedback when an old loaded bridge cannot perform a new media operation.

## Safety boundary
No synthetic desktop mouse/keyboard input is added. All actions use Chromium tab APIs or page DOM/media APIs, and Game Mode remains the mandatory firewall for future synthetic input capabilities.

## Live acceptance focus
1. Search YouTube and play a result, then pause/resume it.
2. Set volume, mute/unmute, seek, restart, and change playback speed on that same video.
3. Enter and exit video fullscreen.
4. Switch to a named browser tab and scroll without noticeable planner delay.
5. Run a Web Intelligence freshness regression to confirm 0.3.0 research behavior is unchanged.
