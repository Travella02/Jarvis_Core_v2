# Testing Guide — 0.2.2-repair6 Inbox Control

## One-time Google permission refresh

This repair adds Gmail read-state control. Existing 0.2.2 Google tokens do not contain that permission yet.

1. Open **Controls → Connected apps**.
2. Click **Enable Gmail Actions**.
3. Complete Google's consent screen once.
4. Return to Jarvis and confirm Google shows connected.

No new client ID or client secret is required.

## Test 1 — contextual mark as read

1. Ask: **“Do I have any unread emails?”**
2. Then ask: **“Can you mark those all as read?”**

Expected:

- Jarvis uses the bounded set he just identified, not the entire mailbox.
- He answers briefly, for example: **“Done. I marked 3 messages as read.”**
- Repeating the unread check should no longer include those messages.

## Test 2 — reading marks the thread read

Ask Jarvis to open/read one unread email.

Expected: the Gmail thread is shown normally and is no longer unread on the next inbox check.

## Test 3 — replying marks the source thread read

Draft a reply to an unread email and review the draft.

Expected: the reply still targets the correct external sender, and the source Gmail thread is no longer unread.

## Test 4 — Short response hard cap

Set Jarvis to **Short** mode and run several Gmail/Calendar actions, including a failure or clarification case.

Expected: spoken Connected Action output never exceeds **3 sentences or 50 words**. The written Gmail cards can still contain the full content.
