# 0.0.5 — Wake Acceleration Repair

## Summary

This repair targets the remaining model-wake latency after the window-sizing and first-pass wake-speed fixes. It preserves model-based wake accuracy, false-wake filtering, cost controls, first-turn ownership, and the corrected single-monitor window behavior.

## Changes

- Wake transcription and OpenAI Realtime session creation now run in parallel after a valid local utterance ends.
- The existing sleeping microphone stream is transferred directly into WebRTC rather than being released and reacquired.
- Opening audio remains gated until the transcribed request is confirmed and Cedar's opening response finishes.
- Speculative sessions are cancelled immediately when the transcript does not contain Jarvis or transcription fails.
- Wake WAV audio is downsampled to 16 kHz mono before upload, reducing payload size.
- Local end-of-speech detection now uses a 280–450 ms adaptive silence window and a 512-sample processing buffer.
- The remembered room-noise floor allows abbreviated recalibration on later sleep/wake cycles.
- The desktop prewarms transcription and Realtime provider connections during initialization without blocking the UI.
- Production provider gateways reuse HTTP keep-alive pools and close them cleanly during FastAPI shutdown.
- Added safe wake-stage timing events for transcription, preconnection, and total fast-path readiness.

## Privacy and cost boundary

A speculative Realtime connection may be opened after local VAD confirms a real spoken utterance, before transcription confirms that it contains Jarvis. Its microphone track is disabled and no response is requested. If the keyword is absent, the connection is immediately closed. Continuous sleeping audio is still not sent to OpenAI.

## Issue record

- `issues/ISSUE_036_WAKE_PIPELINE_SERIAL_NETWORK.md`

## Validation

- 100 Python tests passed.
- Electron main, preload, and renderer JavaScript syntax validation passed.
- Doctor and safe diagnostic passed.
- Desktop runtime staging passed.
- Installer rerun and `.env` preservation passed.
