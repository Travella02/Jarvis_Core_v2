# Testing Guide — 0.3.2-repair3 SQLite Handle Closure

## Apply

Remove the old repair2 delivery files before extracting repair3 so pytest cannot discover duplicate tests inside an old payload:

```powershell
Remove-Item -Force .\apply_0_3_2_account_foundation_repair2_patch.py -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force .\patch_payload_0_3_2_account_foundation_repair2 -ErrorAction SilentlyContinue
```

Extract repair3 into the Jarvis project root, then run:

```powershell
python .\apply_0_3_2_account_foundation_repair3_patch.py
```

Expected: Jarvis remains version **0.3.2** and repair3 applies over the existing repair2 candidate.

## Focused Windows regression

```powershell
python -m pytest -q tests/test_accounts.py tests/test_account_api.py tests/test_release_consistency.py
```

Expected: all focused Account Foundation/release tests pass and no `PermissionError`, `WinError 32`, or locked `accounts.sqlite3` appears during temporary-directory cleanup.

Then run:

```powershell
npm run desktop:check
node --test tests_js/account_foundation.test.cjs
```

## Live acceptance

After the focused regression passes, launch Jarvis and verify account signup, persistent sign-in, logout/login, wrong-password rejection, stable tenant identity, and one previously accepted Browser Control action.

Do not commit until live acceptance passes.
