# Testing Guide — 0.1.0 Electron Extraction Repair

## Apply

Extract the repair ZIP directly into the `Jarvis_Real_Time` project root, approve merging/replacing files, then run:

```powershell
py -3.12 apply_0_1_0_repair5_patch.py
```

## Clear only incomplete Forge output

```powershell
Remove-Item -Recurse -Force .\out -ErrorAction SilentlyContinue
```

Do not delete `.venv`, `build\python`, `build\cache`, `build\desktop_runtime`, or `build\runtime_bundle.zip`.

## Build

```powershell
npm run alpha:make
```

Expected new output begins with:

```text
START extractElectronArchive
[Jarvis Alpha] Extracting Electron archive with Python
[Jarvis Alpha] Electron extraction progress: ...
DONE  extractElectronArchive
START initialize
```

The Electron ZIP extraction should normally complete in roughly one to five minutes on the laptop. The full package and Squirrel installer build may take another five to fifteen minutes.

## Failure boundary

The runner now treats a zero exit code as failure when the packaged app or installer is absent. Preserve this log after any failure:

```text
build\alpha-packaging-diagnostic.log
```

Do not wait longer than 15 minutes on one unchanged `START` stage with negligible CPU and disk activity.

## Verify

After `alpha:make` returns successfully:

```powershell
npm run alpha:verify
```

Expected Setup executable:

```text
out\make\squirrel.windows\x64\Jarvis_Real_Time_Setup.exe
```

## Installed acceptance

Run the Setup executable and verify first-run setup, microphone access, natural `Jarvis` wake requests, Cedar speech, interruption, sleep, clean shutdown, relaunch, and retained settings. The application executable may still use Electron's default icon/metadata during this diagnostic alpha; installer branding remains configured.
