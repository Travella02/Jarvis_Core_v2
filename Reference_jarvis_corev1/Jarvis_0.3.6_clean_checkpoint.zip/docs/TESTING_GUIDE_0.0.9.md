# Testing Guide — 0.0.9 Interface Layout

## Automated validation

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Live interface acceptance

1. Launch Jarvis with `npm run desktop`.
2. Confirm Home defaults to the Conversation layout and the full window remains on one monitor.
3. Switch among Conversation, Balanced, and Presence. Restart Jarvis and confirm the last choice is restored.
4. Collapse the navigation rail, restart Jarvis, and confirm the rail state is restored.
5. Open Home, Controls, Insights, and System. Confirm every control and metric remains visible.
6. Confirm Ctrl+1 through Ctrl+4 switch workspaces.
7. Confirm Ctrl+Shift+F enters Conversation Focus and Escape exits it.
8. Create enough conversation messages to make the transcript scroll.
9. Scroll upward manually, then let Jarvis continue speaking. The transcript must not pull the view back down.
10. Confirm **Jump to latest** appears, returns to the newest message, and disappears afterward.
11. Type a multi-line message with Shift+Enter. Press Enter without Shift and confirm it sends once.
12. Resize the Electron window through laptop and narrow widths. No panel may overlap, clip controls, or extend beyond the window.
13. Confirm wake, interruption, typed messages, silent spoken sleep, simulation, tray behavior, X-to-quit, orb states, cost totals, and Desktop Presence still work.

## Acceptance boundary

Do not commit `0.0.9` until smart scrolling, layout persistence, compact controls, and responsive resizing all pass without regressing the voice lifecycle.
