# Testing Guide — 0.0.6 Desktop Presence Repair 1

## Install

```powershell
py -3.12 apply_0_0_6_repair1_patch.py
```

## Expected automated validation

```text
Ran 111 Python tests
OK

# tests 6
# pass 6
# fail 0
```

The exact Node durations may vary. Unicode status symbols are not used as validation evidence.

## Manual validation

After installation:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
npm run desktop
```

Then continue the Desktop Presence acceptance checks: heartbeat, manual core restart, tray background operation, startup toggle, suspend/resume, wake latency metrics, and X-to-quit.
