# 0.2.1-repair2 — Draft Continuity

Fixes the live 0.2.1 acceptance failure where Jarvis created the correct Gmail draft, asked whether it should be sent, then lost the draft context when the user naturally answered, “Yes, send it, please.” It also upgrades draft presentation so the user can review the actual recipient, subject, and message body before sending.

## Changes

- Every successfully created, replied, or revised Gmail draft now carries a confirmation-bound reference to that exact Gmail draft ID.
- Natural follow-ups such as `Yes`, `Yes, please`, `Send it`, and `Yes, send it, please` confirm the waiting send directly without asking the user for a draft ID and without asking Luna to rediscover the draft.
- `Cancel it`, `No`, `Leave it`, and equivalent supported declines cancel the waiting send while leaving the Gmail draft saved.
- Confirmation and cancellation grammars are now disjoint, closing a safety edge case where `Cancel it` could previously be classified as approval for a pending external write.
- The pending-send record stores a bounded preview snapshot of the exact draft so the confirmation remains attached to the message the user just reviewed.
- After provider-confirmed sending, the completed action preserves the same preview snapshot for accurate result presentation and audit continuity.
- The desktop conversation now renders a dedicated email preview card beneath Jarvis’s short spoken summary, with status, From, To, Cc/Bcc when present, Subject, and the exact message body.
- Draft cards are explicitly labeled `EMAIL DRAFT` with `Draft saved · Not sent`. After Gmail confirms the send, the same preview changes to `EMAIL SENT` with `Sent` status.
- Long draft bodies continue to use the existing conversation overflow/fullscreen behavior instead of forcing the transcript to expand indefinitely.
- Luna remains the connected-action planner/writer. Realtime remains speech-only for Connected Actions.

## Safety boundary

Creating a draft is still non-executing and requires no confirmation. Sending remains an external write and occurs only after a separate explicit confirmation. The confirmation is bound to the exact draft ID created/revised in the prior step; Jarvis does not infer a new recipient or message at send time.

## Primary regression

1. Ask Jarvis to create a disposable draft.
2. Verify the conversation shows a dedicated email preview card with the correct sender, recipient, subject, and body.
3. Say:

> Yes, send it, please.

Jarvis must send that exact draft once, without asking for the draft ID or asking whether it should locate the draft.

## Apply it

Close Jarvis. Extract the repair ZIP directly into the current `Jarvis_Real_Time` project root, then run:

```powershell
py -3.12 apply_0_2_1_repair2_patch.py
```

Then start Jarvis:

```powershell
npm run desktop
```
