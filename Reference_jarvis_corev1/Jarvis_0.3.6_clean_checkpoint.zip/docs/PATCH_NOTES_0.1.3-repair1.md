# 0.1.3-repair1 — Source-Aware Consolidation

Repairs entity consolidation so Jarvis builds project and business profiles from authoritative source events rather than treating his own replies as equivalent evidence.

## Changes

- Existing events are re-linked to established entities during the next consolidation run.
- Case differences and conservative speech variants such as `Orvex`, `Orvix`, and `Orbex` can resolve to `ORVEX` when the reference is unambiguous.
- Explicit creation of a new entity remains distinct even when its name resembles an existing alias.
- User-authored goals, decisions, and commitments become provenance-backed structured facts:
  - `has_goal`
  - `decided_to`
  - `open_task`
- Entity profiles use source events for facts and state.
- Assistant responses are preserved but moved into a separate **Jarvis conversation mentions** section.
- The profile event count now reflects authoritative source events rather than every assistant mention.
- A one-time source-aware rebuild is requested automatically for existing databases.

## Data safety

No original memory event is rewritten or deleted. The repair only adds derived links, structured facts, aliases, and refreshed profiles. Existing correction, deletion, audit, and undo behavior remains intact.

## ORVEX result

After consolidation, the profile should show:

- Tanner created ORVEX.
- Goal: grow ORVEX into a major esports company.
- Decision: register ORVEX as an LLC.
- Open task: file the ORVEX trademark.
- A source-only timeline.
- Jarvis replies in a separate conversation-mentions section.
