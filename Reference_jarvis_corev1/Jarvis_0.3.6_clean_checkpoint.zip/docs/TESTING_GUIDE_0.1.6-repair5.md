# Testing Guide — 0.1.6-repair5

## Apply

1. Close Jarvis completely.
2. Extract the repair ZIP directly into the `Jarvis_Real_Time` project root and allow files to merge/replace.
3. Run `py -3.12 apply_0_1_6_repair5_patch.py` from the project root.
4. Start Jarvis with `npm run desktop`.

## Test permission buttons

1. Open **Memory → People & Identity**.
2. Open Tanner or another person with explicit memory permissions.
3. Click the access-level pill beside **Business**, **Household**, **Personal**, or **Shared**.
4. Confirm an in-app editor opens with the clicked scope and its current level already selected.
5. Change the level, save, and confirm the person detail reloads with the new value.
6. Repeat with keyboard navigation to confirm the permission button can receive focus and activate normally.

## Test quiet sleeping audio

1. Put Jarvis to sleep and confirm the orb is gray.
2. Speak a normal sentence that does not include “Jarvis.”
3. Confirm the orb stays gray and the main state remains **Sleeping** while the local wake listener captures and checks the utterance.
4. Repeat several times with short and longer non-wake speech.
5. Confirm there is no purple Waking flash, blue Listening flash, or temporary connection-error presentation.

## Test a real wake

1. While sleeping, say **“Jarvis, what time is it?”** or another natural request containing Jarvis.
2. Confirm the orb changes to purple Waking only after the keyword is accepted.
3. Confirm Jarvis then reaches Listening and answers the preserved request without requiring repetition.
4. Say only **“Jarvis.”** and confirm the same confirmed-wake presentation occurs.

## Regression checks

- Fast speculative preconnection remains enabled; wake latency should not regress merely to hide the presentation.
- Manual Wake still changes the orb to Waking immediately.
- Reconnect and post-confirmation errors remain visible.
- Forms of address, response-length modes, silent sleep, speaker recognition, and cleared proactive items continue working.
- The installer does not modify `.env`, user memory, or protected voice-profile data.
