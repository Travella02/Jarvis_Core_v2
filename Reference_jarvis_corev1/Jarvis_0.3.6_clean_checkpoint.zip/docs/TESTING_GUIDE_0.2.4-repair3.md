# 0.2.4-repair3 — Contextual Intelligence live test

## 1. Grounded voice-first task

Ask:

> What do I need to get done today?

Expected: Jarvis says the actual task name aloud. A simple one-task answer does not need a forced card.

## 2. Natural visual follow-up

Immediately ask:

> Can you show me?

Expected: Jarvis reuses the exact grounded task, gives a very short spoken orientation, and renders the task card. It should not improvise a generic answer.

## 3. Project understanding

Ask:

> What does that involve?

Expected: Jarvis connects the active task to relevant durable project memory and explains the practical work needed. For the ORVEX website example, remembered ORVEX facts may be used as facts; website launch steps that were not previously decided must be presented as Jarvis's proposed plan/recommendation rather than remembered history.

## 4. Prioritization

Ask:

> What should I work on first?

Expected: Jarvis chooses a useful next step from dependencies and explains why, while staying in the same task/project context.

## 5. Long natural continuation

Continue with examples such as:

> What about deployment?
>
> Tell me more.
>
> What would come after that?
>
> Can you help me do the first one?

Expected: Jarvis keeps the ORVEX website/task as the current subject and resolves ordered references naturally rather than asking the user to restate the whole project.

## 6. Sleep/wake continuity

Let Jarvis sleep, wake him, then ask:

> What does that website task involve again?

Expected: the working task/project context is still available to the same actor. Jarvis should not say that he does not know which task you mean when the prior focus is unambiguous.

## 7. Different-task isolation

Create or discuss a different task, then ask a follow-up about it.

Expected: old ORVEX website workstreams do not leak into the new task. Working context follows the new grounded task.

## Acceptance criteria

- No generic “I don't know your tasks” fallback while a grounded task context exists.
- No unsupported claims that a proposed launch plan was previously decided or already completed.
- Concise speech still contains the useful answer.
- Richer reasoning may appear on screen without violating the selected spoken response cap.
- No regression to Gmail, Calendar, task persistence, reminders, or task dashboard behavior.
