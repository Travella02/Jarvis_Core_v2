# 0.0.8 — Interface Foundation

## Summary

This release replaces the engineering-first Realtime Voice Lab layout with the first product-facing Jarvis desktop interface. The proven voice lifecycle, model wake path, cost controls, desktop supervision, privacy boundaries, and local Python core remain unchanged underneath the new presentation layer.

## Added

- A central animated Jarvis orb driven by the authoritative voice state.
- Distinct visual states for Sleeping, Waking, Connecting, Listening, Thinking, Speaking, Degraded, and Error.
- A persistent modular navigation rail with Home, Controls, Insights, and System workspaces.
- A conversation-focused Home workspace with quick session, cost, wake-latency, budget, and desktop-health summaries.
- Mirrored orb controls for Wake, Sleep, and Stop Speaking.
- A full-screen conversation focus mode with Escape-to-exit behavior.
- Persisted interface preferences for active workspace and focus mode.
- Responsive layouts for laptop-sized windows and reduced-motion accessibility support.

## Changed

- Renamed the visible product surface from Realtime Voice Lab to Jarvis.
- Moved advanced voice settings into a dedicated Controls workspace.
- Moved performance and cost telemetry into Insights.
- Moved desktop supervision and provider diagnostics into System.
- Simplified the conversation composer and empty state.
- Kept every existing DOM control ID and event path to prevent voice regressions.

## Not included

- Dragging, resizing, popping out, or saving arbitrary panel layouts.
- Final avatar artwork or GPU-rendered visual effects.
- Permanent memory, tools, vision, email, calendar, or computer control.

## Validation

- Full Python unit suite passed.
- Electron main, preload, presence, and renderer JavaScript syntax validation passed.
- Node desktop-presence tests passed.
- Doctor, diagnostic, desktop-runtime staging, installer idempotence, and `.env` preservation passed.
