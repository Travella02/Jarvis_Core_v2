# 0.2.4-repair7 — Natural Voice Pipeline Testing Guide

## Install

Close Jarvis, then extract the repair ZIP **directly into your current Jarvis_Real_Time project root** and allow Windows to merge/replace files.

Open PowerShell in that project root and run:

```powershell
py -3.12 .\apply_0_2_4_repair7_patch.py
```

The installer closes the running Jarvis development runtime if needed, verifies the repair payload, preserves a timestamped rollback backup, installs repair7, and removes obsolete `apply_0_2_4*_patch.py` repair installers plus the temporary `patch_files` directory after a successful install.

Then start Jarvis:

```powershell
npm run desktop
```

No Google reconnect, `.env` edit, task recreation, reminder recreation, or manual repair-file cleanup is required.

## Primary live acceptance test — blocking

Use the same existing **Call Tanner** task that the Tasks view shows at **2:00 PM**.

Ask:

> Is there anything I need to do tomorrow?

Then ask:

> What time?

**Expected:** Jarvis should naturally answer **“2 PM.”** The wording may be another short conversational equivalent, but it must preserve **2 PM** and must never say **8 PM**.

Then ask:

> When will you remind me?

**Expected:** **2 PM** again.

Finally ask:

> What time is it?

**Expected:** Jarvis speaks the actual current Windows-local time.

## Naturalness test

After Jarvis mentions a known task, ask a short contextual follow-up such as:

> What time?

Jarvis should not mechanically repeat the full task description when **“2 PM”** is enough.

Then ask a broader question such as:

> What should I work on first?

Jarvis should stay on the current task/project context and answer conversationally rather than reading database-field language.

## Response-mode test

Repeat one simple question and one complex question in **Short, Normal, High, and Full**.

Expected:

- The mode is a maximum depth/length, not a target.
- **“What time?”** can remain **“2 PM.”** in every mode.
- Broader requests can expand as the selected mode allows.
- Full mode can continue speaking longer answers across multiple TTS chunks rather than failing on one oversized speech request.

## Personality test

Open **Controls → Audio → Personality** and try at least two profiles, for example **Classic** and **Casual**.

Ask the same non-factual conversational question in both profiles.

Expected:

- The style should feel different.
- Facts must not change.
- The selected response mode still controls the maximum spoken depth independently of personality.

## Speaker-neutrality test

With a speaker who is not confidently recognized, ask Jarvis a normal question.

Expected: Jarvis does **not** guess the person's identity, gender, `sir`, `ma'am`, or another person's nickname/title.

With a confidently recognized Voice Profile that already has an explicit preferred form of address, Jarvis may use that saved preference occasionally when it sounds natural, but should not append it to every sentence.

## Interruption test

Ask for a response long enough for Jarvis to still be speaking, then interrupt with a new turn.

Expected: dedicated speech stops promptly and the live conversation returns to listening/processing the interruption.

## Regression checks

- Existing Gmail/Calendar/Tasks connections remain intact.
- Existing tasks/reminders remain visible.
- Wake/sleep still work.
- Typed turns use the same Luna-script → Cedar-speech ownership for ordinary replies.
- The conversation bubble shows the authoritative Jarvis script instead of being replaced by an alternate Realtime-generated answer.
