# Testing Guide — 0.0.3 Wake Handoff Repair

## Automated checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts\doctor.py
.\.venv\Scripts\python.exe -m apps.core --diagnostic
```

## Start Jarvis

```powershell
.\.venv\Scripts\python.exe -m apps.core
```

Hard-refresh the Voice Lab once with `Ctrl+F5`.

## Live acceptance

1. Confirm the wake listener reports that it is listening for `jarvis`.
2. Say **“Hey Jarvis, tell me a joke.”**
3. Confirm Jarvis wakes and answers that request without requiring repetition.
4. Put Jarvis back to sleep and try **“Yo Jarvis, what can you help me with?”**
5. Confirm the complete text after the keyword appears once as the opening user message.
6. Ask Jarvis to give a response lasting at least ten seconds.
7. Confirm **Jarvis speaking** increases while audio is audible.
8. Interrupt Jarvis and confirm the speaking total stops increasing shortly after the audio stops.
9. Let another response finish normally and confirm speaking time accumulates.
10. Confirm User speaking, Awake, Idle sleep, response count, and cost tracking still work.
