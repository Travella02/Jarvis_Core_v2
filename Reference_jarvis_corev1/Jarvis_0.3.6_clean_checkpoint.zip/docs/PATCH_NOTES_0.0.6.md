# 0.0.6 — Desktop Presence

**Adds Windows startup controls, bounded core supervision, renderer recovery, power-resume handling, optional desktop notifications, and detailed wake-stage latency measurements.**

## Added

- User-controlled **Start Jarvis with Windows** setting in both the tray and desktop interface.
- Hidden background startup through the `--background` launch argument.
- Development and packaged Windows login-item support, including Squirrel launcher handling.
- Five-second local-core heartbeat monitoring with a three-failure threshold.
- Exponential restart backoff capped at 30 seconds.
- A five-restarts-per-ten-minutes circuit breaker to prevent infinite restart loops.
- Renderer recovery for crashes, failed main-frame loads, and sustained unresponsiveness.
- Suspend, resume, lock, and unlock handling through Electron's power monitor.
- Optional native desktop notifications for successful recovery and degraded states.
- Privacy-safe, rotating `desktop-presence.jsonl` operational diagnostics in Electron user data.
- Desktop Presence panel showing:
  - Application uptime
  - Core state and uptime
  - Core restart count
  - Renderer recovery count
  - Last successful heartbeat
  - Startup and notification controls
- Wake-stage timing for:
  - Wake transcription
  - Speculative Realtime preconnection
  - Speech end to Cedar's first audible response
- Node's built-in test runner for deterministic desktop-presence logic.

## Preserved behavior

- Clicking the window X still fully quits Jarvis and the Python core.
- **Hide Jarvis** remains the explicit way to keep Jarvis running in the tray.
- Wake audio privacy boundaries and the accelerated `0.0.5` model-wake path remain unchanged.
- `.env` remains private and external to Electron renderer code.
- Simulation mode, Cost Control, spoken sleep intent, Cedar voice, and WebRTC interruption remain intact.

## Safety and reliability boundaries

- Automatic restarts are bounded and use exponential backoff.
- A stable two-minute core window clears old restart pressure.
- Sensitive API configuration is never written to the desktop presence journal or IPC snapshot.
- The renderer receives only bounded operational status through the context-isolated preload bridge.
- Hidden-window background throttling is disabled so the local wake listener remains active in tray mode.

## Development issues resolved

- `ISSUE-037`: Windows Squirrel startup paths were initially processed with host-platform path semantics during Linux testing.
- `ISSUE-038`: The first draft registered `ready-to-show` after starting the page load, creating an intermittent hidden-window risk.
- `ISSUE-039`: Release work initially started from a repair-only partial tree rather than the complete accepted baseline; the update was rebuilt on the full repository before packaging.

## Validation

The release is validated through:

```text
python -m unittest discover -s tests -v
npm run desktop:test
npm run desktop:check
python scripts/doctor.py
python -m apps.core --diagnostic
python scripts/stage_desktop_runtime.py
```

Validation result: **108 Python tests and 6 Node tests passed**. Electron/renderer syntax, doctor, diagnostic, and desktop-runtime staging also passed. No paid OpenAI request is part of automated validation.
