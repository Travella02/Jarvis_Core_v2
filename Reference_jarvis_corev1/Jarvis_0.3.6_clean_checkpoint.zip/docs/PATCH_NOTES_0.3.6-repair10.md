# 0.3.6-repair10 — Regression Alignment

**Date:** 2026-09-03  
**Required previous release:** 0.3.6-repair9  
**Status:** Live acceptance test-tooling repair candidate

## Fix

Repair9 installed cleanly and its targeted validation passed, but the real Windows Electron suite reported **161/164** because three historical source-shape assertions still encoded the pre-Repair9 implementation.

Repair10 updates only those stale regression contracts. It does not modify production Jarvis code.

The updated tests now require the Repair9 security invariants instead of rejecting them:

- provider-VAD barge-in remains active for audible/pending Jarvis speech, but is explicitly suppressed while `permissionQuarantined` is true;
- every microphone speech turn still advances `voiceTurnEpoch`, while transcript-turn registration carries the quarantine state so prompt-time speech cannot become a normal user turn;
- authenticated permission reauth enters `requestTrustedPermissionConfirmation(challengeId)`, whose trusted-prompt lifecycle still delegates native user presence to `window.jarvisDesktop.confirmPermission(id)` before the attestation is submitted.

Do not revert the Repair9 quarantine or bypass its trusted wrapper merely to restore the old regex shapes.

See ISSUE-334.
