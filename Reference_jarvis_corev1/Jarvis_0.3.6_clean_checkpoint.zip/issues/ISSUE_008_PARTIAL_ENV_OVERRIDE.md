# ISSUE-008 — Partial Test Environment Still Inherited Private Local Settings

## Summary

The first full `0.0.2` installer simulation correctly preserved an existing private `.env`, but three automated tests failed because their supposedly deterministic test environments overrode only some configuration keys. Unspecified values still came from the developer's real local file.

## Symptom

The suite passed in the clean source workspace, then failed during an installation test that intentionally used safe non-default local settings:

- The doctor reported `Voice: marin` instead of the asserted Cedar default.
- The diagnostic reported medium VAD and a 50-minute limit instead of test defaults.
- The server config test received a 50-minute limit rather than 55.

The installer detected the failures and rolled the patch back automatically. The fake `.env` checksum remained unchanged.

## Impact

A valid user customization could prevent an otherwise correct update from installing. The application behavior was correct; the test isolation contract was incomplete.

## Root cause

`ProjectSettings.load()` intentionally merges the project-root `.env` first and then applies the supplied environment mapping. Several tests supplied a partial mapping and assumed that omitted settings would fall back to built-in defaults. They instead retained values from `.env`, which is the documented production behavior.

## Investigation

The first clue was that every failed assertion matched the deliberately customized fake `.env`. The installer output showed no parsing or application error, and rollback succeeded. Reviewing the configuration merge order confirmed that an explicit test mapping is an overlay, not a replacement environment.

## Fix

Subprocess tests now provide explicit safe values for every setting they assert: API-key status, voice, VAD eagerness, session limit, loopback host, port, and browser-launch behavior. The server fixture also explicitly sets the session limit and related local controls.

This preserves the production merge design while making the tests deterministic on machines with customized private settings.

## Regression protection

- The complete 43-test suite is run with a fake ignored `.env` containing non-default voice, VAD, timeout, port, and browser values.
- Installer validation must pass without modifying that file.
- A checksum comparison verifies the private configuration remains byte-for-byte unchanged.
- The installer is rerun after success to verify idempotency under the same customized environment.

## Result

The installer simulation passed with customized local settings, and the private `.env` remained unchanged. Tests now verify defaults only when they explicitly establish a default test environment.

## Engineering lesson

Passing a partial configuration mapping is not the same as isolating a process from project-local configuration. Tests should explicitly control every value they assert, while production code should continue honoring user overrides.

## Recruiter talking point

During release validation, I found that tests passed in a clean workspace but failed on a realistic configured installation. I traced it to layered configuration semantics, kept the production behavior intact, made the fixtures fully deterministic, and verified the installer rolled back safely without touching secrets.
