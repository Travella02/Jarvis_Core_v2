# ISSUE-064 — Transcription artifacts leaked into chat

## Symptom

Normal voice conversations sometimes produced extra user bubbles labeled `Voice input`, followed by the real transcript, and could also display the internal transcription-guidance sentence as though Tanner had spoken it.

## Root cause

Realtime responses could begin before the separate input-transcription completion event arrived. The renderer immediately finalized the pending speech bubble as a fallback and discarded its reference, so a late transcript created a second bubble. In low-information audio, the transcription model could also echo its private guidance prompt; the client treated that text as user speech and durable memory.

## Fix

Voice turns now remain reconcilable for a short grace period after a response begins. Late completed transcripts update the original bubble instead of creating another one. Provider item IDs prevent duplicate rendering, and the exact internal guidance fingerprint is suppressed before display, sleep-command handling, or memory capture. A genuinely unavailable transcript falls back to the neutral label `Voice message` only after the grace period.

## Regression protection

Python client-contract tests verify the delayed fallback, late-transcript reconciliation path, duplicate provider-item guard, and internal-artifact suppression. Node memory tests also require the suppression and reconciliation markers in the packaged renderer.

## Recruiter talking point

I fixed an asynchronous UI race by preserving turn identity across independently timed speech, transcription, and response events, then added provenance-aware filtering so internal model guidance could never become user-visible history or durable memory.
