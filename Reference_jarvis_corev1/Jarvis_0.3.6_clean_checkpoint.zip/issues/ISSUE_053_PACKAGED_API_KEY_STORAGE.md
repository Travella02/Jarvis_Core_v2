# ISSUE_053 — Packaged API key storage

## Symptom

A packaged build had no safe, user-friendly way to configure the OpenAI API key without manually editing a plaintext `.env` file.

## Root cause

The development configuration model was appropriate for source control but not for a consumer-style installed application.

## Fix

Added a first-run setup flow and encrypted the API key with Electron `safeStorage`. The renderer can submit a new key but cannot retrieve the decrypted saved value. The main process passes it only to the loopback Python child process through its environment.

## Regression protection

Node and Python tests validate payload sanitization, encrypted-store structure, narrow IPC, diagnostic redaction, and the absence of a decrypted-key field in setup status.

## Recruiter talking point

I designed a secure desktop secret boundary across an Electron renderer, main process, and Python service while keeping the setup experience approachable for nontechnical users.
