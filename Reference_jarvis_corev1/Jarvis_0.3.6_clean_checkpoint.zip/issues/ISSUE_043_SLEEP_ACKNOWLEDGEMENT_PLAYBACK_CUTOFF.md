# ISSUE 043 — Sleep acknowledgement playback cut off

## Symptom

Jarvis correctly recognized a natural sleep request and began speaking “Of course, sir.”, but the Electron client closed the Realtime session around the comma. The visible transcript could show only “Of course,” while Cedar’s audible sign-off stopped before the phrase completed.

## Impact

The user often talks to Jarvis without looking at the screen. A truncated sign-off made it unclear whether the sleep lifecycle completed intentionally and reduced trust in hands-free operation.

## Investigation

The sleep tool correctly requested a short follow-up audio response and tracked both `response.done` and remote audio. The remaining shutdown boundary depended on the general remote-audio silence detector, which treated 300 ms below the RMS threshold as completed playback. Natural prosody can include a pause of that length between “course” and “sir.” In addition, `response.done` indicates provider generation completion, not that the browser has drained queued WebRTC audio.

## Root cause

A general speaking-timer silence threshold was reused as an authoritative session-shutdown signal. The state machine did not apply acknowledgement-specific hysteresis, minimum audible duration, or a final playback drain guard.

## Fix

- Preserve the normal 300 ms speaking-timer threshold for regular conversation.
- Require 1,100 ms of sustained remote silence for the sleep acknowledgement.
- Require a minimum observed audible segment before shutdown can complete.
- Track the acknowledgement’s first and most recent audible signal separately.
- Replace direct shutdown from `response.done` with a scheduled playback-completion check.
- Add a short drain guard after sustained silence in case another queued audio packet arrives.
- Cancel and re-arm the completion timer whenever audio resumes.
- Extend no-audio and maximum wait fallbacks without allowing a timeout to terminate active playback.

## Regression protection

Automated tests verify the dedicated acknowledgement silence window, minimum audible duration, drain guard, last-signal tracking, playback-completion state machine, and the absence of the old direct `response.done` shutdown path.

## Result

Jarvis waits for Cedar’s complete “Of course, sir.” playback before closing the Realtime session and returning to the wake listener, while ordinary speaking-time metrics remain responsive.

## Engineering lesson

Provider generation completion, audible signal gaps, and actual playback drain are three different boundaries. Destructive lifecycle transitions should use the strictest user-perceived completion condition rather than a generic media heuristic.

## Recruiter talking point

Diagnosed and repaired a WebRTC playback race by introducing acknowledgement-specific audio hysteresis, last-signal tracking, minimum-duration validation, timer cancellation, and bounded fallback behavior before resource teardown.
