# ISSUE 048 — Engineering UI density and state clarity

## Symptom

The desktop application exposed every setting, timing value, cost field, presence control, and provider event in one long engineering dashboard. The active voice state was represented primarily by a small status dot and text label.

## Impact

The interface worked technically but did not feel like the intended Jarvis product. Important conversation and voice state information competed with diagnostics, and the dense page required excessive scrolling on laptop screens.

## Investigation

The existing renderer was reviewed as a product surface rather than only a test harness. All functional control IDs and event bindings were mapped so the interface could be reorganized without changing the proven voice pipeline.

## Root cause

The UI grew incrementally around debugging and acceptance testing. It had no stable information hierarchy or product-level navigation model.

## Fix

0.0.8 introduces a state-driven orb, a conversation-first Home workspace, dedicated Controls/Insights/System views, compact summary cards, responsive layout rules, persisted navigation, and conversation focus mode. Existing operational IDs remain intact.

## Regression protection

`tests/test_interface_foundation.py` verifies the orb, workspace views, persistence, focus-mode behavior, quick-metric mirroring, responsive boundaries, and preservation of all operational controls.

## Result

Jarvis now has a recognizable product interface foundation while retaining the exact local core, WebRTC, wake, sleep, cost, and supervision behavior accepted in 0.0.7.

## Engineering lesson

A working diagnostic surface should not become the permanent product information architecture. Stabilize behavior first, then reorganize presentation around the user's primary task while preserving tested integration contracts.

## Recruiter talking point

I migrated a dense engineering dashboard into a state-driven desktop product interface without breaking a live voice pipeline by preserving DOM/event contracts and adding targeted regression tests around the new interaction model.
