# ISSUE-032 — Initial Electron window exceeded the available screen

## Symptom

On the laptop, Jarvis opened larger than the usable display area. The user had to maximize or otherwise resize the window before the interface fit correctly.

## Impact

The first-run desktop experience was frustrating and controls could be outside the visible work area, especially on smaller displays or displays with taskbars and scaling.

## Root cause

The default window size was fixed at 1440×920, and the visibility check only verified that some part of the window overlapped a display. It did not clamp width, height, or position to the display work area.

## Fix

- Reduced the default shell size to 1280×800.
- Added work-area-aware width and height clamping with margins.
- Selected the display matching the saved bounds, then clamped the position so the entire window remains visible.
- Reduced minimum dimensions to match the responsive interface and smaller laptop screens.
- Preserved valid saved bounds while repairing oversized or off-screen values.

## Regression protection

Tests verify display matching, work-area margin calculations, dimension clamping, centered fallback placement, and responsive minimum bounds.

## Recruiter talking point

I replaced a simple overlap check with a complete multi-display bounds-normalization algorithm that respects the operating system work area, saved positions, minimum usable dimensions, and smaller laptop screens.
