# ISSUE-009 — Typed Message Appeared Twice

## Summary

After `0.0.2 — Voice Control`, a typed message appeared twice in the conversation panel even though the client intended to create only one user conversation item.

## Symptom

Tanner typed a message and pressed Send. The same user text was rendered once immediately and then appeared again when OpenAI returned the completed conversation item event.

The duplicate presentation made it look as though Jarvis had sent the input upstream twice.

## Impact

Typed and spoken input no longer felt equivalent or trustworthy. Duplicate-looking input can also make debugging response behavior difficult because the transcript appears to show two user turns even when the provider received one.

## Root cause

The Voice Lab optimistically rendered the typed message before sending `conversation.item.create`. Later, the provider emitted `conversation.item.done` for that same user item. The shared user-item handler treated the provider echo like a new speech transcript and created a second bubble.

The outbound path itself sent one `conversation.item.create` followed by one `response.create`; the duplication occurred in client transcript reconciliation.

## Investigation

The typed submit handler and provider event handler were traced separately. The submit path contained one item-create call and one response-create call. The second visual copy aligned with the provider's normal `conversation.item.done` event, identifying the problem as optimistic-UI reconciliation rather than duplicate transport.

A secondary rapid-submit guard was added so a double click or repeated submit event cannot create overlapping sends during the same UI action.

## Fix

The client now records each optimistically rendered typed message in a bounded pending queue. When the matching provider user-item echo arrives, Jarvis consumes it as an acknowledgement and finalizes the original bubble instead of creating another one.

The form also locks for the duration of the submit action and rolls back the optimistic bubble if sending fails.

## Regression protection

- The Voice Lab client test requires a pending typed-message queue.
- The test requires a dedicated `consumeTypedEcho` reconciliation path.
- The event handler must render a new user bubble only when the provider event was not a matching typed echo.
- The submit handler must include a re-entry guard.
- Manual acceptance sends several typed messages, including repeated text, and confirms one visible user turn and one Jarvis response per submit.

## Result

Typed messages remain responsive because they still render immediately, but the provider acknowledgement now updates the existing entry rather than duplicating it.

## Engineering lesson

Optimistic interfaces need an explicit reconciliation identity or matching strategy. Rendering locally and later replaying authoritative server events without reconciliation creates duplicate state even when the network request is correct.

## Recruiter talking point

I diagnosed a duplicate-message report by separating transport behavior from UI event reconciliation. I proved the client sent one provider item, traced the second copy to the authoritative echo event, and added a bounded optimistic-message reconciliation queue plus regression coverage.
