# ISSUE-007 — API Boundary Validation

## Summary

During `0.0.2` development, a regression test showed that an invalid VAD option could reach a test provider and receive a successful response.

## Symptom

The endpoint test sent `vad_eagerness=instant` and received HTTP 200 from the fake gateway instead of a local HTTP 400 validation error.

## Impact

The production OpenAI gateway would reject the value, but alternate providers and test doubles were not required to perform identical validation. This made the local contract inconsistent and could produce provider-dependent behavior.

## Root cause

Voice and VAD validation lived only inside the OpenAI gateway. The local HTTP boundary delegated raw query values before establishing that they satisfied Jarvis’s provider-independent contract.

## Investigation

1. Added a negative route test using the same fake gateway as successful handshake tests.
2. Observed that the fake accepted arbitrary values because its purpose was transport isolation.
3. Traced validation to the concrete OpenAI adapter rather than the local API boundary.
4. Identified this as an architecture issue, not a deficient fake.

## Fix

The FastAPI route now normalizes and validates voice and semantic-VAD eagerness before publishing connection events or calling any provider adapter. Invalid values return HTTP 400 and the provider is never invoked.

## Regression protection

`test_invalid_vad_eagerness_is_rejected_before_provider_use` asserts the 400 response and verifies that the fake gateway’s call list remains empty.

## Result

Jarvis owns its configuration contract independently of whichever intelligence provider is connected.

## Engineering lesson

Validate provider-independent policy at the application boundary. Adapters may perform defensive validation too, but they should not be the sole guardians of core contracts.

## Recruiter talking point

“A negative test exposed that validation was coupled to one provider adapter. I moved the contract to the local API boundary so real providers, mocks, and future adapters behave consistently.”
