# ISSUE-014 — Wake first-turn duplication

## Symptom

During live wake-phrase testing, the first natural request could be handled correctly and then be followed by a second unintended user turn. The transcript showed the queued wake request, Jarvis's answer, a new `Processing speech...` user bubble, and a second unrelated answer. Repeating the same test could work normally, making the defect intermittent.

## Impact

The wake flow felt unreliable because one spoken opener could produce two Jarvis responses. It also inflated response counts and estimated usage cost, and the extra phantom user turn made the conversation history misleading.

## Root cause

The sleeping wake listener correctly converted the complete wake phrase into a queued text request, but the newly opened WebRTC microphone became live at nearly the same time. Residual speech, device startup audio, or the tail of the wake utterance could trigger provider VAD after the typed wake request had already been submitted. The same physical opener was therefore represented through two paths:

1. The intended queued text handoff.
2. An unintended initial microphone/VAD turn.

This was a race condition at the boundary between local wake recognition and the cloud Realtime microphone session.

## Investigation

The transcript evidence was important: the second user bubble showed `Processing speech...` rather than a duplicate typed message. That ruled out the previously fixed typed-message echo problem and pointed to the provider audio-input path. The fact that later wake tests worked normally also indicated a timing-sensitive startup condition instead of deterministic double submission.

The repair was designed around first-turn ownership: when a natural wake phrase already contains a request, that queued request must be the only input source until its response finishes.

## Fix

The client now activates a temporary **wake input gate** whenever a wake-triggered connection has a queued opening request.

- The outgoing microphone track is disabled before it is attached to the active Realtime conversation.
- The queued wake request is sent only after the data channel opens.
- Provider input-audio/VAD events received while the gate is active are discarded and the provider input buffer is cleared.
- The microphone is released only after the opening response is complete and its audible remote audio has ended, with a bounded safety timeout.
- Manual mute, cleanup, provider errors, dispatch failures, and sleep all respect or release the gate safely.

Wake-word-only activation still opens the microphone normally because there is no queued request competing for the first turn.

## Regression protection

Automated tests assert that:

- A wake-triggered opening request activates the microphone gate.
- The local audio track is disabled while the queued prompt owns the first turn.
- Provider input-audio events are suppressed during the gate.
- The input buffer is cleared before microphone release.
- The gate releases after the opening response and audible output finish.
- Manual mute cannot accidentally bypass the gate.

Live acceptance requires repeating full wake phrases several times and confirming exactly one user turn and one Jarvis response per opener.

## Recruiter talking point

I diagnosed an intermittent duplicate-turn bug by separating the optimistic text handoff from the provider microphone path. I implemented a first-turn ownership gate that coordinates local wake recognition, WebRTC microphone transport, provider VAD, response lifecycle, and actual audio playback, eliminating a race without disabling normal interruption behavior after the opening response.
