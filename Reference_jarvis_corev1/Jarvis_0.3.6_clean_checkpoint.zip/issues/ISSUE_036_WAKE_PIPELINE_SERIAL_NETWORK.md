# ISSUE-036 — Wake Pipeline Serial Network Latency

## Symptom

After the first wake-speed repair, the window opened correctly and false activations remained controlled, but Jarvis still felt much too slow after the user finished saying the wake phrase. The visible delay occurred after speech capture, before Cedar began answering.

## Scope and impact

The delay affected every model-based wake in the Electron desktop application. Manual Wake was faster, which isolated the regression to the sleeping-state wake handoff rather than the Realtime model's normal response speed.

## Root cause

The wake path still performed its two slowest network operations sequentially. Jarvis first uploaded the completed utterance for model transcription and waited for the result. Only after confirming the Jarvis keyword did it reacquire the microphone, build the WebRTC offer, create the Realtime session, and open the data channel. The transcription gateway and Realtime gateway also created fresh HTTP clients, so cold DNS/TLS setup could be repeated.

The wake microphone was then closed and reopened for Realtime, adding another device-acquisition delay. The captured WAV remained at the computer's 48 kHz sample rate even though 16 kHz mono is sufficient for speech transcription, increasing the upload payload.

## Investigation

The pipeline was decomposed into four independently measurable stages: end-of-speech detection, wake transcription, WebRTC handshake, and first response dispatch. The previous repair had reduced local VAD waits, but the two provider requests still sat one after the other. Manual Wake bypassed transcription and therefore confirmed that the remaining delay was architectural rather than solely model inference.

## Fix

- Start a microphone-gated speculative Realtime connection immediately after a valid local utterance ends.
- Run wake transcription and WebRTC session creation concurrently.
- Cancel the speculative connection safely when the transcript does not contain the wake keyword or transcription fails.
- Hand the existing wake microphone stream directly to WebRTC instead of requesting the device again.
- Downsample captured wake audio to 16 kHz mono before upload.
- Prewarm both provider connections during desktop initialization without blocking the interface.
- Reuse production HTTP connection pools across wake and session requests.
- Shorten adaptive end-of-speech detection to 280–450 ms while retaining noise-floor, voiced-duration, peak-energy, and opening-turn gate protections.

## Regression protection

The automated suite verifies that preconnection begins before the transcription request is awaited, rejected wake attempts cancel the speculative session, the wake stream is reused, the microphone remains gated, audio is downsampled to 16 kHz, provider prewarming is protected by the trusted local-client header, and the provider clients use persistent production pools. Existing tests continue protecting false-wake rejection and duplicate-opening-turn behavior.

## Result

The transcription and Realtime handshake now overlap rather than accumulate. The first valid wake after application startup also benefits from prewarmed provider connections, while later wakes reuse established HTTP connection pools.

## Recruiter talking point

I reduced assistant wake latency by profiling the entire critical path and parallelizing independent network operations, reusing media and HTTP resources, and adding cancellation semantics so speculative work remained safe when the wake keyword was absent.
