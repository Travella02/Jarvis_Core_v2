# ISSUE-022 — Cross-platform `.gitignore` validation failure

## Symptom

The `0.0.5 — Electron Shell` installer stopped before applying the update and reported:

```text
update stopped to avoid overwriting unexpected edits: .gitignore has local changes
```

Running the installer again produced the same result. The rollback path completed, so the accepted `0.0.4` project files remained intact.

## Impact

The desktop update could not be installed on the Windows laptop even though the tracked project was otherwise valid. No Electron dependencies were installed and no accepted source files were intentionally changed.

## Root cause

The installer compared raw SHA-256 bytes. `.gitattributes` marked `.gitignore` only as generic text, so Git could check it out with CRLF line endings on Windows while the release baseline had LF line endings. The text was semantically identical, but the byte hashes differed and the installer incorrectly classified the file as a user edit.

## Investigation

The failure affected only `.gitignore`, while Python, JSON, Markdown, and TOML files passed baseline validation. Those formats already had explicit `eol=lf` rules. Comparing the accepted `.gitignore` with a CRLF-normalized copy reproduced the exact class of false conflict.

The correct repair was not to disable conflict protection. That would risk overwriting real user changes. Instead, validation needed to distinguish semantic text equality from binary equality while preserving strict checks for binary files.

## Fix

- The repair installer normalizes CRLF and CR line endings to LF when comparing known text files.
- Payload checksum verification remains byte-exact.
- Binary files continue using raw SHA-256 validation.
- `.gitattributes` now explicitly enforces LF for `.gitignore` and `.gitattributes` on future checkouts.
- Real content edits still stop the installer.

## Regression protection

- Added a release-consistency test that requires deterministic LF rules for both Git control files.
- Tested installation from an accepted `0.0.4` tree whose `.gitignore` was converted to CRLF.
- Tested that a genuine added line in `.gitignore` is still rejected.
- Tested installer rollback, idempotent rerun, and byte-for-byte `.env` preservation.

## Result

The Electron Shell installer now accepts semantically identical Windows and Unix text checkouts without weakening overwrite protection.

## Recruiter talking point

I diagnosed a cross-platform deployment failure caused by line-ending-sensitive integrity checks. I replaced raw text-file comparison with canonicalized validation while retaining byte-exact checks for payloads and binary assets, then added Git attribute rules and regression tests so true local edits still remain protected.
