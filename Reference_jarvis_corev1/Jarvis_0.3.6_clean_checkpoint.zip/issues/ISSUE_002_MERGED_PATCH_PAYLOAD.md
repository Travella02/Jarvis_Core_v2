# ISSUE-002 — Merged Patch Payload

## Summary

A repair installer rejected its own valid payload after Windows merged the new `patch_files` directory with files left by an earlier patch.

## Symptom

The installer reported dozens of unexpected extra files and stopped before changing the project.

## Impact

No source files were damaged because validation occurred before installation, but the normal Windows extraction workflow could not proceed.

## Root cause

The installer assumed `patch_files` was an isolated directory containing only the active release. Windows folder merging preserved older payload files, so directory-wide equality was stricter than the release manifest contract required.

## Investigation

1. Recreated the sequence of extracting the bootstrap and then extracting the repair into the same project root.
2. Verified all files required by the active manifest had correct checksums.
3. Confirmed the rejected extras belonged to previous signed payloads and were not referenced by the current manifest.
4. Verified the failure happened before project modification.

## Fix

Installers now treat `RELEASE_MANIFEST.json` as the authoritative file list. They verify every listed file and checksum, install only those files, and report—but safely ignore—unrelated files already present in `patch_files`.

## Regression protection

Installer integration tests merge multiple patch payloads into one directory and confirm only manifest-listed files are copied. Missing or checksum-invalid manifest files still fail closed.

## Result

Users can extract successive ZIP packages with normal Windows merge behavior without deleting payload folders between every attempted repair.

## Engineering lesson

A manifest should define the trusted installation boundary. Unrelated files should not gain authority merely because they share a staging directory, but they also should not break a valid scoped release.

## Recruiter talking point

“I hardened a patch system after discovering that Windows directory merging violated an isolation assumption. I changed validation from directory equality to checksum-verified manifest scope while preserving fail-closed behavior.”
