# ISSUE-049 — Orb state flicker and hard transitions

## Symptom

During live voice acceptance, the new Jarvis orb rapidly alternated between **Speaking** and **Listening** while Cedar was still audibly delivering one uninterrupted response. State colors and labels also changed instantly, making the interface feel fragile rather than calm and intentional.

## Impact

The orb is the primary at-a-glance representation of Jarvis. Even though the underlying Realtime conversation remained healthy, transient media events made the product appear unstable and could mislead the user into thinking Jarvis had stopped speaking or accepted an interruption.

## Investigation

The renderer previously sent every lifecycle signal directly into `setStatus()`. OpenAI could complete response generation before Electron finished playing the received audio, and the local analyser could observe short low-energy gaps between audio chunks. These normal cross-layer timing differences caused a sequence such as:

```text
Speaking -> response.done -> Listening -> next audible chunk -> Speaking
```

The voice session itself did not actually transition between those states.

## Root cause

Operational provider events and visual presentation state were treated as the same thing. The interface had no presentation-layer hysteresis, no pending-state cancellation, and no minimum release period after Speaking. In addition, most orb properties had no CSS transitions, so legitimate state changes appeared as hard cuts.

## Fix

- Added a dedicated visual-state coordinator behind `setStatus()`.
- Kept desktop lifecycle notifications immediate while allowing the renderer to stabilize presentation-only transitions.
- Added an 850 ms Speaking-to-Listening release window.
- Cancelled a pending Listening transition immediately if more audible speech arrives.
- Allowed genuine user interruption and speech-start events to force Listening immediately.
- Added a short Thinking-to-Listening debounce for transient provider ordering.
- Added smooth color, glow, shadow, opacity, scale, and copy-settling transitions across the orb, status dot, and state text.
- Preserved reduced-motion behavior by disabling the new visual animation when requested by the operating system.

## Regression protection

Automated tests verify that:

- The renderer contains presentation hysteresis constants and pending-state cancellation.
- Speaking is an immediate visual state while Speaking-to-Listening is delayed.
- User interruption can bypass the release delay.
- Orb components define gradual transitions.
- Reduced-motion mode still disables transitions and animation.

Live acceptance requires a long Cedar response with natural pauses to remain visually Speaking until audible playback is complete.

## Result

Provider-event jitter no longer directly flashes the orb between states. The interface now presents a stable Speaking state through short playback gaps and settles gradually into Listening afterward.

## Engineering lesson

A product-facing state indicator should not mirror every transport event one-for-one. Operational truth and visual truth share the same source, but the visual layer often needs bounded hysteresis so harmless timing differences do not become visible instability.

## Recruiter talking point

I separated transport lifecycle events from presentation state, implemented cancellable hysteresis for audio playback, and added accessible CSS transitions. This fixed a live UI flicker without weakening interruption responsiveness or changing the authoritative voice state machine.
