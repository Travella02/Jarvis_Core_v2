# ISSUE-065 — Response token cap cut off speech

## Symptom

Jarvis could stop speaking in the middle of a sentence while the chat transcript ended with an unfinished phrase, even though Normal mode already instructed the model to stay concise.

## Root cause

Every Normal response was hard-capped at 384 output tokens. Realtime output-token accounting includes the generated audio response, so otherwise reasonable spoken answers could reach the cap before the model completed its thought.

## Fix

Normal and Full modes now use the Realtime API's model-maximum setting, `inf`, while retaining concise behavioral instructions. Test mode keeps its 96-token cost-control cap. `inf` does not mean an unbounded response; it allows the selected model's supported maximum instead of imposing Jarvis's smaller artificial cutoff.

## Regression protection

Provider tests require Normal and Full modes to serialize `max_output_tokens` as `inf` and require Test mode to remain capped at 96. Existing response-mode instruction tests continue to enforce concise Normal behavior.

## Recruiter talking point

I separated behavioral brevity from transport-level truncation: prompt instructions control style, while the protocol limit no longer terminates valid speech mid-sentence. A dedicated low-cost test mode preserves a deliberate hard cap where it is useful.
