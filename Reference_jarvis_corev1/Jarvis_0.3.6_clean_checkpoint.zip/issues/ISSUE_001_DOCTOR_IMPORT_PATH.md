# ISSUE-001 — Doctor Import Path

## Summary

Running the documented command `python scripts/doctor.py` failed even though the bootstrap tests had passed.

## Symptom

The script terminated with `ModuleNotFoundError` while importing the local `jarvis` package.

## Impact

The project itself had installed successfully, but the first user-facing health check appeared broken. This reduced confidence in the bootstrap and blocked the documented validation workflow.

## Root cause

Python sets the first import-search location to the directory containing the directly executed script. For `scripts/doctor.py`, that location was `scripts/`, not the repository root. The unit-test process happened to start from the repository root, so it did not reproduce the documented direct invocation.

## Investigation

1. Confirmed the virtual environment, repository, and package files existed.
2. Compared the execution context of `unittest discover` with direct script execution.
3. Reproduced the failure from a parent working directory with `PYTHONPATH` removed.
4. Verified the error was import resolution rather than installation corruption.

## Fix

The doctor script now resolves its repository root from `__file__` and inserts that path into `sys.path` before importing project packages.

## Regression protection

`tests/test_doctor_script.py` launches the exact documented command in a subprocess, from outside the repository root, without relying on `PYTHONPATH`. It verifies successful imports and secret-safe output.

## Result

The direct health-check command works consistently from PowerShell and from automated installer validation.

## Engineering lesson

Tests should execute public commands exactly as users execute them. Import behavior can differ substantially between module execution and direct script execution.

## Recruiter talking point

“I diagnosed a Python packaging issue that passed unit tests but failed through the documented CLI path. I reproduced the user environment in a subprocess and added a regression test around the actual command.”
