# ISSUE-068 — Literal search could not express temporal or entity intent

## Symptom

Queries such as “what did I say yesterday?” or “show me everything about ORVEX” could fail because filler words were treated as literal full-text terms and no date, actor, source, or entity filters were inferred.

## Root cause

The original endpoint exposed only direct full-text and field filters. It did not include a deterministic query-interpretation layer for common personal-memory language.

## Fix

Memory Explorer interprets relative dates, actors, sources, importance, review status, and known entity names, removes non-semantic filler words, applies structured filters, and shows the interpretation in the UI.

## Regression protection

Tests freeze interpretation of entity-plus-date queries and verify the desktop displays interpreted filters rather than silently hiding search behavior.

## Recruiter talking point

Implemented transparent natural-language query interpretation that converts conversational recall requests into auditable structured filters without requiring an opaque model call.
