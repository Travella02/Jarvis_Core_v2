# ISSUE-016 — Wake microphone reopened before audio playback finished

## Symptom

A full wake phrase such as **“Jarvis, tell me a joke”** correctly produced the intended first response, but an extra **“Processing speech…”** user bubble sometimes appeared immediately afterward and Jarvis answered the same request a second time.

## Impact

The wake request looked duplicated even though the queued text message itself was sent only once. This made wake detection feel unreliable and increased unnecessary provider usage and estimated cost.

## Root cause

The first-turn microphone gate used `response.done` as one signal that the opening turn had completed. In Realtime WebRTC, `response.done` can arrive before the remote audio track has begun or finished audible playback because provider generation completion and browser playback completion are separate timelines.

When `response.done` arrived before the analyser observed the first remote audio samples, the client concluded that there was no active audio and reopened the microphone. Cedar's answer then played through the laptop speakers while the microphone was live. The provider VAD interpreted that playback or acoustic tail as a new user turn, creating the phantom processing bubble and duplicate response.

## Investigation

The visible sequence was important:

1. The intended wake text appeared once.
2. Jarvis produced the correct first answer.
3. A new processing bubble appeared only after or during that answer.
4. Jarvis repeated the answer.

That sequence ruled out duplicate wake-text dispatch and pointed to a second audio/VAD turn. Review of the gate state showed an early-release branch inside `response.done` that could run before browser audio playback had started.

## Fix

The wake gate now tracks provider completion and audible playback as separate conditions:

- `response.done` marks the opening provider response complete but does not immediately reopen the microphone.
- The remote-audio analyser marks that opening audio was actually observed.
- The gate normally releases only after observed audio has returned to sustained silence.
- If no audible signal is observed, a bounded grace timer releases the gate as a fallback for text-only, failed-audio, or analyser-unavailable cases.
- Any observed audio cancels the fallback timer.
- The post-audio microphone release delay was increased slightly to avoid reopening during the speaker's acoustic tail.
- Gate state and timers reset together during cleanup, errors, and sleep.

## Regression protection

Automated tests assert that:

- The wake gate records separate `wakeOpeningResponseDone` and `wakeOpeningAudioObserved` states.
- `response.done` waits for remote audio rather than directly releasing the gate.
- Audible remote output cancels the no-audio fallback timer.
- Normal release occurs after the analyser finalizes the opening audio segment.
- A bounded fallback remains for responses where no remote audio is ever observed.

Live acceptance requires at least five full wake requests with exactly one visible user turn and one Jarvis response each.

## Recruiter talking point

I debugged a race between provider lifecycle events and actual browser media playback. Instead of treating `response.done` as proof that the user could safely regain the microphone, I synchronized the wake gate against analyser-observed audio completion and added a bounded fallback for no-audio cases.
