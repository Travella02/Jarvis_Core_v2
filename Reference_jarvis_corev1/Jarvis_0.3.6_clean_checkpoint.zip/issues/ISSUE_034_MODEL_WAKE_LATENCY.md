# ISSUE-034 — Model Wake Latency

## Symptom

After false-wake and duplicate-turn protections were added, saying “Jarvis” reliably woke the assistant but the delay before the first response felt much too long for a natural assistant.

## Root cause

The safety repair introduced several serial waits in the wake path: a 1.2-second microphone calibration, a hard minimum of 1.2 seconds of trailing silence, a larger Web Audio processing buffer, a fresh usage-summary request, and an awaited device refresh before WebRTC setup. Each step was individually defensible, but together they added noticeable latency before transcription and connection could even begin.

## Fix

The wake detector now uses a 300 ms adaptive calibration, a 1024-sample processor, and a bounded 450–700 ms end-of-speech window. Recent budget state is reused for 30 seconds, and nonessential device enumeration is deferred until after the Realtime connection succeeds. Noise-floor adaptation, consecutive-frame confirmation, voiced-duration checks, peak-energy checks, the opening-turn microphone gate, and provider input clearing remain intact.

## Regression protection

The Voice Lab regression suite verifies the fast calibration and processor size, the bounded silence window, cached budget preflight, and removal of device enumeration from the serial WebRTC setup path. Existing tests continue verifying false-wake rejection and opening-turn ownership.

## Recruiter talking point

I profiled a latency regression as an end-to-end pipeline rather than blaming the model alone, then removed unnecessary serial waits while preserving the safety controls that had fixed false activations and duplicate turns.
