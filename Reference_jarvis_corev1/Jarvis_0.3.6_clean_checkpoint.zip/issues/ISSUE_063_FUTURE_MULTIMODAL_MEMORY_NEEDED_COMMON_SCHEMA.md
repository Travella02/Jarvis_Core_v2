# ISSUE-063 — Future multimodal memory needed a common schema

## Symptom

Voice identity, vision, web research, app activity, email, calendar, files, and tools would otherwise create isolated storage silos that could not answer who did what, when, or how Jarvis knows.

## Root cause

The project previously had no shared event contract for current conversation data and future sensors/connectors.

## Investigation

The schema was reviewed against future requirements: speaker attribution, observations, searches, actions, files, privacy boundaries, confidence, relationships, duplicate handling, and cross-source timelines.

## Fix

Defined shared source and event-kind enums plus generic metadata, actor, timestamp, category, entity, and fact relationships. Current voice/chat producers use the same API that future vision, web, app, email, calendar, file, and tool producers can call.

## Regression protection

Model and API tests validate all source types, bounded metadata, autonomous category creation, and shared timeline retrieval without source-specific database tables.

## Recruiter talking point

Created an extensible multimodal event model early so future sensors and integrations can contribute to one coherent personal knowledge graph instead of fragmented histories.
