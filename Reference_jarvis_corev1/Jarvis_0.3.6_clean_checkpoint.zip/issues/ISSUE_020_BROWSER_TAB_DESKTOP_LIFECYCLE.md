# ISSUE-020 — Browser Tab Could Not Own Desktop Lifecycle

## Summary

The proven Realtime Voice Lab ran correctly in Chromium, but it still behaved like a web page. It could not own a system tray, prevent duplicate application instances, restore native window placement, or reliably start and stop the local Python core.

## Symptom

Starting Jarvis opened a browser tab and required the Python server to be launched separately. Closing the tab did not represent quitting Jarvis, and there was no native background-presence control.

## Root cause

The browser renderer was being used as both the interface and the application shell. Browser pages do not have authority over native application process management or Windows tray behavior.

## Fix

`0.0.5` adds a hardened Electron main process and preload boundary. Electron owns the native window, tray menu, single-instance lock, window-state persistence, Python-core child process, health polling, recovery view, and clean shutdown. The existing WebRTC client remains a renderer served by the independent loopback Python core.

## Regression protection

- Static Electron-shell tests verify the single-instance lock, tray actions, process shutdown, state persistence, and renderer security options.
- Node syntax checks cover the main process, preload, and Voice Lab client.
- Python tests continue validating the independent core.

## Engineering lesson

Desktop lifecycle belongs in the native shell, while business logic and provider authority remain in the independent local core.

## Recruiter talking point

I migrated a working browser-based Realtime prototype into a secure Electron shell without merging the desktop process and Python core, preserving provider isolation while adding tray lifecycle, single-instance protection, native window state, and supervised process startup.
