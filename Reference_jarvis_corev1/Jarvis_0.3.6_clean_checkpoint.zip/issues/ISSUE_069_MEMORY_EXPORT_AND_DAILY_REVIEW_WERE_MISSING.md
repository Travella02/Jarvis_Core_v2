# ISSUE-069 — Memory export and daily review were missing

## Symptom

Tanner could not review one day as a coherent timeline or export a filtered memory set for backup, audit, or transfer.

## Root cause

The memory API returned search rows but lacked summary aggregation and downloadable serialization formats.

## Fix

`0.1.2` adds deterministic daily summaries and filtered JSON/Markdown exports containing timestamps, source, category, privacy, status, and provenance fields.

## Regression protection

Tests verify daily counts, category aggregation, export media types, filenames, attachment headers, and provenance content.

## Recruiter talking point

Added user-owned export and review capabilities to a local-first memory system, making AI-derived organization inspectable and portable.
