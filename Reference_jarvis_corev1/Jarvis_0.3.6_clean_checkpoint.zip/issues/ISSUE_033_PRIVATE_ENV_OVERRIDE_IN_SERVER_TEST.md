# ISSUE-033 — Private `.env` settings leaked into a server test

## Symptom

The `0.0.5 — Desktop Stability Repair` installer reached the full test suite but failed one server configuration assertion. The test expected a 1,200 ms wake-silence value, while the developer machine correctly returned the preserved private `.env` value of 750 ms.

## Impact

The update rolled back even though the application code and private configuration were both valid. This blocked installation on a machine whose local settings differed from release defaults.

## Root cause

The server test built `ProjectSettings` from a partial environment overlay while still using the real project root. Any omitted setting could therefore be inherited from the developer's private `.env`. The assertion then compared the API response to a hard-coded release default instead of the explicit settings object supplied to the server.

## Fix

- Added explicit wake-transcription and wake-VAD values to the server test environment.
- Changed the endpoint assertion to compare the returned value with `self.settings.wake_vad_silence_ms`, proving that the API reflects its authoritative settings rather than assuming a global constant.
- Updated the patch installer to run the test suite with a deterministic, secret-free configuration overlay so private machine settings cannot alter release validation.
- Continued preserving the user's `.env` byte-for-byte.

## Regression protection

The repaired suite is validated with a private `.env` containing the older 750 ms value. The complete test run must still pass, the installer must succeed, a second run must be idempotent, and the `.env` checksum must remain unchanged.

## Recruiter talking point

I diagnosed a configuration-isolation failure where a valid local override contaminated an automated release test. I separated release defaults from user-owned settings, made the test assert against the injected configuration contract, and added a deterministic test environment without modifying private secrets.
