# ISSUE-019 — Normal voice turns remained stuck on “Processing speech…”

## Symptom

Wake-phrase requests displayed their captured text correctly, but ordinary follow-up speech created a user bubble that stayed on **“Processing speech…”** even though Jarvis heard the turn and answered normally.

## Impact

The conversation panel made a successful voice turn look incomplete or broken. It also made genuine duplicate-turn problems harder to distinguish from a normal second spoken request during live acceptance testing.

## Root cause

The Realtime model consumes user audio directly. Exact input transcription is a separate ASR process and is disabled by default in the current cost-control configuration. The UI created an optimistic `Listening…` bubble and changed it to `Processing speech…`, but it assumed a later transcription event would always replace that placeholder. With transcription disabled, no such event was guaranteed.

## Investigation

The provider event flow and screenshot were compared against the active session configuration:

- User speech start and stop events arrived correctly.
- Jarvis created and completed the expected response.
- Response count and usage accounting were correct.
- No input-transcription completion event arrived for the ordinary voice turn.
- The wake phrase looked different because its text came from the separate sleeping-state wake listener, not from the Realtime input-audio stream.

OpenAI documents that input audio transcription defaults to off and runs as a separate asynchronous transcription process rather than representing what the native audio model heard.

## Fix

The Voice Lab now finalizes unresolved voice placeholders as **“Voice input”** when a response begins or completes without an exact transcript.

The repair also:

- Converts placeholder-only `conversation.item.done` events to **“Voice input”**.
- Keeps actual typed text and any future real transcript unchanged.
- Prevents the fallback label from being interpreted as a spoken sleep command.
- Adds an explanatory note to the Conversation panel.
- Deliberately does not enable separate transcription automatically, preserving the cost-control objective.

## Regression protection

Automated tests verify that:

- The placeholder detector recognizes both three-dot and ellipsis variants.
- `response.created` and `response.done` finalize unresolved voice bubbles.
- The visible fallback is **“Voice input”**.
- The Realtime session still does not silently enable a separate transcription service.

Manual acceptance requires one wake request followed by an ordinary spoken follow-up. The second user bubble must show **“Voice input”**, not remain on **“Processing speech…”**.

## Recruiter talking point

I traced a misleading UI state to an incorrect event-contract assumption: the audio-native model could answer without producing a separate ASR transcript. I added a deterministic fallback at response lifecycle boundaries, preserved real transcripts when present, and avoided adding hidden transcription cost just to repair presentation state.
