# ISSUE-010 — Forced Low Semantic VAD Delayed Responses

## Summary

`0.0.2 — Voice Control` forced semantic VAD with low eagerness to provide more room for mid-sentence pauses. In Tanner's real microphone environment, Jarvis waited noticeably too long after speech had clearly ended.

## Symptom

Before the voice-control update, Jarvis generally detected the end of Tanner's turn at a comfortable speed. After the update, he continued listening for too long before beginning a response.

## Impact

The extra wait made the otherwise low-latency Realtime interaction feel sluggish. It also showed that a globally selected “safer” pause profile was not automatically the best profile for Tanner's room, microphone, cadence, and provider model.

## Root cause

The session builder explicitly replaced OpenAI Realtime's provider default turn detection with `semantic_vad` and `eagerness=low`. Low semantic eagerness is intentionally designed to allow longer pauses, so the observed delay was expected behavior for that configuration rather than a provider failure.

## Investigation

The behavior changed immediately after the explicit semantic-VAD configuration was introduced. OpenAI's current Realtime VAD documentation states that speech-to-speech sessions default to `server_vad`, while semantic eagerness `low` gives the speaker more time and `auto` is equivalent to medium.

Because the earlier provider-managed behavior worked well, the investigation favored removing the forced override rather than guessing a new silence threshold.

## Fix

Jarvis now defaults to `provider_default`. In this profile, the local session configuration omits `turn_detection`, allowing the current Realtime provider and model to apply their supported default behavior.

The Voice Lab still exposes opt-in semantic profiles—auto, low, medium, and high—so Tanner can tune behavior without editing code. The new preference version intentionally discards the old low-VAD default while preserving voice and audio-device preferences.

A new local setting, `JARVIS_TURN_DETECTION_PROFILE`, replaces the older eagerness-only setting. A legacy `JARVIS_VAD_EAGERNESS` entry no longer silently forces the old low profile.

## Regression protection

- Configuration tests assert `provider_default` is the clean default.
- Provider tests assert the default session payload omits `turn_detection` entirely.
- Separate tests verify semantic profiles still generate valid `semantic_vad` configuration.
- API tests validate profile values before provider delegation.
- Client tests require provider default to be selected while preserving all semantic tuning options.
- Manual acceptance compares end-of-speech responsiveness with provider default and optional semantic profiles.

## Result

Jarvis returns to provider-managed end-of-turn timing by default, while advanced tuning remains available and explicit.

## Engineering lesson

A tuning option should not become a global default solely because it sounds safer in theory. Preserve strong provider defaults until real measurements justify an override, and expose experimentation as configuration rather than hard-coded behavior.

## Recruiter talking point

I used live user feedback to reverse an over-tuned voice setting. Rather than guessing another threshold, I traced the delay to an intentional semantic-VAD profile, restored provider-default behavior by omitting the override, retained opt-in tuning, and added contract tests around the exact API payload.
