# ISSUE_054 — Alpha diagnostic visibility

## Symptom

An installed alpha could fail on another computer without an easy way to identify versions, paths, recent recovery events, or local-core output.

## Root cause

Development diagnostics were spread across a terminal, source-tree logs, and UI panels that would not all exist in a packaged launch.

## Fix

Added rotating per-user process logs, a secret-redacted JSON diagnostic export, installed-runtime and path visibility, and a bounded read-only GitHub release check.

## Regression protection

Tests verify diagnostic redaction, native save-dialog usage, external data/log paths, GitHub host validation, and the absence of automatic update installation.

## Recruiter talking point

I added production-grade observability to a desktop alpha while deliberately separating operational evidence from secrets and personal conversation data.
