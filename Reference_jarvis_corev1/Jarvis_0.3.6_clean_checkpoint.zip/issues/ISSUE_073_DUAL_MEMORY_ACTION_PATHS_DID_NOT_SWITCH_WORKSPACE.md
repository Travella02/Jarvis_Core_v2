# ISSUE-073 — Dual memory action paths did not switch the visible workspace

## Symptom

A live request such as “Show me everything about ORVEX” produced a verbal answer, but the interface remained on Home. The conversation could also show an empty Jarvis bubble followed by a claim that Memory Explorer was still loading.

## Root cause

The display action had two owners: deterministic renderer interception and a Realtime `show_memory` function tool. Provider event ordering could start or complete the tool response while the local navigation path was still resolving. The extra function-call output cycle also created a second response lifecycle and made UI success dependent on model behavior. The workspace switch relied primarily on classes, so any stale Focus state or renderer asset could leave Home visible even when memory loading had started.

## Fix

- Removed the Realtime `show_memory` tool and its follow-up response cycle.
- Made the local renderer the single authority for visual memory commands.
- Performs the Memory workspace switch synchronously before network or model work.
- Clears Focus mode and explicitly updates classes, `hidden`, `aria-hidden`, `inert`, and inline display state.
- Keeps a bounded visibility guard active while the memory query resolves.
- Advances renderer cache-busting to the repair3 asset version.
- Keeps entity matching and timeline fallback fully local.

## Regression protection

Python renderer-contract tests verify typed and voice interception, forced workspace state, cache-busted assets, and the absence of the former model-tool handlers. Node tests verify visual intent parsing, unrelated-command rejection, and fuzzy entity resolution.

## Outcome

“Show me…” is now a deterministic desktop command. Jarvis may summarize the result, but the model no longer controls whether the visual workspace opens.

## Lessons

A local UI navigation action should have one owner. Model tools are valuable for autonomous external actions, but they add unnecessary timing and response-state complexity when a deterministic client command can be recognized safely and executed immediately.
