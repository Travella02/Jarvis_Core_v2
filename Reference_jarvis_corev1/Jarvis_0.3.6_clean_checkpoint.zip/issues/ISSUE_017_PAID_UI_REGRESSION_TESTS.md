# ISSUE-017 — UI regression testing required paid Realtime calls

## Symptom

Validating wake detection, timers, transcript behavior, idle sleep, and duplicate-turn fixes required repeatedly opening live OpenAI Realtime sessions. A short repair cycle consumed about **$0.20** even though most of the checks were interface and lifecycle checks rather than model-quality checks.

## Impact

Routine development had a direct cost and encouraged fewer repetitions than a reliability-sensitive voice workflow should receive. A UI regression could either be under-tested or require avoidable paid audio output.

## Root cause

The Voice Lab had only one provider path. Its state transitions, transcript rendering, timers, sleep controls, wake dispatch, and interruption controls were coupled to a live WebRTC session. There was no deterministic local provider capable of producing representative events without contacting OpenAI.

## Investigation

The automated Python and JavaScript checks did not spend API money. The spend occurred only during manual live acceptance. Review of the acceptance steps showed that most checks needed predictable lifecycle events, not model intelligence:

- Wake and sleep transitions.
- One visible user turn per request.
- Jarvis response rendering.
- Timer movement.
- Interruption and idle behavior.
- Budget panel updates.

Only final voice quality, real VAD, audio playback, and provider usage metadata truly required a live call.

## Fix

`0.0.4 — Cost Control` adds a **Local simulation — free** connection mode:

- No OpenAI session or API key is used.
- Wake-only and full wake requests exercise the same UI dispatch path.
- Typed turns produce deterministic simulated responses.
- Test, Normal, and Full response modes can be previewed.
- Sleep, idle timeout, timers, transcript updates, and interruption controls remain testable.
- Simulated responses are explicitly labeled in provider diagnostics and always report zero API cost.

Live mode remains available for a small final acceptance set.

## Regression protection

Automated tests assert that simulation mode exists, does not use the live WebRTC creation path, supports wake and typed responses, and reports zero cost. The testing guide separates free simulation checks from the minimal paid live checklist.

## Recruiter talking point

I reduced the cost of a Realtime voice-agent test loop by separating deterministic UI/lifecycle validation from provider-quality validation. I introduced a local simulation provider so most regressions can be reproduced repeatedly for free, reserving paid calls for final audio and model acceptance.
