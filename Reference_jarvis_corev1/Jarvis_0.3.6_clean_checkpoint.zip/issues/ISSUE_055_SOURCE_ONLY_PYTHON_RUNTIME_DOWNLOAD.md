# ISSUE_055 — Source-only Python runtime download

## Symptom

`npm run alpha:make` stopped during `alpha:runtime` with `HTTP Error 404: Not Found`. The installer was never produced, so `npm run alpha:verify` then reported that no Squirrel Setup executable existed.

## Root cause

The embedded-runtime builder requested `python-3.12.13-embed-amd64.zip`. Python 3.12.13 is a security-only source release and does not publish Windows installers or embeddable packages. Python 3.12.10 is the final Python 3.12 release with official Windows binary artifacts.

## Fix

Pinned the private runtime to the official 64-bit Python 3.12.10 embeddable archive, switched to the canonical `embeddable-amd64` artifact, and added its official SHA-256 checksum. The builder now rejects corrupt cached or downloaded archives, removes failed temporary downloads, and requires a matching 64-bit Python 3.12 build interpreter so compiled dependency wheels remain ABI-compatible.

## Regression protection

Automated tests verify the exact release, URL, archive name, and checksum; confirm valid cached archives are reused; confirm stale archives are replaced; and confirm checksum failures cannot be promoted into the bundled runtime. The alpha plan check also prints the pinned URL and digest before a native build.

## Recruiter talking point

I diagnosed a packaging failure caused by a language release moving to source-only support, then hardened the distribution pipeline with a compatible binary pin, supply-chain checksum validation, cache recovery, and ABI guards.
