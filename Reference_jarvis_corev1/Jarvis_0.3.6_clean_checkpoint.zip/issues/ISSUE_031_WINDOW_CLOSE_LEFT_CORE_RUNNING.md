# ISSUE-031 — Closing the Electron window left Jarvis running and speaking

## Symptom

Clicking the window close button hid the Electron window instead of ending the application. The Python core and active Realtime audio continued running, so Jarvis could keep talking after the user believed the app was closed.

## Impact

This violated user expectations, could continue API spending, and left background microphone/audio activity active without a visible window.

## Root cause

The initial desktop shell intentionally implemented close-to-tray behavior by canceling the close event and hiding the window. That behavior was not explicit in the interface and did not match the desired close semantics.

## Fix

- Changed the window close button to close the window and trigger a full Jarvis quit.
- Added a single `quitJarvis` path that saves bounds, terminates the Python process tree, and exits Electron.
- Added `will-quit` and process-exit cleanup as defensive process-supervision layers.
- Kept background operation available only through an explicit **Hide Jarvis** tray command.

## Regression protection

Tests verify the absence of `event.preventDefault()` in the close path, the presence of explicit Hide and Quit tray actions, `window-all-closed` routing through `quitJarvis`, and Python-core shutdown hooks.

## Recruiter talking point

I corrected an ambiguous desktop lifecycle by separating “hide” from “quit.” The visible close action now guarantees process-tree cleanup, while background behavior is an explicit tray command rather than a hidden side effect.
