# ISSUE-028 — Windows speech recognition was too inaccurate for Jarvis lifecycle control

## Symptom

The Electron shell and Python core launched successfully, but the native Windows speech recognizer repeatedly misunderstood normal speech. Dedicated grammars improved recognition of a few exact phrases, yet longer wake requests and conversational sleep intent were still unreliable compared with the OpenAI audio-native conversation path.

## Impact

Hands-free desktop use did not meet the quality bar. A wake system that occasionally mishears the assistant name or changes the request can start the wrong action, while a rigid sleep phrase list prevents natural conversation. Continuing to tune the legacy recognizer would also create a second interpretation layer that disagreed with the model already handling the active conversation well.

## Investigation

The Electron Web Speech implementation first failed because its network-backed recognition service was unavailable in Electron. The replacement used Windows `System.Speech`, generic dictation, then prioritized Jarvis grammars and microphone diagnostics. Process supervision, microphone routing, IPC, and grammar loading all worked, proving the remaining problem was recognition quality rather than application lifecycle.

Live testing showed that the legacy recognizer was fundamentally less accurate than the OpenAI transcription and Realtime models. More phrase-specific grammars would increase maintenance, still fail on natural wording, and create a growing list of special cases.

## Root cause

The desktop wake and sleep design depended on an older grammar-oriented recognizer to perform open-ended conversational speech understanding. That engine was not suitable for the accuracy, proper-noun handling, and natural-intent interpretation expected from Jarvis.

## Fix

- Retired the Windows `System.Speech` subprocess and its Electron IPC channel from the active runtime.
- Added local Web Audio VAD in the Electron renderer so silence and background idle time remain local.
- Buffered only a completed sleeping-state utterance and sent that short WAV to the local Python core.
- Added a server-owned `gpt-4o-mini-transcribe` gateway that preserves the complete request and keeps the permanent API key out of Electron.
- Reused the captured transcript to determine whether the utterance contains “Jarvis,” then handed the remaining request into the proven Realtime conversation.
- Added a Realtime `sleep_jarvis` function tool so the audio-native model decides natural sleep intent instead of a rigid phrase grammar.
- Added wake-transcription usage records and a separate cost metric in the existing local budget ledger.
- Kept manual Wake and Sleep controls, and kept free simulation manual-only so simulation does not silently create transcription charges.

## Regression protection

Automated tests verify that Electron no longer launches or exposes the Windows speech subprocess, sleeping audio is gated by local VAD before transcription, WAV data is sent only through the trusted loopback endpoint, API errors redact the private key, wake transcription costs are ledgered separately, the Realtime session declares the `sleep_jarvis` tool, and function-call output is acknowledged before local sleep.

The final acceptance test must still run on Windows with the real microphone because the build environment cannot validate microphone sensitivity, room noise, or live provider recognition.

## Recruiter talking point

I recognized when incremental tuning was reinforcing the wrong architecture. After proving that Electron Web Speech and Windows grammar recognition were both unsuitable, I replaced them with a privacy-conscious hybrid: local VAD limits cloud exposure to completed utterances, a modern transcription model handles wake accuracy, and the Realtime model uses function calling for natural lifecycle intent. I also integrated the added spend into an authoritative budget ledger and preserved a provider-free simulation path.
