# ISSUE-012 — Wake phrase opened the session but dropped the request

## Symptom

Saying **“Jarvis”** correctly woke the assistant and started the Realtime connection. However, a complete phrase such as **“Hey Jarvis, tell me a joke”** only opened the session. Jarvis did not receive or answer the words after the wake keyword, so the user had to repeat the request after the connection finished.

## Impact

- The wake keyword itself appeared to work, but the intended one-sentence wake-and-command interaction did not.
- The user had to repeat every opening request, defeating the purpose of natural wake detection.
- Provider events showed a successful connection without a corresponding typed opening request.
- The failure could be mistaken for a model or microphone problem even though the Realtime connection was healthy.

## Investigation

The wake listener used interim browser speech-recognition results. As soon as an interim transcript contained the keyword `jarvis`, the listener stopped recognition and started the WebRTC connection. At that instant, the browser often had not yet produced the remainder of the sentence.

A second timing problem existed after wake detection. The code attempted to send the queued opening request when the `RTCPeerConnection` reported `connected`. The WebRTC data channel can still be in `connecting` at that moment. `sendText()` rejected the request because the data channel was not open, and the queued prompt had already been cleared.

## Root cause

Two asynchronous boundaries were treated as if they completed at the same time:

1. **Keyword detection was treated as utterance completion.** Interim recognition output exposed `Jarvis` before the full sentence was finalized.
2. **Peer connection completion was treated as data-channel readiness.** The remote media path could be connected before the event data channel was ready to accept a conversation item.

The combination woke Jarvis successfully while discarding the actual opening request.

## Fix

- Added a short bounded wake-capture window after the keyword is first detected.
- Rebuilt the candidate wake phrase from the complete recognition-result collection instead of only the latest partial result.
- Finalized immediately after a final recognition result, or after a short interim-result quiet period.
- Preserved the queued opening request until it is successfully sent.
- Moved primary dispatch to the data channel's `open` event.
- Added bounded retry behavior while the data channel is still connecting, with a clear user-facing failure message if it never opens.
- Kept **“Jarvis”** by itself valid: an empty trailing prompt simply wakes the session without manufacturing a request.

## Regression protection

- Added a client regression test that requires a wake-candidate buffer and delayed utterance finalization.
- Added a test that requires prompt dispatch from the data-channel `open` path.
- Added a test that prevents the queued prompt from being cleared before a successful send.
- Retained the existing tests for final SDP, manual wake/sleep, typed-message parity, and bounded reconnect behavior.
- Included the live acceptance phrase **“Hey Jarvis, tell me a joke”** in the repair testing guide.

## Result

Jarvis can now wake from a natural sentence, wait long enough to capture the complete opening utterance, establish the Realtime session, and submit the words after `Jarvis` as the first user request without requiring repetition.

## Recruiter talking point

I debugged a race condition across two independent browser APIs: streaming speech recognition and WebRTC data-channel setup. I separated keyword detection from utterance completion, preserved pending work across the connection handshake, dispatched only at the correct readiness boundary, and added bounded retries plus regression tests.
