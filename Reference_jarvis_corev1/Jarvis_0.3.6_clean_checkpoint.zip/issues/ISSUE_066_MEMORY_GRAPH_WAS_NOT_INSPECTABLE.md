# ISSUE-066 — Memory graph was not inspectable

## Symptom

`0.1.1` created events, entities, categories, facts, aliases, and evidence, but Tanner could only see a basic event list and category filter. There was no way to inspect why an entity existed or how it related to a project, business, person, or decision.

## Root cause

The Total Recall release prioritized durable storage and provenance contracts. It did not yet expose graph traversal, entity pages, relationship statements, or event-level provenance in the desktop interface.

## Fix

`0.1.2` adds entity pages, relationship statements, aliases, evidence counts, related timelines, and a detail drawer that shows exact source event provenance.

## Regression protection

Python tests verify entity-detail relationships and merged members. Node tests verify the entity graph, detail drawer, and provenance controls remain present in the desktop interface.

## Recruiter talking point

Built a local knowledge-graph explorer on top of a provenance-first SQLite event ledger, including evidence-backed relationships rather than opaque AI summaries.
