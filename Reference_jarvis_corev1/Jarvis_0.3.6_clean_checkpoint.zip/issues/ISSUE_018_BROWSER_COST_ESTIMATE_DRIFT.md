# ISSUE-018 — Browser-only cost totals were fragile and incomplete

## Symptom

The Voice Lab displayed estimated session and daily cost, but the totals were calculated entirely in browser JavaScript and stored in `localStorage`. The display could reset between browsers, diverge across computers, or double-count a replayed provider event.

## Impact

Cost information was useful as a rough indicator but was not reliable enough for budget enforcement. A refreshed browser, duplicate `response.done` event, or different computer could produce a misleading total.

## Root cause

Usage metadata was parsed and priced at the presentation layer. There was no authoritative local ledger, no response-ID deduplication, no crash-safe append, and no server-side budget decision. The UI also had to infer changing provider usage field names by itself.

## Investigation

The existing implementation was reviewed against the desired safeguards:

- Response-level cost.
- Session, daily, and monthly totals.
- Cached-input savings.
- Duplicate-event protection.
- Hard budget stops before new live sessions.
- Persistence outside browser storage.

The browser-only design could not satisfy those requirements consistently.

## Fix

`0.0.4 — Cost Control` moves accounting into the local Python core:

- A normalized token-usage parser accepts current Realtime usage variants.
- A centralized, versioned pricing profile computes text, audio, and cached-input costs.
- `UsageLedger` appends privacy-safe records to `data/realtime_usage.jsonl` with flush and `fsync`.
- Provider response IDs make writes idempotent.
- Session, day, month, and all-time summaries are computed by the core.
- Session, daily, and monthly warning/hard thresholds are evaluated centrally.
- The server refuses new live sessions when daily or monthly hard limits are already reached.
- The UI becomes a renderer of server-authoritative totals rather than the billing source of truth.

No transcript text, raw audio, API key, or SDP credential is stored in the usage ledger.

## Regression protection

Unit tests cover usage-schema normalization, pricing math, cached savings, persistent reload, response-ID deduplication, period summaries, budget scopes, safe API endpoints, and absence of secrets.

## Recruiter talking point

I replaced a fragile browser estimate with an idempotent local accounting service. The design normalizes provider usage metadata, persists crash-safe response records, calculates scoped budgets, and prevents duplicate events from inflating spend totals.
