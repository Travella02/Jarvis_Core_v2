# ISSUE_052 — Packaged app required system Python

## Symptom

The Electron package could start only by finding Python 3.12 on the user's computer and creating a virtual environment during first launch.

## Root cause

The initial Electron shell packaged the Jarvis source runtime but not the Python interpreter or installed dependencies.

## Fix

Added a Windows build step that downloads the official Python embeddable distribution, installs Jarvis and its dependencies into a private `Lib/site-packages`, validates the runtime, and includes it as an Electron extra resource. Packaged launches now use `pythonw.exe` directly.

## Regression protection

Source tests verify that packaged startup no longer creates a virtual environment, the embedded-runtime build plan uses the official Python download, and Forge includes both runtime resources.

## Recruiter talking point

I converted a development-only Electron/Python hybrid into a self-contained Windows application by designing a deterministic private-runtime build pipeline and removing first-run dependency installation.
