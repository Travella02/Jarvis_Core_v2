# ISSUE-013 — Jarvis speaking duration stayed empty

## Symptom

The **User speaking** metric increased correctly, but **Jarvis speaking** remained empty even while audible Realtime speech played through the selected speaker.

## Impact

- Awake-session instrumentation was incomplete.
- Cost and activity comparisons could show user speech but not assistant speech.
- The UI suggested Jarvis was not producing audio even though the remote WebRTC track was clearly audible.
- Any future analytics based on assistant speaking time would undercount activity.

## Investigation

User-speaking time was measured from explicit provider speech-start and speech-stop events. Jarvis-speaking time was started only when a `response.output_audio.delta` event appeared on the Realtime data channel.

In the WebRTC transport, audible audio is delivered through the remote media track. The browser can play that track even when the expected per-chunk audio delta event is absent or not used as the playback signal. The existing remote `AnalyserNode` already measured actual speaker-bound audio for first-audible-response latency, making it the more reliable source of truth.

## Root cause

The speaking timer depended on a provider event-path assumption rather than the actual audio path. The UI heard audio through WebRTC, but the timer waited for a data-channel event that was not guaranteed to drive media playback in this transport.

## Fix

- Moved Jarvis-speaking timing to the existing remote-audio analyser.
- Start a speaking segment when measured RMS audio crosses the audible threshold.
- Continue the segment while remote audio remains active.
- End and accumulate the segment after a short sustained-silence window.
- Finalize any active segment when the analyser or connection shuts down.
- Preserve the provider audio event as a fallback for first-audio diagnostics, but no longer use it as the authoritative speaking timer.

## Regression protection

- Added tests requiring the remote RMS threshold and sustained-silence boundary.
- Added tests requiring the shared speaking-segment finalizer.
- Added a test preventing the timer from returning to the old `response.output_audio.delta`-only start condition.
- Retained first-audible-audio, response-completion, interruption, and session-timer tests.
- Added a manual acceptance step requiring the metric to advance while Cedar is audibly speaking.

## Result

The **Jarvis speaking** metric now follows actual audible remote WebRTC output and accumulates across multiple responses, interruptions, and normal connection cleanup.

## Recruiter talking point

I corrected an observability bug by replacing an unreliable provider-event assumption with measurement at the true media boundary. I reused the Web Audio analyser, added threshold and silence hysteresis, handled cleanup safely, and locked the behavior down with regression tests.
