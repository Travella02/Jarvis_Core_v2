# ISSUE-005 — SDP Answer Framing

## Summary

After OpenAI accepted the offer, Chromium rejected the relayed SDP answer at an `a=ice-pwd` line.

## Symptom

`RTCPeerConnection.setRemoteDescription` reported an SDP parse error even though the provider had returned a successful response.

## Impact

The provider session existed, but the browser could not complete the peer connection.

## Root cause

The local bridge treated successful SDP as ordinary trimmed text. SDP is a strict line-oriented protocol; newline conversion, a missing terminal CRLF, or a UTF-8 BOM can make browser parsing fail at a later line that appears unrelated.

## Investigation

1. Used the successful provider response to establish that authentication and offer parsing were fixed.
2. Avoided logging raw SDP because it contains ephemeral ICE credentials.
3. Added privacy-safe byte and line counts at the browser boundary.
4. Tested LF-only, BOM-prefixed, and missing-terminal-line inputs against a canonicalization function.

## Fix

The gateway keeps the response byte-oriented until one validated UTF-8 decode, rejects malformed controls and blank internal lines, canonicalizes all line endings to CRLF, and guarantees a final CRLF. FastAPI returns exact SDP bytes. The Chromium client repeats defensive normalization before `setRemoteDescription`.

## Regression protection

Tests cover BOM removal, LF-to-CRLF conversion, terminal framing, malformed internal lines, exact HTTP response bytes, and client-side normalization. Logs expose only size and line count.

## Result

The live Realtime WebRTC connection completed and voice conversation worked successfully.

## Engineering lesson

Protocol framing is data, not formatting. Debug diagnostics should reveal structural evidence without leaking security-sensitive payloads.

## Recruiter talking point

“I fixed a cross-runtime SDP parser failure by treating the protocol as bytes, canonicalizing CRLF framing, and designing privacy-safe diagnostics that never logged ICE credentials.”
