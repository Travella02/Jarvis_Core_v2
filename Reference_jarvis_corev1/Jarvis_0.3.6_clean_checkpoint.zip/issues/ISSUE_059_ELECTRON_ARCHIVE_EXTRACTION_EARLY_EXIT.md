# ISSUE-059 — Electron archive extraction exited before packaging

## Symptom

With repair4 diagnostics enabled, `npm run alpha:make` reached Electron Packager's cached Windows ZIP extraction, printed the extraction source and target, and then Electron Forge exited with code 0. No packaged app directory and no `out\make` installer were created. `npm run alpha:verify` therefore reported that no Squirrel Setup executable existed.

## Scope and impact

Runtime preparation, one-file runtime bundling, source-scope verification, configuration loading, and target resolution all succeeded. The build failed before Electron application initialization, ASAR creation, executable rename, external-resource copying, or Squirrel maker execution. Desktop Alpha acceptance remained blocked.

## Root cause

Electron Packager 18.4.4 delegates Electron ZIP extraction to `extract-zip`. On this Windows/Node build path, the extraction promise remained unresolved without a dependable active process handle. The interactive Forge renderer previously kept the event loop alive and made the problem appear as an indefinite `Finalizing package` hang. The repair4 fallback/debug renderer removed that incidental timer, revealing the underlying early process exit. Forge propagated exit code 0 even though no artifacts existed.

## Investigation

- Confirmed the runtime payload was already compact: 834 files compressed to a 15.68 MiB ZIP.
- Confirmed the Electron app source was only 22 files and 0.31 MiB.
- Confirmed repair4 never recorded `START initialize`, proving the Windows finalization methods had not begun.
- Confirmed the last Packager line was extraction of the cached Electron Windows ZIP.
- Confirmed the Forge child exited code 0 while `out\make` remained absent.
- Rejected executable resource editing and final directory movement as the current cause because neither operation was reached.

## Fix

- Replaced Packager's Electron ZIP extraction function with a supervised Python `zipfile` implementation.
- Added archive path-traversal protection, atomic per-file replacement, required-template validation, and progress output.
- Kept the Python child process attached until a definite exit code is received.
- Restored standard Packager temporary staging instead of direct-to-`out` extraction.
- Added post-exit artifact guards so Forge cannot report success without the packaged `app.asar` and, for `make`, the Squirrel Setup executable.
- Retained method-level Packager diagnostics and temporary resource-editor bypass for the rest of the Windows path.

## Regression protection

- Python tests create and extract a synthetic Electron archive.
- Python tests reject `../` traversal entries and verify no file escapes the target directory.
- Node tests verify the reliable extractor is installed into Packager's unzip module.
- Node tests verify build-Python resolution, restored standard staging, and false-success artifact checks.
- Existing runtime bundle, packaging scope, installer, security, and release metadata tests remain active.

## Manual verification

Run `npm run alpha:make` on Windows and confirm `DONE extractElectronArchive` is followed by `START initialize`. Then run `npm run alpha:verify` and install the generated Setup executable.

## Outcome

The build no longer relies on an extraction promise that can silently lose event-loop ownership, and a missing package can no longer be mislabeled as a successful build.

## Lessons

A spinner's label may describe the UI task rather than the actual blocked operation. Durable method logs plus artifact-based success criteria are more trustworthy than process exit codes alone.

## Recruiter talking point

Diagnosed an Electron Forge Windows build that alternated between an indefinite spinner and a false zero exit, isolated the failure to third-party archive extraction, replaced it with a supervised safe extractor, and added artifact-level success verification.
