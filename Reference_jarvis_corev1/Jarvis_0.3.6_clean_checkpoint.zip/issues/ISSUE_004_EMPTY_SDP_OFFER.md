# ISSUE-004 — Empty SDP Offer

## Summary

The first live OpenAI Realtime connection reached the provider but was rejected because the SDP multipart field was parsed as empty.

## Symptom

OpenAI returned an `invalid_offer` response containing the safe diagnostic `failed to unmarshal SDP: EOF`.

## Impact

Authentication, billing access, and the local server route were functioning, but no WebRTC session could be established.

## Root cause

The backend submitted `sdp` and `session` as generic multipart text fields. The Realtime calls endpoint expected typed byte parts. The browser also initially held an earlier offer object rather than explicitly posting the final `RTCPeerConnection.localDescription.sdp` after bounded ICE gathering.

## Investigation

1. Confirmed the request reached OpenAI and received a provider request ID.
2. Ruled out API-key, billing, and model-access errors from the response class.
3. Compared the generated multipart request with OpenAI’s official SDK behavior.
4. Reproduced the request using a mocked HTTP transport and inspected safe multipart headers and body structure.

## Fix

- Encode SDP and session JSON as bytes.
- Mark the multipart parts `application/sdp` and `application/json`.
- Request an `application/sdp` response.
- Wait for bounded ICE gathering and post `peer.localDescription.sdp`.

## Regression protection

Provider tests inspect the multipart body and assert exact media types, SDP preservation, backend-only authorization, and absence of the API key from the session payload. Client tests reject use of the stale `offer.sdp` path.

## Result

OpenAI accepted the offer and returned an SDP answer, advancing the live handshake to browser answer parsing.

## Engineering lesson

A request can be syntactically multipart yet semantically wrong. Wire-level media types and the lifecycle timing of WebRTC descriptions matter.

## Recruiter talking point

“I debugged a live WebRTC handshake across browser, local FastAPI, and a hosted Realtime endpoint. By comparing wire format with the official SDK, I corrected multipart media typing and ICE-offer timing.”
