# ISSUE-026 — Electron Web Speech network restart loop

## Symptom

The first successful native Electron launch opened the Jarvis window and started the Python core, but the terminal rapidly repeated Chromium network errors while the interface alternated between **Listening for Jarvis** and **Restarting**.

## Impact

The desktop shell itself was usable, but automatic wake recognition and spoken sleep commands could not be tested reliably. The restart loop also flooded the terminal and made the app appear unstable even though the core and native window were healthy.

## Root cause

The wake and lifecycle listeners still depended on the renderer's browser `SpeechRecognition` implementation. In the Electron runtime, that recognition path attempted to use Chromium's network-backed speech service and repeatedly failed. The existing retry behavior treated every failure as transient and immediately started another recognition session, creating a tight error loop.

## Investigation

- The native window appeared normally.
- Uvicorn started and remained healthy on the loopback endpoint.
- The errors began only when the sleeping-state speech listener armed.
- Manual Electron lifecycle features were not the source of the failure.

These observations isolated the problem to renderer speech recognition rather than Electron startup, Python supervision, WebRTC, the OpenAI API, or npm installation.

## Fix

- Replaced Electron wake and lifecycle recognition with a local Windows `System.Speech` listener launched by the Electron main process.
- Added structured JSON IPC messages through the context-isolated preload boundary.
- Preserved browser `SpeechRecognition` only as a non-Electron fallback.
- Added process restart and shutdown handling without rapid renderer retries.
- Added packaged-app unpacking for the PowerShell listener script.

## Regression protection

Automated tests verify that:

- Electron starts and supervises the Windows listener script.
- The preload exposes only the narrow local-speech subscription API.
- The renderer chooses native local speech inside Electron.
- Wake phrases, sleep phrases, and local transcript handoff are routed through the native listener.
- The browser speech path remains available only as fallback behavior.

## Result

The native Electron window no longer relies on Chromium's network speech service for lifecycle listening. Sleeping wake detection and spoken sleep commands remain local and do not create OpenAI Realtime charges.

## Recruiter talking point

I isolated a noisy Electron failure to a renderer-only Web Speech dependency even though the native window and Python service were healthy. I moved recognition behind the desktop process boundary, built a narrow context-isolated IPC contract, added process supervision and packaged-resource handling, and preserved a browser fallback without exposing privileged Electron APIs to the renderer.
