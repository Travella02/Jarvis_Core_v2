# ISSUE-029 — Wake opening response duplicated and microphone stayed active

## Symptom

After model-based wake transcription opened the Electron Realtime session, Jarvis sometimes produced two opening responses or behaved as if he was still hearing the user while the first response was playing.

## Impact

The first desktop turn felt unpredictable and could create duplicate paid responses. It also weakened user trust because the assistant appeared to ignore the intended first-turn boundary.

## Root cause

The wake listener shutdown and the Realtime microphone startup were not fully serialized. The renderer started the new media stream before it had awaited complete teardown of the sleeping-state wake stream, and the first-turn microphone gate was applied after media acquisition rather than before the transition began.

## Fix

- Made wake-listener shutdown asynchronous and awaited its completion before opening the Realtime microphone.
- Made wake detection handoff asynchronous so the old stream is fully stopped before connection work begins.
- Activated the first-turn input gate before `getUserMedia` and immediately disabled new audio tracks before attaching them to WebRTC.
- Cleared the provider input buffer when the data channel opens and continued suppressing input events until the opening audio has audibly completed.
- Increased the local end-of-utterance silence window to preserve a natural pause after “Jarvis” inside the same opening request.

## Regression protection

Tests verify that wake shutdown is awaited, the input gate is activated before Realtime media acquisition, the new audio track starts disabled for an owned opening turn, and the provider input buffer is cleared before the queued wake request is dispatched.

## Recruiter talking point

I fixed a cross-stream race by treating wake capture and Realtime capture as an explicit ownership transfer. The repair serializes microphone teardown/startup, gates the first provider turn before media acquisition, and verifies the order in regression tests to prevent duplicate paid responses.
