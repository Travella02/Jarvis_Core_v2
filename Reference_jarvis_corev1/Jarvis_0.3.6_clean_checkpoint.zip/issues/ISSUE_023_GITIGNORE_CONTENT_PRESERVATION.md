# ISSUE-023 — `.gitignore` Content Preservation

## Summary

The first Electron Shell repair correctly normalized Windows line endings, but installation still stopped when the user's `.gitignore` contained legitimate local rules that did not match the exact accepted baseline.

## Symptom

The installer reported:

```text
ERROR: update stopped to avoid overwriting unexpected edits: .gitignore has local changes
Update validation failed; restoring project files.
```

The project remained on the accepted `0.0.4` release because validation failed before the Electron update was committed.

## Impact

A harmless, developer-owned ignore rule blocked installation even though the file still protected private configuration and runtime artifacts. Requiring an exact whole-file baseline was too strict for a file that is intentionally customized across machines and development environments.

## Root cause

Repair 1 changed validation from raw-byte comparison to canonical text comparison. That solved CRLF/LF drift, but it still treated `.gitignore` as an immutable release file. In practice, `.gitignore` is a merge-owned control file: Jarvis needs a minimum set of security and build exclusions, while developers may safely add their own rules.

## Investigation

- Confirmed the update stopped during pre-install validation and rolled back safely.
- Verified line-ending normalization was already active, ruling out CRLF as the remaining cause.
- Compared the design intent of `.gitignore` with normal source files.
- Rejected disabling conflict validation globally because that would allow genuine source-code edits to be overwritten.
- Rejected replacing the user's `.gitignore` because it would discard valid local exclusions.

## Fix

- Added a dedicated `.gitignore` merge utility.
- Preserved every existing comment and local rule.
- Appended only missing Jarvis security, patch, runtime, and Electron build exclusions.
- Kept exact conflict protection for every normal source file.
- Backed up `.gitignore` before the installer modifies it.
- Made the merge idempotent and normalized the resulting control file to LF under `.gitattributes`.

## Regression protection

Automated tests verify that:

- Custom local rules survive the merge.
- Required `.env`, virtual-environment, patch, runtime, and Electron exclusions are present.
- Existing rules are not duplicated.
- Windows CRLF input is accepted and normalized.
- A second merge changes nothing.
- The complete update installer succeeds against a customized `.gitignore` and preserves `.env` byte-for-byte.

## Result

Electron Shell installation no longer depends on an exact `.gitignore` snapshot. Jarvis retains its required privacy and build exclusions without taking ownership away from the developer.

## Engineering lesson

Configuration files need ownership-specific validation. Source files are safely protected by exact known baselines, while merge-owned files should be validated by invariants and updated additively.

## Recruiter talking point

> I repaired a cross-machine installer that was too strict about developer-owned Git configuration. Instead of weakening validation globally, I introduced invariant-based, additive merging for `.gitignore`, preserved local rules, kept source-file conflict protection, and added idempotency and Windows line-ending regression tests.
