# ISSUE-045 — Stale audio-buffer event closed the sleep acknowledgement

## Symptom

During live `0.0.7` acceptance, Jarvis recognized a natural sleep request and began Cedar's sign-off, but the desktop switched to **Sleeping** while the transcript contained only a partial phrase such as `Of course,`. In the most severe reproduction, playback stopped before Cedar completed the word “of.”

## Impact

The spoken lifecycle was unreliable for screen-free use. The session could close even though the correct acknowledgement response was still playing, undermining the intended audible confirmation that Jarvis had accepted the sleep request.

## Root cause

`output_audio_buffer.started` and `output_audio_buffer.stopped` are response-scoped events and include the response ID that produced the audio. The renderer treated every buffer-stop event received while a sleep sequence was active as if it belonged to the new sleep acknowledgement.

A late `output_audio_buffer.stopped` event from the preceding tool-call response could therefore set the acknowledgement's `bufferStopped` flag before the acknowledgement response had even been created. When the acknowledgement later reached `response.done`, Jarvis saw the stale stopped flag and immediately closed the WebRTC session, cutting off Cedar's current audio.

## Investigation

The earlier fixes correctly delayed the authoritative `Sleeping` state and increased playback-drain hysteresis, yet live testing still showed the state change while the acknowledgement transcript was incomplete. That ruled out a simple silence-threshold problem.

Reviewing the event ordering exposed that the implementation stored only generic booleans for audio-buffer start and stop. It did not bind those events to the acknowledgement response's unique ID. The official Realtime event contract describes `response_id` as the response that produced the buffered audio, making response correlation the missing lifecycle boundary.

## Fix

- Capture the acknowledgement response ID from the first `response.created` event after the dedicated sign-off `response.create` request.
- Retain the client request event ID for diagnostics.
- Accept `output_audio_buffer.started` and `output_audio_buffer.stopped` only when their `response_id` matches the bound acknowledgement response ID.
- Ignore and safely log stale buffer events from earlier responses.
- Mark the acknowledgement complete from `response.done` only when that event belongs to the same bound response.
- Reset all response-correlation identifiers whenever the sleep sequence is reset or restarted.

## Regression protection

Automated client tests now verify that:

- Sleep acknowledgement state includes a bound response ID.
- Buffer events are checked through a response-correlation helper before changing playback state.
- Stale buffer events are explicitly ignored.
- An unrelated `response.done` event cannot mark the acknowledgement complete or close the session.
- The request and response correlation fields are reset between sleep sequences.

The full Python suite, Electron JavaScript validation, Node desktop tests, doctor, diagnostic, runtime staging, idempotent installer test, and `.env` preservation check are run before delivery.

## Result

The session shutdown boundary now belongs to the exact Cedar acknowledgement response instead of whichever output-buffer event happened to arrive most recently. Earlier response events can no longer cut off the current sign-off.

## Engineering lesson

Asynchronous media events must be correlated by response or stream identity. Global booleans are unsafe when multiple response lifecycles can overlap or deliver delayed terminal events.

## Recruiter talking point

I debugged a race where delayed WebRTC audio-buffer events from one response were terminating a later response. I fixed it by introducing response-ID correlation across creation, playback, completion, and shutdown, then added regression tests that explicitly reject stale media events.
