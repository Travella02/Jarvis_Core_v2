# ISSUE-025 — Windows npm shim resolution

## Symptom

The `0.0.5` installer completed all Python tests, doctor checks, diagnostics, and desktop-runtime staging, then failed during the Node dependency step with:

```text
ERROR: [WinError 193] %1 is not a valid Win32 application
```

The command display showed the installer attempting to execute the extensionless path `C:\Program Files\nodejs\npm`.

## Impact

Electron dependencies could not be installed on Windows even though Node.js and npm were correctly installed. The installer then rolled the project source files back, preventing a partial `0.0.5` installation.

## Root cause

The official Windows Node.js installation can contain both:

- `npm`, an extensionless POSIX shell script; and
- `npm.cmd`, the Windows command shim intended for direct execution.

The installer asked `shutil.which("npm")` first. On this laptop it resolved the extensionless shell script. Python launched subprocesses without a command shell, so Windows attempted to execute that text script as a native program and raised WinError 193.

## Investigation

The successful `node.exe --version` result ruled out a missing or incompatible Node runtime. The failure occurred only when launching npm, and the printed executable path lacked `.cmd`. That isolated the problem to launcher selection rather than Node architecture, Electron, package metadata, or network access.

## Fix

- Added a centralized Node-tool resolver.
- On Windows, npm resolution now prefers `npm.cmd`, then `npm.exe`, and only then the extensionless `npm` name.
- The installer uses the resolved Windows command shim for both `npm install` and `npm run desktop:check`.
- The doctor uses the same resolver so diagnostics and installation agree about tool availability.

## Regression protection

An automated test supplies both an extensionless `npm` path and an `npm.cmd` path while simulating Windows, then verifies that the executable command shim is selected.

The full Python suite, JavaScript syntax checks, doctor, safe diagnostic, installer rerun, `.env` preservation, and desktop runtime staging are also required before delivery.

## Recruiter talking point

I diagnosed a Windows-only process-launch failure after the entire cross-language test suite had passed. By inspecting the exact executable path, I separated a launcher-resolution bug from Node architecture or Electron problems, centralized platform-aware command discovery, and added a deterministic regression test for the Windows shim-selection behavior.
