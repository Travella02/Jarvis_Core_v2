# ISSUE-057 — Loose runtime files stalled Electron finalization

## Symptom

After `0.1.0-repair2` reduced the Electron source payload to 22 files and 0.30 MiB, `npm run alpha:make` still remained on `Finalizing package` for roughly 30 minutes. The build produced no error and did not advance to `postPackage`, `preMake`, or distributable creation.

## Scope and impact

The application source filter was correct, but the Windows Desktop Alpha could not produce an installer. This blocked clean-machine installation and acceptance of `0.1.0`.

## Root cause

Electron Packager's `extraResource` still received `build\python` and `build\desktop_runtime` as loose directories. The Python runtime contains thousands of small files. During package finalization, Electron/Windows filesystem and security scanning still had to traverse and copy every runtime file even though those files no longer entered `app.asar`.

## Investigation

The second screenshot confirmed that the previous repair worked: the app source scope was only 22 files and 0.30 MiB. The unchanged stall location therefore separated the problem from source-tree copying and pointed to external-resource finalization. Re-running the same command would reproduce the same traversal and was rejected as a useful next step.

## Fix

- Build one `runtime_bundle.zip` containing top-level `python/` and `desktop_runtime/` trees.
- Generate a sidecar manifest with content fingerprint, bundle SHA-256, file count, and required entries.
- Reuse the archive when source content is unchanged.
- Give Electron Forge only the archive and manifest as external resources.
- Verify the archive before installed first-use extraction.
- Extract to a version-specific per-user staging path, validate required files, and atomically promote it.
- Show runtime-preparation status in the loading window.

## Regression protection

- Python tests cover archive contents, unchanged-bundle reuse, source-change rebuild, and tamper recovery.
- Node tests confirm runtime install paths and that Forge receives only two runtime resources.
- Packaging preflight verifies the archive SHA-256 and rejects unexpected `extraResource` entries.
- Final build verification checks archive integrity and rejects loose packaged runtime directories.
- The app refuses to start an incomplete or checksum-invalid runtime.

## Outcome

The build pipeline no longer asks Electron Packager to traverse the complete Python runtime. Forge finalizes a compact Electron shell plus a single runtime payload, while the installed app retains a private, verified Python environment.

## Lessons

A compact `app.asar` does not guarantee a compact packaging workload. Large dependency trees passed through `extraResource` can still dominate finalization. Packaging boundaries must be measured across both application source and external resources.

## Recruiter talking point

Diagnosed a second-order Windows packaging stall by using stage-specific evidence, redesigned thousands of runtime files into a checksum-verified one-file deployment artifact, and added atomic first-run extraction plus layered regression checks.
