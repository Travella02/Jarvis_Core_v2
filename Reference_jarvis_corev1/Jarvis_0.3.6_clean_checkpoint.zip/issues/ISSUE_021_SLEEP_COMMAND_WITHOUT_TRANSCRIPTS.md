# ISSUE-021 — Spoken Sleep Commands Without Paid Input Transcription

## Summary

Cost Control intentionally disabled exact ordinary input transcription, but Jarvis still needed to understand lifecycle phrases such as “That’s all, Jarvis” while remaining inexpensive.

## Symptom

Jarvis could be put to sleep manually, but ordinary follow-up speech appeared as `Voice input`. The UI therefore could not inspect provider transcript text and reliably detect a spoken sleep command.

## Root cause

Lifecycle detection had been coupled to provider transcript events that were deliberately unavailable in the cost-conscious configuration.

## Investigation

Enabling full provider input transcription would have solved the text-visibility problem but would add another provider dependency and expense. Sending the phrase to the model and hoping it chose to close the session would also leave lifecycle authority with the provider.

## Fix

`0.0.5` adds a narrow client-side lifecycle listener dedicated to a small allowlist of sleep phrases. Detection immediately gates microphone input, clears pending provider audio input, interrupts active output when necessary, records a local acknowledgement, closes the Realtime session, and returns to the existing wake listener.

## Regression protection

- Client tests verify the lifecycle listener and phrase allowlist.
- Desktop tray Sleep routes through the same authoritative renderer lifecycle path.
- The normal conversation transcript remains cost-conscious and does not enable separate input transcription.

## Engineering lesson

High-authority lifecycle commands should use a narrow deterministic path rather than depend on probabilistic provider behavior or optional transcript services.

## Recruiter talking point

I separated assistant lifecycle control from conversational transcription, using a deterministic low-cost phrase detector to close paid sessions safely while preserving an audio-native model for normal conversation.
