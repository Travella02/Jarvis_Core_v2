# ISSUE-040 — Node test reporter format caused a false installer failure

## Symptom

The `0.0.6 — Desktop Presence` installer ran all six Node tests successfully on Windows. The output reported `tests 6`, `pass 6`, and `fail 0`, but the installer still ended with:

```text
ERROR: expected 6 Node tests
Update validation failed; restoring project files.
```

The visible test lines also contained mojibake prefixes such as `âœ”` and `â„¹`.

## Impact

The release source and tests were valid, but the installer rolled the update back and prevented live Desktop Presence acceptance. No project corruption occurred because rollback completed successfully.

## Investigation

The original installer looked only for the TAP-specific summary form:

```text
# tests 6
```

Node 24 selected its spec reporter on the Windows machine and produced:

```text
tests 6
pass 6
fail 0
```

The leading Unicode status symbols were decoded through a legacy Windows code page and appeared as mojibake. The numeric test result remained correct, but the rigid regular expression did not recognize it.

## Root cause

The installer coupled release validation to one presentation format of Node's test runner instead of validating the structured numeric summary across supported reporters. Node's default reporter can vary by version and execution environment.

## Fix

- Force `desktop:test` to use Node's TAP reporter for deterministic automation output.
- Decode subprocess output explicitly as UTF-8 with replacement for malformed bytes.
- Add a reusable parser that accepts both TAP and spec summary lines while ignoring leading reporter glyphs.
- Validate all three values: total tests, passed tests, and zero failed tests.
- Keep exit-code validation as the first failure boundary.

## Regression protection

Automated tests now cover:

- Standard TAP output with `# tests 6`.
- Windows spec output with mojibake-prefixed `tests 6`, `pass 6`, and `fail 0` lines.
- Missing summaries being rejected.
- The six real Node Desktop Presence tests still running through the forced TAP reporter.

## Result

The same six passing Node tests are now recognized correctly on Windows, and genuine Node test failures still stop installation and trigger rollback.

## Engineering lesson

Automation should validate semantic outcomes rather than assume a tool's default human-readable reporter will remain stable across versions, platforms, and TTY conditions.

## Recruiter talking point

I diagnosed a cross-platform CI-style false negative where Node's tests passed but a Python installer rejected a version-dependent reporter format. I stabilized the reporter, built a format-tolerant parser, validated pass/fail totals, and added Windows mojibake regression coverage without weakening rollback safety.
