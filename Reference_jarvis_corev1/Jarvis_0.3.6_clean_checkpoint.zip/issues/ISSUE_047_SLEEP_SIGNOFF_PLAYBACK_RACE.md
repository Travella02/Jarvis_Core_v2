# ISSUE-047 — Sleep sign-off playback race persisted across the local audio stack

## Symptom

During `0.0.7` acceptance, Jarvis correctly recognized natural sleep intent but repeatedly cut off the dedicated Cedar sign-off. The transcript could stop at `Of course,` or even before the first word finished. In another reproduction, the model also produced a natural sleep sentence and the client then requested the separate `Of course, sir.` response, creating two replies for one sleep command.

## Impact

The sleep lifecycle felt unreliable, spent additional output-audio tokens, and could leave confusing partial transcript bubbles. Multiple repairs that waited on provider events or local audio heuristics did not produce a stable destructive shutdown boundary across every Windows audio pipeline.

## Investigation

The team separately tested response completion, provider output-buffer stop, response-ID correlation, local analyser silence, minimum playback duration, and delayed wake-listener restart. Live evidence showed that no single WebRTC or analyser event consistently represented the exact moment the selected Windows speaker finished rendering the final samples.

## Root cause

The design coupled session destruction to a second generated audio response. Provider generation, provider buffer drain, Chromium buffering, Electron playback, and the physical audio device each have distinct completion timing. The sign-off provided little user value compared with the complexity and cost it introduced.

## Fix

- Retired the generated sleep acknowledgement.
- Strengthened the Realtime instruction so `sleep_jarvis` must be the only model output for clear sleep intent.
- Handles `response.function_call_arguments.done` immediately, with `response.done` as a fallback.
- Cancels any active response and clears queued input/output audio.
- Disables the microphone, closes the session silently, and resumes wake monitoring after cleanup.
- Deduplicates repeated tool-call events.
- Keeps sleep timing metrics without requesting another audio response.

## Regression protection

Automated tests verify that the early function-call event is handled, the fallback remains available, no sign-off instructions or 16-token response request remain active, output audio is cleared, the legacy acknowledgement configuration is disabled, duplicate tool calls are ignored, and the wake listener resumes only after shutdown completes.

## Result

Natural sleep intent remains model-decided while shutdown becomes deterministic, silent, faster, and cheaper. No local playback completion event is required to close the session.

## Engineering lesson

A small conversational flourish should not own a destructive lifecycle boundary when its completion depends on several independently buffered media layers. Removing optional behavior can be a stronger reliability improvement than adding more timing heuristics.

## Recruiter talking point

I traced a persistent cross-layer media race through provider events, WebRTC, Chromium, Electron, and Windows playback. After multiple evidence-driven repairs, I simplified the architecture by removing the optional generated sign-off, handling the tool call earlier, and making shutdown deterministic while reducing API cost.
