# ISSUE-050 — Fixed layout proportions and transcript scroll friction

## Symptom

The first product interface was visually coherent, but its Home proportions were fixed. On different laptop and desktop widths, the orb could occupy more space than the active conversation needed. The transcript also always scrolled to the bottom during streaming, which could pull the user away from older messages they were reading.

## Impact

The interface felt less adaptable than the underlying assistant. Long responses were harder to review, compact windows required more vertical movement, and routine settings occupied one large undifferentiated panel. These issues did not break voice transport, but they reduced daily usability and made the UI feel fragile under resizing.

## Investigation

The renderer used a single hard-coded Home grid and every bubble update directly assigned `scrollTop = scrollHeight`. That implementation could not distinguish between an intentional user scroll and a user who wanted to follow the newest message. The Controls screen also used one large two-column form regardless of task grouping.

## Root cause

Layout and transcript behavior were implemented as static presentation rules rather than persisted user choices with explicit scroll ownership. Message streaming had no near-bottom threshold, and the settings hierarchy reflected implementation order instead of user intent.

## Fix

- Added persisted Conversation, Balanced, and Presence Home layouts.
- Added a persisted collapsible navigation rail.
- Replaced unconditional transcript scrolling with a near-bottom follow policy.
- Added a Jump to latest control for unread streamed content.
- Added a resizable multi-line composer with explicit Enter and Shift+Enter behavior.
- Split Controls into Session, Audio, and Lifecycle modules.
- Added viewport-aware responsive breakpoints and safer compact layouts.

## Regression protection

Automated tests verify the new layout controls, persistence functions, transcript threshold logic, jump control, multi-line composer behavior, keyboard shortcuts, responsive rules, unique element IDs, and preservation of established operational controls. Existing voice, Electron, cost, state, and lifecycle suites remain part of every installer validation.

## Result

The default interface gives conversation more room, remains adaptable across laptop and desktop dimensions, and no longer forces the transcript to the bottom while the user reads older content.

## Lesson

A real-time interface needs separate ownership rules for transport state, presentation state, and user viewport state. Treating every incoming token as permission to move the viewport creates avoidable usability defects.

## Recruiter talking point

I redesigned a streaming assistant UI so layout proportions and navigation were persisted user choices, then replaced unconditional auto-scroll with a threshold-based follow model that preserves the reader's position while still surfacing new content through an explicit Jump to latest control.
