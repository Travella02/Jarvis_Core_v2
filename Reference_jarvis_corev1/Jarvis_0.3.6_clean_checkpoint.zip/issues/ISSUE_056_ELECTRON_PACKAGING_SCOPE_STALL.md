# ISSUE-056 — Electron packaging scope stalled the Windows alpha build

## Symptom

After the embedded Python runtime completed successfully, `npm run alpha:make` remained in Electron Forge's packaging/post-package stage for nearly an hour and did not produce `Jarvis_Real_Time_Setup.exe`.

## Impact

The first installable Windows alpha could not complete on the laptop. Repeated retries risked wasting significant time and disk I/O while offering little diagnostic visibility.

## Root cause

Electron Packager was launched from the repository root without project-specific ignore rules. The repository contains large development-only trees such as `build`, `.venv`, `.patch_backups`, logs, tests, and `node_modules`. Most importantly, `build\python` and `build\desktop_runtime` were both inside the source tree and also configured as `extraResource`, so they could be traversed or copied as application source in addition to being copied to `resources`.

The app has no production Node dependencies, but the default pruning path still had to inspect the development dependency tree instead of rejecting it at the root.

## Investigation

The terminal output showed that Python 3.12.10 downloaded, installed dependencies, validated, and staged successfully. The stall began only after Electron Forge entered packaging. Repository-size inspection showed that development dependencies dominated the source tree, while the actual Electron runtime consists only of `package.json` and `apps/desktop/electron`.

The repair preserves the external Python and desktop-runtime resources and narrows only the Electron source-copy scope.

## Fix

- Added deterministic Electron Packager ignore patterns for development, private, generated, and duplicate-runtime paths.
- Excluded the complete `node_modules` tree when no production dependencies exist and disabled unnecessary pruning in that state.
- Kept an automatic fallback to normal pruning when production dependencies are introduced later.
- Added `npm run alpha:scope` as a preflight step in `alpha:prepare`.
- Added a source-scope size limit and required-resource checks.
- Added an `app.asar` size guard to final alpha verification.

## Regression protection

Python and Node tests assert that development paths are excluded, Electron entrypoints remain included, the preflight is part of `alpha:prepare`, and final verification enforces the `app.asar` limit. The preflight runs before every alpha package or make operation.

## Outcome

Electron Forge receives a compact application source tree, while the bundled Python runtime and staged desktop runtime are copied exactly once through `extraResource`. The already completed runtime and cache remain reusable.

## Lessons

Desktop packaging must explicitly distinguish build-time repository contents from runtime application contents. Generated runtimes located under the project root require especially careful exclusion when they are also configured as external resources.

## Recruiter talking point

Diagnosed a Windows Electron build that appeared hung after a successful Python-runtime stage, traced it to packaging-scope duplication and development-tree traversal, and implemented a tested source-scope preflight plus artifact-size guard to make builds deterministic.
