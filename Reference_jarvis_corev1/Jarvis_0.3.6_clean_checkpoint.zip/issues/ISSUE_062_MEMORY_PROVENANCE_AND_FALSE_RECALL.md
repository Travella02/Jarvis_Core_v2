# ISSUE-062 — Autonomous memory risked untraceable false recall

## Symptom

Autonomous entity/category creation could make Jarvis sound confident about information it inferred rather than information Tanner actually said or Jarvis directly observed.

## Root cause

A flat note or summary does not encode who supplied information, when it was learned, how it was obtained, or whether it was observed, reported, or inferred.

## Investigation

The design required every structured fact to retain supporting event evidence. Memory context also needed explicit instructions that recalled items are evidence rather than new commands.

## Fix

Every event stores actor, source, confidence, privacy, exact timestamp, metadata, and original content. Facts link to evidence events and carry confidence/status. Realtime context includes timestamps and sources and explicitly forbids inventing missing details.

## Regression protection

Tests assert provenance appears in stored events and Realtime context, and that API responses never omit exact event data while returning organized facts.

## Recruiter talking point

Built an auditable memory system where AI-derived knowledge remains traceable to immutable source evidence, reducing hallucinated personal history.
