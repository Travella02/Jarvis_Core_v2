# ISSUE-035 — Multi-Monitor Window Restore

## Symptom

The Electron window could reopen so large that it covered parts of multiple monitors. The user had to maximize or manually resize it before the interface became usable.

## Root cause

The earlier restoration logic selected a display based on overlap and then clamped width and height, but it still trusted stale saved coordinates and oversized bounds created under a different monitor arrangement or display scaling state. Maximized bounds could also be persisted as a normal launch size.

## Fix

The desktop shell now uses a conservative 1100×720 target capped at 82% of one display’s work area. Saved bounds are restored only when the complete rectangle fits inside one current display and remains under the startup ratio. Otherwise, Jarvis resets to a centered size on the primary display. Maximized bounds are no longer saved, the final bounds are reapplied immediately before showing the window, and the tray includes a **Reset window size** action.

## Regression protection

Electron-shell tests verify the conservative defaults, single-display containment check, startup ratios, maximized-state exclusion, ready-to-show bounds application, and tray reset command.

## Recruiter talking point

I hardened persisted desktop-window state against monitor topology and DPI changes by validating the full rectangle instead of trusting stale coordinates, then added a user-visible recovery action.
