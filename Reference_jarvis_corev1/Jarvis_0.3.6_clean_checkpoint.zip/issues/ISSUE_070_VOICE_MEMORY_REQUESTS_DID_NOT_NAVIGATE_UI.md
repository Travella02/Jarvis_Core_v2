# ISSUE-070 — Voice memory requests did not navigate the UI

## Symptom

When Tanner said “Show me everything about ORVEX,” Jarvis verbally summarized the bounded memory context but left the interface on Conversation. The Memory Explorer existed and could show the exact records, yet the natural command did not open it.

## Root cause

Memory search interpretation was implemented only inside the Memory Explorer search form. Realtime voice and typed chat turns were sent to the model and stored in memory, but no local intent bridge connected display verbs such as “show,” “open,” or “pull up” to workspace navigation. The model also had no reliable awareness that the local desktop could display a richer result than the bounded memory context injected into the voice session.

## Fix

Added a small, testable local parser that distinguishes visual memory requests from ordinary verbal recall. The desktop now clears stale explorer filters, opens Memory Explorer, applies the natural-language query, and opens a matching entity page when the request names a specific entity. Voice transcripts, typed turns, and preserved wake prompts share the same navigation path. Realtime instructions now acknowledge the local visual action without claiming that Jarvis lacks a memory database.

## Regression protection

Node tests cover entity, temporal, speaker, wake-name, workspace-only, and false-positive phrases. Python tests verify the parser is loaded before the main client, both typed and voice paths invoke navigation, and the Realtime prompt describes the local display contract. Full validation passed with 187 Python tests and 30 Node tests.

## Recruiter talking point

I separated language intent recognition from UI orchestration, built the parser as a pure independently tested module, and integrated it across voice, typed, and wake-preserved turns while deliberately avoiding false positives for unrelated “show me” requests.
