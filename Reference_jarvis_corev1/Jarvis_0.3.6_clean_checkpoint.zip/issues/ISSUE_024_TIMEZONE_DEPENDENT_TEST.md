# ISSUE-024 — Timezone-dependent local-time test

## Symptom

The `0.0.5` installer completed its file staging but rolled back during validation on a laptop in Mountain Daylight Time. The failing assertion expected `Monday, July 27, 2026`, while the generated context correctly showed `Sunday, July 26, 2026` at `07:23:45 PM` in `UTC-06:00`.

## Impact

The Electron Shell update could not be installed even though the production local-time behavior was correct for the user's machine. The failure blocked all Electron acceptance testing and made the release appear broken on timezones west of UTC near midnight.

## Root cause

The regression test supplied a timezone-aware UTC datetime but `local_time_context()` converted it through the host machine's local timezone. The assertion was therefore only valid on UTC-configured systems. At `01:23 UTC`, Mountain time was still the previous calendar day.

## Investigation

The safe failure output contained both the expected UTC date and the actual local date, timezone name, and UTC offset. Comparing those values showed a six-hour offset and a legitimate date rollover rather than an incorrect clock calculation. The installer rollback confirmed no accepted project files were left partially updated.

## Fix

`local_time_context()` now uses the system timezone only when production code omits the optional datetime. When tests provide an aware datetime, its own timezone is preserved. Naive injected datetimes still resolve through the machine's local timezone.

The test suite now verifies both an explicit UTC datetime and a Mountain Daylight Time datetime that crosses the UTC calendar boundary.

## Regression protection

- An explicit UTC test verifies the supplied timezone is not silently converted.
- A second test verifies a `UTC-06:00` datetime remains on the correct previous local date.
- The full suite is run in the patch installer before acceptance.
- The installer continues to roll back all staged files if any platform-dependent validation fails.

## Recruiter talking point

I diagnosed a cross-timezone CI failure by distinguishing a correct production conversion from a brittle test assumption, then redesigned the time injection seam so deterministic tests preserve explicit timezone context while production still uses the host's local clock.
