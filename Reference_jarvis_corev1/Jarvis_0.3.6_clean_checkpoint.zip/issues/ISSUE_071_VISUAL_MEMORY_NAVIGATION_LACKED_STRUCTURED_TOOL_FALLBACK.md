# ISSUE-071 — Visual memory navigation lacked a structured tool fallback

## Symptom

After `0.1.2-repair1`, a spoken request such as “Show me everything about ORVEX” could still receive a correct verbal answer while the desktop remained on the Home conversation workspace. Speech transcription could also render a close spelling such as “Orvix,” preventing literal entity lookup.

## Root cause

The first repair relied primarily on renderer-side transcript interception. That path could be bypassed by a provider event ordering variation, and Electron could retain an older cached renderer asset. The Realtime model also had no structured desktop action it could call when it understood the visual intent. Finally, entity resolution required near-literal text instead of tolerating a small transcription error.

## Fix

- Added a `show_memory` Realtime function tool for explicit visual memory requests.
- Added the complete function-call output and follow-up response cycle so the model can request local navigation and then briefly acknowledge it.
- Retained the deterministic local parser for immediate navigation before a model response is available.
- Added a self-contained parser fallback in the main renderer.
- Added cache-busted renderer script URLs and loopback no-cache headers.
- Added conservative fuzzy entity resolution so a close transcript such as “Orvix” can resolve to `ORVEX` without broadly guessing unrelated names.
- Re-applies the Memory workspace switch on the next animation frame and scrolls the selected view into position.

## Regression protection

Node tests cover explicit visual intent, ordinary verbal recall, broad memory opening, tool arguments, typo-tolerant entity selection, and unrelated display requests. Python tests cover the Realtime tool schema, model instructions, cache-control headers, and staged desktop assets. Manual acceptance still verifies the live Windows Electron/provider event path.

## Recruiter talking point

I repaired an unreliable cross-layer voice-to-UI action by combining deterministic local intent handling, model function calling, cache invalidation, fuzzy entity resolution, and end-to-end regression tests rather than depending on one transcript event path.
