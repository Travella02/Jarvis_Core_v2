# ISSUE-072 — Response-length presets were not user configurable

## Symptom

Jarvis exposed only a limited response-mode selection, and the hard-coded token ceilings either cut off a spoken sentence or provided no precise way for an owner or future customer to tune response length for cost, speed, and conversational preference.

## Root cause

Response profiles were constants in the usage layer. A single token ceiling was being used as both a conversational-length preference and a safety boundary, even though token limits are only an indirect measure of spoken length. The configuration API and desktop controls did not expose a complete five-level profile set.

## Fix

- Added Test, Short, Normal, Medium, and Full response modes.
- Added two `.env` values for every mode: an approximate target word count and an exact maximum output-token ceiling.
- Treats a token value of `0` as the model-supported maximum.
- Treats a target word value of `0` as adaptive detail rather than a forced word count.
- Injects the selected target into Jarvis's response instructions while preserving a separate hard provider ceiling.
- Returns all resolved profiles through `/api/config` and labels each desktop option with its effective word target and token ceiling.
- Keeps Test-mode automatic sleep behavior intact.

## Regression protection

Configuration tests cover defaults, all five modes, custom exact values, zero-as-model-maximum behavior, and invalid boundaries. Provider tests verify the selected ceiling and word guidance reach the Realtime session. Server and renderer tests verify profile publication and UI presentation.

## Recruiter talking point

I separated a user-facing conversational preference from a provider safety limit, then made both product-configurable across five presets with validation, API exposure, UI feedback, and backward-compatible defaults.
