# ISSUE-011 — Fresh laptop virtual environment lacked runtime dependencies

## Symptom

After the `0.0.3 — Wake Detection` files were installed on a laptop, the test suite and diagnostics reported that FastAPI, HTTPX, and Uvicorn were unavailable. The safe diagnostic also stopped with `ModuleNotFoundError: No module named 'uvicorn'` before it could print the configuration summary.

The same source tree had already worked on the desktop, which made the failure appear related to the new wake-detection code even though the actual difference was the per-computer Python environment.

## Impact

- The laptop could not start the local FastAPI/Uvicorn core.
- Tests that import the server or provider stack could not load, reducing the number of discovered tests and producing misleading secondary failures.
- The diagnostic command was less useful because it imported server-only dependencies before checking the `--diagnostic` path.
- A cloned repository looked complete while its local `.venv` was not actually ready.

## Investigation

The doctor output showed all three runtime modules as missing while the source version, handoff, Git repository, prompt, and private API-key configuration were present. That separated the problem into two layers:

1. The Git-tracked project files were correct.
2. The laptop-specific virtual environment had not installed the dependencies declared in `pyproject.toml`.

The smaller test count was a consequence of import failures, not missing committed test files. The desktop had previously hidden this workflow gap because its existing `.venv` already contained the required packages.

During repair validation, the first bootstrap approach used an editable project install. In a restricted clean environment, pip attempted build isolation and could not obtain the requested build-tool version. The bootstrap was narrowed to install the three explicit runtime requirements directly, avoiding an unnecessary packaging/build dependency for this source-run application.

## Root cause

Python virtual environments are intentionally local to each computer and are excluded from Git. Cloning or pulling the repository transfers source code and dependency declarations, but it does not transfer installed packages.

The `0.0.3` installer copied project files but assumed the current `.venv` had already been bootstrapped. In addition, `apps/core/__main__.py` imported Uvicorn and the FastAPI server at module import time, so the secret-safe diagnostic path unnecessarily depended on the full runtime stack.

## Fix

- Added `scripts/ensure_environment.py`, which checks the active interpreter for FastAPI, HTTPX, and Uvicorn and installs the declared FastAPI, HTTPX, and Uvicorn runtime requirements with pip when required.
- Updated the repair installer to create `.venv` when absent, run the environment bootstrap inside that venv, and only then execute tests and diagnostics.
- Changed `apps/core/__main__.py` to lazily import Uvicorn and the FastAPI server only when starting the live service. `--diagnostic` now works with standard-library and local project modules alone.
- Updated the doctor to print an exact actionable repair command when runtime dependencies are missing.

## Regression protection

- Added tests for required dependency declaration and deterministic missing-module detection.
- Added a `python -S -m apps.core --diagnostic` regression test, which disables normal site-packages and proves the diagnostic path does not import runtime dependencies.
- Tested the repair installer against a reconstructed `0.0.3` project with a fresh empty virtual environment.
- Verified the installer can be rerun without changing already-installed project files.
- Verified the private `.env` remains unchanged.

## Result

A Git clone can now become runnable on a new computer through one repair installer or one permanent environment-bootstrap command. The diagnostic remains available even before optional runtime packages are installed, making future setup failures easier to isolate.

## Recruiter talking point

I diagnosed a cross-machine failure where the source repository was correct but the ignored virtual environment was incomplete. I separated code state from machine-local dependency state, added an idempotent environment bootstrap, made diagnostics independent of server imports, and added regression tests that simulate Python without site-packages.
