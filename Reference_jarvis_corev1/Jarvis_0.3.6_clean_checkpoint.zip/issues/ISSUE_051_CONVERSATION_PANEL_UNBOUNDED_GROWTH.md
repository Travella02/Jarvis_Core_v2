# ISSUE-051 — Conversation panel grew without limit

## Symptom

As the conversation accumulated messages, the Home conversation card kept increasing in height instead of showing an internal scrollbar. The whole page became extremely tall, the composer moved far below the visible window, and the orb panel stretched beside the transcript.

## Impact

Long conversations made the main interface difficult to use. The user had to scroll the entire application instead of the conversation history, and the layout no longer behaved like a stable desktop workspace.

## Investigation

The transcript itself declared `overflow: auto`, so the first assumption was that the scrollbar code or smart-follow logic was failing. The screenshots showed that the transcript never became constrained enough for overflow to occur. Inspecting the flex and grid hierarchy revealed that the Home row and conversation panel used minimum heights but no actual bounded height. Content therefore participated in intrinsic sizing and continuously enlarged the grid row.

The transcript also retained a compact-breakpoint minimum height, which could reintroduce growth even after constraining the desktop layout.

## Root cause

`overflow-y: auto` only creates a scroll viewport when the element has a constrained available size. The Home grid used content-driven row sizing, the featured panel used only `min-height`, and the transcript flex child did not have the zero-height/minimum-size combination required to shrink within a column flex container.

## Fix

- Added responsive viewport-bounded heights to the Home grid.
- Made the orb and conversation cards fill the bounded row with `height: 100%` and `min-height: 0`.
- Made the transcript shell a shrinkable flex region using `height: 0`, `min-height: 0`, and hidden outer overflow.
- Assigned vertical scrolling exclusively to the transcript.
- Added a stable scrollbar gutter to prevent width shifts.
- Disabled the bounded two-column row on narrow single-column layouts and assigned the conversation card its own responsive height.
- Removed the compact transcript minimum height that could force panel expansion.

## Regression protection

`tests/test_conversation_viewport.py` verifies that the Home row is height-bounded, the conversation card can shrink, and the transcript owns internal vertical scrolling. Existing interface-layout tests continue to verify smart following, Jump to latest, responsive tiers, and unique operational IDs.

## Recruiter talking point

I diagnosed a UI that appeared to have a broken scrollbar but was actually an intrinsic sizing problem across CSS Grid and Flexbox. I fixed the full sizing chain rather than adding a cosmetic max-height, preserved responsive single-column behavior, and added regression tests for the layout contracts that make overflow scrolling possible.
