# ISSUE-003 — Environment-Sensitive Tests

## Summary

A valid repair rolled back because two tests changed behavior after the user created the real ignored `.env` file.

## Symptom

A missing-key test did not raise an error, and a doctor-output test received the safe “key configured” status instead of the expected missing-key warning.

## Impact

The installer correctly rolled back, so the private configuration and project files remained safe. However, tests that passed in a clean build environment failed in the expected real developer environment.

## Root cause

Negative-path tests loaded configuration from the active repository root. Once `.env` existed, the tests inherited a real local state they were supposed to simulate as absent.

## Investigation

1. Confirmed the ignored `.env` was present and was not tracked by Git.
2. Verified the application correctly loaded the key and never printed it.
3. Re-ran tests with and without `.env` to isolate the environmental dependency.
4. Checked the installer rollback and confirmed the secret file checksum was unchanged.

## Fix

Tests for missing secrets and default settings now create temporary project roots with controlled `VERSION` and environment values. Tests that intentionally inspect the active project accept either safe key state while still rejecting key disclosure.

## Regression protection

The suite is run both without a project `.env` and with a valid fake `.env`. Installer tests verify that installation and rollback do not delete, replace, print, or hash-report the private key value.

## Result

Validation is deterministic on clean machines and configured developer machines.

## Engineering lesson

Ignored configuration is still part of the runtime environment. Tests must isolate the state they claim to test rather than assuming a developer’s machine is empty.

## Recruiter talking point

“I found a test isolation bug where local secrets changed negative-path behavior. I moved those cases to temporary roots and verified the installer preserved the user’s private environment through success and rollback.”
