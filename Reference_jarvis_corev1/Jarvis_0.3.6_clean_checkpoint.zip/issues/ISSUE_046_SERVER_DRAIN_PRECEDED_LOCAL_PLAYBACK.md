# ISSUE-046 — Server drain preceded local Electron playback

## Symptom

During `0.0.7` live acceptance, Jarvis recognized natural sleep intent and began the Cedar sign-off, but the desktop app changed to **Sleeping** after only the first word or two. The transcript could show `Of course,` while the audible output stopped even earlier. The terminal also showed repeated speculative wake requests and out-of-order `listening -> waking` lifecycle warnings after the premature shutdown.

## Impact

The spoken sign-off was not usable when Tanner was away from the screen. Repeated repair attempts improved event ordering but still allowed the Realtime connection to close before Chromium finished playing the audio already received by the client.

## Investigation

The previous repairs established three important facts:

1. `response.done` is a generation-complete signal, not a local playback-complete signal.
2. `output_audio_buffer.stopped` carries a response ID and can be correlated to the correct response.
3. Even a correctly correlated provider buffer-stop event can occur before Electron's local `HTMLAudioElement` and Web Audio graph finish rendering the final buffered samples.

The client treated the provider's server-side drain event as a destructive shutdown boundary. A short 250 ms guard was insufficient for the additional buffering between the Realtime service, WebRTC stack, Chromium media pipeline, selected output device, and physical speaker.

The premature transition also re-armed sleeping-state wake monitoring while residual Cedar audio was still present. That could trigger speculative wake setup and produce safe but noisy lifecycle-conflict warnings.

## Root cause

The implementation conflated **server output-buffer drained** with **local audible playback completed**. Response correlation solved stale-event attribution but did not prove that Electron had played every received sample.

## Fix

- Treat `output_audio_buffer.stopped` as advisory diagnostic evidence only.
- Require the local Web Audio analyser to observe Cedar's acknowledgement.
- Enforce a conservative minimum local playback window of 4.2 seconds from the first audible signal.
- Require acknowledgement-specific local silence after the most recent signal before disconnecting.
- Use a seven-second no-audio fallback only when the local analyser never observes output.
- Poll the local playback state instead of closing directly from a provider event.
- Block model-wake monitoring and speculative Realtime connections while the sign-off is draining and while shutdown cleanup owns the microphone.
- Re-arm wake monitoring only after the Realtime peer, media tracks, and local core state have completed the sleep transition.

## Regression protection

- Added tests proving that the provider buffer-stop handler cannot call `finishSpokenSleep` directly.
- Added tests for the minimum local playback window and last-signal silence boundary.
- Added tests that wake monitoring and new connections remain blocked during sign-off shutdown.
- Re-ran the complete Python and Node suites, JavaScript syntax validation, doctor, diagnostic, desktop-runtime staging, installer idempotence, and `.env` preservation checks.

## Result

The final sleep boundary is now owned by the local Electron playback path rather than a remote generation or server-buffer event. Provider events still improve diagnostics, but they cannot cut off Cedar's audio.

## Engineering lesson

Distributed media completion has multiple layers. A remote producer finishing, a server buffer draining, a WebRTC receiver obtaining packets, and a physical output device finishing playback are distinct events. Destructive lifecycle transitions should be tied to the layer whose completion the user actually experiences.

## Recruiter talking point

I debugged a real-time audio race where correctly correlated server events still preceded local playback completion. I redesigned shutdown around client-observed audio, added a bounded fallback, and prevented a secondary wake/reconnect race during media teardown.
