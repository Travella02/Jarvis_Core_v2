# ISSUE-015 — Wake-only activation stayed silent

## Symptom

Saying only **“Jarvis”** correctly woke the assistant and opened the Realtime connection, but Jarvis remained silent. Tanner had to speak a second time before the conversation felt active.

## Impact

The wake keyword worked technically, but the interaction did not feel natural. Calling an assistant by name is a common conversational opener and should produce a brief acknowledgement such as “Yes, sir?” so the user knows the assistant is awake and listening.

## Root cause

The wake handoff supported two paths:

1. A wake phrase containing a request, where text after the keyword was queued and sent after the data channel opened.
2. A wake phrase containing only the keyword, where the queued request was empty.

The dispatch function intentionally returned when no request text existed. As a result, the session connected successfully but no provider response was requested. The microphone then opened normally and waited for another user turn.

## Investigation

Live testing confirmed that the wake detector, WebRTC handshake, microphone, and session state all worked. The only missing behavior was an assistant turn when the parsed wake request was empty. This isolated the defect to the wake dispatch branch rather than recognition accuracy or provider connectivity.

The existing first-turn input gate also needed to apply to a wake-only acknowledgement; otherwise microphone startup audio could compete with the acknowledgement and reintroduce the duplicate-turn race fixed in ISSUE-014.

## Fix

The wake flow now distinguishes an empty wake request from no queued work:

- Saying only “Jarvis” queues a dedicated wake acknowledgement.
- After the Realtime data channel opens, the client sends a `response.create` event with brief server-side instructions to acknowledge the user naturally and address him as “sir.”
- No artificial user transcript bubble is created for the internal acknowledgement instruction.
- The first-turn microphone gate remains active until the acknowledgement response and audible output complete.
- Natural wake requests containing text continue to use the existing queued-message path unchanged.

## Regression protection

Automated tests assert that:

- Wake-only detection creates an acknowledgement state.
- The acknowledgement is dispatched through `response.create` only after the data channel is available.
- The wake-only path participates in the same first-turn ownership gate used by natural wake requests.
- The acknowledgement state resets during sleep and failed dispatch cleanup.

Live acceptance requires saying only “Jarvis” repeatedly and confirming one short acknowledgement, no phantom user bubble, and an immediately usable microphone afterward.

## Recruiter talking point

I treated wake-only activation as a distinct conversational intent rather than an empty command. I added a provider response turn without fabricating user-visible transcript data, and reused the existing first-turn synchronization gate to preserve reliable microphone and response ordering.
