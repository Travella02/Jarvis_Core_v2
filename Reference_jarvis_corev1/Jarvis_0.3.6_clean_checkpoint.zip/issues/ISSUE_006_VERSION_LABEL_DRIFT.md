# ISSUE-006 — Version Label Drift

## Summary

The first voice milestone was accepted and committed as `0.0.1`, but the internal `VERSION` and package metadata still said `0.0.1-dev1`.

## Symptom

User-facing release language and machine-readable project state disagreed about whether the milestone was still in development.

## Impact

The code worked, but future installers, handoffs, and portfolio history could become confusing if development suffixes remained after acceptance.

## Root cause

The initial workflow used development suffixes while proving the live transport, but it did not include a final promotion step after the successful repair and acceptance test.

## Investigation

Compared the accepted Git commit message and user confirmation with `VERSION`, `pyproject.toml`, the handoff, and patch notes.

## Fix

Normal releases now use clean patch increments and the requested presentation format: `version — one- or two-word title`, followed by a brief description. `0.0.2 — Voice Control` normalizes `VERSION` and package metadata to `0.0.2`. Repair labels are reserved for unaccepted updates that need correction.

## Regression protection

Installer validation checks the exact required previous internal version, then tests the installed `VERSION`, diagnostics, doctor output, manifest, and package metadata for `0.0.2` consistency.

## Result

Human-readable and machine-readable release history now share one numbering system.

## Engineering lesson

Version promotion is part of release acceptance, not merely documentation. Automated release checks should compare all version-bearing files.

## Recruiter talking point

“I corrected release-state drift by formalizing promotion rules and adding consistency checks across version files, package metadata, manifests, diagnostics, and handoff documentation.”
