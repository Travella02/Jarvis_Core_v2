# ISSUE-038 — Electron ready-to-show handler was attached after the initial load

## Summary

During `0.0.6 — Desktop Presence` development, the first draft awaited the loading page before registering the `ready-to-show` listener.

## Symptom

The normal interactive launch could remain hidden if the one-time Electron event fired before its listener was registered.

## User-visible risk

On a fast computer, Electron could emit `ready-to-show` before the listener existed. A normal launch might then remain hidden even though it was not a background startup.

## Root cause

The event subscription was placed after `await mainWindow.loadFile(...)`. Event-driven initialization must register lifecycle handlers before starting the action that can emit them.

## Investigation

A manual lifecycle review of the new background-start code showed that the handler order differed from the accepted `0.0.5` implementation. The issue was corrected before delivery.

## Fix

The desktop shell now attaches `mainWindow.once('ready-to-show', ...)` before loading the initial page. The callback still respects `--background` startup and shows the window only for an interactive launch.

## Regression protection

The Electron shell tests verify that the native window uses a `ready-to-show` handler, conservative bounds, and background-launch gating. JavaScript syntax validation is also part of the installer.

## Result

Interactive launches show reliably, while Windows startup launches remain hidden in the tray as designed.

## Engineering lesson

Listeners for one-time lifecycle events must be registered before the operation that may emit the event begins.

## Recruiter talking point

I reviewed an asynchronous Electron startup path for event-order races and prevented an intermittent invisible-window bug before release.
