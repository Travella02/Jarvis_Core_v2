# ISSUE-061 — Memory deduplication could erase real events

## Symptom

A naive semantic deduplicator could incorrectly merge distinct experiences, such as eating pizza on Monday and again on Friday, while duplicated provider events could create multiple copies of the exact same utterance.

## Root cause

Text similarity alone cannot distinguish a duplicate delivery from a repeated real-world event. Episodic identity depends on source event IDs, timestamps, actors, sessions, and provenance.

## Investigation

The memory design compared idempotency keys, source/provider event IDs, timestamps, actors, sources, and normalized content. Repeated semantic facts and repeated episodic events required different treatment.

## Fix

Provider events are idempotent by source event ID. Facts may accumulate multiple evidence records and support counts. Safe consolidation merges only provably identical same-second events while preserving repeated experiences across dates, sessions, sources, or actors.

## Regression protection

Tests verify duplicate provider events create one ledger entry, repeated preferences consolidate into one supported fact, repeated meals on different dates remain separate, and consolidation does not erase them.

## Recruiter talking point

Implemented evidence-aware deduplication that differentiates transport duplicates from legitimately repeated human activity instead of relying on unsafe text similarity.
