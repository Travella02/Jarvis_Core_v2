# ISSUE 042 — Fixed wake tuning could not serve all environments

## Symptom

One wake configuration could be fast in a quiet room but overly sensitive in noise, while stricter settings reduced false wakes at the cost of noticeable latency.

## Impact

Repeatedly changing hard-coded timing constants made performance tuning risky and forced every device and room to accept the same tradeoff.

## Investigation

Wake calibration, signal-frame count, adaptive silence, noise multiplier, minimum voiced duration, and peak evidence were fixed constants in the renderer.

## Root cause

The wake detector exposed low-level `.env` values but did not provide a coherent user-facing performance policy.

## Fix

Added three validated profiles:

- **Fast:** minimizes calibration and endpoint delay.
- **Balanced:** preserves the previously proven middle ground.
- **Strict:** requires stronger speech evidence for noisy rooms.

The profile is selectable in the desktop UI, persists locally, and applies consistently to calibration, start detection, evidence rejection, and speech-end timing.

## Regression protection

Configuration tests reject unknown profiles, server tests expose only supported profiles, and renderer tests verify profile persistence and use throughout adaptive VAD.

## Result

Wake performance can now be tuned without code edits while retaining a safe fallback for noisy environments.

## Engineering lesson

Performance-sensitive systems benefit from named policy profiles that bundle coordinated parameters instead of exposing unrelated magic numbers.

## Recruiter talking point

Converted a hard-coded voice-activity detector into a validated, persistent multi-profile performance policy with regression coverage across local configuration, API boundaries, and renderer behavior.
