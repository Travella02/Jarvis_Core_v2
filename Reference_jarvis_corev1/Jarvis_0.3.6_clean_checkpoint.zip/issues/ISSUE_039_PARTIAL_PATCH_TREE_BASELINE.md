# ISSUE-039 — Partial Patch Tree Baseline

## Symptom

The first `0.0.6` working tree appeared to contain the current Electron files, but full release validation exposed missing historical issue records, tests, and accepted project files. Building the release from that tree would have produced an incomplete update package and weakened the handoff history.

## Impact

A patch can look correct when only the newly edited files are inspected while still omitting accepted files that belong to the repository. Shipping from a partial baseline risks deleting documentation, skipping regression coverage, and making future troubleshooting harder.

## Root cause

The release work initially copied a repair-oriented staging directory instead of the complete accepted `0.0.5` repository reconstruction. That staging directory was designed to contain only files relevant to a previous repair, not the full project state.

## Investigation

The issue-documentation test and directory comparison showed that the working tree stopped at earlier issue records and lacked files present in the accepted repository. Comparing the partial tree against the reconstructed full `0.0.5` baseline confirmed the source-selection error rather than a code-generation failure.

## Fix

All `0.0.6` changes were migrated onto the complete accepted `0.0.5` repository tree. Release metadata, issue documentation, JavaScript tests, Python tests, and the final payload manifest are generated only from that full baseline. The incomplete working tree is excluded from packaging.

## Regression protection

- The complete Python discovery suite must pass from the final work tree.
- The issue-portfolio test verifies every historical issue record remains present.
- The release manifest is built from the final full repository rather than from a repair-only payload tree.
- Installer validation is performed against a fresh copy of the accepted `0.0.5` baseline.

## Result

The `0.0.6` package retains the entire accepted history and adds Desktop Presence without silently dropping previous project files or regression tests.

## Engineering lesson

A patch payload and a repository baseline are different artifacts. Release work should always begin from a verified complete accepted baseline, then derive the minimal payload by comparing that baseline with the finished release.

## Recruiter talking point

I caught a release-engineering problem where a repair staging tree looked current but was not a complete repository. I used full-suite validation and tree comparison to identify the baseline mismatch, rebuilt the update on the accepted repository, and added checks that protect historical tests and documentation from accidental omission.
