# ISSUE-030 — Background noise caused false Jarvis wake detections

## Symptom

The sleeping desktop assistant sometimes believed it heard “Jarvis” when nobody was speaking, causing unnecessary wake transcription requests and occasional Realtime connections.

## Impact

False wakes interrupted the user, spent API funds, and made the always-listening experience feel unreliable.

## Root cause

The first model-wake implementation used one fixed RMS threshold and began recording after a single loud frame. Its transcription prompt also explicitly suggested the word “Jarvis,” which could bias uncertain audio toward the wake keyword.

## Fix

- Added a local microphone calibration period and adaptive noise-floor threshold.
- Required multiple consecutive signal frames before beginning a wake capture.
- Measured voiced duration and peak energy, rejecting weak captures locally before any paid transcription call.
- Added a cooldown after rejected or non-wake utterances.
- Replaced the keyword-biased transcription prompt with a neutral verbatim prompt that requests an empty transcript for silence, noise, music, breathing, or unintelligible audio.

## Regression protection

Tests assert the adaptive calibration constants, consecutive-frame requirement, voiced-duration and peak checks, local rejection event, negative-result cooldown, and neutral transcription prompt.

## Recruiter talking point

I reduced false activations and unnecessary spend by combining adaptive local signal processing with prompt de-biasing. Low-confidence noise is rejected before the network boundary, and ambiguous cloud transcription is explicitly instructed not to infer the wake keyword.
