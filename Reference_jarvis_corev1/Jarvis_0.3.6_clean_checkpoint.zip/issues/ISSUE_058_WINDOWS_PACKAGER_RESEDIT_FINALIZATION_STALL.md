# ISSUE-058 — Windows executable resource editing stalled package finalization

## Symptom

After `0.1.0-repair3` reduced the Electron shell to 22 files and compressed the complete Python/desktop runtime into a 15.68 MiB archive, `npm run alpha:make` still remained on `Finalizing package` for more than 20 minutes. A second PowerShell diagnostic showed the Electron Forge process alive, no active packaging child process, and no files under `out`.

## Scope and impact

The runtime download, dependency installation, runtime bundle, source filter, and Forge target resolution all completed. The Windows package never reached the Squirrel maker, so no Setup executable could be produced and `0.1.0` remained unaccepted.

## Root cause

Electron Forge groups several hidden Electron Packager operations under one `Finalizing package` line. The Windows path performs executable renaming, external-resource copying, executable icon/version resource editing, signing when configured, and the final staging-directory move. The previous build provided no durable stage evidence. The strongest remaining suspect was the executable resource editor operating on the large Electron executable, with the temporary-directory move as the other unisolated operation.

## Investigation

- Confirmed the app source was only 0.31 MiB.
- Confirmed the runtime was one 15.68 MiB archive rather than hundreds of loose resources.
- Confirmed no Squirrel or Electron child process remained active.
- Confirmed `out` was empty because Packager was still working in its temporary staging path.
- Rejected further payload-size changes because the measured inputs were already compact.
- Chose to instrument the actual Windows Packager methods and bypass resource editing for the diagnostic alpha instead of making another blind packaging change.

## Fix

- Added timestamped wrappers around `initialize`, `renameElectron`, `copyExtraResources`, `runResedit`, signing, and final move.
- Persisted the trace to `build/alpha-packaging-diagnostic.log` so evidence survives cancellation.
- Disabled Electron executable icon/version resource editing by default for this diagnostic alpha build.
- Preserved the branding metadata configuration so resource editing can be re-enabled later with `JARVIS_ALPHA_ENABLE_RESEDIT=1`.
- Set Electron Packager `tmpdir: false` so packaging happens directly under `out` and cannot freeze during a final cross-directory move.
- Added a Forge launcher that enables Electron Packager debug output and prints a one-minute heartbeat with the last completed stage.

## Regression protection

- Node tests verify direct-to-`out` packaging, the diagnostic Forge runner, default resource-editor bypass, and persistent log writing.
- Python tests verify the new diagnostic scripts, bypass marker, direct-output configuration, and heartbeat text remain present.
- Existing source-scope, runtime-bundle, installer, security, and release-consistency tests remain active.
- The final Windows run must preserve `build/alpha-packaging-diagnostic.log` if it fails, allowing the next repair to target the exact method rather than the generic Forge spinner.

## Outcome

The build no longer depends on the suspected Windows executable resource-editing operation and no longer hides all finalization work in an inaccessible temporary directory. A successful run may temporarily use Electron's default application executable icon/metadata; the Squirrel Setup icon remains configured. Full branded executable resources can be restored after the installer path is proven.

## Lessons

Progress labels are not diagnostic boundaries. When a third-party build tool combines multiple operations under one spinner, instrument the underlying methods, persist evidence outside the temporary workspace, and remove one risky operation at a time.

## Recruiter talking point

Instrumented an opaque Windows Electron packaging hang at method-level granularity, introduced durable timestamped diagnostics and heartbeat reporting, and isolated executable resource editing without weakening the application's runtime or secret-storage architecture.
