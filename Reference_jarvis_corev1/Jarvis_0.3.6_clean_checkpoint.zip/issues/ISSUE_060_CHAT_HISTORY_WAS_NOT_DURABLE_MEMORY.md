# ISSUE-060 — Chat history was not durable memory

## Symptom

Jarvis could hold the active Realtime conversation but could not reliably answer what Tanner said, did, ate, created, or decided after the session ended. There was no exact timeline, category structure, source attribution, or persistent evidence.

## Root cause

The stable voice lifecycle deliberately avoided durable conversation storage. No event-ledger schema connected timestamps, actors, sources, entities, facts, and future multimodal producers.

## Investigation

A simple transcript table would preserve text but would not support future voice identity, vision, web activity, evolving businesses, duplicate consolidation, corrections, relationships, or provenance. Storing only summaries would also create untraceable AI rewrites and lose exact history.

## Fix

Implemented a local SQLite event ledger plus knowledge graph. Exact events are append-only and retain local time, timezone, actor, source, session, content, metadata, category, entities, and facts. Derived facts keep evidence links back to the original events. Bounded memories are rendered into new Realtime sessions.

## Regression protection

Tests cover persistence, exact timestamp preservation, autonomous categories, entity/fact creation, search, date filtering, Realtime context, and server routes.

## Recruiter talking point

Designed a provenance-first memory architecture that separates immutable event evidence from reorganizable knowledge, allowing a real-time assistant to learn continuously without sacrificing auditability.
