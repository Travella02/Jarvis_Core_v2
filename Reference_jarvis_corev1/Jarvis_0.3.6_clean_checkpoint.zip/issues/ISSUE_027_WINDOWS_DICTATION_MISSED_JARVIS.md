# ISSUE-027 — Windows dictation listener stayed ready but missed “Jarvis”

## Symptom

The Electron desktop shell opened successfully and the local speech status remained ready, but saying “Jarvis,” “Hey Jarvis,” or a longer wake request did not wake the assistant. The listener did not crash or restart; it simply continued waiting.

## Impact

The native desktop lifecycle was healthy, but hands-free wake and spoken sleep behavior could not be accepted. Manual controls still worked, which isolated the defect to local recognition rather than Electron, the Python core, or OpenAI Realtime.

## Investigation

Repair 5 replaced Electron Web Speech with Windows `System.Speech`. The subprocess stayed alive and reported an installed English recognizer, so process supervision and IPC were functioning. The recognizer had only a generic `DictationGrammar` with a context hint for “Jarvis.” Generic dictation is optimized for ordinary vocabulary and may reject or substitute uncommon proper nouns, especially one-word wake utterances.

The first implementation also had no microphone-signal diagnostic. A ready status therefore could not distinguish between a grammar mismatch and Windows listening to the wrong default recording device.

## Root cause

The lifecycle listener depended on unrestricted dictation to recognize a product-specific keyword. “Jarvis” was not represented as a high-priority constrained grammar, so the engine could remain healthy while failing to return a matching result. The lack of signal/no-match diagnostics obscured whether the default Windows microphone was receiving audio.

## Fix

- Added explicit high-priority grammars for wake-only phrases, wake phrases followed by free-form dictation, and supported sleep phrases.
- Retained a lower-weight general dictation grammar for normal follow-up transcript assistance.
- Added audio-level monitoring and bounded status events that distinguish no microphone signal from speech that did not match a grammar.
- Added safe terminal diagnostics showing recognized text, grammar name, and confidence without exposing secrets.
- Updated the renderer to show actionable microphone/default-device guidance instead of silently remaining on “listening.”

## Regression protection

Automated tests verify that the Windows listener contains explicit `Choices`, a `jarvis_wake_request` grammar using `AppendDictation`, a dedicated sleep grammar, a lower-weight general dictation fallback, and microphone/no-match diagnostic statuses. Electron and renderer syntax validation remain part of installer acceptance.

The final microphone test must run on Windows because the Linux build environment cannot execute the installed Windows speech engine.

## Recruiter talking point

I diagnosed a native speech feature that looked healthy at the process level but failed at the language-model layer. I replaced a generic dictation-only design with prioritized domain grammars and added observability that separated microphone routing failures from recognition failures, making the desktop wake system both more reliable and easier to support.
