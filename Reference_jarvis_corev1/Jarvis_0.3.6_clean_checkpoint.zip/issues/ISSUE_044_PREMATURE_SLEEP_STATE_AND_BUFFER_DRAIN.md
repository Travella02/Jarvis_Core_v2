# ISSUE-044 — Premature Sleep State and Buffer Drain

## Symptom

During live Electron testing, Jarvis began the Cedar sign-off but the Realtime session closed before even the first phrase completed. The terminal also emitted a long FastAPI/ASGI traceback ending in an invalid state transition from `sleeping` to `speaking`.

## Impact

The spoken sign-off was unreliable in hands-free use, and the server log looked like a core crash even though the actual defect was an out-of-order lifecycle event. Repeated repair attempts that only lengthened audio silence thresholds did not solve the underlying problem.

## Investigation

The client sent `client.sleeping` as soon as the model called `sleep_jarvis`, before requesting the spoken acknowledgement. That moved the authoritative local state machine to `sleeping`. When Cedar's acknowledgement then began, the client relayed `response.output_audio.started`, producing the impossible transition `sleeping -> speaking` and an ASGI traceback.

The shutdown path also treated `response.done` plus local RMS silence as proof that playback had drained. In a WebRTC Realtime session, provider response generation can complete before all queued output audio has finished playing. Natural pauses and threshold dips therefore remained unsafe as the primary teardown boundary.

## Root cause

Two lifecycle boundaries were conflated:

1. **Sleep intent accepted** — Jarvis is still awake and must speak the sign-off.
2. **Sleep completed** — Cedar has finished playback and the session can close.

The renderer published the final sleep event at boundary one, and the playback logic relied on a heuristic instead of the provider-managed WebRTC output-buffer completion signal.

## Fix

- Add `client.sleep.acknowledging` as a non-terminal lifecycle event.
- Keep the authoritative state in `thinking`/`speaking` while Cedar signs off.
- Publish `client.sleeping` only from the final shared shutdown path after playback completion.
- Listen for `output_audio_buffer.started` and `output_audio_buffer.stopped` during the acknowledgement.
- Treat provider buffer stop plus `response.done` as the primary completion condition.
- Retain a longer analyser-based fallback only when the buffer-stop event is unavailable.
- Remove the live exact-phrase shortcut that could directly close the session before the model tool lifecycle completed; keep it only for free simulation.
- Return HTTP 409 for genuinely out-of-order lifecycle events instead of exposing an unhandled ASGI traceback.

## Regression protection

Automated tests verify:

- `client.sleep.acknowledging` does not move the core into `sleeping`.
- The core can transition to `speaking` during the acknowledgement.
- Only the final `client.sleeping` event completes the lifecycle.
- The renderer waits for `output_audio_buffer.stopped` as the authoritative WebRTC completion signal.
- The analyser path is fallback-only and uses conservative timing.
- Live transcript phrase matching delegates to the `sleep_jarvis` model tool.
- Out-of-order lifecycle events return a bounded 409 response instead of an ASGI 500.

## Result

Jarvis remains authoritatively awake while Cedar speaks, waits for the provider-managed output buffer to stop, then closes the Realtime session and returns to wake monitoring without truncating the sign-off or generating a state-transition traceback.

## Engineering lesson

Intent acceptance, response generation completion, audio playback completion, and resource teardown are separate distributed-system boundaries. Destructive transitions should follow the strongest available completion signal, and intermediate lifecycle states must be represented explicitly rather than overloaded onto the final state.

## Recruiter talking point

Diagnosed a cross-layer WebRTC lifecycle race from a FastAPI state-transition traceback, introduced an explicit acknowledgement phase, used provider playback-buffer completion as the authoritative teardown signal, added a conservative fallback, and converted unexpected event order into a safe API conflict response.
