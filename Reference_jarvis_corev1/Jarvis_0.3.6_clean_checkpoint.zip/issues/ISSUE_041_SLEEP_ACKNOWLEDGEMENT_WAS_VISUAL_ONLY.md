# ISSUE 041 — Sleep acknowledgement was visual only

## Symptom

When the user ended a voice conversation, Jarvis displayed “Of course, sir.” in the conversation panel but closed the Realtime session before any acknowledgement was spoken.

## Impact

Jarvis is intended to operate without requiring the user to watch a screen. A silent visual-only sign-off made the voice lifecycle feel incomplete and left the user uncertain whether Jarvis had actually understood the sleep request.

## Investigation

The `sleep_jarvis` tool handler immediately added a text bubble and scheduled session shutdown. It returned function output to the provider but did not request a follow-up audio response or wait for WebRTC playback.

## Root cause

Tool execution and user-facing acknowledgement were treated as the same synchronous step. The implementation did not model generation completion and audible playback completion as separate lifecycle events.

## Fix

- Disable the conversation microphone as soon as sleep intent is accepted.
- Return `function_call_output` to the Realtime conversation.
- Request one follow-up response with an exact short sign-off instruction.
- Cap the response at 16 output tokens.
- Track first audible acknowledgement audio through the existing remote analyser.
- Close the session only after audio playback reaches sustained silence.
- Keep a bounded timeout fallback so shutdown cannot hang.

## Regression protection

Tests verify the short instruction, output cap, audio-observed flag, response-done flag, completion path, lifecycle metrics, and final authoritative `sleepJarvis` call.

## Result

Jarvis can now audibly confirm a natural sleep request while adding only a tiny amount of output audio and closing the paid session immediately afterward.

## Engineering lesson

In voice systems, “response generated” and “response heard” are different states. Lifecycle transitions should be driven by the user-perceived completion boundary.

## Recruiter talking point

Implemented a tool-driven voice shutdown state machine that coordinates function calling, low-cost audio generation, WebRTC playback detection, usage accounting, timeout recovery, and final resource cleanup.
