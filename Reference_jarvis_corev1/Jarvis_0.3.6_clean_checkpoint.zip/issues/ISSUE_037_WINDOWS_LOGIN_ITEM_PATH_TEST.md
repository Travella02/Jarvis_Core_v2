# ISSUE-037 — Windows login-item path logic failed under cross-platform validation

## Summary

While building `0.0.6 — Desktop Presence`, the new startup-with-Windows helper passed development-mode tests but failed the packaged Squirrel-launcher test in the Linux validation environment.

## User-visible risk

Without correction, a packaged Windows build could register the wrong executable path for startup, or the test suite could report a false failure even though the Windows path was valid.

## Symptom

The pure Node test expected a Windows path such as:

```text
C:\Users\Tanner\AppData\Local\Jarvis\Jarvis.exe
```

but Node's host-platform `path` module interpreted it with POSIX rules and produced a malformed path beginning with `/C:\...`.

## Root cause

`path.dirname`, `path.basename`, and `path.resolve` use the semantics of the operating system running the test. The implementation needed to reason about a Windows path even when tests ran on Linux.

## Investigation

The failing Node test isolated the problem to the Squirrel stub-path calculation. Development login-item arguments were correct, while only the packaged Windows path was malformed.

## Fix

The helper now detects drive-letter paths and explicitly uses `path.win32` for Windows path manipulation. Native host-path behavior remains in place for non-Windows paths.

## Regression protection

`tests_js/presence.test.cjs` verifies both:

- Development Electron startup arguments.
- Packaged Squirrel launcher path selection using a Windows path while running on any test host.

## Result

The complete Node presence suite passes on the Linux build environment while still validating the exact Windows path behavior Jarvis needs.

## Engineering lesson

Cross-platform tests must select path semantics based on the data being processed, not only the operating system executing the test.

## Recruiter talking point

I caught a portability defect in Windows startup registration by testing path logic on a non-Windows CI host, then separated host-platform behavior from target-platform behavior with deterministic tests.
