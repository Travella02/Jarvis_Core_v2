(function memoryNavigationModule(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.JarvisMemoryNavigation = api;
}(typeof globalThis !== "undefined" ? globalThis : this, function createMemoryNavigation() {
  "use strict";

  const DISPLAY_PREFIX = /^(?:please\s+)?(?:(?:show|display)\s+me|show|display|open|pull\s+up|bring\s+up|take\s+me\s+to|let\s+me\s+see)\b/i;
  const MEMORY_WORD = /\bmemor(?:y|ies)\b/i;
  const EVERYTHING_ABOUT = /^(?:me\s+)?(?:everything|all(?:\s+(?:that\s+)?(?:you\s+)?(?:know|remember))?)\s+(?:about|on|regarding|related\s+to)\s+(.+)$/i;
  const WHAT_WAS_SAID = /^(?:me\s+)?what\b.*\b(?:said|told|mentioned|discussed|remembered)\b/i;
  const TEMPORAL_WORDS = /\b(?:today|yesterday|tomorrow|tonight|morning|afternoon|evening|week|month|year|monday|tuesday|wednesday|thursday|friday|saturday|sunday|before|after|between|during|since|until|from)\b/i;
  const SPEECH_WORDS = /\b(?:said|told|mentioned|discussed|asked|answered|spoke|talked)\b/i;
  const COMBINED_SHOW_AND_TELL = /^(?:please\s+)?(?:show|display)(?:\s+me)?\s+and\s+(?:tell|explain|describe)\s+(?:me\s+)?(?:about\s+)?(.+)$/i;
  const TRAILING_RESPONSE_REQUEST = /\s+(?:and|then)\s+(?:(?:(?:give|provide)\s+me\s+(?:a\s+)?(?:(?:very\s+)?(?:short|brief|quick|detailed|full)\s+)?summary(?:\s+of\s+(?:it|them|this|the\s+results?))?)|(?:(?:tell|explain|summarize|describe)\s+(?:me\s+)?(?:about\s+)?(?:it|them|this|the\s+results?|what\s+you\s+(?:know|remember)(?:\s+about\s+it)?))|(?:walk\s+me\s+through\s+(?:it|them|this|the\s+results?)))(?:\s+please)?$/i;

  function normalizeText(value) {
    return String(value || "")
      .replace(/[\u2018\u2019]/g, "'")
      .replace(/\s+/g, " ")
      .trim();
  }

  function stripJarvisPrefix(value) {
    return normalizeText(value).replace(/^(?:hey\s+|okay\s+|ok\s+)?jarvis\b[\s,.:;!?-]*/i, "").trim();
  }

  function cleanSubject(value) {
    return normalizeText(value)
      .replace(/[.?!,;:]+$/g, "")
      .replace(/\bplease$/i, "")
      .trim();
  }

  function splitResponseRequest(value) {
    const normalized = cleanSubject(value);
    const match = normalized.match(TRAILING_RESPONSE_REQUEST);
    if (!match || match.index === undefined) {
      return {displayText: normalized, responseRequested: false, responseDirective: ""};
    }
    return {
      displayText: cleanSubject(normalized.slice(0, match.index)),
      responseRequested: true,
      responseDirective: cleanSubject(match[0].replace(/^\s+(?:and|then)\s+/i, "")),
    };
  }

  function subjectFromRemainder(remainder) {
    const everything = remainder.match(EVERYTHING_ABOUT);
    if (everything) return cleanSubject(everything[1]);

    const memoryAfter = remainder.match(/(?:my\s+|the\s+|all\s+)?memor(?:y|ies)\s+(?:about|for|on|related\s+to)\s+(.+)$/i);
    if (memoryAfter) return cleanSubject(memoryAfter[1]);

    const memoryBefore = remainder.match(/^(.+?)\s+(?:memor(?:y|ies)|memory\s+records?)$/i);
    if (memoryBefore) return cleanSubject(memoryBefore[1]);

    return "";
  }

  function hasMemoryDisplayMeaning(remainder) {
    if (MEMORY_WORD.test(remainder)) return true;
    if (EVERYTHING_ABOUT.test(remainder)) return true;
    if (WHAT_WAS_SAID.test(remainder)) return true;
    if (/^(?:me\s+)?(?:everything|all)\b/i.test(remainder) && /\b(?:about|related\s+to|from|on)\b/i.test(remainder)) return true;
    if (/^(?:me\s+)?what\s+(?:i|we|you|[a-z][\w'-]*)\s+(?:said|told|mentioned|discussed)/i.test(remainder)) return true;
    return false;
  }

  function parseMemoryNavigationIntent(text) {
    const original = normalizeText(text);
    const withoutWakeName = stripJarvisPrefix(original);

    const combined = withoutWakeName.match(COMBINED_SHOW_AND_TELL);
    if (combined) {
      const subject = cleanSubject(combined[1]);
      if (!subject) return null;
      return {
        original,
        query: original,
        subject,
        preferEntity: !TEMPORAL_WORDS.test(subject) && subject.split(/\s+/).length <= 8,
        mode: !TEMPORAL_WORDS.test(subject) && subject.split(/\s+/).length <= 8 ? "entity" : "timeline",
        reason: "show_and_describe_memory",
        responseRequested: true,
        responseDirective: "tell me about the displayed memory",
      };
    }

    const prefix = withoutWakeName.match(DISPLAY_PREFIX);
    if (!prefix) return null;

    const rawRemainder = cleanSubject(withoutWakeName.slice(prefix[0].length));
    const responseSplit = splitResponseRequest(rawRemainder);
    const remainder = responseSplit.displayText;
    if (!remainder || !hasMemoryDisplayMeaning(remainder)) return null;

    const broadMemoryOpen = /^(?:me\s+)?(?:my\s+|the\s+)?memor(?:y|ies)(?:\s+(?:explorer|timeline|page|workspace))?$/i.test(remainder);
    const subject = broadMemoryOpen ? "" : subjectFromRemainder(remainder);
    const preferEntity = Boolean(subject)
      && !TEMPORAL_WORDS.test(subject)
      && !SPEECH_WORDS.test(remainder)
      && subject.split(/\s+/).length <= 8;

    return {
      original,
      query: broadMemoryOpen ? "" : remainder,
      subject,
      preferEntity,
      mode: preferEntity ? "entity" : "timeline",
      reason: broadMemoryOpen ? "open_memory_workspace" : (preferEntity ? "show_entity_memory" : "show_filtered_memory"),
      responseRequested: responseSplit.responseRequested,
      responseDirective: responseSplit.responseDirective,
    };
  }

  function narrationPolicy(directive) {
    const normalized = normalizeText(directive).toLocaleLowerCase();
    if (/\b(?:short|brief|quick)\b.*\bsummary\b|\bsummary\b.*\b(?:short|brief|quick)\b/i.test(normalized)) {
      return {
        style: "short_summary",
        maxSentences: 1,
        maxWords: 40,
        instruction: "Give exactly one concise sentence containing only unique facts. Use no more than 40 spoken words, mention each fact once, and stop immediately after that sentence.",
      };
    }
    if (/\b(?:detailed|full|complete|thorough)\b/i.test(normalized)) {
      return {
        style: "detailed_explanation",
        maxSentences: 0,
        maxWords: 0,
        instruction: "Give one coherent detailed explanation without appending a second summary.",
      };
    }
    return {
      style: "single_explanation",
      maxSentences: 0,
      maxWords: 0,
      instruction: "Give one coherent explanation without repeating the same facts in a recap or second summary.",
    };
  }

  function comparableName(value) {
    return normalizeText(value).toLocaleLowerCase().replace(/[^a-z0-9]+/g, "");
  }

  function editDistance(left, right) {
    const a = comparableName(left);
    const b = comparableName(right);
    if (a === b) return 0;
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    const previous = Array.from({length: b.length + 1}, (_, index) => index);
    for (let row = 1; row <= a.length; row += 1) {
      const current = [row];
      for (let column = 1; column <= b.length; column += 1) {
        const cost = a[row - 1] === b[column - 1] ? 0 : 1;
        current[column] = Math.min(
          current[column - 1] + 1,
          previous[column] + 1,
          previous[column - 1] + cost,
        );
      }
      previous.splice(0, previous.length, ...current);
    }
    return previous[b.length];
  }

  function chooseEntityCandidate(subject, candidates) {
    const expected = comparableName(subject);
    if (!expected) return null;
    const list = Array.isArray(candidates) ? candidates : [];
    const namesFor = (candidate) => [candidate?.name, ...(candidate?.aliases || []).map((alias) => alias?.alias || alias)]
      .filter(Boolean);
    const exact = list.find((candidate) => namesFor(candidate).some((name) => comparableName(name) === expected));
    if (exact) return exact;

    let best = null;
    for (const candidate of list) {
      for (const name of namesFor(candidate)) {
        const comparable = comparableName(name);
        if (!comparable) continue;
        const distance = editDistance(expected, comparable);
        const allowed = Math.max(1, Math.min(2, Math.floor(Math.max(expected.length, comparable.length) / 4)));
        if (distance <= allowed && (!best || distance < best.distance)) best = {candidate, distance};
      }
    }
    if (best) return best.candidate;
    return list.length === 1 ? list[0] : null;
  }

  return {parseMemoryNavigationIntent, chooseEntityCandidate, editDistance, normalizeText, splitResponseRequest, narrationPolicy};
}));
