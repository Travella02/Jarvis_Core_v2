"use strict";

const $ = (id) => document.getElementById(id);
const ui = {
  statusDot: $("statusDot"), statusText: $("statusText"), gameModeWrap: $("gameModeWrap"), gameModeText: $("gameModeText"), version: $("version"), model: $("model"),
  voice: $("voice"), turnDetection: $("turnDetection"), responseMode: $("responseMode"),
  wakeProfile: $("wakeProfile"), connectionMode: $("connectionMode"), testAutoSleep: $("testAutoSleep"),
  microphone: $("microphone"), speaker: $("speaker"), voicePersonality: $("voicePersonality"), speechProvider: $("speechProvider"),
  refreshDevices: $("refreshDevices"), mute: $("mute"), wake: $("wake"), sleep: $("sleep"),
  stopSpeaking: $("stopSpeaking"), configurationMessage: $("configurationMessage"),
  handshakeMetric: $("handshakeMetric"), speechMetric: $("speechMetric"), decisionMetric: $("decisionMetric"),
  firstAudioMetric: $("firstAudioMetric"), totalMetric: $("totalMetric"), interruptionMetric: $("interruptionMetric"),
  sessionAge: $("sessionAge"), transcript: $("transcript"), textForm: $("textForm"), textInput: $("textInput"),
  sendText: $("sendText"), events: $("events"), clearEvents: $("clearEvents"), remoteAudio: $("remoteAudio"),
  wakeKeyword: $("wakeKeyword"), wakeListenerStatus: $("wakeListenerStatus"), awakeMetric: $("awakeMetric"),
  connectedMetric: $("connectedMetric"), userSpeakingMetric: $("userSpeakingMetric"),
  jarvisSpeakingMetric: $("jarvisSpeakingMetric"), responsesMetric: $("responsesMetric"),
  paidCallsMetric: $("paidCallsMetric"), textCallsMetric: $("textCallsMetric"), realtimeCallsMetric: $("realtimeCallsMetric"),
  idleMetric: $("idleMetric"), sessionCostMetric: $("sessionCostMetric"), responseCostMetric: $("responseCostMetric"),
  costPerMinuteMetric: $("costPerMinuteMetric"), todayCostMetric: $("todayCostMetric"), monthCostMetric: $("monthCostMetric"),
  cachedSavingsMetric: $("cachedSavingsMetric"), audioInputCostMetric: $("audioInputCostMetric"),
  audioOutputCostMetric: $("audioOutputCostMetric"), textCostMetric: $("textCostMetric"), wakeTranscriptionCostMetric: $("wakeTranscriptionCostMetric"), budgetStatus: $("budgetStatus"),
  wakeTranscriptionMetric: $("wakeTranscriptionMetric"), wakePreconnectMetric: $("wakePreconnectMetric"), wakeFirstAudioMetric: $("wakeFirstAudioMetric"),
  sleepIntentMetric: $("sleepIntentMetric"), sleepAckMetric: $("sleepAckMetric"), sleepCompleteMetric: $("sleepCompleteMetric"),
  presenceBadge: $("presenceBadge"), presenceAppUptime: $("presenceAppUptime"), presenceCoreState: $("presenceCoreState"),
  presenceCoreUptime: $("presenceCoreUptime"), presenceCoreRestarts: $("presenceCoreRestarts"),
  presenceRendererRecoveries: $("presenceRendererRecoveries"), presenceHeartbeat: $("presenceHeartbeat"),
  startWithWindows: $("startWithWindows"), desktopNotifications: $("desktopNotifications"), restartCore: $("restartCore"),
  jarvisOrb: $("jarvisOrb"), orbStateTitle: $("orbStateTitle"), orbStateDetail: $("orbStateDetail"),
  orbWake: $("orbWake"), orbSleep: $("orbSleep"), orbStop: $("orbStop"),
  quickAwakeMetric: $("quickAwakeMetric"), quickConnectedMetric: $("quickConnectedMetric"),
  quickSessionCostMetric: $("quickSessionCostMetric"), quickWakeMetric: $("quickWakeMetric"),
  homePresenceState: $("homePresenceState"), homePresenceDetail: $("homePresenceDetail"),
  homeBudgetStatus: $("homeBudgetStatus"), homeBudgetDetail: $("homeBudgetDetail"),
  interfaceFocusToggle: $("interfaceFocusToggle"), interfaceRailToggle: $("interfaceRailToggle"),
  conversationJumpLatest: $("conversationJumpLatest"), appFrame: $("appFrame"),
  firstRunOverlay: $("firstRunOverlay"), firstRunForm: $("firstRunForm"), setupApiKey: $("setupApiKey"), setupProviderIntro: $("setupProviderIntro"), setupApiKeyRow: $("setupApiKeyRow"),
  setupVoice: $("setupVoice"), setupWakeProfile: $("setupWakeProfile"), setupResponseMode: $("setupResponseMode"),
  setupMicrophone: $("setupMicrophone"), setupSpeaker: $("setupSpeaker"),
  setupDailyWarning: $("setupDailyWarning"), setupDailyHard: $("setupDailyHard"),
  setupMonthlyWarning: $("setupMonthlyWarning"), setupMonthlyHard: $("setupMonthlyHard"),
  setupStartWithWindows: $("setupStartWithWindows"), setupNotifications: $("setupNotifications"),
  setupMessage: $("setupMessage"), setupCancel: $("setupCancel"), setupSave: $("setupSave"), openSetup: $("openSetup"),
  alphaBuildBadge: $("alphaBuildBadge"), alphaAppVersion: $("alphaAppVersion"),
  alphaElectronVersion: $("alphaElectronVersion"), alphaPythonVersion: $("alphaPythonVersion"),
  alphaKeyStatus: $("alphaKeyStatus"), alphaProviderLabel: $("alphaProviderLabel"), alphaInstallPath: $("alphaInstallPath"), alphaDataPath: $("alphaDataPath"),
  alphaLogPath: $("alphaLogPath"), exportDiagnostics: $("exportDiagnostics"), checkUpdates: $("checkUpdates"),
  openRelease: $("openRelease"), alphaUpdateStatus: $("alphaUpdateStatus"),
  memoryHealthBadge: $("memoryHealthBadge"), memoryEventsMetric: $("memoryEventsMetric"),
  memoryEntitiesMetric: $("memoryEntitiesMetric"), memoryFactsMetric: $("memoryFactsMetric"),
  memoryCategoriesMetric: $("memoryCategoriesMetric"), memoryFindingsMetric: $("memoryFindingsMetric"), memoryProactiveMetric: $("memoryProactiveMetric"), memoryPeopleMetric: $("memoryPeopleMetric"), memoryCaptureForm: $("memoryCaptureForm"),
  memoryCaptureInput: $("memoryCaptureInput"), memoryCaptureButton: $("memoryCaptureButton"),
  memorySearchForm: $("memorySearchForm"), memorySearchInput: $("memorySearchInput"),
  memoryDateFromFilter: $("memoryDateFromFilter"), memoryDateToFilter: $("memoryDateToFilter"),
  memoryCategoryFilter: $("memoryCategoryFilter"), memorySourceFilter: $("memorySourceFilter"),
  memoryStatusFilter: $("memoryStatusFilter"), memoryImportantFilter: $("memoryImportantFilter"),
  memoryClearFilters: $("memoryClearFilters"), memoryRefreshButton: $("memoryRefreshButton"),
  memoryTimeline: $("memoryTimeline"), memoryCategoryList: $("memoryCategoryList"),
  memoryInterpretation: $("memoryInterpretation"), memoryEntitySearchForm: $("memoryEntitySearchForm"),
  memoryEntitySearchInput: $("memoryEntitySearchInput"), memoryEntityGrid: $("memoryEntityGrid"),
  memoryPeopleSearchForm: $("memoryPeopleSearchForm"), memoryPeopleSearchInput: $("memoryPeopleSearchInput"), memoryPeopleGrid: $("memoryPeopleGrid"),
  memoryAppSearchForm: $("memoryAppSearchForm"), memoryAppSearchInput: $("memoryAppSearchInput"), memoryAppRefreshButton: $("memoryAppRefreshButton"),
  memoryAppStatus: $("memoryAppStatus"), memoryAppGrid: $("memoryAppGrid"),
  voiceProfilePersonSelect: $("voiceProfilePersonSelect"), voiceProfileUploadButton: $("voiceProfileUploadButton"),
  voiceProfileRecordButton: $("voiceProfileRecordButton"), voiceProfileFileInput: $("voiceProfileFileInput"),
  voiceProfileConsent: $("voiceProfileConsent"), voiceProfileStatus: $("voiceProfileStatus"), voiceProfileGrid: $("voiceProfileGrid"),
  voiceEnrollmentGuide: $("voiceEnrollmentGuide"), voiceEnrollmentStep: $("voiceEnrollmentStep"),
  voiceEnrollmentReadiness: $("voiceEnrollmentReadiness"), voiceEnrollmentPhrase: $("voiceEnrollmentPhrase"), voiceEnrollmentHint: $("voiceEnrollmentHint"),
  memorySummaryDate: $("memorySummaryDate"), memorySummaryContent: $("memorySummaryContent"),
  memoryDetailOverlay: $("memoryDetailOverlay"), memoryDetailClose: $("memoryDetailClose"),
  memoryDetailKicker: $("memoryDetailKicker"), memoryDetailTitle: $("memoryDetailTitle"),
  memoryDetailContent: $("memoryDetailContent"), memoryUndoButton: $("memoryUndoButton"),
  messageReaderOverlay: $("messageReaderOverlay"), messageReaderClose: $("messageReaderClose"),
  messageReaderTitle: $("messageReaderTitle"), messageReaderContent: $("messageReaderContent"),
  memoryExportJson: $("memoryExportJson"), memoryExportMarkdown: $("memoryExportMarkdown"),
  memoryConsolidateButton: $("memoryConsolidateButton"), memoryStatus: $("memoryStatus"),
  memoryConsolidationOverview: $("memoryConsolidationOverview"), memoryConsolidationRuns: $("memoryConsolidationRuns"),
  memoryConsolidationFindings: $("memoryConsolidationFindings"),
  memoryProactiveOverview: $("memoryProactiveOverview"), memoryProactiveList: $("memoryProactiveList"),
  memoryProactiveRefreshButton: $("memoryProactiveRefreshButton"), memoryProactiveStatusFilter: $("memoryProactiveStatusFilter"),
  memoryProactivePriorityFilter: $("memoryProactivePriorityFilter"), memoryProactivePriorityOutput: $("memoryProactivePriorityOutput"),
  homeProactiveCard: $("homeProactiveCard"), homeProactiveStatus: $("homeProactiveStatus"), homeProactiveDetail: $("homeProactiveDetail"),
  homeTaskCard: $("homeTaskCard"), homeTaskStatus: $("homeTaskStatus"), homeTaskDetail: $("homeTaskDetail"),
  taskOpenList: $("taskOpenList"), taskCompletedList: $("taskCompletedList"), taskRefreshButton: $("taskRefreshButton"),
  taskOpenMetric: $("taskOpenMetric"), taskOverdueMetric: $("taskOverdueMetric"), taskCompletedMetric: $("taskCompletedMetric"),
  googleConnectionCard: $("googleConnectionCard"), googleConnectionStatus: $("googleConnectionStatus"),
  googleConnectionDetail: $("googleConnectionDetail"), googleConnectionBadge: $("googleConnectionBadge"),
  googleConnectButton: $("googleConnectButton"), googleDisconnectButton: $("googleDisconnectButton"),
  refreshConnectedAppsButton: $("refreshConnectedAppsButton"), connectedAppsMessage: $("connectedAppsMessage"),
  permissionList: $("permissionList"), permissionRefreshButton: $("permissionRefreshButton"), permissionMessage: $("permissionMessage"),
  accountGate: $("accountGate"), accountGateTitle: $("accountGateTitle"), accountGateDetail: $("accountGateDetail"),
  accountGateCreate: $("accountGateCreate"), accountGateSignIn: $("accountGateSignIn"), accountGateRecovery: $("accountGateRecovery"), accountGateStatus: $("accountGateStatus"),
  accountBrowserCreate: $("accountBrowserCreate"), accountBrowserSignIn: $("accountBrowserSignIn"), accountBrowserRecovery: $("accountBrowserRecovery"), accountManageButton: $("accountManageButton"),
  accountStatusBadge: $("accountStatusBadge"), accountSignedOutPanel: $("accountSignedOutPanel"), accountSignedInPanel: $("accountSignedInPanel"),
  accountBindingNotice: $("accountBindingNotice"), accountMessage: $("accountMessage"),
  accountDisplayName: $("accountDisplayName"), accountEmail: $("accountEmail"), accountTenantName: $("accountTenantName"), accountId: $("accountId"), accountTenantId: $("accountTenantId"),
  accountDeviceLabel: $("accountDeviceLabel"), accountSessionExpiry: $("accountSessionExpiry"), accountDataNamespace: $("accountDataNamespace"), accountVerificationStatus: $("accountVerificationStatus"), accountCloudStatus: $("accountCloudStatus"),
  accountProfileForm: $("accountProfileForm"), accountProfileName: $("accountProfileName"), accountProfileSave: $("accountProfileSave"), accountLogoutButton: $("accountLogoutButton"), accountProfileMessage: $("accountProfileMessage"),
  accountBillingPanel: $("accountBillingPanel"), accountBillingBadge: $("accountBillingBadge"), accountBillingMessage: $("accountBillingMessage"),
  accountPlanName: $("accountPlanName"), accountSubscriptionStatus: $("accountSubscriptionStatus"), accountMonthlyUsage: $("accountMonthlyUsage"),
  accountBillingReset: $("accountBillingReset"), accountAdditionalUsage: $("accountAdditionalUsage"), accountDeviceAllowance: $("accountDeviceAllowance"),
  accountCloudSyncPanel: $("accountCloudSyncPanel"), accountCloudBadge: $("accountCloudBadge"), accountCloudMessage: $("accountCloudMessage"),
  accountCloudEnabled: $("accountCloudEnabled"), accountCloudTasks: $("accountCloudTasks"), accountCloudMemory: $("accountCloudMemory"),
  accountCloudLastSync: $("accountCloudLastSync"), accountCloudConflicts: $("accountCloudConflicts"), accountCloudTransport: $("accountCloudTransport"),
  accountCloudSyncNow: $("accountCloudSyncNow"), accountCloudRefresh: $("accountCloudRefresh"),
  accountDeviceList: $("accountDeviceList"), accountDeviceRefresh: $("accountDeviceRefresh"),
  actionPlannerModel: $("actionPlannerModel"), googleContactsStatus: $("googleContactsStatus"), lastActionLatency: $("lastActionLatency"),
  pendingActionPanel: $("pendingActionPanel"), pendingActionTitle: $("pendingActionTitle"), pendingActionRisk: $("pendingActionRisk"),
  pendingActionSummary: $("pendingActionSummary"), pendingActionDetails: $("pendingActionDetails"), pendingActionReview: $("pendingActionReview"), pendingActionEdit: $("pendingActionEdit"),
  pendingActionConfirm: $("pendingActionConfirm"), pendingActionCancel: $("pendingActionCancel"),
};

const CLIENT_HEADER = "voice-lab-v1";
const HANDSHAKE_TIMEOUT_MS = 30000;
const DISCONNECT_GRACE_MS = 3500;
const MAX_AUTO_RECONNECTS = 1;
const PREFERENCES_KEY = "jarvis.voice-lab.preferences.v6";
const LEGACY_PREFERENCES_KEY = "jarvis.voice-lab.preferences.v5";
let accountReady = false;
let accountStatusState = null;
let browserAuthPollTimer = null;
let pendingBrowserAuthEphemeral = null;
// Legacy key is retained only so 0.3.6 can erase any poll token written by older builds.
const BROWSER_AUTH_STATE_KEY = "jarvis.account.browser_auth.pending.v1";
const INTERFACE_STATE_KEY = "jarvis.interface.foundation.v1";
const WAKE_RESTART_MS = 400;
const WAKE_CAPTURE_DELAY_MS = 700;
const WAKE_FINAL_DELAY_MS = 120;
const WAKE_PROMPT_RETRY_MS = 150;
const WAKE_PROMPT_MAX_WAIT_MS = 5000;
const WAKE_INPUT_GATE_RELEASE_DELAY_MS = 750;
const WAKE_BARGE_IN_RELEASE_DELAY_MS = 80;
const WAKE_VISUAL_MIN_MS = 360;
const WAKE_RESPONSE_AUDIO_START_GRACE_MS = 3500;
const WAKE_INPUT_GATE_MAX_MS = 90000;
const REMOTE_AUDIO_THRESHOLD = 0.012;
const REMOTE_AUDIO_SILENCE_MS = 300;
const ORB_SPEAKING_RELEASE_MS = 850;
const ORB_TRANSIENT_RELEASE_MS = 140;
const ORB_STATE_ANIMATION_MS = 520;
const TRANSCRIPT_BOTTOM_THRESHOLD_PX = 72;
const COMPOSER_MAX_HEIGHT_PX = 118;
const LIFECYCLE_RESTART_MS = 500;
const WAKE_VAD_PROCESSOR_SIZE = 512;
const WAKE_PROFILES = Object.freeze({
  fast: Object.freeze({calibrationMs: 80, minSilenceMs: 190, maxSilenceMs: 300, noiseMultiplier: 3.0, startFrames: 2, minVoicedMs: 130, minPeakMultiplier: 1.2}),
  balanced: Object.freeze({calibrationMs: 150, minSilenceMs: 280, maxSilenceMs: 450, noiseMultiplier: 3.5, startFrames: 3, minVoicedMs: 180, minPeakMultiplier: 1.35}),
  strict: Object.freeze({calibrationMs: 260, minSilenceMs: 420, maxSilenceMs: 700, noiseMultiplier: 4.5, startFrames: 4, minVoicedMs: 260, minPeakMultiplier: 1.55}),
});
const SLEEP_ACK_MAX_WAIT_MS = 12000;
const SLEEP_ACK_AUDIO_SILENCE_MS = 1600;
const SLEEP_ACK_LOCAL_MIN_PLAYBACK_MS = 4200;
const SLEEP_ACK_NO_AUDIO_FALLBACK_MS = 7000;
const SLEEP_ACK_COMPLETION_POLL_MS = 100;
const SLEEP_ACK_BUFFER_STOP_FALLBACK_MS = 6500;
const WAKE_NEGATIVE_COOLDOWN_MS = 500;
const WAKE_TRANSCRIPTION_SAMPLE_RATE = 16000;
const VOICE_TRANSCRIPT_FALLBACK_DELAY_MS = 2500;
const VOICE_TRANSCRIPT_DEDUPE_WINDOW_MS = 4000;
const VOICE_BARGE_IN_CONFIRM_MS = 180;
const VOICE_FALSE_VAD_RECOVERY_MS = 900;
const MEMORY_NAVIGATION_HOLD_MS = 5000;
const VISUAL_ONLY_RESPONSE_SUPPRESSION_MS = 8000;
const INTERNAL_TRANSCRIPTION_GUIDANCE = "Personal assistant conversation. Preserve names, dates, times, project names, business names, technical terms, and corrections accurately.";
const HYBRID_ANSWER_PURPOSE = "hybrid_answer";
const MESSAGE_READER_MIN_HEIGHT_PX = 420;
const MESSAGE_READER_VIEWPORT_RATIO = 0.62;
const LONG_ANSWER_PREVIEW_MIN_HEIGHT_PX = 210;
const LONG_ANSWER_PREVIEW_MAX_HEIGHT_PX = 330;
const LONG_ANSWER_PREVIEW_VIEWPORT_RATIO = 0.44;
const SPOKEN_SUMMARY_PURPOSE = "spoken_summary";
const STANDARD_VOICE_PURPOSE = "standard_voice";
const DETAILED_CONTEXT_MAX_CHARACTERS = 7000;
const CONNECTED_ACTION_CONTEXT_MAX_CHARACTERS = 9000;
const CONNECTED_ACTION_HINT = /\b(emails?|e-mails?|gmail|inbox|mail|messages?|drafts?|send|reply|forward|contacts?|address book|calendars?|schedules?|meetings?|appointments?|events?|availability|available|free time|tasks?|to[- ]?dos?|reminders?|remind|due|overdue)\b/i;
const CONNECTED_ACTION_TASK_HINT = /\b(?:tasks?|to[- ]?dos?|reminders?|remind\s+me|overdue|what\s+do\s+i\s+need\s+to\s+(?:do|get\s+done)|mark\b.{1,100}\b(?:as\s+)?(?:done|complete|completed|finished))\b/i;
const CONNECTED_ACTION_TASK_CONTEXT_FOLLOWUP = /\b(?:that|this|it)\s+(?:task|reminder)\b|^\s*(?:what|which)\s+(?:task|reminder)\s+(?:is|was)\s+(?:that|it)\b|^\s*(?:what(?:'s| is)\s+(?:that|it)|which\s+one)\s*[?!.]*\s*$|^\s*(?:mark\s+)?(?:that|it)\s+(?:done|complete|completed|finished)\b|^\s*(?:move|postpone|snooze|change|make|remind)\s+(?:that|it)\b/i;
const CONNECTED_ACTION_TASK_ATTRIBUTE_FOLLOWUP = /^\s*(?:and\s+)?(?:what\s+time|when|what\s+(?:day|date)|when\s+is\s+(?:that|it)|when\s+(?:is|was)\s+(?:that|it)\s+(?:due|scheduled)|when\s+will\s+you\s+remind\s+me|what(?:'s|\s+is)\s+(?:the\s+)?(?:reminder\s+time|due\s+(?:time|date)|priority)|is\s+there\s+(?:a\s+)?reminder(?:\s+set)?|what\s+priority)\s*[?!.]*\s*$/i;
const CONNECTED_ACTION_TASK_CONTEXT_SHOW = /^\s*(?:(?:can|could|would)\s+you\s+|please\s+)?(?:show(?:\s+me)?|display|open|pull\s+(?:it|that)\s+up|let\s+me\s+see)(?:\s+(?:it|that|this|the\s+task|the\s+reminder))?\s*[?!.]*\s*$/i;
const CONNECTED_ACTION_TASK_CONTEXT_REASONING = /\b(?:what\s+does\s+(?:that|this|it|the\s+task|the\s+website|the\s+project)\s+(?:mean|involve|require)|what\s+(?:do|should)\s+i\s+(?:do|work\s+on|focus\s+on)\s+(?:first|next)|what(?:'s|\s+is)\s+(?:next|the\s+next\s+step)|how\s+(?:do|should|can)\s+i\s+(?:do|finish|complete|start|approach|handle)\s+(?:that|this|it)|(?:can|could|would)\s+you\s+help\s+me\s+(?:with|do|finish|plan|break\s+down)\s+(?:that|this|it)|break\s+(?:that|this|it)\s+down|plan\s+(?:that|this|it)\s+out|what\s+else\s+(?:do\s+i\s+need|needs\s+to\s+happen)|how\s+far\s+(?:along|away)\s+(?:are\s+we|is\s+that|is\s+it))\b/i;
const CONNECTED_ACTION_TASK_EXPLICIT_REASONING = /\b(?:what\s+does|what\s+would|what\s+will|how\s+do\s+i|how\s+should\s+i|help\s+me|break\s+down|plan|steps?|first|next)\b.{0,140}\b(?:task|to[- ]?do|reminder|website|launch|project|goal)\b|\b(?:task|to[- ]?do|reminder|website|launch|project|goal)\b.{0,140}\b(?:involve|require|mean|steps?|first|next|plan|finish|complete|launch)\b/i;
const CONNECTED_ACTION_TASK_CONTEXT_DIALOGUE = /^\s*(?:why|how\s+so|tell\s+me\s+more|go\s+deeper|then\s+what|after\s+that|what\s+about\b.+|what\s+if\b.+|do\s+you\s+think\b.+|should\s+(?:i|we)\b.+|could\s+(?:i|we)\b.+|can\s+(?:i|we)\b.+|would\s+it\b.+|how\s+(?:long|much)\b.+|what\s+(?:are|would)\b.+|explain\b.+)\s*[?!.]*\s*$/i;
const CONNECTED_ACTION_TASK_CONTEXT_TTL_MS = 10 * 60 * 1000;
const CONNECTED_ACTION_TASK_RESTORED_TTL_MS = 2 * 60 * 1000;
const CONNECTED_ACTION_GMAIL_MARK_READ_HINT = /\bmark\b[^.!?]{0,120}\b(?:as\s+)?read\b|\b(?:mark|set)\b[^.!?]{0,120}\b(?:message|messages|email|emails|that|those|it|them)\b[^.!?]{0,80}\bread\b/i;
const CONNECTED_ACTION_CALENDAR_HINT = /\b(calendars?|schedules?|meetings?|appointments?|events?|availability|available|free time)\b/i;
// Broad day-level questions mean the user's whole agenda. Explicit Calendar
// wording remains Calendar-only, while task/to-do wording remains Tasks-only.
const CONNECTED_ACTION_UNIFIED_AGENDA_HINT = /^\s*(?![^?!.]{0,80}\b(?:calendar|schedule|agenda|tasks?|to[- ]?dos?|reminders?|due)\b)(?![^?!.]{0,80}\b(?:need|have)\s+to\s+(?:do|get\s+done)\b)(?:what\s+do\s+i\s+have(?!\s+(?:to\s+do|to\s+get\s+done|due))(?:\s+going\s+on)?|do\s+i\s+have\s+anything(?:\s+going\s+on)?|is\s+there\s+anything(?:\s+going\s+on)?|what(?:'s|\s+is)\s+(?:going\s+on|happening)|what\s+am\s+i\s+doing)\b.{0,48}\b(?:today|tomorrow)\b/i;
const CONNECTED_ACTION_CALENDAR_AGENDA_HINT = /^\s*(?:what(?:'s|\s+is)\s+(?:on\s+)?(?:my\s+)?(?:calendar|schedule|agenda)|what\s+do\s+i\s+have\s+(?:on\s+)?(?:my\s+)?(?:calendar|schedule|agenda)|do\s+i\s+have\s+anything\s+(?:on\s+)?(?:my\s+)?(?:calendar|schedule|agenda)|do\s+i\s+have\s+anything\s+scheduled|is\s+there\s+anything\s+scheduled|what\s+do\s+i\s+have\s+scheduled)\b.{0,48}\b(?:today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|this\s+(?:morning|afternoon|evening)|next\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday))\b/i;
const CONNECTED_ACTION_FREE_HINT = /\b(?:when\s+(?:am|are)\s+(?:i|we)\s+free|find\s+(?:me\s+)?(?:a\s+)?time\b.{0,120}\bfree|free\s+(?:today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|this\s+(?:morning|afternoon|evening|week|weekend)|next\s+(?:week|weekend|monday|tuesday|wednesday|thursday|friday|saturday|sunday)))\b/i;
const CONNECTED_ACTION_CONFIRMATION = /^\s*(?:(?:yes|yeah|yep|sure|okay|ok)(?:\s*,?\s*please)?|(?:(?:yes|yeah|yep|sure|okay|ok)\s*,?\s*)?(?:please\s+)?(?:(?:go ahead)(?:\s+and\s+(?:send(?:\s+(?:it|that(?:\s+(?:draft|email))?|the\s+(?:draft|email)))?|do it|schedule it|create it|update it|delete it))?|confirm(?:ed)?|do it|send(?:\s+(?:it|that(?:\s+(?:draft|email))?|the\s+(?:draft|email)))?|schedule it|create it|update it|delete it)(?:\s*,?\s*please)?|(?:no|nope)(?:\s*,?\s*(?:thanks|thank you))?|(?:no|nope)\s*,?\s*(?:please\s+)?(?:don't|do not)\s+send(?:\s+(?:it|that))?|(?:please\s+)?(?:don't|do not)\s+send(?:\s+(?:it|that))?|cancel(?:\s+(?:it|that))?|leave it|keep it(?:\s+as\s+(?:a\s+)?draft)?|never mind|nevermind|stop)\s*[.!]*\s*$/i;
const CONNECTED_ACTION_DECISION_PREFACE = /^\s*(?:(?:perfect|great|awesome|excellent|wonderful|fantastic|good|nice|sounds good|looks good|that works|works for me|that's good|that is good|that's perfect|that is perfect|thank you|thanks|alright|all right)(?:\s*,?\s*jarvis)?(?=$|[\s,.!;:—-])\s*[,!.;:—-]*\s*)+/i;
const CONNECTED_ACTION_DECISION_VOCATIVE = /^\s*jarvis(?=$|[\s,.!;:—-])\s*[,!.;:—-]*\s*/i;
const CONNECTED_ACTION_DECISION_EXPLICIT_START = /\b(?:yes|yeah|yep|sure|okay|ok|please\s+go\s+ahead|go\s+ahead|confirm(?:ed)?|do\s+it|send|schedule\s+it|create\s+it|update\s+it|delete\s+it|no|nope|don['’]?t|do\s+not|cancel|leave\s+it|keep\s+it|never\s+mind|nevermind|stop)\b/ig;
const CONNECTED_ACTION_PENDING_EDIT = /\b(?:change|edit|revise|rewrite|update|adjust|make|add|remove|replace|subject|title|message|body|recipient|recipients|cc|bcc|wording|tone|friendly|friendlier|formal|casual|shorter|longer|fix|correct|say|says|write|put|include|start|end)\b/i;
const CONNECTED_ACTION_CALENDAR_CONTEXT_FOLLOWUP = /\b(?:(?:move|reschedule|shift|change|update|cancel|delete|remove)\s+(?:that|it|the\s+(?:event|meeting|appointment))|(?:make|set)\s+(?:that|it)\s+(?:for\s+)?(?:\d{1,2}(?::\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)?|\d+\s*(?:minutes?|hours?)|today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|(?:add|invite|remove)\s+[A-Za-z][^.!?]{0,80})\b/i;
const CONNECTED_ACTION_CALENDAR_CLARIFICATION_REPLY = /^\s*(?:(?:to|for|at)\s+)?(?:(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|half(?:\s+an?)?)\s*(?:minutes?|mins?|hours?|hrs?)|(?:at\s+)?\d{1,2}(?::\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)|today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|[^\s@]+@[^\s@]+\.[^\s@]+)\s*[.!]?\s*$/i;
const CONNECTED_ACTION_CALENDAR_SELECTION_CLARIFICATION = /^\s*(?:(?:the\s+)?(?:only\s+)?(?:one|meeting|event|appointment)(?:\s+that\s+exists)?(?:\s+(?:with|for|about|called|named|titled)\s+.+)?|(?:the\s+)?(?:only\s+)?(?:one\s+)?with\s+.+|that\s+(?:one|meeting|event|appointment))\s*[.!?]?\s*$/i;
const CONNECTED_ACTION_CALENDAR_INFLIGHT_CONTINUATION = /(?:\btoday\b|\btomorrow\b|\b(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b|\b\d{1,2}(?::\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)(?=\s|[,!.?]|$)|\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|half(?:\s+an?)?)\s*(?:minutes?|mins?|hours?|hrs?)\b|[^\s@]+@[^\s@]+\.[^\s@]+)/i;
const CONNECTED_ACTION_CALENDAR_CONTEXT_TTL_MS = 5 * 60 * 1000;
const CONNECTED_ACTION_CALENDAR_CLARIFICATION_TTL_MS = 2 * 60 * 1000;
const CONNECTED_ACTION_GENERIC_CLARIFICATION_TTL_MS = 2 * 60 * 1000;
const CONNECTED_ACTION_REQUEST_TIMEOUT_MS = 30000;
const COMPUTER_APP_NATURAL_PREFIX = String.raw`\s*(?:(?:(?:actually|well|okay|ok|alright|all\s+right|sorry|wait|hold\s+on|never\s+mind|nevermind|scratch\s+that|instead)\b|jarvis\b)\s*[,.;:—-]*\s*)*(?:(?:and|then)\s*[,;:—-]?\s+)?(?:(?:hey|hi|hello)\s*[,;:—-]?\s+)?(?:jarvis\s*[,;:—-]?\s*)?(?:(?:please|just|actually|really|kindly|maybe|possibly|quickly|also)\s+|go\s+ahead\s+and\s+)*(?:(?:can|could|would|will)\s+you\s+(?:(?:please|just|actually|really|kindly|maybe|possibly|quickly|also)\s+|go\s+ahead\s+and\s+)*|(?:i(?:['’]d|\s+would)\s+like|i\s+(?:need|want))\s+you\s+to\s+(?:(?:please|just|actually|really|kindly|maybe|possibly|quickly|also)\s+|go\s+ahead\s+and\s+)*)?`;
const COMPUTER_APP_LAUNCH_HINT = new RegExp(`^${COMPUTER_APP_NATURAL_PREFIX}(?:open|launch|start|run|pull\\s+up|bring\\s+up|fire\\s+up|load)\\s+(.+?)\\s*[.!?]*\\s*$`, "i");
const COMPUTER_APP_CLOSE_HINT = new RegExp(`^${COMPUTER_APP_NATURAL_PREFIX}(?:close|quit|exit|shut\\s+down|terminate)\\s+(.+?)\\s*[.!?]*\\s*$`, "i");
const BROWSER_DIRECT_URL_HINT = new RegExp(
  `^${COMPUTER_APP_NATURAL_PREFIX}(?:open|go\\s+to|navigate\\s+to|visit|load)\\s+` +
  `((?:(?:https?:\\/\\/|www\\.)?(?:[a-z0-9](?:[a-z0-9-]{0,62})\\.)+[a-z]{2,63}(?::\\d{1,5})?(?:[/?#][^\\s]*)?|localhost(?::\\d{1,5})?(?:[/?#][^\\s]*)?))` +
  `(?:\\s+(?:in|on)\\s+(?:a\\s+)?new\\s+(?:browser\\s+)?tab|\\s+in\\s+(?:the\\s+)?browser)?\\s*[.!?]*\\s*$`,
  "i",
);
const BROWSER_DIRECT_URL_LOCAL_FILE_SUFFIX = /\.(?:txt|md|pdf|docx?|xlsx?|pptx?|csv|json|ya?ml|xml|zip|rar|7z|exe|msi|bat|cmd|ps1|py|jsx?|tsx?|css|html?|jpg|jpeg|png|gif|webp|svg|mp3|wav|flac|mp4|mov|mkv|avi)$/i;
const COMPUTER_APP_ALIAS_HINTS = [
  /^\s*(?:jarvis\s*[,,:-]?\s*)?(?:from\s+now\s+on[, ]*\s*)?(?:(?:i\s+)?(?:want|would\s+like)\s+(?:you\s+)?to\s+)?(?:call|refer\s+to|remember)\s+.+?\s+(?:as|by)\s+.+?\s*[.!?]*\s*$/i,
  /^\s*(?:jarvis\s*[,,:-]?\s*)?.+?\s+is\s+(?:another\s+name|an?\s+alias|my\s+alias)\s+for\s+.+?\s*[.!?]*\s*$/i,
  /^\s*(?:jarvis\s*[,,:-]?\s*)?(?:remember\s+that\s+)?.+?\s+(?:means|should\s+mean)\s+.+?\s*[.!?]*\s*$/i,
];
const COMPUTER_APP_FORGET_ALIAS_HINTS = [
  /^\s*(?:jarvis\s*[,,:-]?\s*)?(?:(?:please\s+)?(?:forget|remove)\s+).+?\s+(?:as\s+)?(?:an?\s+)?(?:nickname|alias|name)\s+for\s+.+?\s*[.!?]*\s*$/i,
  /^\s*(?:jarvis\s*[,,:-]?\s*)?(?:i\s+)?(?:no\s+longer\s+want|don['’]?t\s+want|do\s+not\s+want)\s+.+?\s+(?:as\s+)?(?:an?\s+)?(?:nickname|alias|name)\s+for\s+.+?\s*[.!?]*\s*$/i,
  /^\s*(?:jarvis\s*[,,:-]?\s*)?(?:stop\s+calling|don['’]?t\s+call|do\s+not\s+call)\s+.+?\s+.+?(?:\s+anymore)?\s*[.!?]*\s*$/i,
  /^\s*(?:jarvis\s*[,,:-]?\s*)?.+?\s+is\s+no\s+longer\s+(?:another\s+name|an?\s+alias|a\s+nickname|my\s+alias)\s+for\s+.+?\s*[.!?]*\s*$/i,
];
const COMPUTER_APP_CLARIFICATION_TTL_MS = 2 * 60 * 1000;
const COMPUTER_APP_REQUEST_TIMEOUT_MS = 60000;
const BROWSER_ACTION_EXPLICIT_HINT = /(?:https?:\/\/|\b(?:browser|website|web\s*page|current\s+page|this\s+page|tabs?|links?|url|google|bing|youtube)\b|\b(?:search|look\s+up|find)\b.{0,100}\b(?:web|online|internet|google|bing|youtube)\b|^\s*(?:(?:hey|hi)\s*,?\s*)?(?:jarvis\s*,?\s*)?(?:go\s+back|go\s+forward|refresh(?:\s+the\s+page)?|scroll\s+(?:up|down|to\s+the\s+(?:top|bottom))|open\s+(?:a\s+)?new\s+tab|close\s+(?:this\s+)?tab|switch\s+(?:to\s+)?(?:the\s+)?(?:.+\s+)?tab|(?:pause|resume|unpause|play)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube)\s+)?(?:video|playback)|(?:set|change|turn)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube|browser)\s+)?(?:(?:video|playback)\s+)?volume\s+(?:to\s+)?\d{1,3}\s*(?:%|percent)?)\b)/i;
const BROWSER_ACTION_MEDIA_EXTENDED = /^\s*(?:(?:hey|hi)\s*,?\s*)?(?:jarvis\s*[,,:-]?\s*)?(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?(?:(?:mute|unmute)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube|browser)\s+)?(?:video|playback|audio)|(?:restart|start\s+(?:the\s+)?(?:video|playback)\s+over|go\s+back\s+to\s+the\s+beginning|start\s+(?:the\s+)?(?:video|playback)\s+from\s+the\s+beginning)|(?:skip\s+ahead|jump\s+ahead|go\s+forward|skip\s+forward|rewind|skip\s+back|jump\s+back|go\s+back)\s+\d{1,4}\s*(?:seconds?|secs?|minutes?|mins?)|(?:(?:set|change)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube|browser)\s+)?(?:video\s+|playback\s+)?(?:speed|rate)\s+(?:to\s+)?|play\s+(?:(?:the|this|current)\s+)?(?:video\s+)?at\s+)(?:\d(?:\.\d+)?|normal|half|double)\s*(?:x|times|speed)?|(?:(?:make|put)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube)\s+)?(?:video|player)\s+(?:full\s*screen|fullscreen)|(?:full\s*screen|fullscreen)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube)\s+)?(?:video|player)|(?:exit|leave|close)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube)\s+)?(?:video\s+)?(?:full\s*screen|fullscreen)))\s*[.!?]*\s*$/i;
const BROWSER_ACTION_GENERIC_SEARCH = /^\s*(?:(?:hey|hi)\s*,?\s*)?(?:jarvis\s*,?\s*)?(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?(?:search|look\s+up|find\s+online)\s+(?:the\s+web\s+)?(?:for\s+)?(.+?)\s*[.!?]*\s*$/i;
const BROWSER_ACTION_SEARCH_EXCLUSION = /\b(?:email|gmail|inbox|calendar|schedule|meeting|contact|task|reminder|memory|memories|file|folder|installed\s+app|application)\b/i;
const BROWSER_ACTION_CONTEXT_FOLLOWUP = /^\s*(?:(?:and|then|also|okay|ok|alright|actually|please)\s*[,;:-]?\s*)*(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?(?:open|play|click|choose|select)\s+(?:(?:the\s+)?(?:first|second|third|fourth|fifth|newest|latest|next|previous)\s+(?:one|result|video|link)|that|it|(?:the\s+)?.+?\s+(?:result|video|link|button))|^\s*(?:scroll\s+(?:up|down|more|to\s+the\s+(?:top|bottom)|to\s+.+)|go\s+back|go\s+forward|refresh|read\s+(?:this|that|the)\s+page|what\s+does\s+(?:this|that|the)\s+page\s+say|what(?:'s|\s+is)\s+on\s+(?:this|that|the)\s+page|find\s+(?:the\s+)?.+?(?:\s+(?:section|heading|text)|\s+on\s+(?:this|that|the)\s+page)|click\s+.+|type\s+.+|fill\s+(?:in|out)\s+.+|switch\s+.+\s+tab|close\s+(?:this|that|the)\s+tab|open\s+(?:a\s+)?new\s+tab|(?:pause|resume|unpause)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube)\s+)?(?:video|playback)|(?:set|change|turn)\s+(?:(?:the|this|current)\s+)?(?:(?:youtube|browser)\s+)?(?:(?:video|playback)\s+)?volume\s+(?:to\s+)?\d{1,3}\s*(?:%|percent)?|play\s+.+)\s*[.!?]*\s*$/i;
const BROWSER_ACTION_NATURAL_MEDIA_FOLLOWUP = /^\s*(?:(?:and|then|also|okay|ok|alright|actually|please)\s*[,;:-]?\s*)*(?:(?:can|could|would|will)\s+you\s+)?(?:please\s+)?(?:pause\s+(?:it|this|that)|hold\s+(?:it|this|that)|resume\s+(?:it|this|that)|unpause\s+(?:it|this|that)|keep\s+(?:(?:it|this|that)\s+)?playing|continue(?:\s+playing)?|(?:play|resume|continue)\s+youtube|keep\s+youtube\s+playing|mute\s+(?:it|this|that)|unmute\s+(?:it|this|that)|(?:turn|put|set|make)\s+(?:it|this|that)\s+(?:up|down|at|to)\s+(?:\d{1,3}\s*(?:%|percent)|half|quarter|full|max(?:imum)?|zero)|(?:restart\s+(?:it|this|that)|start\s+(?:it|this|that)\s+over|start\s+over|play\s+(?:it|this|that)\s+from\s+the\s+(?:start|beginning)|go\s+back\s+to\s+the\s+(?:start|beginning))|(?:skip\s+ahead|jump\s+ahead|go\s+forward|move\s+forward|rewind|skip\s+back|jump\s+back|go\s+back|move\s+back)\s+(?:\d{1,4}\s*(?:seconds?|secs?|minutes?|mins?)|(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty)(?:[- ](?:one|two|three|four|five|six|seven|eight|nine))?\s+(?:seconds?|minutes?)|half\s+(?:a\s+)?minute|(?:a|one)\s+minute)|(?:put|set|make|play)\s+(?:it|this|that)\s+(?:back\s+)?(?:to\s+)?(?:normal(?:\s+speed)?|\d(?:\.\d+)?\s*x)|(?:go|make|put|take|get\s+out\s+of|exit|leave)\b.*\b(?:full\s*screen|fullscreen)\b)\s*(?:(?:[,;:-]\s*)?(?:please|thanks|thank\s+you|for\s+me(?:\s+please)?|if\s+you\s+can|if\s+you\s+would|real\s+quick|really\s+quick))?\s*[.!?]*\s*$/i;
const BROWSER_MEDIA_TARGET_HINT = /\b(?:youtube|video|playback|player|media|audio)\b/i;
const BROWSER_MEDIA_ACTION_HINT = /\b(?:pause|pausing|hold|freeze|halt|suspend|stop|resume|resuming|unpause|play|playing|continue|carry\s+on|restart|toggle|mute|unmute|volume|loudness|rewind|skip|jump|seek|speed|rate|full\s*screen|fullscreen|minimi[sz]e|shrink|start\s+over|start\s+(?:it|this|that)\s+over|play\s+(?:it|this|that)\s+from\s+the\s+(?:start|beginning)|go\s+back\s+to\s+the\s+(?:start|beginning))\b/i;
const BROWSER_MEDIA_PRONOUN_HINT = /\b(?:it|this|that)\b/i;
const BROWSER_ACTION_CONFIRMATION = /^\s*(?:(?:yes|yeah|yep|sure|okay|ok|confirmed?|absolutely)(?:\s*[,;:-]?\s*(?:go\s+ahead|do\s+it|submit\s+it|send\s+it|post\s+it|publish\s+it|buy\s+it|purchase\s+it|pay|place\s+the\s+order|book\s+it|reserve\s+it|delete\s+it|remove\s+it))?|go\s+ahead|do\s+it|submit\s+it|send\s+it|post\s+it|publish\s+it|buy\s+it|purchase\s+it|pay|place\s+the\s+order|book\s+it|reserve\s+it|delete\s+it|remove\s+it|(?:no|nope|cancel|stop|never\s*mind|nevermind|don['’]?t|do\s+not|leave\s+it)(?:\s*[,;:-]?\s*(?:cancel\s+it|stop|please|thanks?))?)(?:\s*[,;:-]?\s*please)?[.!]*\s*$/i;
const BROWSER_ACTION_CONTEXT_TTL_MS = 5 * 60 * 1000;
const BROWSER_ACTION_REQUEST_TIMEOUT_MS = 180000;
const WEB_INTELLIGENCE_RESEARCH_HINT = /(?:\b(?:search(?:\s+the\s+web)?|look\s+up|research|investigate|compare)\b|\bfind\b.{0,140}\b(?:latest|newest|current|recent|official|updates?|news|releases?|drivers?|prices?|best|source|information)\b|\b(?:latest|newest|current|recent)\b.{0,120}\b(?:updates?|news|drivers?|releases?|prices?|versions?|status|information)\b|\bwhat\s+(?:changed|happened)\b|\bwhat(?:'s|\s+is)\s+new\b|\b(?:today|this\s+week|right\s+now)\b.{0,100}\b(?:news|updates?|prices?|status)\b)/i;
const WEB_INTELLIGENCE_GENERIC_RESEARCH = /^\s*(?:(?:hey|hi)\s*,?\s*)?(?:jarvis\s*[,,:-]?\s*)?(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?(?:search(?:\s+the\s+web)?|look\s+up|research|investigate|compare|find)\b/i;
const WEB_INTELLIGENCE_LOCAL_EXCLUSION = /\b(?:email|gmail|inbox|calendar|schedule|meeting|contact|task|reminder|memory|memories|file|folder|installed\s+app|application|program|voice\s+profile)\b/i;
const WEB_INTELLIGENCE_BROWSER_CONTROL = /(?:https?:\/\/|\b(?:current\s+page|this\s+page|that\s+page|click|scroll|go\s+back|go\s+forward|refresh|switch\s+tabs?|close\s+(?:this\s+)?tab|fill\s+(?:in|out)|type\s+into|play\s+(?:the|this|a)|pause\s+(?:the|this)|resume\s+(?:the|this)|unpause\s+(?:the|this)|(?:youtube|browser|video|playback)\s+volume)\b|\bopen\s+(?:a\s+)?new\s+tab\b|\bopen\s+(?:edge|chrome|google|youtube)\b|\b(?:search|look\s+up|find)\b.{0,70}\b(?:on|in|using)\s+(?:google|bing|youtube)\b)/i;
const WEB_INTELLIGENCE_PAGE_FIND = /\bfind\b.{0,100}\b(?:on\s+(?:this|that|the)\s+page|section|heading|button|link|field)\b/i;
const WEB_INTELLIGENCE_REQUEST_TIMEOUT_MS = 150000;
const WEB_INTELLIGENCE_SOURCE_CONTEXT_TTL_MS = 10 * 60 * 1000;
const WEB_INTELLIGENCE_SOURCE_FOLLOWUP = /\b(?:open|show|view|take\s+me\s+to|go\s+to)\b.{0,80}\b(?:source|result|page|site|website|link|it|that)\b|\b(?:open|show|view)\s+(?:it|that)\b/i;
const DEDICATED_SPEECH_SYNTHESIS_TIMEOUT_MS = 20000;
const DEDICATED_SPEECH_PLAYBACK_MIN_TIMEOUT_MS = 15000;
const DEDICATED_SPEECH_PLAYBACK_MAX_TIMEOUT_MS = 180000;
const LOCAL_CURRENT_TIME_HINT = /^\s*(?:what\s+time\s+is\s+it|what(?:'s|\s+is)\s+the\s+(?:current\s+)?time|tell\s+me\s+the\s+(?:current\s+)?time|current\s+time|time\s+right\s+now)\s*[?!.]*\s*$/i;
const LOCAL_CURRENT_DATE_HINT = /^\s*(?:what(?:'s|\s+is)\s+(?:today(?:'s)?\s+date|the\s+date(?:\s+today)?)|what\s+(?:day|date)\s+is\s+it(?:\s+today)?|what\s+day\s+is\s+today|today(?:'s)?\s+date)\s*[?!.]*\s*$/i;

let config = null;
let activeRealtimeProfile = null;
let peer = null;
let channel = null;
let realtimeControlHeartbeatTimer = null;
let localStream = null;
let connectPromise = null;
let handshakeAbort = null;
let reconnectTimer = null;
let stableConnectionTimer = null;
let sessionWarningTimer = null;
let sessionTimeoutTimer = null;
let sessionClockTimer = null;
let idleTimer = null;
let sessionStartedAt = 0;
let connectionEpoch = 0;
let autoReconnectAttempts = 0;
let intentionalSleep = true;
let muted = false;
let providerEventSequence = 0;
let connectStartedAt = 0;
let speechStartedAt = 0;
let speechStoppedAt = 0;
let responseCreatedAt = 0;
let firstAudioAt = 0;
let responseActive = false;
let awaitingFirstAudibleAudio = false;
let dedicatedSpeechAudio = null;
let dedicatedSpeechObjectUrl = "";
let dedicatedSpeechAbortController = null;
let dedicatedSpeechResponseId = "";
let dedicatedSpeechPurpose = "";
let dedicatedSpeechBubble = null;
let dedicatedSpeechStartedAt = 0;
let dedicatedSpeechPlaybackResolve = null;
let interruptions = 0;
let activeResponseId = "";
let activeJarvisBubble = null;
let pendingDetailedCompanion = null;
let activeMessageReaderBubble = null;
let messageReaderPreviousFocus = null;
let detailedCompanionInProgress = false;
let pendingTestAutoSleepAfterDetail = false;
let connectedActionPending = false;
let connectedActionRequestInFlight = false;
let connectedActionRequestPromise = null;
let connectedActionRequestKey = "";
let connectedActionRequestRoute = "";
let connectedActionVoiceOwnerUntil = 0;
let connectedActionExpectedResponseToken = "";
let connectedActionAuthorizedResponseId = "";
const connectedActionSupersededRequestKeys = new Set();
let recentCalendarContextUntil = 0;
let recentCalendarClarificationUntil = 0;
let recentConnectedActionClarificationUntil = 0;
let recentConnectedActionClarificationRoute = "";
let recentTaskContextUntil = 0;
let connectedActionContextSpeakerKey = "";
let connectedActionContextSessionId = "";
let connectedActionContextOwnerAttributed = false;
let recentComputerAppClarificationUntil = 0;
let computerAppRequestInFlight = false;
let recentBrowserContextUntil = 0;
let browserActionPendingConfirmation = false;
let trustedPermissionPrompt = null;
let browserActionRequestInFlight = false;
let browserActionRequestId = "";
let browserActionAbortController = null;
let webResearchRequestInFlight = false;
let webResearchRequestId = "";
let webResearchAbortController = null;
let recentWebResultId = "";
let recentWebSources = [];
let recentWebContextUntil = 0;
let recentTaskFocusTerms = new Set();
let recentTaskFocusItems = [];
let taskReminderPollTimer = null;
let gameModePollTimer = null;
const surfacedReminderIds = new Set();
const recentConnectedActionSpeech = new Map();
let connectedMicroConfirmationSequence = 0;
let lastConnectedMicroConfirmationAt = 0;
let googleConnectionPollTimer = null;
const responseBubblesById = new Map();
const responsePurposesById = new Map();
const pendingResponsePurposes = [];
const responseItemOwners = new Map();
const interruptedResponseIds = new Set();
const authoritativeSpeechResponseIds = new Set();
let interruptedAudioMuteOwnerResponseId = "";
let activeUserBubble = null;
// Natural interruption epoch: every new microphone speech turn invalidates any
// asynchronous speech script that belongs to an older user turn. This prevents
// a cancelled Jarvis reply from restarting after the user has already barged in.
let voiceTurnEpoch = 0;
let voiceBargeInTimer = null;
let voiceBargeInEpoch = 0;
let pendingVoiceTranscriptTurns = [];
const renderedVoiceTranscriptItemIds = new Set();
const recentVoiceTranscriptSignatures = new Map();
let pendingTypedMessages = [];
let typedSubmitInProgress = false;
let audioContext = null;
let speakerCaptureContext = null;
let speakerCaptureSource = null;
let speakerCaptureProcessor = null;
let speakerCaptureSink = null;
let speakerCaptureFrames = [];
let speakerCaptureActive = false;
let pendingSpeakerRecognition = null;
let latestSpeakerRecognition = null;
let wakeSpeakerRecognition = null;
let pendingVoiceEnrollmentOffer = null;
let pendingSpeakerOnboarding = null;
const manuallyRespondedVoiceItems = new Set();
let remoteAnalyser = null;
let remoteSamples = null;
let analyserFrame = null;
let wakeRecognition = null;
let wakeListeningArmed = false;
let wakeDetectionTriggered = false;
let wakeCandidateText = "";
let wakeFinalizeTimer = null;
let wakePromptDispatchTimer = null;
let wakePromptDispatchStartedAt = 0;
let queuedWakePrompt = "";
let queuedWakeAcknowledgement = false;
let queuedWakeMemoryRecorded = false;
let wakeAcknowledgementExpected = false;
let wakeAcknowledgementDispatching = false;
let wakeAcknowledgementResponseId = "";
const rememberedProviderMemoryIds = new Set();
let memoryLoadInFlight = null;
let memoryExplorerMode = "timeline";
let voiceProfilesCache = [];
let voicePeopleCache = [];
let voiceEnrollmentPrompts = [
  {id: "balanced-1", text: "Jarvis, remember my voice clearly whenever we talk together."},
  {id: "balanced-2", text: "Bright morning sunlight moved quickly across the quiet blue water."},
  {id: "balanced-3", text: "Seven curious people shared warm coffee, fresh bread, and good stories."},
];
let voiceRecommendedSamples = 3;
let activeWorkspaceView = "home";
let memoryNavigationHoldUntil = 0;
let memoryNavigationGuardTimer = null;
let lastMemoryNavigationSignature = "";
let lastMemoryNavigationAt = 0;
let lastMemoryNavigationPromise = Promise.resolve(null);
let memoryNarrationRequestSerial = 0;
let proactiveRefreshTimer = null;
let proactivePollTimer = null;
let lastAssistantMemoryText = "";
let lastAssistantMemoryAt = 0;
let latestRelevantProactiveItems = [];
let visualOnlyResponseSuppression = null;
let visualOnlyResponseSuppressionTimer = null;
let wakeInputGateActive = false;
let wakePromptResponsePending = false;
let wakeOpeningResponseDone = false;
let wakeOpeningAudioObserved = false;
let wakeInputGateTimer = null;
let wakeNoAudioReleaseTimer = null;
let lastActivityAt = 0;
let idleWarningSent = false;
let userSpeakingTotalMs = 0;
let jarvisSpeakingTotalMs = 0;
let jarvisSpeakingStartedAt = 0;
let remoteAudioActive = false;
let lastRemoteSignalAt = 0;
let responseCount = 0;
let sessionCostUsd = 0;
let latestResponseCostUsd = 0;
let usageSummary = null;
let budgetState = null;
let lastUsageSummaryAt = 0;
let clientSessionId = "";
let simulationConnected = false;
let simulationResponseTimer = null;
let simulationResponseId = 0;
let testAutoSleepPending = false;
let lifecycleRecognition = null;
let lifecycleListeningArmed = false;
let lifecycleSleepTriggered = false;
let sleepSequenceActive = false;
let sleepAcknowledgementPending = false;
let sleepAcknowledgementResponseDone = false;
let sleepAcknowledgementAudioObserved = false;
let sleepAcknowledgementBufferStarted = false;
let sleepAcknowledgementBufferStopped = false;
let sleepAcknowledgementTimer = null;
let sleepAcknowledgementPlaybackTimer = null;
let sleepAcknowledgementAudioStartedAt = 0;
let sleepAcknowledgementLastSignalAt = 0;
let sleepAcknowledgementResponseId = "";
let sleepAcknowledgementRequestEventId = "";
let sleepAcknowledgementAwaitingResponseCreated = false;
let sleepAcknowledgementResponseCreatedAt = 0;
let sleepAcknowledgementProviderStoppedAt = 0;
let sleepShutdownInProgress = false;
let sleepIntentStartedAt = 0;
let sleepAcknowledgementStartedAt = 0;
const handledSleepToolCallIds = new Set();
let modelWakeStream = null;
let modelWakeContext = null;
let modelWakeSource = null;
let modelWakeProcessor = null;
let modelWakeSilentGain = null;
let modelWakeInFlight = false;
let modelWakeSpeechActive = false;
let modelWakeFrames = [];
let modelWakePreroll = [];
let modelWakePrerollSamples = 0;
let modelWakeCapturedSamples = 0;
let modelWakeLastSignalAt = 0;
let modelWakeSampleRate = 48000;
let modelWakeNoiseFloor = 0;
let modelWakeCalibrationStartedAt = 0;
let modelWakeConsecutiveSignalFrames = 0;
let modelWakeVoicedSamples = 0;
let modelWakePeakRms = 0;
let modelWakeEffectiveThreshold = 0;
let modelWakeRememberedNoiseFloor = 0;
let wakeHandoffStream = null;
let speculativeWakeActive = false;
let speculativeWakeAccepted = false;
let speculativeWakeConnectPromise = null;
let speculativeWakePresentation = null;
let speculativeWakeActivation = null;
let wakeSpeechEndedAt = 0;
let wakeTranscriptionCompletedAt = 0;
let wakePreconnectReadyAt = 0;
let wakeFirstAudioObservedAt = 0;
let desktopPresence = null;
let presenceUiTimer = null;
let renderedStatusKind = "unknown";
let renderedStatusLabel = "";
let wakeVisualHoldUntil = 0;
let pendingVisualStatus = null;
let visualStatusTimer = null;
let visualStateAnimationTimer = null;
let transcriptStickToBottom = true;
let alphaSetupStatus = null;
let pendingReleaseUrl = "";

function interfaceStateCopy(kind, label) {
  const copy = {
    sleeping: ["Sleeping", "Say “Jarvis” whenever you need me."],
    waking: ["Waking", "Opening the secure voice path."],
    connecting: ["Connecting", "Preparing the Realtime session."],
    listening: ["Listening", "I’m listening."],
    awake: ["Ready", "The voice session is active."],
    thinking: ["Thinking", "Working on your request."],
    speaking: ["Speaking", "Responding now."],
    degraded: ["Attention needed", "Jarvis is recovering from a service issue."],
    error: ["Core unavailable", "Open System for diagnostics."],
  };
  return copy[kind] || [label || "Jarvis", "Voice core state updated."];
}

function syncInterfaceSummary() {
  if (ui.quickAwakeMetric && ui.awakeMetric) ui.quickAwakeMetric.textContent = ui.awakeMetric.textContent;
  if (ui.quickConnectedMetric && ui.connectedMetric) ui.quickConnectedMetric.textContent = ui.connectedMetric.textContent;
  if (ui.quickSessionCostMetric && ui.sessionCostMetric) ui.quickSessionCostMetric.textContent = ui.sessionCostMetric.textContent;
  if (ui.quickWakeMetric && ui.wakeFirstAudioMetric) ui.quickWakeMetric.textContent = ui.wakeFirstAudioMetric.textContent;
  if (ui.homeBudgetStatus && ui.budgetStatus) ui.homeBudgetStatus.textContent = ui.budgetStatus.textContent;
  if (ui.homeBudgetDetail && ui.sessionCostMetric) ui.homeBudgetDetail.textContent = `Current session ${ui.sessionCostMetric.textContent}`;
}

function desktopStateFor(kind) {
  return kind === "sleeping" ? "sleeping"
    : (["listening", "speaking", "thinking", "waking", "connecting"].includes(kind) ? "awake" : kind || "unknown");
}

function clearPendingVisualStatus() {
  clearTimeout(visualStatusTimer);
  visualStatusTimer = null;
  pendingVisualStatus = null;
}

function animateVisualStateChange() {
  clearTimeout(visualStateAnimationTimer);
  document.documentElement.classList.remove("jarvis-state-transitioning");
  ui.jarvisOrb?.classList.remove("state-transitioning");
  ui.orbStateTitle?.parentElement?.classList.remove("state-transitioning");
  // Force a style flush so repeated state changes restart the settling animation.
  void document.documentElement.offsetWidth;
  document.documentElement.classList.add("jarvis-state-transitioning");
  ui.jarvisOrb?.classList.add("state-transitioning");
  ui.orbStateTitle?.parentElement?.classList.add("state-transitioning");
  visualStateAnimationTimer = window.setTimeout(() => {
    document.documentElement.classList.remove("jarvis-state-transitioning");
    ui.jarvisOrb?.classList.remove("state-transitioning");
    ui.orbStateTitle?.parentElement?.classList.remove("state-transitioning");
  }, ORB_STATE_ANIMATION_MS);
}

function commitVisualStatus(label, kind) {
  const normalizedKind = kind || "unknown";
  const stateChanged = renderedStatusKind !== normalizedKind;
  renderedStatusKind = normalizedKind;
  renderedStatusLabel = label;
  ui.statusText.textContent = label;
  ui.statusDot.className = `dot ${normalizedKind}`.trim();
  document.documentElement.dataset.jarvisState = normalizedKind;
  if (ui.jarvisOrb) ui.jarvisOrb.dataset.state = normalizedKind;
  const [title, detail] = interfaceStateCopy(normalizedKind, label);
  if (ui.orbStateTitle) ui.orbStateTitle.textContent = title;
  if (ui.orbStateDetail) ui.orbStateDetail.textContent = detail;
  if (stateChanged) animateVisualStateChange();
  syncInterfaceSummary();
}

function visualTransitionDelay(currentKind, nextKind, immediate) {
  // A speculative wake can finish its WebRTC handshake before the confirmed
  // wake event reaches the renderer. Keep the Waking state visible long enough
  // to actually paint, without delaying the underlying connection or routing.
  if (
    currentKind === "waking"
    && nextKind !== "waking"
    && !["sleeping", "error", "degraded"].includes(nextKind)
  ) {
    const remainingWakeVisualMs = Math.max(0, wakeVisualHoldUntil - performance.now());
    if (remainingWakeVisualMs > 0) return remainingWakeVisualMs;
  }
  if (immediate || currentKind === "unknown" || currentKind === nextKind) return 0;
  if (["sleeping", "error", "degraded", "waking", "connecting", "speaking"].includes(nextKind)) return 0;
  if (currentKind === "speaking" && ["listening", "awake", "thinking"].includes(nextKind)) {
    return ORB_SPEAKING_RELEASE_MS;
  }
  if (currentKind === "thinking" && nextKind === "listening") return ORB_TRANSIENT_RELEASE_MS;
  return 0;
}

function setStatus(label, kind = "", {immediate = false} = {}) {
  const normalizedKind = kind || "unknown";
  window.jarvisDesktop?.setState?.(desktopStateFor(normalizedKind));

  if (normalizedKind === renderedStatusKind) {
    if (pendingVisualStatus && pendingVisualStatus.kind !== normalizedKind) clearPendingVisualStatus();
    if (renderedStatusLabel !== label) commitVisualStatus(label, normalizedKind);
    return;
  }

  if (pendingVisualStatus?.kind === normalizedKind) {
    pendingVisualStatus.label = label;
    return;
  }

  clearPendingVisualStatus();
  const delay = visualTransitionDelay(renderedStatusKind, normalizedKind, immediate);
  if (!delay) {
    commitVisualStatus(label, normalizedKind);
    return;
  }

  pendingVisualStatus = {label, kind: normalizedKind};
  visualStatusTimer = window.setTimeout(() => {
    const pending = pendingVisualStatus;
    clearPendingVisualStatus();
    if (pending) commitVisualStatus(pending.label, pending.kind);
  }, delay);
}

function loadInterfaceState() {
  try { return JSON.parse(localStorage.getItem(INTERFACE_STATE_KEY) || "{}"); } catch (_) { return {}; }
}

function saveInterfaceState(state) {
  localStorage.setItem(INTERFACE_STATE_KEY, JSON.stringify(state));
}

function setActiveWorkspaceView(view, {persist = true, force = false} = {}) {
  const allowed = new Set(["home", "controls", "tasks", "insights", "memory", "account", "system"]);
  const selected = allowed.has(view) ? view : "home";
  if (!force && selected !== "memory" && Date.now() < memoryNavigationHoldUntil) return activeWorkspaceView;
  const changed = activeWorkspaceView !== selected;
  activeWorkspaceView = selected;
  document.body.dataset.activeWorkspace = selected;
  document.documentElement.dataset.activeWorkspace = selected;
  document.querySelectorAll("[data-workspace-view]").forEach((button) => {
    const active = button.dataset.workspaceView === selected;
    button.classList.toggle("active", active);
    button.setAttribute("aria-current", active ? "page" : "false");
    button.setAttribute("aria-pressed", active ? "true" : "false");
  });
  document.querySelectorAll(".workspace-view").forEach((section) => {
    const active = section.dataset.view === selected;
    section.classList.toggle("active", active);
    section.hidden = !active;
    section.inert = !active;
    section.setAttribute("aria-hidden", active ? "false" : "true");
    section.style.setProperty("display", active ? "block" : "none", "important");
  });
  if (persist) {
    const state = loadInterfaceState();
    saveInterfaceState({...state, activeView: selected});
  }
  if (selected === "tasks" && changed) {
    void loadTaskDashboard();
  }
  if (selected === "controls" && changed) {
    void loadPermissions();
  }
  if (selected === "memory" && changed) {
    void loadMemoryDashboard();
    if (memoryExplorerMode === "entities") void loadMemoryEntities();
    if (memoryExplorerMode === "people") void loadMemoryPeople();
    if (memoryExplorerMode === "voices") void loadVoiceProfiles();
    if (memoryExplorerMode === "apps") void loadMemoryApps();
    if (memoryExplorerMode === "summary") void loadMemorySummary();
    if (memoryExplorerMode === "consolidation") void loadMemoryConsolidation();
    if (memoryExplorerMode === "proactive") void loadMemoryProactive();
  }
  return selected;
}

function forceMemoryWorkspaceVisible(reason = "memory_navigation") {
  memoryNavigationHoldUntil = Date.now() + MEMORY_NAVIGATION_HOLD_MS;
  setConversationFocus(false, {persist: false});
  document.body.classList.remove("focus-mode");
  const verify = () => setActiveWorkspaceView("memory", {force: true});
  verify();
  document.querySelector('.workspace-view[data-view="memory"]')?.scrollIntoView({block: "start", behavior: "auto"});
  if (memoryNavigationGuardTimer) window.clearInterval(memoryNavigationGuardTimer);
  memoryNavigationGuardTimer = window.setInterval(() => {
    if (Date.now() >= memoryNavigationHoldUntil) {
      window.clearInterval(memoryNavigationGuardTimer);
      memoryNavigationGuardTimer = null;
      return;
    }
    verify();
  }, 125);
  logEvent("memory.navigation.workspace_forced", reason);
}

function setConversationFocus(enabled, {persist = true} = {}) {
  document.body.classList.toggle("focus-mode", Boolean(enabled));
  ui.interfaceFocusToggle?.setAttribute("aria-pressed", enabled ? "true" : "false");
  if (ui.interfaceFocusToggle) ui.interfaceFocusToggle.querySelector(".nav-label").textContent = enabled ? "Exit" : "Focus";
  if (persist) {
    const state = loadInterfaceState();
    saveInterfaceState({...state, focusMode: Boolean(enabled)});
  }
  window.requestAnimationFrame(resizeLongAnswerPreviews);
}

function setRailCollapsed(collapsed, {persist = true} = {}) {
  const active = Boolean(collapsed);
  document.body.classList.toggle("rail-collapsed", active);
  ui.interfaceRailToggle?.setAttribute("aria-pressed", active ? "true" : "false");
  ui.interfaceRailToggle?.setAttribute("aria-label", active ? "Expand navigation" : "Collapse navigation");
  ui.interfaceRailToggle?.setAttribute("title", active ? "Expand navigation" : "Collapse navigation");
  if (persist) {
    const state = loadInterfaceState();
    saveInterfaceState({...state, railCollapsed: active});
  }
  window.requestAnimationFrame(resizeLongAnswerPreviews);
}

function setHomeLayout(layout, {persist = true} = {}) {
  const allowed = new Set(["conversation", "balanced", "presence"]);
  const selected = allowed.has(layout) ? layout : "conversation";
  document.documentElement.dataset.homeLayout = selected;
  document.querySelectorAll("[data-home-layout-option]").forEach((button) => {
    const active = button.dataset.homeLayoutOption === selected;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", active ? "true" : "false");
  });
  if (persist) {
    const state = loadInterfaceState();
    saveInterfaceState({...state, homeLayout: selected});
  }
  window.requestAnimationFrame(resizeLongAnswerPreviews);
}

function isTranscriptNearBottom() {
  if (!ui.transcript) return true;
  return ui.transcript.scrollHeight - ui.transcript.scrollTop - ui.transcript.clientHeight <= TRANSCRIPT_BOTTOM_THRESHOLD_PX;
}

function updateJumpLatestVisibility() {
  if (!ui.conversationJumpLatest) return;
  ui.conversationJumpLatest.hidden = transcriptStickToBottom || isTranscriptNearBottom();
}

function scrollTranscriptToLatest({force = false, behavior = "smooth"} = {}) {
  if (!ui.transcript) return;
  if (!force && !transcriptStickToBottom) {
    updateJumpLatestVisibility();
    return;
  }
  transcriptStickToBottom = true;
  window.requestAnimationFrame(() => {
    ui.transcript.scrollTo({top: ui.transcript.scrollHeight, behavior});
    updateJumpLatestVisibility();
  });
}

function resizeComposer() {
  if (!ui.textInput) return;
  ui.textInput.style.height = "auto";
  ui.textInput.style.height = `${Math.min(ui.textInput.scrollHeight, COMPOSER_MAX_HEIGHT_PX)}px`;
}

function initializeInterfaceFoundation() {
  const state = loadInterfaceState();
  setActiveWorkspaceView(state.activeView || "home", {persist: false, force: true});
  setConversationFocus(Boolean(state.focusMode), {persist: false});
  setRailCollapsed(Boolean(state.railCollapsed), {persist: false});
  setHomeLayout(state.homeLayout || "conversation", {persist: false});
  document.querySelectorAll("[data-workspace-view]").forEach((button) => {
    button.addEventListener("click", () => {
      setConversationFocus(false);
      setActiveWorkspaceView(button.dataset.workspaceView, {force: true});
    });
  });
  document.querySelectorAll("[data-home-layout-option]").forEach((button) => {
    button.addEventListener("click", () => setHomeLayout(button.dataset.homeLayoutOption));
  });
  ui.interfaceRailToggle?.addEventListener("click", () => {
    setRailCollapsed(!document.body.classList.contains("rail-collapsed"));
  });
  ui.interfaceFocusToggle?.addEventListener("click", () => {
    setActiveWorkspaceView("home", {force: true});
    setConversationFocus(!document.body.classList.contains("focus-mode"));
  });
  ui.conversationJumpLatest?.addEventListener("click", () => scrollTranscriptToLatest({force: true}));
  ui.transcript?.addEventListener("scroll", () => {
    transcriptStickToBottom = isTranscriptNearBottom();
    updateJumpLatestVisibility();
  }, {passive: true});
  window.addEventListener("resize", resizeLongAnswerPreviews, {passive: true});
  ui.textInput?.addEventListener("input", resizeComposer);
  ui.textInput?.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      ui.textForm?.requestSubmit();
    }
  });
  ui.orbWake?.addEventListener("click", () => ui.wake.click());
  ui.orbSleep?.addEventListener("click", () => ui.sleep.click());
  ui.orbStop?.addEventListener("click", () => ui.stopSpeaking.click());
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && ui.messageReaderOverlay && !ui.messageReaderOverlay.hidden) {
      event.preventDefault();
      closeMessageReader();
      return;
    }
    if (event.key === "Escape" && document.body.classList.contains("focus-mode")) setConversationFocus(false);
    if (event.ctrlKey && !event.shiftKey && ["1", "2", "3", "4", "5", "6"].includes(event.key)) {
      event.preventDefault();
      setConversationFocus(false);
      setActiveWorkspaceView({"1": "home", "2": "controls", "3": "tasks", "4": "insights", "5": "memory", "6": "system"}[event.key], {force: true});
    }
    if (event.ctrlKey && event.shiftKey && event.key.toLowerCase() === "f") {
      event.preventDefault();
      setActiveWorkspaceView("home");
      setConversationFocus(!document.body.classList.contains("focus-mode"));
    }
  });
  const observer = new MutationObserver(syncInterfaceSummary);
  [ui.wakeFirstAudioMetric, ui.sessionCostMetric, ui.awakeMetric, ui.connectedMetric, ui.budgetStatus]
    .filter(Boolean).forEach((node) => observer.observe(node, {childList: true, characterData: true, subtree: true}));
  resizeComposer();
  syncInterfaceSummary();
}

function logEvent(type, detail = "") {
  if (ui.events.textContent === "Waiting for a session…") ui.events.textContent = "";
  const stamp = new Date().toLocaleTimeString();
  ui.events.textContent += `[${stamp}] ${type}${detail ? ` — ${detail}` : ""}\n`;
  ui.events.scrollTop = ui.events.scrollHeight;
}

async function relayEvent(type, payload = {}) {
  try {
    await fetch("/api/events", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify({type, payload}),
    });
  } catch (_) {
    // Diagnostics must never break the active WebRTC session.
  }
}

function localIsoTimestamp(date = new Date()) {
  const pad = (value, width = 2) => String(value).padStart(width, "0");
  const offsetMinutes = -date.getTimezoneOffset();
  const sign = offsetMinutes >= 0 ? "+" : "-";
  const absolute = Math.abs(offsetMinutes);
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
    + `T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}.${pad(date.getMilliseconds(), 3)}`
    + `${sign}${pad(Math.floor(absolute / 60))}:${pad(absolute % 60)}`;
}

function memorySourceEventId(prefix, event = {}) {
  const providerId = event.item_id || event.item?.id || event.response_id || event.response?.id || event.event_id || "";
  return providerId ? `${prefix}:${providerId}` : `${prefix}:${clientSessionId || "local"}:${Date.now()}:${providerEventSequence}`;
}

function normalizeSpokenCorrectionName(value) {
  const cleaned = String(value || "").trim().replace(/[.!?]+$/, "").replace(/\s+/g, " ");
  const parts = cleaned.split(" ");
  if (parts.length === 2 && /^(?:lee|leigh|ley|ly)$/i.test(parts[1]) && /^[A-Za-z][A-Za-z'-]{1,11}$/.test(parts[0])) {
    return `${parts[0][0].toUpperCase()}${parts[0].slice(1).toLowerCase()}ley`;
  }
  return cleaned;
}

function recentAssistantCorrectionTarget() {
  if (!lastAssistantMemoryText || Date.now() - lastAssistantMemoryAt > 90000) return null;
  const matches = [...lastAssistantMemoryText.matchAll(/\b(?:with|to|from|called|named)\s+([A-Z][A-Za-z'-]{1,40})\b/g)];
  return matches.length ? matches[matches.length - 1][1] : null;
}

function inferMemoryClassification(content, source, requestedKind, metadata = {}) {
  if (source === "assistant" || requestedKind !== "utterance") return {kind: requestedKind, metadata};
  const text = String(content || "").trim();
  const normalized = text.toLowerCase().replace(/[’]/g, "'");
  const correctionContextPresent = /\b(?:actually|sorry|correction|no)\b/i.test(text);
  const contextualCorrection = correctionContextPresent
    ? text.match(/\bi\s+(?:actually\s+)?(?:meant|met)\s+([A-Za-z][A-Za-z'-]{1,40}(?:\s+[A-Za-z][A-Za-z'-]{1,40}){0,2})(?:[.!?]|$)/i)
    : null;
  const contextualOld = contextualCorrection ? recentAssistantCorrectionTarget() : null;
  if (contextualCorrection && contextualOld) {
    return {
      kind: "correction",
      metadata: {
        ...metadata,
        inferred_memory_kind: "correction",
        correction_old: contextualOld,
        correction_new: normalizeSpokenCorrectionName(contextualCorrection[1]),
        correction_context: lastAssistantMemoryText.slice(0, 500),
        correction_detection: "contextual_stt_homophone",
      },
    };
  }
  const correctionCue = /\b(?:correction|i said|i meant|i corrected(?: it| him| her| that)? to|changed?(?: it| that)? to|actually|no[,;:]?\s+it(?:'s| is)|not [a-z][a-z'-]{1,40}[,;:-]|[a-z][a-z'-]{1,40}\s+not\s+[a-z][a-z'-]{1,40})\b/i.test(text);
  if (correctionCue) return {kind: "correction", metadata: {...metadata, inferred_memory_kind: "correction"}};

  const standaloneName = text.replace(/[.!?]+$/, "").match(/^[A-Za-z][A-Za-z'-]{1,40}$/);
  const recentAssistant = lastAssistantMemoryText && Date.now() - lastAssistantMemoryAt <= 90000;
  if (standaloneName && recentAssistant) {
    const oldName = recentAssistantCorrectionTarget();
    const blocked = new Set(["okay", "thanks", "thank", "yes", "no", "right", "correct", "got", "sure"]);
    const correctedName = normalizeSpokenCorrectionName(standaloneName[0]);
    if (oldName && !blocked.has(correctedName.toLowerCase()) && oldName.toLowerCase() !== correctedName.toLowerCase()) {
      return {
        kind: "correction",
        metadata: {
          ...metadata,
          inferred_memory_kind: "correction",
          correction_old: oldName,
          correction_new: correctedName,
          correction_context: lastAssistantMemoryText.slice(0, 500),
        },
      };
    }
  }
  if (/\b(?:i|we)\s+(?:need|have|must|plan|intend)\s+to\b/i.test(text) || /\bremind me to\b/i.test(text)) {
    return {kind: "commitment", metadata: {...metadata, inferred_memory_kind: "commitment"}};
  }
  if (/\bmy goal is to\b/i.test(text)) return {kind: "plan", metadata: {...metadata, inferred_memory_kind: "plan"}};
  return {kind: requestedKind, metadata};
}

async function rememberMemory({
  content,
  source = "typed",
  kind = "utterance",
  actor = null,
  sourceEventId = null,
  occurredAt = null,
  categoryPath = null,
  confidence = 1,
  metadata = {},
} = {}) {
  const normalized = normalizeNaturalText(content || "");
  if (!normalized || config?.memory_enabled === false) return null;
  const classification = inferMemoryClassification(normalized, source, kind, metadata);
  const body = {
    content: normalized,
    source,
    kind: classification.kind,
    actor: actor || (source === "assistant" ? "Jarvis" : (config?.local_user_name || "Local User")),
    occurred_at: occurredAt || localIsoTimestamp(),
    timezone_name: Intl.DateTimeFormat().resolvedOptions().timeZone || "local",
    session_id: clientSessionId || null,
    source_event_id: sourceEventId || null,
    confidence,
    metadata: {
      response_mode: ui.responseMode?.value || config?.default_response_mode || "normal",
      connection_mode: ui.connectionMode?.value || "live",
      ...classification.metadata,
    },
  };
  if (Array.isArray(categoryPath) && categoryPath.length) body.category_path = categoryPath;
  try {
    const response = await fetch("/api/memory/events", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify(body),
    });
    if (!response.ok) {
      let detail = `Memory write failed (${response.status})`;
      try { detail = (await response.json()).detail || detail; } catch (_) {}
      throw new Error(detail);
    }
    const payload = await response.json();
    renderMemoryStats(payload.stats || {});
    if (document.querySelector('[data-view="memory"]')?.classList.contains("active")) {
      window.setTimeout(() => loadMemoryDashboard(), 80);
    }
    if (source !== "assistant") scheduleProactiveRefresh(normalized);
    return payload.memory || null;
  } catch (error) {
    logEvent("memory.write.failed", error.message);
    if (ui.memoryStatus) ui.memoryStatus.textContent = `Memory write failed: ${error.message}`;
    return null;
  }
}

async function rememberRecognizedVoiceMemory({content, sourceEventId, providerEvent, providerItemId}) {
  const recognition = await resolveSpeakerForMemory();
  let actor = "Unknown speaker";
  if (isAttributedSpeaker(recognition) && recognition.person_name) actor = recognition.person_name;
  const metadata = {
    provider_event: providerEvent,
    provider_item_id: providerItemId || null,
  };
  if (recognition) {
    metadata.speaker_recognition = {
      status: recognition.status,
      confidence: recognition.confidence,
      threshold: recognition.threshold,
      person_entity_id: recognition.person_entity_id || null,
      candidate_person_id: recognition.candidate_person_id || null,
      candidate_name: recognition.candidate_name || null,
      local_model: "jarvis-local-voice-v1",
    };
  }
  const stored = await rememberMemory({
    content,
    source: "voice",
    kind: "utterance",
    actor,
    sourceEventId,
    confidence: isAttributedSpeaker(recognition) ? Number(recognition.confidence || 1) : 1,
    metadata,
  });
  if (stored && recognition?.status === "likely") {
    logEvent("speaker.recognition.likely", `${recognition.candidate_name || "unknown"} ${Math.round(Number(recognition.confidence || 0) * 100)}%`);
  }
  return stored;
}

function renderMemoryStats(stats = {}) {
  if (ui.memoryEventsMetric) ui.memoryEventsMetric.textContent = Number(stats.events || 0).toLocaleString();
  if (ui.memoryEntitiesMetric) ui.memoryEntitiesMetric.textContent = Number(stats.entities || 0).toLocaleString();
  if (ui.memoryFactsMetric) ui.memoryFactsMetric.textContent = Number(stats.facts || 0).toLocaleString();
  if (ui.memoryCategoriesMetric) ui.memoryCategoriesMetric.textContent = Number(stats.categories || 0).toLocaleString();
  if (ui.memoryFindingsMetric) ui.memoryFindingsMetric.textContent = Number(stats.consolidation_findings || 0).toLocaleString();
  if (ui.memoryProactiveMetric) ui.memoryProactiveMetric.textContent = Number(stats.proactive_open || 0).toLocaleString();
  if (ui.memoryPeopleMetric) ui.memoryPeopleMetric.textContent = Number(stats.people || 0).toLocaleString();
  renderHomeProactiveStatus(stats);
  if (ui.memoryHealthBadge) ui.memoryHealthBadge.textContent = stats.schema_version ? `Local schema ${stats.schema_version}` : "Local & private";
  if (ui.memoryUndoButton) ui.memoryUndoButton.disabled = Number(stats.undo_available || 0) < 1;
}

function memoryDisplayTime(value, options = {}) {
  if (!value) return "Unknown time";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString([], options.dateOnly ? {dateStyle: "full"} : {dateStyle: "medium", timeStyle: "medium"});
}

function createMemoryChip(text, className = "memory-entity-chip") {
  const chip = document.createElement("span");
  chip.className = className;
  chip.textContent = text;
  return chip;
}

function memoryEmpty(target, title, copy) {
  if (!target) return;
  target.replaceChildren();
  const empty = document.createElement("div");
  empty.className = "empty-state";
  const symbol = document.createElement("span");
  symbol.className = "empty-symbol";
  symbol.textContent = "◈";
  const strong = document.createElement("strong");
  strong.textContent = title;
  const detail = document.createElement("span");
  detail.textContent = copy;
  empty.append(symbol, strong, detail);
  target.append(empty);
}

function renderMemoryTimeline(memories = []) {
  if (!ui.memoryTimeline) return;
  ui.memoryTimeline.replaceChildren();
  if (!memories.length) {
    memoryEmpty(ui.memoryTimeline, "No matching memories", "Try another question, date range, source, or category.");
    return;
  }
  let currentDate = "";
  for (const memory of memories) {
    if (memory.local_date !== currentDate) {
      currentDate = memory.local_date;
      const dateHeading = document.createElement("div");
      dateHeading.className = "memory-date-heading";
      const parsed = new Date(`${currentDate}T12:00:00`);
      dateHeading.textContent = Number.isNaN(parsed.getTime()) ? currentDate : parsed.toLocaleDateString([], {dateStyle: "full"});
      ui.memoryTimeline.append(dateHeading);
    }
    const item = document.createElement("article");
    item.className = `memory-event memory-status-${memory.status || "active"}`;
    item.dataset.memoryEventId = memory.event_id;
    if (memory.important) item.classList.add("important");

    const head = document.createElement("div");
    head.className = "memory-event-head";
    const identity = document.createElement("div");
    const actor = document.createElement("strong");
    actor.textContent = memory.actor || "Unknown";
    const time = document.createElement("span");
    time.textContent = memoryDisplayTime(memory.local_timestamp || memory.occurred_at);
    identity.append(actor, time);
    const headBadges = document.createElement("div");
    headBadges.className = "memory-event-badges";
    headBadges.append(createMemoryChip(String(memory.source || "unknown").replaceAll("_", " "), "memory-source-pill"));
    if (memory.important) headBadges.append(createMemoryChip("Important", "memory-important-pill"));
    if ((memory.status || "active") !== "active") headBadges.append(createMemoryChip(memory.status, "memory-review-pill"));
    head.append(identity, headBadges);

    const content = document.createElement("p");
    content.className = "memory-event-content";
    content.textContent = memory.content || "";

    const footer = document.createElement("div");
    footer.className = "memory-event-footer";
    const category = document.createElement("button");
    category.type = "button";
    category.className = "memory-category-chip";
    category.textContent = memory.category || "Uncategorized";
    category.addEventListener("click", (event) => {
      event.stopPropagation();
      if (ui.memoryCategoryFilter) ui.memoryCategoryFilter.value = memory.category || "";
      void loadMemoryDashboard();
    });
    footer.append(category);
    for (const entity of (memory.entities || []).slice(0, 5)) {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "memory-entity-chip";
      chip.textContent = entity.name;
      chip.addEventListener("click", (event) => {
        event.stopPropagation();
        void openMemoryEntity(entity.id);
      });
      footer.append(chip);
    }
    const details = document.createElement("button");
    details.type = "button";
    details.className = "memory-details-button";
    details.textContent = "Details & provenance";
    details.addEventListener("click", () => openMemoryEvent(memory.event_id));
    footer.append(details);
    item.append(head, content, footer);
    item.addEventListener("dblclick", () => openMemoryEvent(memory.event_id));
    ui.memoryTimeline.append(item);
  }
}

function renderMemoryCategories(categories = []) {
  if (ui.memoryCategoryList) ui.memoryCategoryList.replaceChildren();
  const current = ui.memoryCategoryFilter?.value || "";
  if (ui.memoryCategoryFilter) ui.memoryCategoryFilter.replaceChildren(new Option("All categories", ""));
  const visible = categories.filter((item) => Number(item.event_count || 0) > 0);
  if (!visible.length && ui.memoryCategoryList) {
    const empty = document.createElement("span");
    empty.className = "memory-muted";
    empty.textContent = "No categories yet.";
    ui.memoryCategoryList.append(empty);
  }
  for (const category of visible) {
    if (ui.memoryCategoryFilter) ui.memoryCategoryFilter.add(new Option(`${category.path} (${category.event_count})`, category.path));
    if (!ui.memoryCategoryList) continue;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "memory-category-row";
    const label = document.createElement("span");
    label.textContent = category.path;
    const count = document.createElement("strong");
    count.textContent = Number(category.event_count || 0).toLocaleString();
    button.append(label, count);
    button.addEventListener("click", () => {
      setMemoryExplorerMode("timeline");
      if (ui.memoryCategoryFilter) ui.memoryCategoryFilter.value = category.path;
      void loadMemoryDashboard();
    });
    ui.memoryCategoryList.append(button);
  }
  if (ui.memoryCategoryFilter && [...ui.memoryCategoryFilter.options].some((option) => option.value === current)) {
    ui.memoryCategoryFilter.value = current;
  }
}

function renderMemoryEntities(entities = []) {
  if (!ui.memoryEntityGrid) return;
  ui.memoryEntityGrid.replaceChildren();
  if (!entities.length) {
    memoryEmpty(ui.memoryEntityGrid, "No matching entities", "Jarvis creates entities as people, projects, businesses, places, and concepts are mentioned.");
    return;
  }
  for (const entity of entities) {
    const shell = document.createElement("div");
    shell.className = "memory-entity-card-shell";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "memory-entity-card";
    const type = document.createElement("span");
    type.textContent = String(entity.type || "concept").replaceAll("_", " ");
    const name = document.createElement("strong");
    name.textContent = entity.name;
    const counts = document.createElement("small");
    counts.textContent = `${Number(entity.event_count || 0)} events · ${Number(entity.fact_count || 0)} facts`;
    const last = document.createElement("small");
    last.textContent = `Last seen ${memoryDisplayTime(entity.last_seen_at)}`;
    button.append(type, name, counts, last);
    button.addEventListener("click", () => openMemoryEntity(entity.id));
    shell.append(button);
    if (String(entity.type || "") === "person") {
      const merge = document.createElement("button");
      merge.type = "button";
      merge.className = "memory-entity-card-action";
      merge.textContent = "Merge duplicate";
      merge.addEventListener("click", async () => {
        try {
          const response = await fetch(`/api/memory/people/${encodeURIComponent(entity.id)}?event_limit=1`, {cache: "no-store"});
          if (!response.ok) throw new Error(`Person detail failed (${response.status})`);
          await openIdentityMergeEditor((await response.json()).person);
        } catch (error) {
          if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
        }
      });
      shell.append(merge);
    }
    ui.memoryEntityGrid.append(shell);
  }
}

function renderMemoryPeople(people = []) {
  if (!ui.memoryPeopleGrid) return;
  ui.memoryPeopleGrid.replaceChildren();
  if (!people.length) {
    memoryEmpty(ui.memoryPeopleGrid, "No matching people", "Person profiles appear when speakers, relationships, or named people enter Jarvis memory.");
    return;
  }
  for (const person of people) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `memory-person-card identity-scope-${person.access_scope || "restricted"}`;
    const heading = document.createElement("div"); heading.className = "memory-person-heading";
    const name = document.createElement("strong"); name.textContent = person.name || person.display_name || person.canonical_name;
    const scope = createMemoryChip(String(person.access_scope || "restricted").replaceAll("_", " "), "memory-identity-scope");
    heading.append(name, scope);
    const relationship = document.createElement("span");
    relationship.textContent = person.is_local_user ? "Local owner" : String(person.relationship_to_owner || "known person").replaceAll("_", " ");
    const role = document.createElement("small");
    role.textContent = person.role || `${Number(person.event_count || 0)} attributed events · ${Number(person.alias_count || 0)} aliases`;
    const recognition = document.createElement("small");
    recognition.textContent = `Voice ${String(person.voice_status || "not_enrolled").replaceAll("_", " ")} · Face ${String(person.face_status || "not_enrolled").replaceAll("_", " ")}`;
    button.append(heading, relationship, role, recognition);
    button.addEventListener("click", () => openMemoryPerson(person.id));
    ui.memoryPeopleGrid.append(button);
  }
}

async function openMemoryPerson(personId) {
  try {
    const response = await fetch(`/api/memory/people/${encodeURIComponent(personId)}?event_limit=100`, {cache: "no-store"});
    if (!response.ok) throw new Error(`Person detail failed (${response.status})`);
    const person = (await response.json()).person;
    const root = document.createElement("div"); root.className = "memory-person-detail";
    root.append(detailSection("Identity profile", [
      detailField("Display name", person.display_name || person.name),
      detailField("Preferred name", person.preferred_name || "Not set"),
      detailField("Relationship to owner", String(person.relationship_to_owner || "known_person").replaceAll("_", " ")),
      detailField("Role", person.role || "Not set"),
      detailField("Access boundary", String(person.access_scope || "restricted").replaceAll("_", " ")),
      detailField("Retention", String(person.retention_policy || "permanent").replaceAll("_", " ")),
      detailField("Trusted", person.trusted ? "Yes" : "No"),
      detailField("Local owner", person.is_local_user ? "Yes" : "No"),
      detailField("First seen", memoryDisplayTime(person.first_seen_at)),
      detailField("Last seen", memoryDisplayTime(person.last_seen_at)),
    ]));

    const aliases = document.createElement("div"); aliases.className = "memory-detail-chips";
    for (const alias of person.aliases || []) aliases.append(createMemoryChip(alias.alias));
    if (!(person.aliases || []).length) aliases.append(createMemoryChip("No aliases", "memory-muted"));
    root.append(detailSection("Names and aliases", [aliases]));

    const addressNames = document.createElement("div"); addressNames.className = "memory-detail-chips";
    for (const name of person.active_address_names || []) addressNames.append(createMemoryChip(name));
    if (!(person.active_address_names || []).length) addressNames.append(createMemoryChip("Use canonical name", "memory-muted"));
    root.append(detailSection("Preferred forms of address", [addressNames]));

    const recognition = document.createElement("div"); recognition.className = "memory-recognition-grid";
    for (const biometric of person.biometrics || []) {
      const card = document.createElement("div"); card.className = "memory-recognition-card";
      const label = document.createElement("strong"); label.textContent = `${String(biometric.modality).replaceAll("_", " ")} identity`;
      const status = document.createElement("span"); status.textContent = String(biometric.status || "not_enrolled").replaceAll("_", " ");
      const detail = document.createElement("small");
      detail.textContent = biometric.profile_ref ? "Protected profile reference available" : "No raw biometric template stored in memory";
      card.append(label, status, detail); recognition.append(card);
    }
    root.append(detailSection("Future recognition foundations", [recognition]));

    const permissions = document.createElement("div"); permissions.className = "memory-permission-list";
    if (!(person.permissions || []).length) permissions.append(createMemoryChip("No explicit permissions; restricted defaults apply", "memory-muted"));
    for (const permission of person.permissions || []) {
      const row = document.createElement("div"); row.className = "memory-permission-row";
      const label = document.createElement("span");
      label.textContent = String(permission.memory_scope).replaceAll("_", " ");
      const edit = document.createElement("button");
      edit.type = "button";
      edit.className = "memory-permission-action";
      edit.textContent = String(permission.access_level || "read").replaceAll("_", " ");
      edit.title = `Edit ${label.textContent} memory permission`;
      edit.setAttribute("aria-label", `Edit ${label.textContent} memory permission`);
      edit.addEventListener("click", () => openIdentityPermissionEditor(person, permission));
      row.append(label, edit);
      permissions.append(row);
    }
    root.append(detailSection("Memory access permissions", [permissions]));

    const relationships = document.createElement("div"); relationships.className = "memory-relationship-list";
    if (!(person.relationships || []).length) relationships.append(createMemoryChip("No identity relationships recorded", "memory-muted"));
    for (const relation of person.relationships || []) {
      const row = document.createElement("div"); row.className = "memory-relationship-row";
      const direction = relation.source_entity_id === person.id
        ? `${person.name} ${String(relation.relationship).replaceAll("_", " ")} ${relation.target_name}`
        : `${relation.source_name} ${String(relation.relationship).replaceAll("_", " ")} ${person.name}`;
      const statement = document.createElement("strong"); statement.textContent = direction;
      const support = document.createElement("span"); support.textContent = `${relation.status} · confidence ${Number(relation.confidence || 0).toFixed(2)}`;
      const controls = document.createElement("div"); controls.className = "memory-inline-controls";
      const control = (label, status) => {
        const button = document.createElement("button"); button.type = "button"; button.className = "text-button"; button.textContent = label;
        button.disabled = relation.status === status;
        button.addEventListener("click", () => void setMemoryRelationshipLifecycle(relation.id, status, person.id));
        controls.append(button);
      };
      control("Current", "current");
      control("Historical", "historical");
      control("Incorrect", "incorrect");
      row.append(statement, support, controls); relationships.append(row);
    }
    root.append(detailSection("Relationships", [relationships]));

    const events = document.createElement("div"); events.className = "memory-related-events";
    if (!(person.events || []).length) events.append(createMemoryChip("No attributed events", "memory-muted"));
    for (const memory of (person.events || []).slice(0, 40)) {
      const button = document.createElement("button"); button.type = "button";
      button.textContent = `${memoryDisplayTime(memory.local_timestamp)} — ${memory.content}`;
      button.addEventListener("click", () => openMemoryEvent(memory.event_id)); events.append(button);
    }
    root.append(detailSection(`Attributed timeline (${(person.events || []).length})`, [events]));

    if ((person.related_events || []).length) {
      const related = document.createElement("div"); related.className = "memory-related-events";
      for (const memory of person.related_events.slice(0, 30)) {
        const button = document.createElement("button"); button.type = "button";
        button.textContent = `${memoryDisplayTime(memory.local_timestamp)} — ${memory.content}`;
        button.addEventListener("click", () => openMemoryEvent(memory.event_id)); related.append(button);
      }
      root.append(detailSection(`Related memories (${person.related_events.length})`, [related]));
    }

    if ((person.attributions || []).length) {
      const history = document.createElement("div"); history.className = "memory-attribution-history";
      for (const attribution of person.attributions.slice(0, 30)) {
        const row = document.createElement("div"); row.className = "memory-attribution-row";
        const title = document.createElement("strong");
        title.textContent = `${attribution.previous_actor_label} → ${attribution.current_actor_label}`;
        const reason = document.createElement("span"); reason.textContent = `${String(attribution.reason).replaceAll("_", " ")} · ${memoryDisplayTime(attribution.created_at)}`;
        const evidence = document.createElement("small"); evidence.textContent = attribution.correction_content || attribution.event_content || "Attribution correction";
        row.append(title, reason, evidence); history.append(row);
      }
      root.append(detailSection("Attribution history", [history]));
    }

    const actions = document.createElement("div"); actions.className = "memory-detail-actions memory-identity-actions";
    const action = (label, handler, className = "secondary") => {
      const button = document.createElement("button"); button.type = "button"; button.className = className; button.textContent = label;
      button.addEventListener("click", () => void handler()); actions.append(button);
    };
    action("Edit relationship / role", () => openIdentityProfileEditor(person));
    action("Set privacy boundary", () => openIdentityPrivacyEditor(person));
    action("Add alias", () => openIdentityAliasEditor(person));
    action("Manage forms of address", () => openIdentityAddressNamesEditor(person));
    action("Set memory permission", () => openIdentityPermissionEditor(person));
    action("Merge duplicate person", () => openIdentityMergeEditor(person));
    root.append(detailSection("Identity controls", [actions]));
    showMemoryDetail({kicker: "PEOPLE & IDENTITY", title: person.name, content: root});
    return person;
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
    return null;
  }
}

function identityControlField(label, control, help = "") {
  const wrapper = document.createElement("label");
  wrapper.className = "memory-identity-form-field";
  const heading = document.createElement("span"); heading.textContent = label;
  wrapper.append(heading, control);
  if (help) { const note = document.createElement("small"); note.textContent = help; wrapper.append(note); }
  return wrapper;
}

function identityTextControl(value = "", {multiline = false, required = false, placeholder = ""} = {}) {
  const control = document.createElement(multiline ? "textarea" : "input");
  if (!multiline) control.type = "text";
  control.value = value || "";
  control.required = required;
  control.placeholder = placeholder;
  if (multiline) control.rows = 4;
  return control;
}

function identitySelectControl(values, selected) {
  const select = document.createElement("select");
  for (const value of values) {
    const option = document.createElement("option"); option.value = value; option.textContent = value.replaceAll("_", " ");
    option.selected = value === selected; select.append(option);
  }
  return select;
}

function showIdentityEditor(person, title, fields, submitLabel, onSubmit) {
  const form = document.createElement("form"); form.className = "memory-identity-form";
  for (const field of fields) form.append(field.node);
  const status = document.createElement("div"); status.className = "memory-identity-form-status"; status.setAttribute("aria-live", "polite");
  const actions = document.createElement("div"); actions.className = "memory-detail-actions";
  const cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "secondary"; cancel.textContent = "Cancel";
  cancel.addEventListener("click", () => void openMemoryPerson(person.id));
  const submit = document.createElement("button"); submit.type = "submit"; submit.textContent = submitLabel;
  actions.append(cancel, submit); form.append(status, actions);
  form.addEventListener("submit", async (event) => {
    event.preventDefault(); submit.disabled = true; cancel.disabled = true; status.textContent = "Saving…";
    try {
      await onSubmit(Object.fromEntries(fields.map((field) => [field.name, field.control])));
      await loadMemoryPeople();
      await openMemoryPerson(person.id);
      if (ui.memoryStatus) ui.memoryStatus.textContent = `${title} saved.`;
    } catch (error) {
      status.textContent = error.message; submit.disabled = false; cancel.disabled = false;
    }
  });
  showMemoryDetail({kicker: "IDENTITY CONTROL", title, content: form});
}

function openIdentityProfileEditor(person) {
  const display = identityTextControl(person.display_name || person.name, {required: true});
  const preferred = identityTextControl(person.preferred_name || "");
  const relationship = identityTextControl(person.relationship_to_owner || "known_person", {required: true});
  const role = identityTextControl(person.role || "");
  const notes = identityTextControl(person.notes || "", {multiline: true});
  const fields = [
    {name: "display", control: display, node: identityControlField("Canonical display name", display, "Changing this keeps the previous name as an alias.")},
    {name: "preferred", control: preferred, node: identityControlField("Preferred name", preferred)},
    {name: "relationship", control: relationship, node: identityControlField("Relationship to local owner", relationship)},
    {name: "role", control: role, node: identityControlField("Role or context", role)},
    {name: "notes", control: notes, node: identityControlField("Notes", notes)},
  ];
  showIdentityEditor(person, `Edit ${person.name}`, fields, "Save identity", async (controls) => {
    await memoryWrite(`/api/memory/people/${encodeURIComponent(person.id)}`, {method: "PATCH", body: {
      display_name: controls.display.value.trim(), preferred_name: controls.preferred.value.trim(),
      relationship_to_owner: controls.relationship.value.trim(), role: controls.role.value.trim(), notes: controls.notes.value.trim(),
    }});
  });
}

function openIdentityPrivacyEditor(person) {
  const scope = identitySelectControl(["owner", "household", "business", "guest", "restricted"], person.access_scope || "restricted");
  const retention = identitySelectControl(["permanent", "session", "ask", "none"], person.retention_policy || "permanent");
  const trusted = document.createElement("input"); trusted.type = "checkbox"; trusted.checked = Boolean(person.trusted);
  const fields = [
    {name: "scope", control: scope, node: identityControlField("Access boundary", scope)},
    {name: "retention", control: retention, node: identityControlField("Retention policy", retention)},
    {name: "trusted", control: trusted, node: identityControlField("Trusted identity", trusted, "Trusted status does not bypass memory permissions.")},
  ];
  showIdentityEditor(person, `Privacy for ${person.name}`, fields, "Save privacy", async (controls) => {
    await memoryWrite(`/api/memory/people/${encodeURIComponent(person.id)}`, {method: "PATCH", body: {
      access_scope: controls.scope.value, retention_policy: controls.retention.value, trusted: controls.trusted.checked,
    }});
  });
}

function openIdentityAliasEditor(person) {
  const alias = identityTextControl("", {required: true, placeholder: "Nickname, alternate spelling, or transcription variant"});
  const fields = [{name: "alias", control: alias, node: identityControlField("Alias", alias, "Aliases resolve to this same person without creating a duplicate profile.")}];
  showIdentityEditor(person, `Add alias for ${person.name}`, fields, "Add alias", async (controls) => {
    await memoryWrite(`/api/memory/people/${encodeURIComponent(person.id)}/aliases`, {body: {alias: controls.alias.value.trim()}});
  });
}

function openIdentityAddressNamesEditor(person) {
  const names = identityTextControl((person.active_address_names || []).join(", "), {
    placeholder: "Boss, Chief, Captain",
  });
  const fields = [{
    name: "names",
    control: names,
    node: identityControlField(
      "Active forms of address",
      names,
      "Separate multiple choices with commas. Leave blank to stop using special names or titles.",
    ),
  }];
  showIdentityEditor(person, `Forms of address for ${person.name}`, fields, "Save forms of address", async (controls) => {
    const values = splitAddressNames(controls.names.value);
    const payload = await memoryWrite(`/api/memory/people/${encodeURIComponent(person.id)}/address-names`, {
      body: {action: values.length ? "replace" : "clear", names: values},
    });
    updateAddressContext(payload.person);
  });
}

function openIdentityPermissionEditor(person, permission = null) {
  const currentScope = String(permission?.memory_scope || "household");
  const currentLevel = String(permission?.access_level || "read");
  const scope = identityTextControl(currentScope, {required: true});
  const level = identitySelectControl(["none", "read", "contribute", "manage"], currentLevel);
  const fields = [
    {name: "scope", control: scope, node: identityControlField("Memory scope", scope, "Examples: personal, household, business, shared.")},
    {name: "level", control: level, node: identityControlField("Access level", level)},
  ];
  const title = permission
    ? `${String(permission.memory_scope).replaceAll("_", " ")} permission for ${person.name}`
    : `Memory permission for ${person.name}`;
  showIdentityEditor(person, title, fields, "Save permission", async (controls) => {
    await memoryWrite(`/api/memory/people/${encodeURIComponent(person.id)}/permissions`, {method: "PUT", body: {
      memory_scope: controls.scope.value.trim(), access_level: controls.level.value,
    }});
  });
}

async function openIdentityMergeEditor(person) {
  try {
    const response = await fetch("/api/memory/people?limit=250", {cache: "no-store"});
    if (!response.ok) throw new Error(`People list failed (${response.status})`);
    const candidates = ((await response.json()).people || []).filter(
      (candidate) => candidate.id !== person.id && (person.is_local_user || !candidate.is_local_user),
    );
    if (!candidates.length) throw new Error("No separate person profiles are available to merge.");
    const select = document.createElement("select");
    for (const candidate of candidates) {
      const option = document.createElement("option");
      option.value = candidate.id;
      const localLabel = candidate.is_local_user ? "local owner profile" : String(candidate.relationship_to_owner || "known person").replaceAll("_", " ");
      option.textContent = `${candidate.name} — ${localLabel}`;
      select.append(option);
    }
    const confirm = document.createElement("input"); confirm.type = "checkbox"; confirm.required = true;
    const fields = [
      {name: "duplicate", control: select, node: identityControlField("Duplicate profile", select)},
      {name: "confirm", control: confirm, node: identityControlField("I confirm these records are the same person", confirm, "All aliases, attribution, relationships, and evidence will move to the canonical profile. The merge is audit logged and reversible.")},
    ];
    showIdentityEditor(person, `Merge into ${person.name}`, fields, "Merge profiles", async (controls) => {
      if (!controls.confirm.checked) throw new Error("Confirm that both profiles are the same person.");
      await memoryWrite("/api/memory/entities/merge", {body: {source_id: controls.duplicate.value, target_id: person.id}});
    });
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  }
}

function setMemoryExplorerMode(mode) {
  memoryExplorerMode = ["timeline", "entities", "people", "voices", "apps", "summary", "consolidation", "proactive"].includes(mode) ? mode : "timeline";
  for (const button of document.querySelectorAll("[data-memory-mode]")) {
    const active = button.dataset.memoryMode === memoryExplorerMode;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", String(active));
  }
  for (const panel of document.querySelectorAll("[data-memory-panel]")) {
    panel.hidden = panel.dataset.memoryPanel !== memoryExplorerMode;
  }
  if (memoryExplorerMode === "summary") void loadMemorySummary();
  if (memoryExplorerMode === "entities") void loadMemoryEntities();
  if (memoryExplorerMode === "people") void loadMemoryPeople();
  if (memoryExplorerMode === "voices") void loadVoiceProfiles();
  if (memoryExplorerMode === "apps") void loadMemoryApps();
  if (memoryExplorerMode === "consolidation") void loadMemoryConsolidation();
  if (memoryExplorerMode === "proactive") void loadMemoryProactive();
}

function resetMemoryExplorerFilters({query = ""} = {}) {
  closeMemoryDetail();
  if (ui.memorySearchInput) ui.memorySearchInput.value = query;
  if (ui.memoryEntitySearchInput) ui.memoryEntitySearchInput.value = "";
  if (ui.memoryPeopleSearchInput) ui.memoryPeopleSearchInput.value = "";
  if (ui.memoryDateFromFilter) ui.memoryDateFromFilter.value = "";
  if (ui.memoryDateToFilter) ui.memoryDateToFilter.value = "";
  if (ui.memoryCategoryFilter) ui.memoryCategoryFilter.value = "";
  if (ui.memorySourceFilter) ui.memorySourceFilter.value = "";
  if (ui.memoryStatusFilter) ui.memoryStatusFilter.value = "";
  if (ui.memoryImportantFilter) ui.memoryImportantFilter.checked = false;
}

function fallbackMemoryNavigationIntent(text) {
  const original = normalizeNaturalText(text || "");
  const command = original
    .replace(/^(?:hey\s+|okay\s+|ok\s+)?jarvis\b[\s,.:;!?-]*/i, "")
    .trim();
  const combined = command.match(/^(?:please\s+)?(?:show|display)(?:\s+me)?\s+and\s+(?:tell|explain|describe)\s+(?:me\s+)?(?:about\s+)?(.+)$/i);
  if (combined) {
    const subject = combined[1].replace(/[.?!,;:]+$/g, "").trim();
    if (!subject) return null;
    return {
      original,
      query: original,
      subject,
      preferEntity: true,
      mode: "entity",
      reason: "fallback_show_and_describe_memory",
      responseRequested: true,
      responseDirective: "tell me about the displayed memory",
    };
  }
  const prefix = command.match(/^(?:please\s+)?(?:(?:show|display)\s+me|show|display|open|pull\s+up|bring\s+up|take\s+me\s+to|let\s+me\s+see)\b/i);
  if (!prefix) return null;
  let remainder = command.slice(prefix[0].length).replace(/[.?!,;:]+$/g, "").trim();
  const responseMatch = remainder.match(/\s+(?:and|then)\s+(?:(?:(?:give|provide)\s+me\s+(?:a\s+)?(?:(?:short|brief|quick|detailed|full)\s+)?summary)|(?:(?:tell|explain|summarize|describe)\s+(?:me\s+)?(?:about\s+)?(?:it|them|this|the\s+results?|what\s+you\s+(?:know|remember)(?:\s+about\s+it)?)))(?:\s+please)?$/i);
  const responseRequested = Boolean(responseMatch);
  const responseDirective = responseMatch ? responseMatch[0].replace(/^\s+(?:and|then)\s+/i, "").trim() : "";
  if (responseMatch?.index !== undefined) remainder = remainder.slice(0, responseMatch.index).trim();
  const broad = /^(?:my\s+|the\s+)?memor(?:y|ies)(?:\s+(?:explorer|timeline|page|workspace))?$/i.test(remainder);
  const subjectMatch = remainder.match(/^(?:everything|all(?:\s+(?:that\s+)?(?:you\s+)?(?:know|remember))?)\s+(?:about|on|regarding|related\s+to)\s+(.+)$/i);
  const hasMemoryMeaning = broad || Boolean(subjectMatch) || /\bmemor(?:y|ies)\b/i.test(remainder);
  if (!hasMemoryMeaning) return null;
  const subject = subjectMatch ? subjectMatch[1].trim() : "";
  return {
    original,
    query: broad ? "" : remainder,
    subject,
    preferEntity: Boolean(subject),
    mode: subject ? "entity" : "timeline",
    reason: broad ? "fallback_open_memory_workspace" : "fallback_show_memory",
    responseRequested,
    responseDirective,
  };
}

function parseMemoryNavigationIntent(text) {
  const navigation = window.JarvisMemoryNavigation;
  return navigation?.parseMemoryNavigationIntent?.(text) || fallbackMemoryNavigationIntent(text);
}

function clearVisualOnlyResponseSuppression(reason = "complete") {
  if (visualOnlyResponseSuppressionTimer) window.clearTimeout(visualOnlyResponseSuppressionTimer);
  visualOnlyResponseSuppressionTimer = null;
  if (visualOnlyResponseSuppression) logEvent("memory.navigation.silent_response_released", reason);
  visualOnlyResponseSuppression = null;
  if (ui.remoteAudio) ui.remoteAudio.muted = false;
}

function visualOnlySuppressionMatches(event = null) {
  const suppression = visualOnlyResponseSuppression;
  if (!suppression || Date.now() >= suppression.until) {
    if (suppression) clearVisualOnlyResponseSuppression("expired");
    return false;
  }
  const eventResponseId = providerResponseId(event || {});
  if (!suppression.responseId || !eventResponseId) return true;
  return suppression.responseId === eventResponseId;
}

function removeSilentMemoryResponseBubble() {
  if (activeJarvisBubble) activeJarvisBubble.remove();
  activeJarvisBubble = null;
}

function armVisualOnlyResponseSuppression(intent, {source = "voice", phase = "completed"} = {}) {
  if (!intent || intent.responseRequested) return false;
  const signature = transcriptFingerprint(`${intent.mode}|${intent.subject}|${intent.query}`);
  const sameCommandAlreadyArmed = Boolean(
    visualOnlyResponseSuppression
    && visualOnlyResponseSuppression.signature === signature
    && Date.now() < visualOnlyResponseSuppression.until
  );
  visualOnlyResponseSuppression = {
    until: Date.now() + VISUAL_ONLY_RESPONSE_SUPPRESSION_MS,
    responseId: visualOnlyResponseSuppression?.responseId || "",
    signature,
    source,
  };
  if (visualOnlyResponseSuppressionTimer) window.clearTimeout(visualOnlyResponseSuppressionTimer);
  visualOnlyResponseSuppressionTimer = window.setTimeout(
    () => clearVisualOnlyResponseSuppression("timeout"),
    VISUAL_ONLY_RESPONSE_SUPPRESSION_MS + 100,
  );
  if (ui.remoteAudio) ui.remoteAudio.muted = true;
  if (dedicatedSpeechIsActive()) {
    interruptDedicatedSpeech("visual_memory_navigation");
  } else if (channel?.readyState === "open" && (!sameCommandAlreadyArmed || responseActive)) {
    try {
      if (responseActive) sendProviderEvent({type: "response.cancel"});
      sendProviderEvent({type: "output_audio_buffer.clear"});
    } catch (error) {
      logEvent("memory.navigation.silent_cancel_failed", error.message);
    }
  }
  if (responseActive) setResponseActive(false);
  awaitingFirstAudibleAudio = false;
  removeSilentMemoryResponseBubble();
  setStatus("Listening", "listening", {immediate: true});
  logEvent("memory.navigation.silent_response_armed", `${source}; ${phase}; ${intent.subject || intent.query || "memory"}`);
  void relayEvent("client.memory.navigation.silent", {
    source,
    phase,
    subject: intent.subject || null,
    query: intent.query || null,
  });
  return true;
}

async function navigateMemoryIntent(intent, {source = "typed"} = {}) {
  if (!intent || config?.memory_enabled === false) return {handled: false, outcome: "ignored"};

  resetMemoryExplorerFilters({query: intent.query || ""});
  if (intent.preferEntity && intent.subject) {
    if (ui.memoryEntitySearchInput) ui.memoryEntitySearchInput.value = intent.subject;
    setMemoryExplorerMode("entities");
  } else {
    setMemoryExplorerMode("timeline");
  }
  forceMemoryWorkspaceVisible(`${source}:${intent.reason || "show_memory"}`);
  if (ui.memoryStatus) ui.memoryStatus.textContent = intent.subject
    ? `Opening everything connected to ${intent.subject}…`
    : "Opening Memory Explorer…";
  window.requestAnimationFrame(() => {
    forceMemoryWorkspaceVisible(`${source}:animation_frame`);
    document.querySelector('[data-view="memory"]')?.scrollIntoView({block: "start"});
  });

  let outcome = "timeline";
  let entityName = null;
  let entity = null;
  let memories = [];
  let interpretation = [];
  const navigation = window.JarvisMemoryNavigation;
  try {
    if (intent.preferEntity && intent.subject) {
      const searchEntities = async (query = "") => {
        const params = new URLSearchParams({limit: query ? "25" : "250"});
        if (query) params.set("q", query);
        const response = await fetch(`/api/memory/entities?${params}`, {cache: "no-store"});
        if (!response.ok) throw new Error(`Entity search failed (${response.status})`);
        return (await response.json()).entities || [];
      };
      let entities = await searchEntities(intent.subject);
      let candidate = navigation?.chooseEntityCandidate?.(intent.subject, entities) || null;
      if (!candidate) {
        const allEntities = await searchEntities();
        candidate = navigation?.chooseEntityCandidate?.(intent.subject, allEntities) || null;
        if (candidate) entities = [candidate];
      }
      renderMemoryEntities(entities);
      if (candidate) {
        outcome = "entity";
        entityName = candidate.name;
        entity = await openMemoryEntity(candidate.id);
        memories = entity?.events || [];
        if (ui.memoryStatus) ui.memoryStatus.textContent = `Showing everything connected to ${candidate.name}.`;
      } else {
        setMemoryExplorerMode("timeline");
        if (ui.memorySearchInput) ui.memorySearchInput.value = intent.query || intent.subject;
        const dashboard = await loadMemoryDashboard();
        memories = dashboard?.memories || [];
        interpretation = dashboard?.interpretation || [];
        if (ui.memoryStatus) ui.memoryStatus.textContent = `No exact entity page matched ${intent.subject}; showing related memory records instead.`;
      }
    } else {
      const dashboard = await loadMemoryDashboard();
      memories = dashboard?.memories || [];
      interpretation = dashboard?.interpretation || [];
      if (ui.memoryStatus && !intent.query) ui.memoryStatus.textContent = "Memory Explorer opened.";
    }
    logEvent("memory.navigation.opened", `${source}; ${intent.reason}; ${outcome}${intent.subject ? `; ${intent.subject}` : ""}`);
    void relayEvent("client.memory.navigation", {
      source, reason: intent.reason, outcome, subject: intent.subject || null, query: intent.query || null, entity_name: entityName,
      response_requested: Boolean(intent.responseRequested),
    });
    return {handled: true, outcome, subject: intent.subject || null, entityName, entity, memories, interpretation};
  } catch (error) {
    setMemoryExplorerMode("timeline");
    const dashboard = await loadMemoryDashboard();
    memories = dashboard?.memories || [];
    interpretation = dashboard?.interpretation || [];
    if (ui.memoryStatus) ui.memoryStatus.textContent = `Memory navigation fell back to search: ${error.message}`;
    logEvent("memory.navigation.fallback", error.message);
    return {handled: true, outcome: "timeline_fallback", subject: intent.subject || null, memories, interpretation, error: error.message};
  }
}

function memoryNarrationEvidence(intent, result = {}) {
  const lines = [];
  const displayedName = result.entityName || result.entity?.name || intent.subject || intent.query || "the requested memories";
  lines.push(`The desktop action succeeded. Memory Explorer is open and visibly displaying ${displayedName}.`);
  if (result.entity) {
    const entity = result.entity;
    lines.push(`Displayed entity: ${entity.name || displayedName} (${entity.type || "concept"}; category ${entity.category || "uncategorized"}).`);
    for (const relation of (entity.relationships || []).slice(0, 12)) {
      lines.push(`Relationship: ${relation.subject || entity.name} ${String(relation.predicate || "related_to").replaceAll("_", " ")} ${relation.object || ""}.`);
    }
    for (const memory of (entity.events || []).slice(0, 20)) {
      lines.push(`Exact event: ${memory.local_timestamp || memory.occurred_at || "unknown time"}; ${memory.actor || memory.actor_label || "Unknown"}; ${memory.content || memory.summary || ""}`);
    }
  } else {
    for (const memory of (result.memories || []).slice(0, 20)) {
      lines.push(`Exact event: ${memory.local_timestamp || memory.occurred_at || "unknown time"}; ${memory.actor || memory.actor_label || "Unknown"}; ${memory.content || memory.summary || ""}`);
    }
  }
  if (!(result.memories || []).length && !result.entity) lines.push("The visual search returned no exact records.");
  return lines.join("\n").slice(0, 12000);
}

function memoryNarrationInstructions(intent, result = {}) {
  const directive = intent.responseDirective || "briefly explain what is displayed";
  const policy = window.JarvisMemoryNavigation?.narrationPolicy?.(directive) || {
    style: "single_explanation",
    instruction: "Give one coherent explanation without repeating the same facts in a recap or second summary.",
  };
  return [
    "The local desktop client has already completed the user's visual memory command successfully.",
    "Memory Explorer is open on the user's screen and the requested result is visible now.",
    "Never say that you cannot open, show, access, or display memory. Never say the explorer is still loading.",
    `The user also asked you to ${directive}. Respond to that narration request now.`,
    `NARRATION FORMAT (${policy.style}): ${policy.instruction}`,
    policy.style === "short_summary"
      ? "HARD OUTPUT CONTRACT: Produce exactly one sentence and nothing else. Every clause must add a new fact; omit any closing clause that restates the subject, category, event, date, or lack of details."
      : "Give one continuous explanation without appending a separate recap.",
    "State every fact at most once. Do not give an overview followed by a second summary or recap.",
    "Start directly with the useful memory facts. Do not use preambles or labels such as 'Okay, quick note,' 'Short summary,' 'In summary,' or 'To summarize.'",
    "Do not repeat the date, entity name, category, event, or missing-detail statement in different wording, especially at the end of the response.",
    "Base the response only on the exact local display evidence below. Distinguish exact events from inference, stay concise unless the user requested detail, and do not offer to open something that is already open.",
    "",
    "LOCAL DISPLAY EVIDENCE:",
    memoryNarrationEvidence(intent, result),
  ].join("\n");
}

function cancelAutomaticResponseForMemoryNarration(source = "voice") {
  clearVisualOnlyResponseSuppression("narration_requested");
  if (dedicatedSpeechIsActive()) {
    interruptDedicatedSpeech("memory_narration");
  } else if (isSimulationMode()) {
    clearTimeout(simulationResponseTimer);
    simulationResponseTimer = null;
  } else if (channel?.readyState === "open") {
    try {
      if (responseActive) sendProviderEvent({type: "response.cancel"});
      sendProviderEvent({type: "output_audio_buffer.clear"});
    } catch (error) {
      logEvent("memory.navigation.narration_cancel_failed", error.message);
    }
  }
  setResponseActive(false);
  awaitingFirstAudibleAudio = false;
  if (activeJarvisBubble) activeJarvisBubble.remove();
  activeJarvisBubble = null;
  if (ui.remoteAudio) ui.remoteAudio.muted = true;
  setStatus("Thinking", "thinking", {immediate: true});
  logEvent("memory.navigation.narration_prepared", source);
}

async function requestMemoryNarrationAfterNavigation(memoryNavigation, {source = "voice"} = {}) {
  if (!memoryNavigation?.responseRequested) return false;
  const requestSerial = ++memoryNarrationRequestSerial;
  cancelAutomaticResponseForMemoryNarration(source);
  const result = await (memoryNavigation.navigationPromise || Promise.resolve(null));
  if (requestSerial !== memoryNarrationRequestSerial) return false;
  if (isSimulationMode()) {
    const summary = result?.entityName
      ? `Memory Explorer is showing ${result.entityName}. The local display contains ${(result.entity?.events || []).length} related events.`
      : `Memory Explorer is showing ${(result?.memories || []).length} matching memories.`;
    addBubble("jarvis", summary);
    setStatus("Listening", "listening", {immediate: true});
    return true;
  }
  if (!isConnected()) {
    logEvent("memory.navigation.narration_skipped", "Jarvis is not connected");
    setStatus("Listening", "listening", {immediate: true});
    return false;
  }
  try {
    const recognition = await resolveSpeakerForMemory();
    const userTurn = normalizeNaturalText(
      memoryNavigation.original
      || memoryNavigation.responseDirective
      || `Tell me about ${memoryNavigation.subject || memoryNavigation.query || "what is shown in Memory Explorer"}.`
    );
    const scripted = await requestNaturalVoiceScript(userTurn, recognition, {
      rendered: memoryNarrationInstructions(memoryNavigation, result || {}),
    });
    responseCreateWithSpeaker(recognition, {
      exactReply: scripted.spoken_text,
      userText: userTurn,
      source,
      allowDetailedCompanion: false,
      preparedResponseId: String(scripted.response_id || ""),
      preparedModel: String(scripted.model || config?.text_model || ""),
      preparedProvider: "luna_memory_narration",
      authoritativeSpeech: "luna_memory_narration",
    });
    logEvent("memory.navigation.narration_requested", `${source}; luna; ${memoryNavigation.responseDirective || "describe display"}`);
    void relayEvent("client.memory.navigation.narration_requested", {
      source,
      subject: memoryNavigation.subject || null,
      directive: memoryNavigation.responseDirective || null,
      outcome: result?.outcome || null,
      entity_name: result?.entityName || null,
      speech_role: "luna_script_then_tts",
    });
    return true;
  } catch (error) {
    logEvent("memory.navigation.narration_failed", error.message || "natural narration failed");
    createExactReply("I hit a problem putting that memory summary together.", null, {authoritativeSpeech: "local_error"});
    return false;
  }
}

function navigateMemoryFromNaturalLanguage(text, {source = "typed"} = {}) {
  const intent = parseMemoryNavigationIntent(text);
  if (!intent) return null;

  // The workspace switch is synchronous and independent of network/model timing.
  forceMemoryWorkspaceVisible(`${source}:${intent.reason || "show_memory"}:immediate`);
  const signature = transcriptFingerprint(`${intent.mode}|${intent.subject}|${intent.query}`);
  const now = Date.now();
  const duplicate = signature && signature === lastMemoryNavigationSignature
    && now - lastMemoryNavigationAt <= MEMORY_NAVIGATION_HOLD_MS;
  lastMemoryNavigationSignature = signature;
  lastMemoryNavigationAt = now;
  if (!duplicate) {
    lastMemoryNavigationPromise = navigateMemoryIntent(intent, {source}).catch((error) => {
      logEvent("memory.navigation.failed", error.message);
      if (ui.memoryStatus) ui.memoryStatus.textContent = `Memory Explorer opened, but results failed to load: ${error.message}`;
      return {handled: true, outcome: "failed", subject: intent.subject || null, error: error.message};
    });
  } else {
    logEvent("memory.navigation.duplicate_suppressed", `${source}; ${intent.subject || intent.query || "memory"}`);
  }
  return {...intent, handled: true, visualOnly: !intent.responseRequested, navigationPromise: lastMemoryNavigationPromise};
}

function memorySearchParams() {
  const params = new URLSearchParams({q: ui.memorySearchInput?.value.trim() || "", limit: "100"});
  const mapping = [
    [ui.memoryDateFromFilter, "date_from"], [ui.memoryDateToFilter, "date_to"],
    [ui.memoryCategoryFilter, "category"], [ui.memorySourceFilter, "source"],
    [ui.memoryStatusFilter, "status"],
  ];
  for (const [element, key] of mapping) if (element?.value) params.set(key, element.value);
  if (ui.memoryImportantFilter?.checked) params.set("important", "true");
  return params;
}

async function loadMemoryDashboard() {
  if (!ui.memoryTimeline || config?.memory_enabled === false) return null;
  if (memoryLoadInFlight) return memoryLoadInFlight;
  memoryLoadInFlight = (async () => {
    const params = memorySearchParams();
    if (ui.memoryStatus) ui.memoryStatus.textContent = "Loading local memory…";
    try {
      const [searchResponse, categoryResponse] = await Promise.all([
        fetch(`/api/memory/explore?${params}`, {cache: "no-store"}),
        fetch("/api/memory/categories", {cache: "no-store"}),
      ]);
      if (!searchResponse.ok || !categoryResponse.ok) throw new Error("The local memory service did not respond.");
      const searchPayload = await searchResponse.json();
      const categoryPayload = await categoryResponse.json();
      renderMemoryStats(searchPayload.stats || {});
      renderMemoryTimeline(searchPayload.memories || []);
      renderMemoryCategories(categoryPayload.categories || []);
      if (ui.memoryInterpretation) {
        const interpretation = searchPayload.interpretation || [];
        ui.memoryInterpretation.hidden = !interpretation.length;
        ui.memoryInterpretation.textContent = interpretation.length ? `Jarvis interpreted: ${interpretation.join(" · ")}` : "";
      }
      if (ui.memoryStatus) {
        const count = (searchPayload.memories || []).length;
        ui.memoryStatus.textContent = `${count} ${count === 1 ? "memory" : "memories"} shown. Exact events remain the source of truth.`;
      }
      return searchPayload;
    } catch (error) {
      if (ui.memoryStatus) ui.memoryStatus.textContent = `Memory unavailable: ${error.message}`;
      logEvent("memory.dashboard.failed", error.message);
      return null;
    } finally {
      memoryLoadInFlight = null;
    }
  })();
  return memoryLoadInFlight;
}

async function loadMemoryEntities() {
  if (!ui.memoryEntityGrid) return;
  const query = ui.memoryEntitySearchInput?.value.trim() || "";
  try {
    const response = await fetch(`/api/memory/entities?q=${encodeURIComponent(query)}&limit=250`, {cache: "no-store"});
    if (!response.ok) throw new Error(`Entity search failed (${response.status})`);
    const payload = await response.json();
    renderMemoryEntities(payload.entities || []);
  } catch (error) {
    memoryEmpty(ui.memoryEntityGrid, "Entities unavailable", error.message);
  }
}

async function loadMemoryPeople() {
  if (!ui.memoryPeopleGrid) return;
  const query = ui.memoryPeopleSearchInput?.value.trim() || "";
  try {
    const response = await fetch(`/api/memory/people?q=${encodeURIComponent(query)}&limit=250`, {cache: "no-store"});
    if (!response.ok) throw new Error(`People & identity failed (${response.status})`);
    const payload = await response.json();
    renderMemoryPeople(payload.people || []);
    renderMemoryStats(payload.stats || {});
  } catch (error) {
    memoryEmpty(ui.memoryPeopleGrid, "People & identity unavailable", error.message);
  }
}


function memoryAppActorName() {
  return normalizeNaturalText(config?.local_user_display_name || config?.local_user_name || "Local User");
}

function memoryAppAliases(app = {}) {
  const actorKey = memoryAppActorName().toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  const actorAliases = Array.isArray(app?.actor_aliases?.[actorKey]) ? app.actor_aliases[actorKey] : [];
  const generalAliases = Array.isArray(app?.aliases) ? app.aliases : [];
  return {
    actorAliases: [...new Set(actorAliases.map((value) => normalizeNaturalText(value)).filter(Boolean))],
    generalAliases: [...new Set(generalAliases.map((value) => normalizeNaturalText(value)).filter(Boolean))],
  };
}

function renderMemoryApps(apps = []) {
  if (!ui.memoryAppGrid) return;
  ui.memoryAppGrid.replaceChildren();
  if (!apps.length) {
    memoryEmpty(ui.memoryAppGrid, "No matching apps", "Open an application with Jarvis and its successful launch path will be remembered here.");
    return;
  }
  for (const app of apps) {
    const card = document.createElement("article");
    card.className = "memory-app-card";
    const header = document.createElement("div"); header.className = "memory-app-card-head";
    const identity = document.createElement("div");
    const title = document.createElement("strong"); title.textContent = app.name || "Application";
    const subtitle = document.createElement("small");
    subtitle.textContent = `${String(app.resource_type || "application").replaceAll("_", " ")} · ${String(app.source || "learned").replaceAll("_", " ")}`;
    identity.append(title, subtitle);
    const usage = createMemoryChip(`${Number(app.usage_count || 0)} launch${Number(app.usage_count || 0) === 1 ? "" : "es"}`, "memory-source-chip");
    header.append(identity, usage);

    const path = document.createElement("div"); path.className = "memory-app-path";
    path.title = app.target || "";
    path.textContent = app.target || "No stored target";

    const aliasWrap = document.createElement("div"); aliasWrap.className = "memory-app-aliases";
    const {actorAliases, generalAliases} = memoryAppAliases(app);
    const actorSet = new Set(actorAliases.map((value) => value.toLowerCase()));
    for (const alias of actorAliases.slice(0, 12)) {
      const chip = document.createElement("span"); chip.className = "memory-app-alias actor";
      const label = document.createElement("span"); label.textContent = alias;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "memory-app-alias-remove";
      remove.setAttribute("aria-label", `Forget ${alias} as a name for ${app.name || "this app"}`);
      remove.title = "Forget this alias";
      remove.textContent = "×";
      remove.addEventListener("click", async () => {
        remove.disabled = true;
        try {
          const response = await fetch("/api/computer/apps/aliases", {
            method: "DELETE",
            headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
            body: JSON.stringify({alias, app_query: app.name || app.target, actor: memoryAppActorName()}),
          });
          const payload = await response.json().catch(() => ({}));
          if (!response.ok) throw new Error(payload.detail || `Alias removal failed (${response.status})`);
          if (ui.memoryAppStatus) ui.memoryAppStatus.textContent = `Forgot “${alias}” as another name for ${payload?.app?.name || app.name}.`;
          await loadMemoryApps();
        } catch (error) {
          if (ui.memoryAppStatus) ui.memoryAppStatus.textContent = error.message;
        } finally {
          remove.disabled = false;
        }
      });
      chip.append(label, remove);
      aliasWrap.append(chip);
    }
    for (const alias of generalAliases.filter((value) => !actorSet.has(value.toLowerCase())).slice(0, 10)) {
      const chip = document.createElement("span"); chip.className = "memory-app-alias"; chip.textContent = alias; aliasWrap.append(chip);
    }
    if (!aliasWrap.childNodes.length) {
      const empty = document.createElement("span"); empty.className = "memory-muted"; empty.textContent = "No aliases learned yet."; aliasWrap.append(empty);
    }

    const meta = document.createElement("div"); meta.className = "memory-app-meta";
    const lastUsed = app.last_used_at ? new Date(app.last_used_at).toLocaleString() : "Never launched";
    meta.textContent = `Last used: ${lastUsed}`;

    const diagnostics = document.createElement("details");
    diagnostics.className = "memory-app-diagnostics";
    const diagnosticsSummary = document.createElement("summary");
    const lastDiagnostic = app?.metadata?.last_launch_diagnostic || null;
    if (lastDiagnostic) {
      const state = lastDiagnostic.verified
        ? "verified"
        : (lastDiagnostic.handoff === "accepted" ? "handed off · not confirmed" : "launch rejected");
      const route = lastDiagnostic?.route?.source || app.source || "unknown route";
      diagnosticsSummary.textContent = `Last launch: ${state} · ${String(route).replaceAll("_", " ")}`;
      const diagnosticBody = document.createElement("pre");
      diagnosticBody.className = "memory-app-diagnostic-body";
      diagnosticBody.textContent = [
        `ID: ${lastDiagnostic.id || "—"}`,
        `Route: ${lastDiagnostic?.route?.source || "—"} / ${lastDiagnostic?.route?.launch_kind || "—"}`,
        `Strategy: ${lastDiagnostic?.route?.strategy || "—"}`,
        `Target: ${lastDiagnostic?.route?.target || "—"}`,
        `Command: ${lastDiagnostic?.route?.command || "—"}`,
        `Arguments: ${lastDiagnostic?.route?.arguments || "—"}`,
        `Observed: ${lastDiagnostic.observation || "—"}`,
        `Error: ${lastDiagnostic.error || "none"}`,
      ].join("\n");
      diagnostics.append(diagnosticsSummary, diagnosticBody);
    } else {
      diagnosticsSummary.textContent = "Launch diagnostics: no attempt recorded yet";
      diagnostics.append(diagnosticsSummary);
    }

    const form = document.createElement("form"); form.className = "memory-app-alias-form";
    const input = document.createElement("input"); input.type = "text"; input.maxLength = 160; input.placeholder = `Another name for ${app.name || "this app"}`;
    const button = document.createElement("button"); button.className = "secondary"; button.type = "submit"; button.textContent = "Add alias";
    form.append(input, button);
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const alias = normalizeNaturalText(input.value);
      if (!alias) return;
      button.disabled = true;
      try {
        const response = await fetch("/api/computer/apps/aliases", {
          method: "POST",
          headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
          body: JSON.stringify({alias, app_query: app.name || app.target, actor: memoryAppActorName()}),
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload.detail || `Alias save failed (${response.status})`);
        input.value = "";
        if (ui.memoryAppStatus) ui.memoryAppStatus.textContent = `Saved “${alias}” as another name for ${payload?.app?.name || app.name}.`;
        await loadMemoryApps();
      } catch (error) {
        if (ui.memoryAppStatus) ui.memoryAppStatus.textContent = error.message;
      } finally {
        button.disabled = false;
      }
    });

    card.append(header, path, aliasWrap, meta, diagnostics, form);
    ui.memoryAppGrid.append(card);
  }
}

async function loadMemoryApps() {
  if (!ui.memoryAppGrid) return;
  const query = normalizeNaturalText(ui.memoryAppSearchInput?.value || "").toLowerCase();
  try {
    const response = await fetch("/api/computer/apps?limit=1000", {cache: "no-store"});
    if (!response.ok) throw new Error(`Apps memory failed (${response.status})`);
    const payload = await response.json();
    let apps = Array.isArray(payload.apps) ? payload.apps : [];
    if (query) {
      apps = apps.filter((app) => {
        const actorAliases = Object.values(app.actor_aliases || {}).flat();
        const haystack = [app.name, app.target, app.source, ...(app.aliases || []), ...actorAliases]
          .map((value) => normalizeNaturalText(value).toLowerCase())
          .join(" ");
        return haystack.includes(query);
      });
    }
    renderMemoryApps(apps);
    if (ui.memoryAppStatus && !query) {
      const status = payload.status || {};
      const known = Number(status.known_apps || 0);
      const learned = Number(status.learned_aliases || 0);
      if (status.indexing) {
        const phase = String(status.index_phase || "background").replaceAll("_", " ");
        ui.memoryAppStatus.textContent = `${known} apps/games indexed so far · indexing ${phase} in the background. Known apps can already launch from the local catalog.`;
      } else {
        ui.memoryAppStatus.textContent = `${known} known apps/games · ${learned} learned aliases · local app index ready. Familiar apps resolve before Windows discovery.`;
      }
    }
  } catch (error) {
    memoryEmpty(ui.memoryAppGrid, "Apps memory unavailable", error.message);
    if (ui.memoryAppStatus) ui.memoryAppStatus.textContent = error.message;
  }
}


function voiceProfileForPerson(personId = "") {
  return voiceProfilesCache.find((profile) => String(profile.person_entity_id || "") === String(personId || "")) || null;
}

function voiceReadinessLabel(profile) {
  const readiness = String(profile?.recognition_readiness || "building");
  if (readiness === "high") return "High recognition readiness";
  if (readiness === "ready") return "Recognition ready";
  return "Building voice profile";
}

function guidedVoicePromptForPerson(personId = "") {
  const profile = voiceProfileForPerson(personId);
  const sampleCount = Number(profile?.sample_count || 0);
  const prompts = voiceEnrollmentPrompts.length ? voiceEnrollmentPrompts : [{id: "balanced-1", text: "Speak naturally for several seconds."}];
  const index = Number.isFinite(Number(profile?.next_enrollment_prompt_index))
    ? Number(profile.next_enrollment_prompt_index) % prompts.length
    : sampleCount % prompts.length;
  return {profile, sampleCount, prompt: prompts[Math.max(0, index)]};
}

function renderVoiceEnrollmentGuide(personId = ui.voiceProfilePersonSelect?.value || "") {
  if (!ui.voiceEnrollmentPhrase) return;
  if (!personId) {
    if (ui.voiceEnrollmentStep) ui.voiceEnrollmentStep.textContent = "Guided enrollment";
    if (ui.voiceEnrollmentReadiness) ui.voiceEnrollmentReadiness.textContent = "Choose a person";
    ui.voiceEnrollmentPhrase.textContent = "Choose a person profile and Jarvis will give them a short phrase designed to capture a broad range of speech sounds.";
    if (ui.voiceEnrollmentHint) ui.voiceEnrollmentHint.textContent = `${voiceRecommendedSamples} clear samples are recommended. Jarvis checks each recording locally and only accepts it when the speech is clear enough.`;
    return;
  }
  const {profile, sampleCount, prompt} = guidedVoicePromptForPerson(personId);
  const nextNumber = Math.min(sampleCount + 1, voiceRecommendedSamples);
  if (ui.voiceEnrollmentStep) ui.voiceEnrollmentStep.textContent = sampleCount >= voiceRecommendedSamples
    ? "Optional refinement sample"
    : `Guided sample ${nextNumber} of ${voiceRecommendedSamples}`;
  if (ui.voiceEnrollmentReadiness) ui.voiceEnrollmentReadiness.textContent = voiceReadinessLabel(profile);
  ui.voiceEnrollmentPhrase.textContent = `“${prompt.text}”`;
  if (ui.voiceEnrollmentHint) ui.voiceEnrollmentHint.textContent = sampleCount >= voiceRecommendedSamples
    ? "Your recommended enrollment set is complete. Add another varied sample only if recognition is still inconsistent."
    : "Read the phrase naturally at your normal speaking volume. Keep one speaker near the microphone and avoid TV, music, or loud background noise.";
}

function voiceQualityLabel(value) {
  const quality = Number(value || 0);
  if (quality >= 0.78) return "Strong";
  if (quality >= 0.58) return "Good";
  if (quality >= 0.38) return "Developing";
  return "Needs another sample";
}

function renderVoiceProfiles(payload = {}) {
  voiceProfilesCache = payload.profiles || [];
  voicePeopleCache = payload.people || [];
  if (Array.isArray(payload.enrollment_prompts) && payload.enrollment_prompts.length) voiceEnrollmentPrompts = payload.enrollment_prompts;
  if (Number(payload.recommended_samples) > 0) voiceRecommendedSamples = Number(payload.recommended_samples);
  if (ui.voiceProfilePersonSelect) {
    const selected = ui.voiceProfilePersonSelect.value;
    ui.voiceProfilePersonSelect.replaceChildren(new Option("Choose a person profile", ""));
    for (const person of voicePeopleCache) {
      ui.voiceProfilePersonSelect.add(new Option(person.name || person.display_name || person.canonical_name, person.id));
    }
    if ([...ui.voiceProfilePersonSelect.options].some((option) => option.value === selected)) ui.voiceProfilePersonSelect.value = selected;
  }
  renderVoiceEnrollmentGuide();
  if (!ui.voiceProfileGrid) return;
  ui.voiceProfileGrid.replaceChildren();
  if (!voiceProfilesCache.length) {
    memoryEmpty(ui.voiceProfileGrid, "No enrolled voices", "Choose a person, then record three guided samples for the strongest recognition profile.");
    return;
  }
  for (const profile of voiceProfilesCache) {
    const card = document.createElement("article");
    card.className = "voice-profile-card";
    const header = document.createElement("div"); header.className = "voice-profile-card-head";
    const identity = document.createElement("div");
    const title = document.createElement("strong"); title.textContent = profile.person_name || "Unknown person";
    const subtitle = document.createElement("span");
    subtitle.textContent = `${profile.sample_count || 0} sample${Number(profile.sample_count) === 1 ? "" : "s"} · ${voiceQualityLabel(profile.enrollment_quality)} · ${voiceReadinessLabel(profile)}`;
    identity.append(title, subtitle);
    const badge = createMemoryChip(profile.enabled ? "Recognition enabled" : "Disabled", profile.enabled ? "memory-source-chip" : "memory-muted");
    header.append(identity, badge);
    const details = document.createElement("div"); details.className = "voice-profile-detail-grid";
    for (const [label, value] of [
      ["Threshold", Number(profile.threshold || 0.82).toFixed(2)],
      ["Last confidence", profile.last_confidence ? `${Math.round(Number(profile.last_confidence) * 100)}%` : "Not tested"],
      ["Last recognized", profile.last_recognized_at ? memoryDisplayTime(profile.last_recognized_at) : "Never"],
      ["Storage", "Protected local signature"],
    ]) {
      const item = document.createElement("span"); item.innerHTML = `<small>${label}</small><strong>${value}</strong>`; details.append(item);
    }
    const actions = document.createElement("div"); actions.className = "memory-detail-actions";
    const add = document.createElement("button"); add.type = "button"; add.className = "secondary"; add.textContent = "Add sample";
    add.addEventListener("click", () => { ui.voiceProfilePersonSelect.value = profile.person_entity_id; renderVoiceEnrollmentGuide(profile.person_entity_id); ui.voiceProfileFileInput.click(); });
    const record = document.createElement("button"); record.type = "button"; record.className = "secondary"; record.textContent = "Record guided sample";
    record.addEventListener("click", () => {
      ui.voiceProfilePersonSelect.value = profile.person_entity_id;
      renderVoiceEnrollmentGuide(profile.person_entity_id);
      recordVoiceProfileSample(profile.person_entity_id).catch((error) => { if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = error.message; });
    });
    const toggle = document.createElement("button"); toggle.type = "button"; toggle.className = "text-button"; toggle.textContent = profile.enabled ? "Disable" : "Enable";
    toggle.addEventListener("click", async () => {
      await memoryWrite(`/api/voice-profiles/${encodeURIComponent(profile.person_entity_id)}`, {method: "PATCH", body: {enabled: !profile.enabled}});
      await loadVoiceProfiles();
    });
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "text-button danger"; remove.textContent = "Delete voice identity";
    remove.addEventListener("click", async () => {
      if (remove.dataset.confirm !== "true") {
        remove.dataset.confirm = "true"; remove.textContent = "Click again to confirm delete";
        window.setTimeout(() => { remove.dataset.confirm = "false"; remove.textContent = "Delete voice identity"; }, 5000);
        return;
      }
      const response = await permissionAwareFetch(`/api/voice-profiles/${encodeURIComponent(profile.person_entity_id)}`, {
        method: "DELETE",
        headers: {"X-Jarvis-Client": CLIENT_HEADER},
      }, {confirmationMessage: "Delete this protected voice identity and all of its enrolled samples?"});
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new Error(permissionErrorMessage(payload, "Voice profile deletion failed"));
      }
      await loadVoiceProfiles();
    });
    actions.append(add, record, toggle, remove);
    card.append(header, details, actions);
    ui.voiceProfileGrid.append(card);
  }
}

async function loadVoiceProfiles() {
  if (!ui.voiceProfileGrid) return;
  if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = "Loading protected local voice profiles…";
  try {
    const response = await fetch("/api/voice-profiles", {cache: "no-store"});
    if (!response.ok) throw new Error(`Voice profiles failed (${response.status})`);
    const payload = await response.json();
    renderVoiceProfiles(payload);
    if (ui.voiceProfileStatus) {
      ui.voiceProfileStatus.textContent = payload.enabled
        ? `${(payload.profiles || []).length} enrolled voice profile${(payload.profiles || []).length === 1 ? "" : "s"}. Matching remains local to this device.`
        : "Speaker recognition is disabled in .env.";
    }
  } catch (error) {
    memoryEmpty(ui.voiceProfileGrid, "Voice profiles unavailable", error.message);
    if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = error.message;
  }
}

function audioBufferToMonoPcm(audioBuffer) {
  const length = audioBuffer.length;
  const mono = new Float32Array(length);
  for (let channelIndex = 0; channelIndex < audioBuffer.numberOfChannels; channelIndex += 1) {
    const channel = audioBuffer.getChannelData(channelIndex);
    for (let index = 0; index < length; index += 1) mono[index] += channel[index] / audioBuffer.numberOfChannels;
  }
  return mono;
}

async function audioBlobToVoiceWav(blob) {
  const Context = window.AudioContext || window.webkitAudioContext;
  const context = new Context();
  try {
    const audioBuffer = await context.decodeAudioData(await blob.arrayBuffer());
    const mono = audioBufferToMonoPcm(audioBuffer);
    const resampled = resamplePcmMono([mono], audioBuffer.sampleRate, WAKE_TRANSCRIPTION_SAMPLE_RATE);
    return encodePcm16Wav([resampled.samples], resampled.sampleRate);
  } finally {
    await context.close().catch(() => {});
  }
}

async function uploadVoiceSample(personId, blob, filename = "voice-sample.wav", enrollmentPromptId = "") {
  if (!personId) throw new Error("Choose a person profile first.");
  if (!ui.voiceProfileConsent?.checked) throw new Error("Confirm the person's consent before enrolling a voice sample.");
  if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = "Analyzing the voice sample locally…";
  const wav = await audioBlobToVoiceWav(blob);
  const response = await permissionAwareFetch(`/api/voice-profiles/${encodeURIComponent(personId)}/samples`, {
    method: "POST",
    headers: {
      "Content-Type": "audio/wav",
      "X-Jarvis-Client": CLIENT_HEADER,
      "X-Voice-Consent": "true",
      "X-File-Name": filename,
      "X-Enrollment-Prompt": enrollmentPromptId || "",
    },
    body: wav,
  }, {confirmationMessage: "Enroll this voice sample as protected biometric identity data?"});
  if (!response.ok) {
    let detail = `Voice enrollment failed (${response.status})`;
    try { detail = (await response.json()).detail || detail; } catch (_) {}
    throw new Error(detail);
  }
  const payload = await response.json();
  if (ui.voiceProfileConsent) ui.voiceProfileConsent.checked = false;
  await loadVoiceProfiles();
  renderVoiceEnrollmentGuide(personId);
  const assessment = payload.profile?.latest_sample_assessment || {};
  const profile = payload.profile || voiceProfileForPerson(personId);
  const count = Number(profile?.sample_count || 0);
  const grade = assessment.grade || voiceQualityLabel(profile?.enrollment_quality);
  if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = count >= voiceRecommendedSamples
    ? `Accepted — ${grade} quality. Recommended enrollment complete (${count} samples).`
    : `Accepted — ${grade} quality. ${count} of ${voiceRecommendedSamples} recommended samples complete.`;
  return payload;
}

async function recordVoiceProfileSample(personId = ui.voiceProfilePersonSelect?.value || "") {
  if (!personId) {
    if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = "Choose a person profile before recording.";
    return;
  }
  if (!ui.voiceProfileConsent?.checked) {
    if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = "Confirm the person's consent before recording a guided voice sample.";
    return;
  }
  const {sampleCount, prompt} = guidedVoicePromptForPerson(personId);
  renderVoiceEnrollmentGuide(personId);
  const stream = await navigator.mediaDevices.getUserMedia({audio: {echoCancellation: true, noiseSuppression: true, autoGainControl: true}});
  const Context = window.AudioContext || window.webkitAudioContext;
  const context = new Context();
  const source = context.createMediaStreamSource(stream);
  const processor = context.createScriptProcessor(4096, 1, 1);
  const sink = context.createGain(); sink.gain.value = 0;
  const chunks = [];
  const recordSampleRate = context.sampleRate;
  processor.onaudioprocess = (event) => chunks.push(new Float32Array(event.inputBuffer.getChannelData(0)));
  source.connect(processor); processor.connect(sink); sink.connect(context.destination);
  if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = `Recording guided sample ${Math.min(sampleCount + 1, voiceRecommendedSamples)} — say: “${prompt.text}”`;
  await new Promise((resolve) => setTimeout(resolve, 8000));
  processor.onaudioprocess = null;
  try { processor.disconnect(); source.disconnect(); sink.disconnect(); } catch (_) {}
  stream.getTracks().forEach((track) => track.stop());
  await context.close().catch(() => {});
  const resampled = resamplePcmMono(chunks, recordSampleRate, WAKE_TRANSCRIPTION_SAMPLE_RATE);
  await uploadVoiceSample(personId, encodePcm16Wav([resampled.samples], resampled.sampleRate), `live-enrollment-${Date.now()}.wav`, prompt.id);
}

async function setupSpeakerCapture(stream) {
  stopSpeakerCapture();
  if (config?.speaker_recognition_enabled === false || !stream?.getAudioTracks?.().length) return;
  const Context = window.AudioContext || window.webkitAudioContext;
  if (!Context) return;
  speakerCaptureContext = new Context();
  await speakerCaptureContext.resume();
  speakerCaptureSource = speakerCaptureContext.createMediaStreamSource(stream);
  speakerCaptureProcessor = speakerCaptureContext.createScriptProcessor(2048, 1, 1);
  speakerCaptureSink = speakerCaptureContext.createGain(); speakerCaptureSink.gain.value = 0;
  speakerCaptureProcessor.onaudioprocess = (event) => {
    if (!speakerCaptureActive) return;
    speakerCaptureFrames.push(new Float32Array(event.inputBuffer.getChannelData(0)));
  };
  speakerCaptureSource.connect(speakerCaptureProcessor);
  speakerCaptureProcessor.connect(speakerCaptureSink);
  speakerCaptureSink.connect(speakerCaptureContext.destination);
}

function stopSpeakerCapture() {
  speakerCaptureActive = false;
  speakerCaptureFrames = [];
  if (speakerCaptureProcessor) speakerCaptureProcessor.onaudioprocess = null;
  try { speakerCaptureProcessor?.disconnect(); speakerCaptureSource?.disconnect(); speakerCaptureSink?.disconnect(); } catch (_) {}
  speakerCaptureContext?.close().catch(() => {});
  speakerCaptureContext = null; speakerCaptureSource = null; speakerCaptureProcessor = null; speakerCaptureSink = null;
  pendingSpeakerRecognition = null;
}

function beginSpeakerUtteranceCapture() {
  if (!speakerCaptureProcessor || config?.speaker_recognition_enabled === false) return;
  speakerCaptureFrames = [];
  speakerCaptureActive = true;
  latestSpeakerRecognition = null;
}

async function recognizeVoiceWav(wav, sourceEventId = "") {
  try {
    const response = await fetch("/api/voice-profiles/recognize", {
      method: "POST",
      headers: {
        "Content-Type": "audio/wav",
        "X-Jarvis-Client": CLIENT_HEADER,
        "X-Source-Event-Id": sourceEventId || "",
        "X-Session-Id": clientSessionId || "",
      },
      body: wav,
    });
    if (!response.ok) return null;
    const payload = await response.json();
    return payload.recognition || null;
  } catch (error) {
    logEvent("speaker.recognition.failed", error.message);
    return null;
  }
}

function finishSpeakerUtteranceCapture(sourceEventId = "") {
  if (!speakerCaptureActive || !speakerCaptureContext) return null;
  speakerCaptureActive = false;
  const chunks = speakerCaptureFrames;
  speakerCaptureFrames = [];
  if (!chunks.length) return null;
  const inputRate = speakerCaptureContext.sampleRate;
  pendingSpeakerRecognition = (async () => {
    const resampled = resamplePcmMono(chunks, inputRate, WAKE_TRANSCRIPTION_SAMPLE_RATE);
    const wav = encodePcm16Wav([resampled.samples], resampled.sampleRate);
    latestSpeakerRecognition = await recognizeVoiceWav(wav, sourceEventId);
    return latestSpeakerRecognition;
  })();
  return pendingSpeakerRecognition;
}

async function resolveSpeakerForMemory() {
  if (!pendingSpeakerRecognition) return latestSpeakerRecognition;
  const timeout = new Promise((resolve) => setTimeout(() => resolve(null), 1800));
  const recognition = await Promise.race([pendingSpeakerRecognition, timeout]);
  return recognition || latestSpeakerRecognition || null;
}

function isAttributedSpeaker(recognition) {
  return ["recognized", "session_known"].includes(String(recognition?.status || ""))
    && Boolean(recognition?.person_entity_id);
}

function speakerLabelForRecognition(recognition) {
  if (isAttributedSpeaker(recognition) && recognition?.person_name) return normalizeNaturalText(recognition.person_name);
  if (recognition?.status === "likely" && recognition?.candidate_name) return `Likely ${normalizeNaturalText(recognition.candidate_name)}`;
  if (recognition?.session_speaker_label) return normalizeNaturalText(recognition.session_speaker_label);
  if (recognition?.status === "insufficient_audio") return "Unknown speaker";
  return "Unknown speaker";
}

function updateUserBubbleSpeakerLabel(bubble, recognition) {
  if (!bubble?.isConnected) return;
  const speaker = bubble.querySelector(".speaker");
  if (!speaker) return;
  speaker.textContent = speakerLabelForRecognition(recognition);
  if (recognition?.session_speaker_id) bubble.dataset.sessionSpeakerId = String(recognition.session_speaker_id);
  if (recognition?.person_entity_id) bubble.dataset.personEntityId = String(recognition.person_entity_id);
  bubble.dataset.speakerStatus = String(recognition?.status || "unknown");
}

function relabelSessionSpeakerBubbles(sessionSpeakerId, recognition) {
  const lane = String(sessionSpeakerId || "");
  if (!lane || !ui.transcript) return;
  for (const bubble of ui.transcript.querySelectorAll(".bubble.user")) {
    if (String(bubble.dataset.sessionSpeakerId || "") !== lane) continue;
    updateUserBubbleSpeakerLabel(bubble, recognition);
  }
}

function normalizedAddressCommandText(text) {
  return normalizeNaturalText(text || "")
    .replace(/^\s*(?:hey\s+|yo\s+)?jarvis\s*[,;:—-]?\s*/i, "")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .trim();
}

function cleanAddressName(value) {
  let cleaned = normalizeNaturalText(value || "")
    .replace(/^\s*(?:as\s+)?/i, "")
    .replace(/\s+(?:from now on|going forward|anymore)\s*$/i, "")
    .replace(/^['"]+|['".,;:!?]+$/g, "")
    .trim();
  if (!cleaned || cleaned.length > 80 || cleaned.split(/\s+/).length > 8) return "";
  if (!/[\p{L}\p{N}]/u.test(cleaned)) return "";
  if (/\b(?:because|when|whenever|unless|although|but i|and then|so that)\b/i.test(cleaned)) return "";
  cleaned = cleaned.replace(/\s+/g, " ");
  return cleaned;
}

function splitAddressNames(value) {
  const normalized = normalizeNaturalText(value || "")
    .replace(/\s+(?:or|and)\s+/gi, ",")
    .replace(/\s*\/\s*/g, ",");
  const result = [];
  const seen = new Set();
  for (const part of normalized.split(",")) {
    const name = cleanAddressName(part);
    const key = name.toLocaleLowerCase();
    if (!name || seen.has(key)) continue;
    seen.add(key);
    result.push(name);
    if (result.length >= 6) break;
  }
  return result;
}

function parseAddressPreferenceCommand(text) {
  const command = normalizedAddressCommandText(text);
  if (!command) return null;
  const clearPatterns = [
    /^(?:please\s+)?(?:stop|quit)\s+(?:using|calling me by|addressing me with)\s+(?:all\s+|any\s+|those\s+|these\s+)?(?:nicknames|names|titles|special names)(?:\s+for me)?[.!?]*$/i,
    /^(?:please\s+)?(?:don't|do not)\s+(?:use|call me by)\s+(?:any\s+)?(?:nicknames|titles|special names)(?:\s+anymore)?[.!?]*$/i,
    /^(?:please\s+)?(?:just|only)\s+(?:use|call me by)\s+my\s+(?:real\s+|actual\s+)?name[.!?]*$/i,
  ];
  if (clearPatterns.some((pattern) => pattern.test(command))) return {action: "clear", names: []};

  const removePatterns = [
    /^(?:please\s+)?(?:stop|quit)\s+(?:calling|referring to|addressing)\s+me\s+(?:as\s+)?(.+?)(?:\s+anymore)?[.!?]*$/i,
    /^(?:please\s+)?(?:don't|do not|never)\s+(?:call|refer to|address)\s+me\s+(?:as\s+)?(.+?)(?:\s+anymore)?[.!?]*$/i,
    /^(?:please\s+)?(?:remove|drop)\s+(.+?)\s+from\s+(?:what|the names|the titles)\s+you\s+call\s+me[.!?]*$/i,
  ];
  for (const pattern of removePatterns) {
    const match = command.match(pattern);
    if (match) {
      const names = splitAddressNames(match[1]);
      return names.length ? {action: "remove", names} : null;
    }
  }

  const replacePatterns = [
    /^(?:(?:from now on|going forward)\s*[,;:—-]?\s*)?(?:please\s+)?(?:only|just)\s+(?:call|refer to|address)\s+me\s+(?:as\s+)?(.+?)[.!?]*$/i,
    /^(?:(?:from now on|going forward)\s*[,;:—-]?\s*)?(?:please\s+)?(?:call|refer to|address)\s+me\s+(?:as\s+)?(.+?)\s+instead[.!?]*$/i,
  ];
  for (const pattern of replacePatterns) {
    const match = command.match(pattern);
    if (match) {
      const names = splitAddressNames(match[1]);
      return names.length ? {action: "replace", names} : null;
    }
  }

  const addPatterns = [
    /^(?:(?:from now on|going forward)\s*[,;:—-]?\s*)?(?:please\s+)?(?:call|refer to|address)\s+me\s+(?:as\s+)?(.+?)[.!?]*$/i,
    /^(?:i(?:'d| would)\s+like|i\s+want)\s+you\s+to\s+(?:call|refer to|address)\s+me\s+(?:as\s+)?(.+?)[.!?]*$/i,
    /^(?:you\s+can\s+)(?:also\s+)?call\s+me\s+(.+?)[.!?]*$/i,
  ];
  for (const pattern of addPatterns) {
    const match = command.match(pattern);
    if (match) {
      const names = splitAddressNames(match[1]);
      return names.length ? {action: "add", names} : null;
    }
  }
  return null;
}

function normalizedMemoryCommandText(text) {
  return normalizeNaturalText(text || "")
    .replace(/[’‘]/g, "'")
    .replace(/^\s*(?:(?:hey|yo)\s+)?jarvis\s*[,;:—-]?\s*/i, "")
    .replace(/^(?:(?:um+|uh+|erm+|hmm+|okay|ok|well|actually|sorry|wait|no)\b[\s,;:—-]*)+/i, "")
    .trim();
}

function isNaturalMemoryControlCommand(text) {
  const value = normalizedMemoryCommandText(text);
  if (!value || /^(?:do|can|did)\s+you\s+remember\b/i.test(value)) return false;
  // Google action context owns natural follow-ups before generic memory corrections.
  // This matters even when there is no pending confirmation yet: after Jarvis shows
  // one Calendar event, "Cancel that, please" must stay with Calendar instead of
  // being interpreted as "cancel a memory". Selection answers to a Calendar
  // clarification (for example, "the only one that exists") stay there too.
  if (isPendingConnectedActionContinuation(value)) return false;
  const taskContextActive = typeof recentTaskContextUntil !== "undefined" && recentTaskContextUntil > Date.now();
  const taskHintOwned = typeof CONNECTED_ACTION_TASK_HINT !== "undefined" && CONNECTED_ACTION_TASK_HINT.test(value);
  const taskFollowupOwned = taskContextActive && typeof CONNECTED_ACTION_TASK_CONTEXT_FOLLOWUP !== "undefined" && CONNECTED_ACTION_TASK_CONTEXT_FOLLOWUP.test(value);
  const taskAttributeOwned = taskContextActive && typeof CONNECTED_ACTION_TASK_ATTRIBUTE_FOLLOWUP !== "undefined" && CONNECTED_ACTION_TASK_ATTRIBUTE_FOLLOWUP.test(value);
  if (taskHintOwned || taskFollowupOwned || taskAttributeOwned) return false;
  const calendarContextActive = typeof recentCalendarContextUntil !== "undefined" && recentCalendarContextUntil > Date.now();
  const calendarClarificationActive = typeof recentCalendarClarificationUntil !== "undefined" && recentCalendarClarificationUntil > Date.now();
  if (calendarContextActive && CONNECTED_ACTION_CALENDAR_CONTEXT_FOLLOWUP.test(value)) return false;
  if (calendarClarificationActive && (
    CONNECTED_ACTION_CALENDAR_CLARIFICATION_REPLY.test(value)
    || CONNECTED_ACTION_CALENDAR_SELECTION_CLARIFICATION.test(value)
    || CONNECTED_ACTION_CALENDAR_INFLIGHT_CONTINUATION.test(value)
  )) return false;
  return /^(?:please\s+)?(?:(?:clear|archive|hide|remove)\s+(?:(?:those|the|all)\s+)?completed\s+(?:tasks|items|goals|reminders)|remember(?:\s+(?:that|this))?|keep\s+.+?\s+in\s+mind|forget\b|delete\s+(?:the\s+)?memor(?:y|ies)\b|(?:don't|do not)\s+remember\b|mark\s+.+?\s+(?:as\s+)?(?:complete|completed|done|finished)|(?:i|we)\s+(?:just\s+)?(?:finished|completed|did)\b|.+?\s+is\s+(?:now\s+)?(?:complete|completed|done|finished)|(?:cancel|dismiss|drop)\b|(?:i|we)(?:'re| are)\s+no\s+longer\s+(?:doing|planning|pursuing)\b|.+?\s+is\s+no\s+longer\s+(?:true|a\s+goal|a\s+plan|a\s+task|needed|relevant)|(?:reopen|restore|reactivate)\b|(?:i|we)(?:'re| are)\s+(?:doing|pursuing|planning)\s+.+?\s+again|(?:change|correct|replace)\s+.+?\s+(?:to|with)\s+.+|(?:actually\s+)?i\s+meant\b|.+?\s+is\s+actually\s+.+|(?:that's|that is|this is|it is)\s+(?:not right|wrong|incorrect|outdated))\b/i.test(value);
}

async function applyNaturalMemoryControlCommand(text, storedMemory = null, {source = "voice", actor = null} = {}) {
  try {
    const response = await fetch("/api/memory/commands", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify({
        content: normalizeNaturalText(text || ""),
        command_event_id: storedMemory?.event_id || null,
        session_id: clientSessionId || storedMemory?.session_id || null,
        actor: actor || storedMemory?.actor || config?.local_user_name || "Local User",
      }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Memory command failed (${response.status})`);
    renderMemoryStats(payload.stats || {});
    if (payload.refresh_context && isConnected() && !isSimulationMode()) {
      await refreshRealtimeProfile({apply: true});
    }
    if (document.querySelector('[data-view="memory"]')?.classList.contains("active")) {
      window.setTimeout(() => loadMemoryDashboard(), 80);
    }
    relayEvent("client.memory_command.applied", {
      action: payload.action || "unknown",
      changed: Array.isArray(payload.changed) ? payload.changed.length : 0,
      source,
    });
    return payload;
  } catch (error) {
    logEvent("memory.command.failed", error.message);
    return {handled: true, action: "error", reply: "I couldn’t update that memory."};
  }
}

function isVoiceIdentityQuestion(text) {
  const normalized = normalizeNaturalText(text || "").toLowerCase();
  return /\b(?:do you know )?who (?:i am|am i)(?:\s+(?:based (?:on|off of)|from) (?:my )?voice)?\b/.test(normalized)
    || /\bwhat(?:'s| is) my name\b/.test(normalized)
    || /\bdo you know my name\b/.test(normalized)
    || /\b(?:can you|do you) (?:recognize|identify) me (?:by|from|based on) (?:my )?voice\b/.test(normalized)
    || /\bwhose voice is this\b/.test(normalized);
}

function isVoiceIdentityExplanationQuestion(text) {
  const normalized = normalizeNaturalText(text || "").toLowerCase();
  return /\bhow (?:do|did|can) you know (?:who i am|i(?:'m| am)|my name)\b/.test(normalized)
    || /\bhow did you recognize me\b/.test(normalized)
    || /\bwhy do you think i(?:'m| am)\b/.test(normalized);
}

function addressNamesForRecognition(recognition) {
  const values = isAttributedSpeaker(recognition) ? (recognition.address_names || []) : [];
  return [...new Set(values.map((value) => cleanAddressName(value)).filter(Boolean))];
}

function localSpeakerRecognition() {
  const personName = config?.local_user_display_name || config?.local_user_name || "Local User";
  return {
    status: "recognized",
    confidence: 1,
    person_entity_id: config?.local_user_entity_id || "",
    person_name: personName,
    address_names: [...(config?.local_user_address_names || [])],
    primary_address_name: config?.local_user_primary_address_name || "",
    source: "local_typed_user",
    is_local_user: true,
    relationship_to_owner: "self",
  };
}

function turnSpeakerRecognition(recognition, source = "voice") {
  if (isAttributedSpeaker(recognition)) return recognition;
  if (source === "typed") return localSpeakerRecognition();
  return recognition || null;
}

function humanList(values) {
  const names = values.filter(Boolean);
  if (names.length <= 1) return names[0] || "";
  if (names.length === 2) return `${names[0]} or ${names[1]}`;
  return `${names.slice(0, -1).join(", ")}, or ${names.at(-1)}`;
}

function addressPreferenceReply(command) {
  const names = command.names || [];
  if (command.action === "clear") return "Got it. I’ll just use your name.";
  if (command.action === "remove") {
    return names.length === 1 ? `I won’t call you ${names[0]} anymore.` : "Got it. I’ll stop using those.";
  }
  if (names.length === 1) return `Got it, ${names[0]}.`;
  return `Got it. I’ll use ${humanList(names)}.`;
}

function updateAddressContext(person, recognition = null) {
  if (!person) return;
  const names = [...(person.active_address_names || [])];
  const primary = person.primary_address_name || names[0] || "";
  if (config && String(person.id || "") === String(config.local_user_entity_id || "")) {
    config.local_user_address_names = names;
    config.local_user_primary_address_name = primary;
  }
  for (const candidate of [recognition, latestSpeakerRecognition, wakeSpeakerRecognition]) {
    if (!candidate || String(candidate.person_entity_id || "") !== String(person.id || "")) continue;
    candidate.address_names = names;
    candidate.primary_address_name = primary;
  }
}

async function applyAddressPreferenceCommand(command, recognition, {source = "voice"} = {}) {
  const speaker = turnSpeakerRecognition(recognition, source);
  const personId = isAttributedSpeaker(speaker) ? String(speaker.person_entity_id || "") : "";
  if (!personId) {
    return {ok: false, reply: "I need to know which voice profile is yours first."};
  }
  try {
    const response = await fetch(`/api/memory/people/${encodeURIComponent(personId)}/address-names`, {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify({action: command.action, names: command.names || []}),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Preference update failed (${response.status})`);
    updateAddressContext(payload.person, speaker);
    if (isConnected() && !isSimulationMode()) await refreshRealtimeProfile({apply: true});
    relayEvent("client.address_preference.updated", {
      person_entity_id: personId,
      action: command.action,
      count: command.names?.length || 0,
    });
    return {ok: true, reply: addressPreferenceReply(command), person: payload.person};
  } catch (error) {
    logEvent("address.preference.failed", error.message);
    return {ok: false, reply: "I couldn’t save that preference."};
  }
}

function identityReplyForRecognition(recognition, {explain = false, source = "voice"} = {}) {
  if (isAttributedSpeaker(recognition) && recognition.person_name) {
    if (explain && (source === "typed" || recognition.source === "local_typed_user")) {
      return `Your local profile says you’re ${recognition.person_name}.`;
    }
    if (recognition.status === "session_known") {
      return explain
        ? `You told me you’re ${recognition.person_name} in this conversation. I haven’t treated that as permanent voice recognition.`
        : `You’re ${recognition.person_name}.`;
    }
    return explain
      ? "I recognize your voice from your saved profile."
      : `You’re ${recognition.person_name}.`;
  }
  if (recognition?.status === "likely" && recognition.candidate_name) {
    return explain
      ? `Your voice sounds similar to ${recognition.candidate_name}’s saved profile.`
      : `You sound like ${recognition.candidate_name}, but I’m not completely sure.`;
  }
  if (recognition?.status === "disabled") return "Voice recognition is turned off right now.";
  if (recognition?.status === "insufficient_audio") return "I need a clearer sentence to recognize you.";
  return "I don’t recognize this voice yet. Want to create a voice profile?";
}

function isAffirmativeVoiceEnrollmentReply(text) {
  const normalized = normalizeNaturalText(text || "").toLowerCase().replace(/[^a-z0-9' ]+/g, " ").replace(/\s+/g, " ").trim();
  return /^(?:yes|yeah|yep|sure|okay|ok|please|absolutely|of course)(?:\s+(?:please|do it|let's do it|lets do it|create one|set it up|enroll me|register me))?$/.test(normalized)
    || /^(?:create|make|set up|start|open) (?:a |my )?voice profile(?: please)?$/.test(normalized);
}

function isNegativeVoiceEnrollmentReply(text) {
  const normalized = normalizeNaturalText(text || "").toLowerCase().replace(/[^a-z0-9' ]+/g, " ").replace(/\s+/g, " ").trim();
  return /^(?:no|nope|not now|maybe later|don't|do not)$/.test(normalized);
}

function voiceEnrollmentOfferActive() {
  if (!pendingVoiceEnrollmentOffer) return false;
  if (Date.now() > Number(pendingVoiceEnrollmentOffer.expiresAt || 0)) {
    pendingVoiceEnrollmentOffer = null;
    return false;
  }
  return true;
}

function rememberVoiceEnrollmentOffer(recognition, userText, person = null) {
  pendingVoiceEnrollmentOffer = {
    createdAt: Date.now(),
    expiresAt: Date.now() + 90000,
    sourceText: normalizeNaturalText(userText || ""),
    recognitionStatus: recognition?.status || "unknown",
    personEntityId: String(person?.id || recognition?.person_entity_id || ""),
    personName: normalizeNaturalText(person?.preferred_name || person?.display_name || person?.name || recognition?.person_name || ""),
  };
  logEvent("speaker.enrollment.offered", pendingVoiceEnrollmentOffer.recognitionStatus);
}

async function openVoiceProfileEnrollment() {
  const acceptedOffer = pendingVoiceEnrollmentOffer;
  pendingVoiceEnrollmentOffer = null;
  forceMemoryWorkspaceVisible("voice_enrollment_accepted");
  setMemoryExplorerMode("voices");
  await loadVoiceProfiles();
  if (ui.voiceProfilePersonSelect) {
    const preferredPersonId = String(acceptedOffer?.personEntityId || "");
    ui.voiceProfilePersonSelect.value = [...ui.voiceProfilePersonSelect.options].some((option) => option.value === preferredPersonId)
      ? preferredPersonId
      : "";
    ui.voiceProfilePersonSelect.focus();
  }
  if (ui.voiceProfileStatus) {
    ui.voiceProfileStatus.textContent = "Choose the person this voice belongs to, confirm consent, then upload or record at least two clear samples.";
  }
  relayEvent("client.voice_profile.enrollment_opened", {source: "conversation_offer"});
  logEvent("speaker.enrollment.opened", "voice profiles workspace");
}

function consumeVoiceEnrollmentReply(text) {
  if (!voiceEnrollmentOfferActive()) return false;
  if (isAffirmativeVoiceEnrollmentReply(text)) {
    void openVoiceProfileEnrollment();
    return true;
  }
  if (isNegativeVoiceEnrollmentReply(text)) {
    pendingVoiceEnrollmentOffer = null;
    logEvent("speaker.enrollment.declined", normalizeNaturalText(text));
  }
  return false;
}

function speakerRecognitionInstructions(recognition, {wake = false, userText = ""} = {}) {
  const identityQuestion = isVoiceIdentityQuestion(userText);
  const addressNames = addressNamesForRecognition(recognition);
  const addressGuidance = addressNames.length
    ? ` Active preferred forms of address: ${addressNames.join(", ")}. Use one occasionally when natural; do not use one in every reply and do not default to "sir".`
    : " No special form of address is active. Do not use any nickname or title from earlier conversation history, and do not default to \"sir\".";
  if (isAttributedSpeaker(recognition) && recognition.person_name) {
    const sourceRule = recognition.status === "session_known"
      ? "The speaker explicitly identified themselves in this live conversation; this session binding is not a permanent voice profile or authentication."
      : "This attribution comes from the saved voice profile and is not authentication.";
    const ownerRoleGuidance = recognition.status === "recognized" && recognition.is_local_user
      ? " This person is the local account owner. Treat local owner as an account/permission role, never as the person's name; use their person_name when referring to them."
      : "";
    if (identityQuestion) {
      return `Private speaker context: the current speaker is ${recognition.person_name}. ${sourceRule}${ownerRoleGuidance} Answer in one short sentence: "You’re ${recognition.person_name}."${addressGuidance}`;
    }
    return `Private speaker context: the current speaker is ${recognition.person_name}. ${sourceRule}${ownerRoleGuidance} Never expose private memories solely because a speaker is attributed.${addressGuidance}`;
  }
  if (recognition?.status === "likely" && recognition.candidate_name) {
    if (identityQuestion) {
      return `Private speaker context: this voice sounds like ${recognition.candidate_name}, but the identity is uncertain. Say: "You sound like ${recognition.candidate_name}, but I’m not completely sure." Do not use the candidate's names or titles as a confirmed form of address.`;
    }
    return `Private speaker context: this voice may be ${recognition.candidate_name}, but the identity is uncertain. Do not state the identity as fact or address the speaker by the candidate's names or titles.`;
  }
  if (recognition?.status === "disabled") {
    return "Private speaker context: voice recognition is disabled. If identity matters, say so briefly and offer Voice Profiles.";
  }
  if (recognition?.status === "insufficient_audio") {
    return "Private speaker context: the sample was too short or unclear. Ask for one clear sentence only if identity matters.";
  }
  if (identityQuestion) {
    return "Private speaker context: this voice is not recognized yet. Stay neutral and ask what the speaker would like to be called; do not guess gender or identity.";
  }
  return "Private speaker context: this voice is unknown. Do not guess the speaker's identity or use another person's preferred names.";
}

function speakerOnboardingMatches(recognition) {
  if (!pendingSpeakerOnboarding || Date.now() > Number(pendingSpeakerOnboarding.expiresAt || 0)) {
    pendingSpeakerOnboarding = null;
    return false;
  }
  const expected = String(pendingSpeakerOnboarding.sessionSpeakerId || "");
  const actual = String(recognition?.session_speaker_id || "");
  return Boolean(expected && actual && expected === actual);
}

function normalizeSpeakerNameCandidate(value) {
  const cleaned = normalizeNaturalText(value || "")
    .replace(/^['"\s]+|['".,;:!?\s]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!cleaned || cleaned.length > 80 || cleaned.split(/\s+/).length > 4) return "";
  const blocked = new Set([
    "good", "fine", "okay", "ok", "ready", "here", "back", "doing", "wondering", "trying",
    "not sure", "the one", "me", "myself", "unknown", "someone", "nobody",
  ]);
  if (blocked.has(cleaned.toLowerCase())) return "";
  // "I'm ..." is common conversational grammar, not reliable identity evidence.
  // Reject ordinary state/activity fragments such as "I'm doing pretty good"
  // while still accepting explicit introductions such as "I'm Tanner Yarman".
  if (/^(?:doing|feeling|going|trying|testing|wondering|thinking|working|looking|getting|having|just|pretty|really|very)\b/i.test(cleaned)) return "";
  if (/\b(?:thank\s+you|thanks|for\s+asking|right\s+now|today)\b/i.test(cleaned)) return "";
  if (!/^[\p{L}\p{M}][\p{L}\p{M}'’-]*(?:\s+[\p{L}\p{M}][\p{L}\p{M}'’-]*){0,3}$/u.test(cleaned)) return "";
  return cleaned;
}

function parseSpeakerSelfIntroduction(text, {allowBareName = false} = {}) {
  const value = normalizedAddressCommandText(text);
  if (!value) return null;
  let name = "";
  const patterns = [
    /\b(?:my name is|i am|i'm|this is)\s+(.+?)(?=$|[,.!?;:]|\s+(?:and|but|just|please|you can|call me|address me)\b)/i,
    /\b(?:you can call me|call me)\s+(.+?)(?=$|[,.!?;:]|\s+(?:and|but|please)\b)/i,
  ];
  for (const pattern of patterns) {
    const match = value.match(pattern);
    if (!match) continue;
    name = normalizeSpeakerNameCandidate(match[1]);
    if (name) break;
  }
  if (!name && allowBareName) name = normalizeSpeakerNameCandidate(value);
  if (!name) return null;

  let addressNames = [];
  let addressNamesProvided = false;
  const addressMatch = value.match(/\b(?:just\s+)?(?:call|address|refer to)\s+me\s+(?:as\s+)?(.+?)(?=$|[.!?;]|\s+(?:please|from now on)\b)/i);
  if (addressMatch) {
    const names = splitAddressNames(addressMatch[1]);
    if (names.length) {
      addressNames = names;
      addressNamesProvided = true;
    }
  }
  if (/\b(?:just|only)\s+(?:use\s+)?my\s+(?:real\s+|actual\s+)?name\b/i.test(value)
      || /\b(?:nothing special|no special title|no title|no nickname)\b/i.test(value)) {
    addressNames = [];
    addressNamesProvided = true;
  }
  return {name, addressNames, addressNamesProvided};
}

function parseSpeakerAddressOnboardingReply(text, personName = "") {
  const value = normalizedAddressCommandText(text);
  if (!value) return null;
  if (/^(?:nothing special|no title|no nickname|none|just my name|my name|my name is fine|just use my name)[.!?]*$/i.test(value)) {
    return {action: "clear", names: []};
  }
  const normalizedPersonName = normalizeNaturalText(personName || "");
  if (normalizedPersonName && normalizeNaturalText(value).toLowerCase() === `${normalizedPersonName.toLowerCase()} is fine`) {
    return {action: "replace", names: [normalizedPersonName]};
  }
  const command = parseAddressPreferenceCommand(value);
  if (command) return {action: command.action === "add" ? "replace" : command.action, names: command.names || []};
  const bare = cleanAddressName(value);
  if (bare && bare.split(/\s+/).length <= 4 && !/[?]/.test(value)) return {action: "replace", names: [bare]};
  return null;
}

function unknownSpeakerIdentityMatters(text, recognition) {
  if (!recognition?.session_speaker_id || isAttributedSpeaker(recognition)) return false;
  const value = normalizeNaturalText(text || "").toLowerCase();
  return /\b(?:what about me|and me|for me|mine|who am i|do you know me|do you remember me|remember me|my (?:calendar|schedule|tasks?|reminders?|emails?|messages?|appointments?|day)|what do i have|when am i|where am i)\b/i.test(value);
}

function armSpeakerOnboarding(recognition, phase, extra = {}) {
  const sessionSpeakerId = String(recognition?.session_speaker_id || extra.sessionSpeakerId || "");
  if (!sessionSpeakerId) return false;
  pendingSpeakerOnboarding = {
    phase,
    sessionSpeakerId,
    createdAt: Date.now(),
    expiresAt: Date.now() + 2 * 60 * 1000,
    ...extra,
  };
  logEvent("speaker.onboarding.armed", `${phase}:${sessionSpeakerId}`);
  return true;
}

function applySessionSpeakerBindingToRecognition(recognition, binding) {
  if (!recognition || !binding) return recognition;
  const lane = String(binding.session_speaker_id || recognition.session_speaker_id || "");
  Object.assign(recognition, binding);
  for (const candidate of [latestSpeakerRecognition, wakeSpeakerRecognition]) {
    if (!candidate) continue;
    if (String(candidate.session_speaker_id || "") === lane) Object.assign(candidate, binding);
  }
  relabelSessionSpeakerBubbles(lane, recognition);
  return recognition;
}

async function bindLiveSessionSpeaker(recognition, personName, addressNames = []) {
  const sessionSpeakerId = String(recognition?.session_speaker_id || "");
  if (!clientSessionId || !sessionSpeakerId) throw new Error("This live speaker could not be bound to the conversation.");
  const response = await fetch("/api/voice-profiles/session-bind", {
    method: "POST",
    headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
    body: JSON.stringify({
      session_id: clientSessionId,
      session_speaker_id: sessionSpeakerId,
      person_name: personName,
      address_names: addressNames,
    }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || `Speaker setup failed (${response.status})`);
  applySessionSpeakerBindingToRecognition(recognition, payload.binding || {});
  renderMemoryStats(payload.stats || {});
  return payload;
}

function naturalAddressConfirmation(personName, names) {
  const cleanName = normalizeNaturalText(personName || "");
  const preferred = (names || []).filter(Boolean);
  if (!preferred.length) return `Got it. I’ll just use ${cleanName || "your name"}. Want me to remember your voice for next time?`;
  if (preferred.length === 1 && preferred[0].toLowerCase() === cleanName.toLowerCase()) {
    return `Got it. I’ll call you ${preferred[0]}. Want me to remember your voice for next time?`;
  }
  return `Got it, ${cleanName || "thanks"}. I’ll use ${humanList(preferred)} when it sounds natural. Want me to remember your voice for next time?`;
}

async function handleSpeakerOnboardingTurn(transcript, recognition, userBubble = null) {
  const introduction = parseSpeakerSelfIntroduction(transcript, {
    allowBareName: speakerOnboardingMatches(recognition) && pendingSpeakerOnboarding?.phase === "awaiting_name",
  });
  if (!isAttributedSpeaker(recognition) && introduction && recognition?.session_speaker_id) {
    try {
      const payload = await bindLiveSessionSpeaker(
        recognition,
        introduction.name,
        introduction.addressNamesProvided ? introduction.addressNames : [],
      );
      updateUserBubbleSpeakerLabel(userBubble, recognition);
      const person = payload.person || {};
      const personName = normalizeNaturalText(person.preferred_name || person.display_name || person.name || introduction.name);
      if (introduction.addressNamesProvided) {
        pendingSpeakerOnboarding = null;
        rememberVoiceEnrollmentOffer(recognition, transcript, person);
        return {handled: true, reply: naturalAddressConfirmation(personName, introduction.addressNames)};
      }
      armSpeakerOnboarding(recognition, "awaiting_address", {
        personEntityId: String(person.id || recognition.person_entity_id || ""),
        personName,
      });
      return {handled: true, reply: `Nice to meet you, ${personName}. What would you like me to call you? ${personName} is fine too.`};
    } catch (error) {
      logEvent("speaker.onboarding.bind_failed", error.message);
      return {handled: true, reply: "I heard your name, but I couldn’t save it just now."};
    }
  }

  if (speakerOnboardingMatches(recognition) && pendingSpeakerOnboarding?.phase === "awaiting_address" && isAttributedSpeaker(recognition)) {
    const preference = parseSpeakerAddressOnboardingReply(transcript, pendingSpeakerOnboarding.personName || recognition.person_name || "");
    if (!preference) return {handled: true, reply: "What would you like me to call you—your name, or something else?"};
    const result = await applyAddressPreferenceCommand(preference, recognition, {source: "voice"});
    if (!result.ok) return {handled: true, reply: result.reply || "I couldn’t save that preference."};
    const person = result.person || {};
    const personName = normalizeNaturalText(person.preferred_name || person.display_name || person.name || recognition.person_name || "");
    pendingSpeakerOnboarding = null;
    rememberVoiceEnrollmentOffer(recognition, transcript, person);
    return {handled: true, reply: naturalAddressConfirmation(personName, person.active_address_names || [])};
  }

  if (unknownSpeakerIdentityMatters(transcript, recognition)) {
    armSpeakerOnboarding(recognition, "awaiting_name");
    return {handled: true, reply: "I don’t know this voice yet. What should I call you?"};
  }
  return {handled: false};
}

async function loadRealtimeProfile(responseMode = ui.responseMode.value) {
  const params = new URLSearchParams({
    response_mode: responseMode,
    timezone_name: clientTimezoneName(),
    client_local_now: clientLocalNowIso(),
  });
  const response = await fetch(`/api/realtime/session-profile?${params.toString()}`, {
    cache: "no-store",
    headers: {"X-Jarvis-Client": CLIENT_HEADER},
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || `Response profile failed (${response.status})`);
  activeRealtimeProfile = payload.profile || null;
  return activeRealtimeProfile;
}

function applyRealtimeSessionInstructions(turnInstructions = "") {
  if (isSimulationMode() || !channel || channel.readyState !== "open") return false;
  const base = String(activeRealtimeProfile?.instructions || "").trim();
  const turn = String(turnInstructions || "").trim();
  const instructions = [base, turn].filter(Boolean).join("\n\nCurrent-turn private guidance:\n");
  const session = {type: "realtime", instructions};
  if (activeRealtimeProfile?.max_output_tokens !== undefined) {
    session.max_output_tokens = activeRealtimeProfile.max_output_tokens;
  }
  sendProviderEvent({type: "session.update", session});
  return true;
}

async function refreshRealtimeProfile({apply = false} = {}) {
  const profile = await loadRealtimeProfile(ui.responseMode.value);
  if (apply) applyRealtimeSessionInstructions();
  return profile;
}

function durableMemoryTurnInstructions(storedMemory = null) {
  if (config?.memory_enabled === false) return "";
  const persisted = Boolean(storedMemory?.event_id);
  return [
    "Durable local memory is enabled in this desktop application.",
    persisted
      ? "The exact user turn has already been written to the local memory ledger."
      : "The local memory service is available even if this turn did not produce a new record.",
    "Never say that you lack a memory database, need a separate memory tool, can remember only for this session, or cannot store or forget information.",
    "If the user is simply sharing a fact, preference, plan, or personal detail, acknowledge it briefly and naturally without discussing storage infrastructure unless asked.",
  ].join(" ");
}

async function querySpecificMemoryTurnContext(userText, recognition = null) {
  const empty = {rendered: "", ambiguous: false, intent: "conversation", subject: null};
  const query = normalizeNaturalText(userText);
  if (!query || config?.memory_enabled === false || isSimulationMode()) return empty;
  const actor = isAttributedSpeaker(recognition) && recognition?.person_name ? recognition.person_name : null;
  try {
    const response = await fetch("/api/memory/context/resolve", {
      method: "POST",
      cache: "no-store",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify({
        query,
        actor: actor || null,
        session_id: clientSessionId || null,
        fact_limit: 14,
        event_limit: 10,
        proactive_limit: 6,
        character_limit: 6200,
      }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Context resolution failed (${response.status})`);
    const resolved = {
      rendered: String(payload.rendered || "").trim(),
      ambiguous: Boolean(payload.ambiguous),
      intent: String(payload.intent || "conversation"),
      subject: payload.subject || null,
    };
    if (resolved.rendered) {
      relayEvent("client.memory_context.resolved", {
        subject: resolved.subject?.name || null,
        ambiguous: resolved.ambiguous,
        intent: resolved.intent,
        facts: Array.isArray(payload.facts) ? payload.facts.length : 0,
        events: Array.isArray(payload.events) ? payload.events.length : 0,
        proactive: Array.isArray(payload.proactive) ? payload.proactive.length : 0,
      });
    }
    return resolved;
  } catch (error) {
    logEvent("memory.context.failed", error.message || "context resolution failed");
    relayEvent("client.memory_context.failed", {message: error.message || "context resolution failed"});
    return empty;
  }
}

async function querySpecificMemoryTurnInstructions(userText, recognition = null) {
  return (await querySpecificMemoryTurnContext(userText, recognition)).rendered;
}

function recentConversationContextForActions() {
  const rows = [...ui.transcript.querySelectorAll(".bubble")].slice(-16);
  const lines = [];
  for (const bubble of rows) {
    const rawLabel = normalizeNaturalText(bubble.querySelector(".speaker")?.textContent || "");
    const speaker = bubble.classList.contains("user")
      ? ((rawLabel && !["YOU", "LISTENING"].includes(rawLabel.toUpperCase())) ? rawLabel : "User")
      : "Jarvis";
    const content = normalizeDetailedText(bubble.querySelector(".content")?.textContent || "");
    if (content) lines.push(`${speaker}: ${content}`);
  }
  const joined = lines.join("\n");
  return joined.length > CONNECTED_ACTION_CONTEXT_MAX_CHARACTERS
    ? joined.slice(joined.length - CONNECTED_ACTION_CONTEXT_MAX_CHARACTERS)
    : joined;
}

function recentConversationContextForNaturalReply(currentUserText = "") {
  const current = normalizeNaturalText(currentUserText || "");
  const lines = recentConversationContextForActions().split("\n").filter(Boolean);
  if (current && lines.length) {
    const last = lines[lines.length - 1];
    const separator = last.indexOf(": ");
    const lastSpeaker = separator >= 0 ? last.slice(0, separator) : "";
    const lastText = separator >= 0 ? last.slice(separator + 2) : last;
    if (lastSpeaker !== "Jarvis" && normalizeNaturalText(lastText) === current) lines.pop();
  }
  return lines.join("\n");
}

function connectedActionDecisionText(userText) {
  let value = normalizeNaturalText(userText || "").replace(/[’‘]/g, "'").trim();
  for (let index = 0; index < 6 && value; index += 1) {
    const before = value;
    value = value.replace(CONNECTED_ACTION_DECISION_VOCATIVE, "");
    value = value.replace(CONNECTED_ACTION_DECISION_PREFACE, "");
    if (value === before) break;
  }
  return value.trim();
}

function connectedActionDecisionCandidates(userText) {
  const decisionText = connectedActionDecisionText(userText);
  if (!decisionText) return [];
  const candidates = [decisionText];
  CONNECTED_ACTION_DECISION_EXPLICIT_START.lastIndex = 0;
  let match = CONNECTED_ACTION_DECISION_EXPLICIT_START.exec(decisionText);
  while (match) {
    const suffix = decisionText.slice(match.index).replace(/^[\s,.;:—-]+/, "").trim();
    if (suffix && suffix !== decisionText) candidates.push(suffix);
    match = CONNECTED_ACTION_DECISION_EXPLICIT_START.exec(decisionText);
  }
  CONNECTED_ACTION_DECISION_EXPLICIT_START.lastIndex = 0;
  return [...new Set(candidates)];
}

function isPendingConnectedActionContinuation(userText) {
  if (!connectedActionPending) return false;
  const normalized = normalizeNaturalText(userText);
  if (!normalized) return false;
  const hasDecision = connectedActionDecisionCandidates(normalized).some((candidate) => CONNECTED_ACTION_CONFIRMATION.test(candidate));
  return hasDecision || CONNECTED_ACTION_PENDING_EDIT.test(normalized);
}

function taskFocusTokens(value) {
  const stop = new Set(["the", "and", "for", "with", "from", "that", "this", "task", "finish", "complete", "done", "get", "need", "today", "tomorrow"]);
  return normalizeNaturalText(value || "").toLowerCase().match(/[a-z0-9][a-z0-9_-]{2,}/g)?.filter((token) => !stop.has(token)) || [];
}

function updateRecentTaskFocus({tasks = [], focusTerms = [], focusItems = [], updatedAt = "", restored = false} = {}) {
  const terms = [];
  const add = (value) => {
    const normalized = normalizeNaturalText(value || "").toLowerCase();
    if (normalized && !terms.includes(normalized)) terms.push(normalized);
  };
  (Array.isArray(focusTerms) ? focusTerms : []).forEach(add);
  (Array.isArray(focusItems) ? focusItems : []).forEach((item) => taskFocusTokens(item).forEach(add));
  (Array.isArray(tasks) ? tasks : []).forEach((task) => {
    taskFocusTokens(task?.title || "").forEach(add);
    taskFocusTokens(task?.notes || "").forEach(add);
  });
  if (terms.length) recentTaskFocusTerms = new Set(terms.slice(0, 40));
  if (Array.isArray(focusItems) && focusItems.length) recentTaskFocusItems = focusItems.map((value) => normalizeDetailedText(value)).filter(Boolean).slice(0, 12);
  if (restored) {
    const timestamp = Date.parse(updatedAt || "");
    if (Number.isFinite(timestamp) && Date.now() - timestamp <= 30 * 60 * 1000) {
      recentTaskContextUntil = Math.max(recentTaskContextUntil, Date.now() + CONNECTED_ACTION_TASK_RESTORED_TTL_MS);
    }
  }
}

function updateRecentTaskFocusFromAction(action = {}) {
  const details = action?.result && typeof action.result === "object" ? action.result : {};
  const tasks = Array.isArray(details.tasks)
    ? details.tasks
    : ((details.title || details.id) ? [details] : []);
  updateRecentTaskFocus({
    tasks,
    focusTerms: Array.isArray(details.focus_terms) ? details.focus_terms : [],
    focusItems: Array.isArray(details.focus_items) ? details.focus_items : [],
  });
}

function hydrateTaskWorkingContext(frame = null) {
  if (!frame || typeof frame !== "object") return;
  const payload = frame.payload && typeof frame.payload === "object" ? frame.payload : {};
  updateRecentTaskFocus({
    tasks: Array.isArray(payload.tasks) ? payload.tasks : [],
    focusTerms: Array.isArray(payload.focus_terms) ? payload.focus_terms : [],
    focusItems: Array.isArray(payload.focus_items) ? payload.focus_items : [],
    updatedAt: frame.updated_at || "",
    restored: true,
  });
}

function taskContextTopicOverlap(userText) {
  const text = normalizeNaturalText(userText || "").toLowerCase();
  if (!text || !recentTaskFocusTerms.size) return false;
  const tokens = new Set(taskFocusTokens(text));
  for (const term of recentTaskFocusTerms) {
    if (term.includes(" ") && text.includes(term)) return true;
    const termTokens = taskFocusTokens(term);
    if (termTokens.length && termTokens.every((token) => tokens.has(token))) return true;
    if (!term.includes(" ") && tokens.has(term)) return true;
  }
  return false;
}

function renderGameModeStatus(status = {}) {
  if (!ui.gameModeWrap || !ui.gameModeText) return;
  const active = Boolean(status?.active);
  const pending = Array.isArray(status?.pending_games) && status.pending_games.length > 0;
  if (!active && !pending) {
    ui.gameModeWrap.hidden = true;
    ui.gameModeWrap.classList.remove("active", "pending");
    ui.gameModeText.textContent = "GAME MODE";
    return;
  }
  const name = normalizeNaturalText(status?.foreground_game || status?.primary_game || status?.pending_games?.[0] || "Protected");
  ui.gameModeWrap.hidden = false;
  ui.gameModeWrap.classList.toggle("active", active);
  ui.gameModeWrap.classList.toggle("pending", !active && pending);
  ui.gameModeText.textContent = active ? `GAME MODE · ${name}` : `GAME MODE · ARMING ${name}`;
  ui.gameModeWrap.title = active
    ? `${name} is protected. Native/synthetic browser shortcuts such as voice-triggered fullscreen are unavailable; structural browser controls like pause, play, volume, and seek remain available.`
    : `Jarvis is identifying ${name}. Native/synthetic browser shortcuts are temporarily unavailable until Game Mode finishes its safety check.`;
}

async function refreshGameModeStatus() {
  if (!config?.game_mode_enabled || isSimulationMode()) {
    renderGameModeStatus({});
    return;
  }
  try {
    const response = await fetch("/api/game-mode/status", {cache: "no-store"});
    if (!response.ok) return;
    renderGameModeStatus(await response.json());
  } catch (_) {}
}

function startGameModePolling() {
  window.clearInterval(gameModePollTimer);
  if (!config?.game_mode_enabled || isSimulationMode()) {
    renderGameModeStatus({});
    return;
  }
  void refreshGameModeStatus();
  gameModePollTimer = window.setInterval(() => void refreshGameModeStatus(), 1000);
}

function computerAppLaunchTarget(userText) {
  const normalized = normalizeNaturalText(userText || "");
  const match = normalized.match(COMPUTER_APP_LAUNCH_HINT);
  return normalizeNaturalText(match?.[1] || "")
    .replace(/\s*[,;:-]?\s*(?:please|thanks|thank\s+you)\s*[.!?]*\s*$/i, "")
    .trim();
}

function browserDirectUrlTarget(userText) {
  const normalized = normalizeNaturalText(userText || "");
  const match = normalized.match(BROWSER_DIRECT_URL_HINT);
  if (!match) return "";
  const raw = String(match[1] || "").trim().replace(/[.!?,;:]+$/g, "");
  if (!raw) return "";
  const explicitScheme = /^https?:\/\//i.test(raw);
  const lowerBare = raw.toLowerCase().split(/[/?#]/, 1)[0].replace(/:\d{1,5}$/, "");
  if (!explicitScheme && lowerBare !== "localhost" && BROWSER_DIRECT_URL_LOCAL_FILE_SUFFIX.test(lowerBare)) return "";
  try {
    const parsed = new URL(explicitScheme ? raw : `https://${raw}`);
    if (!parsed.hostname || parsed.username || parsed.password) return "";
    if (parsed.hostname !== "localhost" && !parsed.hostname.includes(".")) return "";
    return parsed.href;
  } catch (_) {
    return "";
  }
}

function looksLikeContextualPronounAppTarget(target) {
  const normalized = normalizeNaturalText(target || "").toLowerCase();
  // Bare conversational referents are not plausible app names. In particular,
  // "start it over" must never become an app search for "it over" when Browser
  // Control has recent media context; without that context it should fall through
  // to ordinary reasoning/clarification rather than launching an arbitrary app.
  return /^(?:it|this|that)(?:\s+over)?$/.test(normalized);
}

function looksLikeComputerAppClarificationReply(userText) {
  if (recentComputerAppClarificationUntil <= Date.now()) return false;
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized) return false;
  if (/^(?:what|why|how|who|when|where|can|could|would|should|do|does|did|is|are|tell|explain)\b/i.test(normalized)) return false;
  return normalized.split(/\s+/).length <= 8 && normalized.length <= 90;
}

function shouldAttemptComputerAction(userText) {
  if (!config?.computer_actions_enabled || isSimulationMode()) return false;
  const normalized = normalizeNaturalText(userText || "");
  const launchTarget = computerAppLaunchTarget(normalized);
  if (launchTarget && looksLikeContextualPronounAppTarget(launchTarget)) return false;
  // Explicit web addresses belong to Browser Control even though Computer Actions
  // intentionally accepts broad "open X" language. Never let a browser failure or
  // an unmatched result continuation degrade into a local app/file lookup.
  if (browserDirectUrlTarget(normalized)) return false;
  // Browser context owns natural media pronouns before Computer Actions. This is a
  // second boundary behind Browser routing so a media follow-up cannot degrade into
  // an app lookup merely because wording/politeness differs from an exact phrase.
  if (recentBrowserContextUntil > Date.now() && naturalMediaContextFollowupHint(normalized)) return false;
  return Boolean(launchTarget)
    || COMPUTER_APP_CLOSE_HINT.test(normalized)
    || COMPUTER_APP_ALIAS_HINTS.some((pattern) => pattern.test(normalized))
    || COMPUTER_APP_FORGET_ALIAS_HINTS.some((pattern) => pattern.test(normalized))
    || looksLikeComputerAppClarificationReply(normalized);
}

function permissionActorScope(recognition = null, source = "voice") {
  // Permission challenges bind to the live speaker lane, not the cosmetic speaker
  // label. A short "yes" may temporarily display as Unknown speaker while still
  // belonging to the same enrolled speaker lane; a different speaker gets a
  // different session_speaker_id and therefore cannot reuse the challenge.
  if (recognition?.session_speaker_id) return `speaker:${String(recognition.session_speaker_id)}`;
  if (String(source || "").startsWith("typed")) {
    if (config?.local_user_entity_id) return `person:${String(config.local_user_entity_id)}`;
    return "account:typed-local";
  }
  return "voice:unattributed";
}

function computerActionSessionId() {
  const base = clientSessionId || `local-${Date.now()}`;
  // Computer-app clarification is one bounded lane inside the live conversation,
  // not a new session per speaker-recognition result. A short reply can temporarily
  // score as Unknown speaker without losing the pending app choice.
  return `${base}::computer`;
}

async function requestComputerActionTurn(userText, recognition = null, {source = "voice"} = {}) {
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized || !shouldAttemptComputerAction(normalized)) return null;
  if (computerAppRequestInFlight) return null;
  computerAppRequestInFlight = true;
  noteActivity();
  setStatus("Working", "thinking", {immediate: true});
  const actor = isAttributedSpeaker(recognition) ? (recognition.person_name || null) : null;
  const actorScopeId = permissionActorScope(recognition, source);
  const controller = new AbortController();
  let timedOut = false;
  const timer = window.setTimeout(() => {
    timedOut = true;
    try { controller.abort(); } catch (_) {}
  }, COMPUTER_APP_REQUEST_TIMEOUT_MS);
  try {
    const sessionId = computerActionSessionId();
    const requestBody = {
      user_text: normalized,
      actor,
      actor_scope_id: actorScopeId,
      session_id: sessionId,
    };
    const sendComputerRequest = async ({challengeId = "", attestation = "", choice = "", includeSignal = true} = {}) => {
      const headers = {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER};
      if (challengeId) headers["X-Permission-Challenge"] = challengeId;
      if (attestation) headers["X-Permission-Native-Attestation"] = attestation;
      if (choice) headers["X-Permission-Native-Choice"] = choice;
      return fetch("/api/computer/apps/launch", {
        method: "POST",
        headers,
        ...(includeSignal ? {signal: controller.signal} : {}),
        body: JSON.stringify(requestBody),
      });
    };
    let response = await sendComputerRequest();
    let payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(permissionErrorMessage(payload, `Computer action failed (${response.status})`));
    for (let permissionRound = 0; permissionRound < 3; permissionRound += 1) {
      const info = executorPermissionPolicyInfo(payload);
      if (!info) break;
      const approval = await approveExecutorPermissionPolicy(info);
      if (!approval.approved) {
        return {handled: true, status: "cancelled", suppress_speech: true, spoken_text: "", display_text: ""};
      }
      response = await sendComputerRequest({
        challengeId: info.challengeId,
        attestation: approval.attestation,
        choice: approval.choice,
        includeSignal: false,
      });
      payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(permissionErrorMessage(payload, `Computer action failed (${response.status})`));
    }
    if (executorPermissionPolicyInfo(payload)) throw new Error("Computer permission confirmation did not settle safely.");
    if (!payload?.handled) return null;
    if (payload.status === "needs_clarification") {
      recentComputerAppClarificationUntil = Date.now() + COMPUTER_APP_CLARIFICATION_TTL_MS;
    } else {
      recentComputerAppClarificationUntil = 0;
    }
    logEvent("computer_app.action", `${payload.status || "handled"}; ${payload?.app?.name || computerAppLaunchTarget(normalized) || normalized}`);
    void refreshGameModeStatus();
    relayEvent("client.computer_app.handled", {
      status: payload.status || "handled",
      app: payload?.app?.name || null,
      searched_deep: Boolean(payload.searched_deep),
      elapsed_ms: Number(payload.elapsed_ms || 0),
    });
    return payload;
  } catch (error) {
    recentComputerAppClarificationUntil = 0;
    const message = timedOut
      ? "I’m still not finding that app quickly enough, so I stopped the search instead of hanging Jarvis."
      : "I hit a problem searching this PC for that app.";
    logEvent("computer_app.failed", error.message || "computer app action failed");
    return {
      handled: true,
      status: "failed",
      spoken_text: message,
      display_text: message,
      action: {operation: "computer_app_launch", status: "failed"},
    };
  } finally {
    window.clearTimeout(timer);
    computerAppRequestInFlight = false;
    setStatus("Listening", "listening", {immediate: true});
    noteActivity();
  }
}

function shouldSilenceSuccessfulComputerAction(result = {}) {
  const status = String(result?.status || result?.action?.status || "").trim().toLowerCase();
  const operation = String(result?.operation || result?.action?.operation || "").trim().toLowerCase();
  return status === "completed" && ["computer_app_launch", "computer_app_close"].includes(operation);
}

function speakComputerActionResult(result, recognition = null) {
  if (!result?.handled) return;
  if (shouldSilenceSuccessfulComputerAction(result)) {
    logEvent("computer_action.visible_success_silent", String(result?.operation || result?.action?.operation || "computer_action"));
    restoreRealtimeInputAfterSilentTurn("computer_action_silent_complete");
    return;
  }
  const spoken = normalizeNaturalText(result.spoken_text || result.display_text || "Done.");
  if (!spoken) return;
  createExactReply(spoken, recognition, {authoritativeSpeech: "computer_action"});
}

function webIntelligenceSessionId() {
  const base = clientSessionId || `local-${Date.now()}`;
  return `${base}::web`;
}

function rememberWebIntelligenceResult(presentation) {
  const resultId = String(presentation?.result_id || "");
  const displaySources = Array.isArray(presentation?.display_sources) && presentation.display_sources.length
    ? presentation.display_sources
    : presentation?.sources;
  const sources = Array.isArray(displaySources) ? displaySources : [];
  if (!resultId || !sources.length) return;
  recentWebResultId = resultId;
  recentWebSources = sources.map((source) => ({
    id: String(source?.id || ""),
    title: normalizeDetailedText(source?.title || ""),
    domain: normalizeNaturalText(source?.domain || ""),
    url: String(source?.url || ""),
    cited: Boolean(source?.cited),
  })).filter((source) => source.id);
  recentWebContextUntil = Date.now() + WEB_INTELLIGENCE_SOURCE_CONTEXT_TTL_MS;
}

function recentWebSourceForFollowup(userText) {
  if (!recentWebResultId || !recentWebSources.length || Date.now() > recentWebContextUntil) return null;
  const normalized = normalizeNaturalText(userText || "");
  if (WEB_INTELLIGENCE_GENERIC_RESEARCH.test(normalized) || WEB_INTELLIGENCE_RESEARCH_HINT.test(normalized)) return null;
  if (!WEB_INTELLIGENCE_SOURCE_FOLLOWUP.test(normalized)) return null;
  const lower = normalized.toLowerCase();
  const ordinals = [
    [/\b(?:first|1st|source\s*1|result\s*1)\b/i, 0],
    [/\b(?:second|2nd|source\s*2|result\s*2)\b/i, 1],
    [/\b(?:third|3rd|source\s*3|result\s*3)\b/i, 2],
    [/\b(?:fourth|4th|source\s*4|result\s*4)\b/i, 3],
  ];
  for (const [pattern, index] of ordinals) {
    if (pattern.test(normalized) && recentWebSources[index]) return recentWebSources[index];
  }
  const stop = new Set(["open", "show", "view", "take", "me", "to", "go", "the", "a", "an", "source", "result", "page", "site", "website", "link", "it", "that", "please", "official"]);
  const terms = lower.split(/[^a-z0-9]+/).filter((term) => term.length >= 3 && !stop.has(term));
  let best = null;
  let bestScore = 0;
  for (const source of recentWebSources) {
    const haystack = `${source.title} ${source.domain} ${source.url}`.toLowerCase();
    let score = source.cited ? 0.25 : 0;
    for (const term of terms) if (haystack.includes(term)) score += 1;
    if (score > bestScore) {
      best = source;
      bestScore = score;
    }
  }
  if (best && bestScore >= 1) return best;
  return recentWebSources.find((source) => source.cited) || recentWebSources[0] || null;
}

async function requestRecentWebSourceFollowup(userText) {
  const source = recentWebSourceForFollowup(userText);
  if (!source) return null;
  const statusNode = null;
  const opened = await openWebIntelligenceSource(recentWebResultId, source.id, statusNode);
  const label = normalizeNaturalText(source.title || source.domain || "the source");
  if (!opened) {
    return {
      handled: true,
      status: "failed",
      spoken_text: "I found the source, but I couldn't open it in your browser.",
      display_text: "I found the source, but I couldn't open it in your browser.",
    };
  }
  recentWebContextUntil = Date.now() + WEB_INTELLIGENCE_SOURCE_CONTEXT_TTL_MS;
  return {
    handled: true,
    status: "completed",
    spoken_text: `Opening ${label}.`,
    display_text: `Opening ${label}.`,
    action: {operation: "web_source_open", status: "completed", source_id: source.id},
  };
}

function shouldAttemptWebResearch(userText) {
  if (config?.web_intelligence_enabled === false || !providerReadyForLive() || isSimulationMode()) return false;
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized) return false;
  if (WEB_INTELLIGENCE_PAGE_FIND.test(normalized)) return false;
  if (BROWSER_ACTION_MEDIA_EXTENDED.test(normalized)) return false;
  const generic = WEB_INTELLIGENCE_GENERIC_RESEARCH.test(normalized);
  const explicit = WEB_INTELLIGENCE_RESEARCH_HINT.test(normalized);
  if (!generic && !explicit) return false;
  if (WEB_INTELLIGENCE_LOCAL_EXCLUSION.test(normalized)) return false;
  // Explicit browser UI manipulation stays in Browser Control. A research goal that
  // merely says "open it/show me the source" remains Web Intelligence and hands the
  // exact cited URL to Browser Control after the grounded answer is ready.
  if (WEB_INTELLIGENCE_BROWSER_CONTROL.test(normalized)
      && !/\b(?:open\s+(?:it|that|the\s+(?:source|site|website|page|result))|show\s+(?:it|me\s+(?:the\s+)?(?:source|site|website|page))|take\s+me\s+to)\b/i.test(normalized)) {
    return false;
  }
  return true;
}

async function cancelWebResearch(reason = "user_interrupt") {
  if (!webResearchRequestInFlight && !webResearchRequestId) return false;
  try { webResearchAbortController?.abort(); } catch (_) {}
  logEvent("web_intelligence.cancelled", `${reason}; ${webResearchRequestId || "unbound"}`);
  return true;
}

async function requestWebResearchTurn(userText, recognition = null) {
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized) return null;
  const freshResearch = shouldAttemptWebResearch(normalized);
  if (!freshResearch) {
    const sourceFollowup = await requestRecentWebSourceFollowup(normalized);
    if (sourceFollowup?.handled) return sourceFollowup;
    return null;
  }
  if (webResearchRequestInFlight) await cancelWebResearch("superseded_by_new_turn");
  const requestId = `web_${globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID().replaceAll("-", "") : `${Date.now()}_${Math.random().toString(16).slice(2)}`}`;
  const controller = new AbortController();
  webResearchRequestInFlight = true;
  webResearchRequestId = requestId;
  webResearchAbortController = controller;
  noteActivity();
  setStatus("Researching", "thinking", {immediate: true});
  const actor = isAttributedSpeaker(recognition) ? (recognition.person_name || null) : null;
  let timedOut = false;
  const timer = window.setTimeout(() => {
    timedOut = true;
    try { controller.abort(); } catch (_) {}
  }, WEB_INTELLIGENCE_REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch("/api/web/turn", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      signal: controller.signal,
      body: JSON.stringify({
        user_text: normalized,
        actor,
        session_id: webIntelligenceSessionId(),
        usage_session_id: clientSessionId || webIntelligenceSessionId(),
        response_mode: ui.responseMode.value,
        task_id: requestId,
      }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Web Intelligence failed (${response.status})`);
    if (!payload?.handled) return null;
    if (payload?.presentation?.type === "web_search_result") rememberWebIntelligenceResult(payload.presentation);
    applyConnectedActionUsage(payload);
    logEvent("web_intelligence.handled", `${payload.status || "handled"}; ${Array.isArray(payload?.presentation?.sources) ? payload.presentation.sources.length : 0} sources`);
    relayEvent("client.web_intelligence.handled", {
      status: payload.status || "handled",
      sources: Array.isArray(payload?.presentation?.sources) ? payload.presentation.sources.length : 0,
      latency_ms: Number(payload.action_latency_ms || 0),
      browser_handoff: payload?.browser_handoff?.status || null,
    });
    return payload;
  } catch (error) {
    if (permissionConfirmationCancelled(error)) {
      browserActionPendingConfirmation = false;
      return {handled: true, status: "cancelled", suppress_speech: true, spoken_text: "", display_text: ""};
    }
    if (error?.name === "AbortError" && !timedOut) {
      return {handled: true, status: "cancelled", suppress_speech: true, spoken_text: "", display_text: ""};
    }
    const message = timedOut
      ? "I stopped that web research because it took too long."
      : "I hit a problem searching the web.";
    logEvent("web_intelligence.failed", error.message || "web research failed");
    return {handled: true, status: "failed", spoken_text: message, display_text: message};
  } finally {
    window.clearTimeout(timer);
    if (webResearchRequestId === requestId) {
      webResearchRequestInFlight = false;
      webResearchRequestId = "";
      webResearchAbortController = null;
      setStatus("Listening", "listening", {immediate: true});
      noteActivity();
    }
  }
}

function speakWebIntelligenceResult(result, recognition = null, {userText = "", itemId = "", source = "voice"} = {}) {
  if (!result?.handled) return;
  if (result?.suppress_speech) {
    restoreRealtimeInputAfterSilentTurn("web_action_silent_complete");
    return;
  }
  const spoken = normalizeNaturalText(result.spoken_text || result.display_text || "I found the result.");
  if (!spoken) {
    restoreRealtimeInputAfterSilentTurn("web_action_empty_reply");
    return;
  }
  responseCreateWithSpeaker(recognition, {
    exactReply: spoken,
    preparedPresentation: result.presentation && typeof result.presentation === "object" ? result.presentation : null,
    preparedResponseId: String(result.response_id || result.result_id || ""),
    preparedModel: String(result.planner_model || config?.web_intelligence_model || config?.action_model || ""),
    preparedProvider: "web_intelligence",
    authoritativeSpeech: "web_intelligence",
    userText,
    itemId,
    source,
    allowDetailedCompanion: false,
  });
}

function browserActionSessionId() {
  const base = clientSessionId || `local-${Date.now()}`;
  // Browser task continuity belongs to the live conversation, not to a temporary
  // voice-recognition label. A short follow-up may score Unknown speaker without
  // losing the current tab/task or a pending confirmation.
  return `${base}::browser`;
}

function naturalMediaContextFollowupHint(userText) {
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized || recentBrowserContextUntil <= Date.now()) return false;
  if (BROWSER_ACTION_NATURAL_MEDIA_FOLLOWUP.test(normalized)) return true;
  if (!BROWSER_MEDIA_ACTION_HINT.test(normalized)) return false;
  if (BROWSER_MEDIA_TARGET_HINT.test(normalized) || BROWSER_MEDIA_PRONOUN_HINT.test(normalized)) return true;
  return /\b(?:keep\s+(?:it\s+)?playing|continue(?:\s+playing)?|start\s+over|go\s+(?:full\s*screen|fullscreen)|exit\s+(?:full\s*screen|fullscreen))\b/i.test(normalized);
}

function naturalBrowserControlHint(userText) {
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized) return false;
  if (BROWSER_MEDIA_TARGET_HINT.test(normalized) && BROWSER_MEDIA_ACTION_HINT.test(normalized)) return true;
  return naturalMediaContextFollowupHint(normalized);
}

function explicitBrowserActionHint(userText) {
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized) return false;
  if (browserDirectUrlTarget(normalized)) return true;
  if (BROWSER_ACTION_EXPLICIT_HINT.test(normalized) || BROWSER_ACTION_MEDIA_EXTENDED.test(normalized) || naturalBrowserControlHint(normalized)) return true;
  const generic = normalized.match(BROWSER_ACTION_GENERIC_SEARCH);
  return Boolean(generic && !BROWSER_ACTION_SEARCH_EXCLUSION.test(normalized));
}

function shouldAttemptBrowserAction(userText) {
  if (!config?.browser_actions_enabled || isSimulationMode()) return false;
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized) return false;
  if (browserActionPendingConfirmation && BROWSER_ACTION_CONFIRMATION.test(normalized)) return true;
  if (explicitBrowserActionHint(normalized)) return true;
  return recentBrowserContextUntil > Date.now() && (BROWSER_ACTION_CONTEXT_FOLLOWUP.test(normalized) || BROWSER_ACTION_NATURAL_MEDIA_FOLLOWUP.test(normalized));
}

async function cancelBrowserAction(reason = "user_interrupt") {
  const taskId = browserActionRequestId;
  if (!taskId && !browserActionRequestInFlight) return false;
  try { browserActionAbortController?.abort(); } catch (_) {}
  if (taskId) {
    try {
      await fetch(`/api/browser/tasks/${encodeURIComponent(taskId)}/cancel`, {
        method: "POST",
        headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
        body: JSON.stringify({reason}),
        keepalive: true,
      });
    } catch (_) {}
  }
  logEvent("browser_action.cancelled", `${reason}; ${taskId || "unbound"}`);
  return true;
}

async function requestBrowserActionTurn(userText, recognition = null, {source = "voice"} = {}) {
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized || !shouldAttemptBrowserAction(normalized)) return null;
  if (browserActionRequestInFlight) {
    await cancelBrowserAction("superseded_by_new_turn");
  }
  const requestId = `browser_${globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID().replaceAll("-", "") : `${Date.now()}_${Math.random().toString(16).slice(2)}`}`;
  const controller = new AbortController();
  browserActionRequestInFlight = true;
  browserActionRequestId = requestId;
  browserActionAbortController = controller;
  noteActivity();
  setStatus("Working", "thinking", {immediate: true});
  const actor = isAttributedSpeaker(recognition) ? (recognition.person_name || null) : null;
  const actorScopeId = permissionActorScope(recognition, source);
  // Follow-up media language must keep its browser context even when the generic
  // hint function already recognizes it. The old negated explicit-hint check
  // accidentally stripped context from phrases like "keep playing", "start it
  // over", and "go forward half a minute", which then fell into Luna/computer
  // routing instead of the deterministic media executor.
  const contextual = recentBrowserContextUntil > Date.now() && (
    BROWSER_ACTION_CONTEXT_FOLLOWUP.test(normalized) || BROWSER_ACTION_NATURAL_MEDIA_FOLLOWUP.test(normalized) || naturalMediaContextFollowupHint(normalized)
  );
  let timedOut = false;
  const timer = window.setTimeout(() => {
    timedOut = true;
    try { controller.abort(); } catch (_) {}
    void fetch(`/api/browser/tasks/${encodeURIComponent(requestId)}/cancel`, {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify({reason: "client_timeout"}),
      keepalive: true,
    }).catch(() => {});
  }, BROWSER_ACTION_REQUEST_TIMEOUT_MS);
  try {
    const sessionId = browserActionSessionId();
    const requestBody = {
      user_text: normalized,
      actor,
      actor_scope_id: actorScopeId,
      session_id: sessionId,
      usage_session_id: clientSessionId || sessionId,
      conversation_context: recentConversationContextForActions(),
      response_mode: ui.responseMode.value,
      task_id: requestId,
      contextual,
    };
    const sendBrowserRequest = async ({challengeId = "", attestation = "", choice = "", initial = false} = {}) => {
      const headers = {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER};
      if (challengeId) headers["X-Permission-Challenge"] = challengeId;
      if (attestation) headers["X-Permission-Native-Attestation"] = attestation;
      if (choice) headers["X-Permission-Native-Choice"] = choice;
      const options = {
        method: "POST",
        headers,
        ...(initial ? {signal: controller.signal, permissionRetryWithoutSignal: true} : {}),
        body: JSON.stringify(requestBody),
      };
      return initial ? permissionAwareFetch("/api/browser/turn", options) : fetch("/api/browser/turn", options);
    };
    let response = await sendBrowserRequest({initial: true});
    let payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(permissionErrorMessage(payload, `Browser action failed (${response.status})`));
    for (let permissionRound = 0; permissionRound < 3; permissionRound += 1) {
      const info = executorPermissionPolicyInfo(payload);
      if (!info) break;
      const approval = await approveExecutorPermissionPolicy(info);
      if (!approval.approved) {
        browserActionPendingConfirmation = false;
        return {handled: true, status: "cancelled", suppress_speech: true, spoken_text: "", display_text: ""};
      }
      response = await sendBrowserRequest({
        challengeId: info.challengeId,
        attestation: approval.attestation,
        choice: approval.choice,
      });
      payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(permissionErrorMessage(payload, `Browser action failed (${response.status})`));
    }
    if (executorPermissionPolicyInfo(payload)) throw new Error("Browser permission confirmation did not settle safely.");
    if (!payload?.handled) return null;
    applyConnectedActionUsage(payload);
    browserActionPendingConfirmation = payload.status === "pending_confirmation";
    if (["completed", "pending_confirmation", "step_limit", "blocked"].includes(String(payload.status || ""))) {
      recentBrowserContextUntil = Date.now() + BROWSER_ACTION_CONTEXT_TTL_MS;
    } else if (payload.status === "cancelled") {
      recentBrowserContextUntil = 0;
      browserActionPendingConfirmation = false;
    }
    logEvent("browser_action.handled", `${payload.status || "handled"}; ${Array.isArray(payload.steps) ? payload.steps.length : 0} steps`);
    relayEvent("client.browser_action.handled", {
      status: payload.status || "handled",
      steps: Array.isArray(payload.steps) ? payload.steps.length : 0,
      latency_ms: Number(payload.action_latency_ms || 0),
      browser: payload?.browser?.browser_name || null,
    });
    return payload;
  } catch (error) {
    if (error?.name === "AbortError" && !timedOut) {
      return {handled: true, status: "cancelled", suppress_speech: true, spoken_text: "", display_text: ""};
    }
    const message = timedOut
      ? "I stopped that browser task because it ran past the safety time limit."
      : "I hit a problem controlling the browser.";
    logEvent("browser_action.failed", error.message || "browser action failed");
    return {handled: true, status: "failed", spoken_text: message, display_text: message};
  } finally {
    window.clearTimeout(timer);
    if (browserActionRequestId === requestId) {
      browserActionRequestInFlight = false;
      browserActionRequestId = "";
      browserActionAbortController = null;
      setStatus("Listening", "listening", {immediate: true});
      noteActivity();
    }
  }
}

function restoreRealtimeInputAfterSilentTurn(reason = "silent_action_complete") {
  if (wakeInputGateActive) {
    releaseWakeInputGate(reason, {delayMs: 0});
    return true;
  }
  if (!isConnected() || muted) return false;
  let restored = 0;
  localStream?.getAudioTracks().forEach((track) => {
    if (track.readyState === "live" && !track.enabled) {
      track.enabled = true;
      restored += 1;
    }
  });
  if (restored) logEvent("voice.input.restored_after_silent_turn", `${reason}; ${restored} track(s)`);
  return restored > 0;
}

function speakBrowserActionResult(result, recognition = null, {userText = "", itemId = "", source = "voice"} = {}) {
  if (!result?.handled) return;
  if (result?.suppress_speech) {
    restoreRealtimeInputAfterSilentTurn("browser_action_silent_complete");
    return;
  }
  const spoken = normalizeNaturalText(result.spoken_text || result.display_text || "Done.");
  const display = normalizeDetailedText(result.display_text || spoken);
  if (!spoken) {
    restoreRealtimeInputAfterSilentTurn("browser_action_empty_reply");
    return;
  }
  responseCreateWithSpeaker(recognition, {
    exactReply: spoken,
    preparedDisplayText: display,
    preparedResponseId: String(result.task_id || ""),
    preparedModel: String(result.planner_model || config?.action_model || ""),
    preparedProvider: "browser_actions",
    authoritativeSpeech: "browser_action",
    userText,
    itemId,
    source,
    allowDetailedCompanion: false,
  });
}

function shouldAttemptConnectedAction(userText) {
  if (!config?.connected_actions_enabled || isSimulationMode()) return false;
  const normalized = normalizeNaturalText(userText);
  if (!normalized) return false;
  const hasRecentCalendarContext = recentCalendarContextUntil > Date.now();
  const hasCalendarClarification = recentCalendarClarificationUntil > Date.now();
  const hasGenericClarification = recentConnectedActionClarificationUntil > Date.now() && Boolean(recentConnectedActionClarificationRoute);
  const hasRecentTaskContext = recentTaskContextUntil > Date.now();
  return CONNECTED_ACTION_HINT.test(normalized)
    || CONNECTED_ACTION_TASK_HINT.test(normalized)
    || CONNECTED_ACTION_TASK_EXPLICIT_REASONING.test(normalized)
    || (hasRecentTaskContext && (CONNECTED_ACTION_TASK_CONTEXT_FOLLOWUP.test(normalized) || CONNECTED_ACTION_TASK_ATTRIBUTE_FOLLOWUP.test(normalized) || CONNECTED_ACTION_TASK_CONTEXT_SHOW.test(normalized) || CONNECTED_ACTION_TASK_CONTEXT_REASONING.test(normalized) || CONNECTED_ACTION_TASK_CONTEXT_DIALOGUE.test(normalized)))
    || (CONNECTED_ACTION_TASK_CONTEXT_DIALOGUE.test(normalized) && taskContextTopicOverlap(normalized))
    || CONNECTED_ACTION_GMAIL_MARK_READ_HINT.test(normalized)
    || CONNECTED_ACTION_UNIFIED_AGENDA_HINT.test(normalized)
    || CONNECTED_ACTION_CALENDAR_AGENDA_HINT.test(normalized)
    || CONNECTED_ACTION_FREE_HINT.test(normalized)
    || (hasRecentCalendarContext && CONNECTED_ACTION_CALENDAR_CONTEXT_FOLLOWUP.test(normalized))
    || (hasCalendarClarification && (CONNECTED_ACTION_CALENDAR_CLARIFICATION_REPLY.test(normalized) || CONNECTED_ACTION_CALENDAR_SELECTION_CLARIFICATION.test(normalized) || CONNECTED_ACTION_CALENDAR_INFLIGHT_CONTINUATION.test(normalized)))
    || hasGenericClarification
    || isPendingConnectedActionContinuation(normalized);
}

function beginConnectedActionVoiceOwnership() {
  connectedActionVoiceOwnerUntil = Date.now() + 30000;
}

function connectedActionResponseTokenFromEvent(event = {}) {
  return String(
    event.response?.metadata?.connected_action_token
    || event.metadata?.connected_action_token
    || "",
  ).trim();
}

function armConnectedActionSpeechResponse() {
  const randomPart = globalThis.crypto?.randomUUID
    ? globalThis.crypto.randomUUID().replaceAll("-", "")
    : `${Date.now()}_${Math.random().toString(16).slice(2)}`;
  connectedActionExpectedResponseToken = `connected_action_${randomPart}`;
  connectedActionAuthorizedResponseId = "";
  connectedActionVoiceOwnerUntil = Date.now() + 20000;
  return connectedActionExpectedResponseToken;
}

function suppressUnownedConnectedActionResponse(event = {}) {
  if (Date.now() > connectedActionVoiceOwnerUntil) return false;
  if (sleepSequenceActive || sleepAcknowledgementPending) return false;
  const responseId = providerResponseId(event) || resolvedResponseId(event);
  const token = connectedActionResponseTokenFromEvent(event);
  if (connectedActionExpectedResponseToken && token === connectedActionExpectedResponseToken) {
    connectedActionAuthorizedResponseId = responseId || connectedActionAuthorizedResponseId;
    connectedActionExpectedResponseToken = "";
    logEvent("connected_action.response.authorized", responseId || token);
    return false;
  }
  if (connectedActionAuthorizedResponseId && responseId === connectedActionAuthorizedResponseId) return false;
  if (responseId) interruptedResponseIds.add(responseId);
  try {
    if (channel?.readyState === "open") {
      sendProviderEvent({type: "response.cancel"});
      sendProviderEvent({type: "output_audio_buffer.clear"});
    }
  } catch (error) {
    logEvent("connected_action.unowned_response_cancel_failed", error.message || "cancel failed");
  }
  logEvent("connected_action.unowned_response_suppressed", responseId || "unbound response");
  relayEvent("client.connected_action.unowned_response_suppressed", {response_id: responseId || null});
  return true;
}

function clearConnectedActionVoiceOwnership(responseId = "") {
  if (responseId && connectedActionAuthorizedResponseId && responseId !== connectedActionAuthorizedResponseId) return;
  connectedActionVoiceOwnerUntil = 0;
  connectedActionExpectedResponseToken = "";
  connectedActionAuthorizedResponseId = "";
}

function applyConnectedActionLatency(payload) {
  const milliseconds = Number(payload?.action_latency_ms);
  if (!Number.isFinite(milliseconds) || milliseconds < 0) return;
  if (ui.lastActionLatency) {
    ui.lastActionLatency.textContent = milliseconds < 1000
      ? `${Math.round(milliseconds)} ms`
      : `${(milliseconds / 1000).toFixed(milliseconds < 10000 ? 1 : 0)} s`;
  }
}

function applyConnectedActionUsage(payload) {
  applyConnectedActionLatency(payload);
  if (payload?.summary) usageSummary = payload.summary;
  if (payload?.budget) budgetState = payload.budget;
  lastUsageSummaryAt = Date.now();
  const records = Array.isArray(payload?.records) ? payload.records : [];
  if (records.length) {
    latestResponseCostUsd = records.reduce((total, record) => total + Number(record?.cost_usd?.total || 0), 0);
  }
  // A live-session cost counter is cumulative by definition. Never let an
  // action response or an out-of-order summary visually rewind the session.
  sessionCostUsd = Math.max(sessionCostUsd, moneyFromSummary("session"));
  updateUsageMetrics();
}

function updateConnectedActionPending(result) {
  const actionStatus = String(result?.action?.status || "");
  const resultStatus = String(result?.status || "");
  if (actionStatus === "pending_confirmation" || resultStatus === "pending_confirmation") {
    connectedActionPending = true;
    return;
  }
  if (["completed", "cancelled", "failed", "expired", "blocked"].includes(actionStatus)
    || ["completed", "cancelled", "failed", "expired", "blocked"].includes(resultStatus)) {
    connectedActionPending = false;
  }
}

function connectedActionFailureResult(userText, message = "") {
  const normalized = normalizeNaturalText(userText);
  const target = CONNECTED_ACTION_UNIFIED_AGENDA_HINT.test(normalized)
    ? "your agenda"
    : CONNECTED_ACTION_TASK_HINT.test(normalized)
      ? "Tasks"
      : (CONNECTED_ACTION_CALENDAR_HINT.test(normalized) || CONNECTED_ACTION_CALENDAR_AGENDA_HINT.test(normalized) || CONNECTED_ACTION_FREE_HINT.test(normalized))
        ? "Calendar"
      : /\b(emails?|e-mails?|gmail|inbox|mail|messages?|drafts?|send|reply|forward)\b/i.test(normalized)
        ? "Gmail"
        : "Google";
  const spoken = message || `I hit a problem using ${target}. Please try that again.`;
  return {
    handled: true,
    status: "failed",
    spoken_text: spoken,
    display_text: spoken,
    action: null,
    planner_model: config?.action_model || "",
  };
}

function clearGenericConnectedActionClarification(reason = "") {
  recentConnectedActionClarificationRoute = "";
  recentConnectedActionClarificationUntil = 0;
  if (reason) logEvent("connected_action.clarification_context.cleared", reason);
}

function connectedActionNeedsStrictSpeech(result = {}) {
  const operation = String(result?.action?.operation || "").trim().toLowerCase();
  const status = String(result?.status || "").trim().toLowerCase();
  if (!operation) return false;
  if (["needs_clarification", "routing_failed", "planner_failed", "failed", "not_connected", "needs_reconnect"].includes(status)) return false;
  if (["gmail_create_draft", "gmail_update_draft", "gmail_reply_draft", "gmail_send_draft"].includes(operation)) return false;
  return operation === "agenda_list"
    || operation.startsWith("task_")
    || operation.startsWith("calendar_")
    || operation === "gmail_search"
    || operation === "gmail_read_thread"
    || operation === "gmail_mark_read"
    || operation === "contact_search"
    || operation === "google_brief"
    || operation === "gmail_to_calendar";
}

function clientLocalNowIso() {
  const now = new Date();
  const pad = (value) => String(Math.abs(Number(value) || 0)).padStart(2, "0");
  const offsetMinutes = -now.getTimezoneOffset();
  const sign = offsetMinutes >= 0 ? "+" : "-";
  const offsetHours = Math.floor(Math.abs(offsetMinutes) / 60);
  const offsetRemainder = Math.abs(offsetMinutes) % 60;
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`
    + `T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`
    + `${sign}${pad(offsetHours)}:${pad(offsetRemainder)}`;
}

function clientTimezoneName() {
  return normalizeNaturalText(Intl.DateTimeFormat().resolvedOptions().timeZone || "local") || "local";
}

function clientUtcOffsetLabel(date = new Date()) {
  const offsetMinutes = -date.getTimezoneOffset();
  const sign = offsetMinutes >= 0 ? "+" : "-";
  const absolute = Math.abs(offsetMinutes);
  return `UTC${sign}${String(Math.floor(absolute / 60)).padStart(2, "0")}:${String(absolute % 60).padStart(2, "0")}`;
}

function authoritativeClientTimeInstructions(date = new Date()) {
  const localTime = new Intl.DateTimeFormat("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
    hour: "numeric", minute: "2-digit", second: "2-digit", hour12: true,
  }).format(date);
  return [
    "Authoritative user-local clock from the Jarvis desktop:",
    `Current local date/time: ${localTime}.`,
    `Current local timestamp: ${clientLocalNowIso()}.`,
    `Desktop timezone label: ${clientTimezoneName()}.`,
    `Desktop UTC offset: ${clientUtcOffsetLabel(date)}.`,
    "The desktop wall clock and explicit UTC offset are authoritative if any server, provider, stored-record, or timezone label disagrees.",
    "Never say that I cannot see the current local time/date when this context is present.",
  ].join("\n");
}

function localTemporalReply(userText, date = new Date()) {
  const normalized = normalizeNaturalText(userText);
  if (LOCAL_CURRENT_TIME_HINT.test(normalized)) {
    const time = new Intl.DateTimeFormat("en-US", {hour: "numeric", minute: "2-digit", hour12: true}).format(date);
    return `It’s ${time}.`;
  }
  if (LOCAL_CURRENT_DATE_HINT.test(normalized)) {
    const day = new Intl.DateTimeFormat("en-US", {weekday: "long", month: "long", day: "numeric", year: "numeric"}).format(date);
    return `Today is ${day}.`;
  }
  return "";
}

function liveSpeakerContextKey(recognition = null) {
  if (isAttributedSpeaker(recognition) && recognition?.person_entity_id) return `person:${recognition.person_entity_id}`;
  if (recognition?.session_speaker_id) return `session:${recognition.session_speaker_id}`;
  return "unknown";
}

function connectedActionSessionIdForSpeaker(recognition = null) {
  const base = clientSessionId || `local-${Date.now()}`;
  return `${base}::${liveSpeakerContextKey(recognition)}`;
}

function connectedActionClarificationActive() {
  const now = Date.now();
  return recentConnectedActionClarificationUntil > now || recentCalendarClarificationUntil > now;
}

function connectedActionHasExecutionDecision(userText) {
  const normalized = normalizeNaturalText(userText || "");
  if (!normalized) return false;
  return connectedActionDecisionCandidates(normalized).some((candidate) => CONNECTED_ACTION_CONFIRMATION.test(candidate));
}

function connectedActionMayReuseUnknownContinuation(userText, recognition = null) {
  if (isAttributedSpeaker(recognition) || !connectedActionContextSessionId) return false;
  if (connectedActionClarificationActive()) return true;
  const normalized = normalizeNaturalText(userText || "");
  if (!connectedActionPending) return false;
  // Short replies are exactly where speaker biometrics are least reliable. Unknown
  // may therefore continue the already-active session for edits, yes/no, send/cancel,
  // etc. This does not authorize execution: consequential actions still cross the
  // native trusted-permission boundary before the executor can consume a grant.
  if (connectedActionHasExecutionDecision(normalized)) return true;
  return CONNECTED_ACTION_PENDING_EDIT.test(normalized);
}

function resetConnectedActionContextForSpeaker(reason = "speaker_switch") {
  recentCalendarContextUntil = 0;
  recentCalendarClarificationUntil = 0;
  recentConnectedActionClarificationUntil = 0;
  recentConnectedActionClarificationRoute = "";
  recentTaskContextUntil = 0;
  recentTaskFocusTerms = new Set();
  recentTaskFocusItems = [];
  connectedActionContextSessionId = "";
  connectedActionContextOwnerAttributed = false;
  clearGenericConnectedActionClarification(reason);
  logEvent("connected_action.speaker_context.reset", reason);
}

async function requestConnectedActionTurn(userText, recognition = null) {
  const normalizedText = normalizeNaturalText(userText);
  if (!normalizedText) return null;
  let shouldAttempt = shouldAttemptConnectedAction(normalizedText);

  const attributedSpeaker = isAttributedSpeaker(recognition);
  const actor = attributedSpeaker ? (recognition.person_name || null) : null;
  const speakerContextKey = liveSpeakerContextKey(recognition);
  const unknownDecisionAgainstAttributedOwner = Boolean(
    connectedActionPending
    && !attributedSpeaker
    && connectedActionContextOwnerAttributed
    && connectedActionHasExecutionDecision(normalizedText)
  );
  if (unknownDecisionAgainstAttributedOwner) {
    // Speaker recognition is advisory for conversational continuity, not the
    // final authorization boundary. Short/unclear utterances frequently fall
    // back to Unknown even when the same person is still speaking. The reuse
    // decision below keeps the original action session; any consequential
    // executor still reaches the trusted permission surface before execution.
    logEvent("connected_action.unknown_decision_continued", connectedActionContextSpeakerKey || "unknown");
  }
  const reuseUnknownContinuation = connectedActionMayReuseUnknownContinuation(normalizedText, recognition);

  // Speaker recognition is useful evidence, but a transient Unknown result must not
  // destroy an active clarification turn. Keep the original Connected Action session
  // for non-executing clarification text so phrases like "Say hi" can finish the
  // draft that Jarvis just asked about. A positively attributed different person still
  // resets the context immediately.
  if (connectedActionContextSpeakerKey && connectedActionContextSpeakerKey !== speakerContextKey && !reuseUnknownContinuation) {
    resetConnectedActionContextForSpeaker(`speaker_switch:${connectedActionContextSpeakerKey}->${speakerContextKey}`);
    connectedActionContextSpeakerKey = "";
  }

  if (!connectedActionContextSpeakerKey) connectedActionContextSpeakerKey = speakerContextKey;
  if (!connectedActionContextSessionId) connectedActionContextSessionId = connectedActionSessionIdForSpeaker(recognition);
  if (attributedSpeaker) connectedActionContextOwnerAttributed = true;

  const actionSessionId = reuseUnknownContinuation
    ? connectedActionContextSessionId
    : (connectedActionContextSpeakerKey === speakerContextKey
      ? connectedActionContextSessionId
      : connectedActionSessionIdForSpeaker(recognition));

  if (reuseUnknownContinuation) {
    logEvent(connectedActionHasExecutionDecision(normalizedText)
      ? "connected_action.unknown_decision_continuity"
      : "connected_action.unknown_clarification_continuity", connectedActionContextSpeakerKey);
  }

  const requestKey = `${actionSessionId}|${actor || "unknown"}|${transcriptFingerprint(normalizedText)}`;
  const inFlightCalendarContinuation = Boolean(
    connectedActionRequestPromise
    && connectedActionRequestRoute === "calendar"
    && CONNECTED_ACTION_CALENDAR_INFLIGHT_CONTINUATION.test(normalizedText)
  );
  if (!shouldAttempt && !inFlightCalendarContinuation) return null;
  beginConnectedActionVoiceOwnership();

  // Realtime can surface more than one completion event for the same user turn.
  // A natural pause can also finalize an incomplete Calendar phrase ("schedule a
  // meeting with Tanner for...") immediately before the user says "tomorrow at
  // 3 PM, please." If that continuation arrives while the first action is still
  // planning, wait for the Calendar clarification, suppress its now-stale spoken
  // question, then re-route the continuation through Connected Actions.
  if (connectedActionRequestPromise) {
    if (connectedActionRequestKey === requestKey) {
      logEvent("connected_action.request.coalesced", normalizedText.slice(0, 120));
      return await connectedActionRequestPromise;
    }
    const priorKey = connectedActionRequestKey;
    if (inFlightCalendarContinuation && priorKey) {
      connectedActionSupersededRequestKeys.add(priorKey);
      logEvent("connected_action.calendar_continuation_wait", normalizedText.slice(0, 120));
    }
    try {
      await connectedActionRequestPromise;
    } catch (_) {
      // The original caller receives the bounded failure result. A genuinely new
      // turn may proceed after the prior request settles.
    }
    if (inFlightCalendarContinuation) {
      recentCalendarClarificationUntil = Date.now() + CONNECTED_ACTION_CALENDAR_CLARIFICATION_TTL_MS;
      shouldAttempt = true;
    }
  }

  connectedActionRequestInFlight = true;
  connectedActionRequestKey = requestKey;
  const clarificationRoute = recentConnectedActionClarificationUntil > Date.now()
    ? recentConnectedActionClarificationRoute
    : "";
  const calendarRoute = CONNECTED_ACTION_CALENDAR_HINT.test(normalizedText)
    || CONNECTED_ACTION_CALENDAR_AGENDA_HINT.test(normalizedText)
    || CONNECTED_ACTION_FREE_HINT.test(normalizedText)
    || (recentCalendarContextUntil > Date.now() && CONNECTED_ACTION_CALENDAR_CONTEXT_FOLLOWUP.test(normalizedText))
    || (recentCalendarClarificationUntil > Date.now() && (CONNECTED_ACTION_CALENDAR_CLARIFICATION_REPLY.test(normalizedText) || CONNECTED_ACTION_CALENDAR_SELECTION_CLARIFICATION.test(normalizedText) || CONNECTED_ACTION_CALENDAR_INFLIGHT_CONTINUATION.test(normalizedText)));
  const taskRoute = CONNECTED_ACTION_TASK_HINT.test(normalizedText)
    || CONNECTED_ACTION_TASK_EXPLICIT_REASONING.test(normalizedText)
    || (recentTaskContextUntil > Date.now() && (CONNECTED_ACTION_TASK_CONTEXT_FOLLOWUP.test(normalizedText) || CONNECTED_ACTION_TASK_ATTRIBUTE_FOLLOWUP.test(normalizedText) || CONNECTED_ACTION_TASK_CONTEXT_SHOW.test(normalizedText) || CONNECTED_ACTION_TASK_CONTEXT_REASONING.test(normalizedText) || CONNECTED_ACTION_TASK_CONTEXT_DIALOGUE.test(normalizedText)))
    || (CONNECTED_ACTION_TASK_CONTEXT_DIALOGUE.test(normalizedText) && taskContextTopicOverlap(normalizedText));
  if (CONNECTED_ACTION_UNIFIED_AGENDA_HINT.test(normalizedText)) connectedActionRequestRoute = "agenda";
  else if (calendarRoute) connectedActionRequestRoute = "calendar";
  else if (taskRoute) connectedActionRequestRoute = "tasks";
  else if (CONNECTED_ACTION_HINT.test(normalizedText) || CONNECTED_ACTION_GMAIL_MARK_READ_HINT.test(normalizedText)) connectedActionRequestRoute = "google";
  else connectedActionRequestRoute = clarificationRoute;
  const activeConnectedActionRoute = connectedActionRequestRoute;
  noteActivity();
  setStatus("Working", "thinking", {immediate: true});
  relayEvent("client.connected_action.started", {characters: normalizedText.length});

  const requestPromise = (async () => {
    try {
      const actionController = new AbortController();
      let actionTimedOut = false;
      const actionTimeout = window.setTimeout(() => {
        actionTimedOut = true;
        try { actionController.abort(); } catch (_) {}
      }, CONNECTED_ACTION_REQUEST_TIMEOUT_MS);
      let response;
      try {
        response = await permissionAwareFetch("/api/actions/turn", {
          method: "POST",
          headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
          signal: actionController.signal,
          permissionRetryWithoutSignal: true,
          body: JSON.stringify({
            user_text: normalizedText,
            actor,
            conversation_context: recentConversationContextForActions(),
            response_mode: ui.responseMode.value,
            session_id: actionSessionId,
            usage_session_id: clientSessionId || actionSessionId,
            timezone_name: clientTimezoneName(),
            client_local_now: clientLocalNowIso(),
            personality: currentVoicePersonality(),
          }),
        });
      } catch (error) {
        if (actionTimedOut) throw new Error("Connected action timed out. Jarvis released the turn so you can keep talking.");
        throw error;
      } finally {
        window.clearTimeout(actionTimeout);
      }
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.detail || `Connected action failed (${response.status})`);
      applyConnectedActionUsage(payload);
      updateConnectedActionPending(payload);
      const calendarRequest = CONNECTED_ACTION_CALENDAR_HINT.test(normalizedText)
        || CONNECTED_ACTION_CALENDAR_AGENDA_HINT.test(normalizedText)
        || CONNECTED_ACTION_FREE_HINT.test(normalizedText)
        || (recentCalendarContextUntil > Date.now() && CONNECTED_ACTION_CALENDAR_CONTEXT_FOLLOWUP.test(normalizedText))
        || (recentCalendarClarificationUntil > Date.now() && (CONNECTED_ACTION_CALENDAR_CLARIFICATION_REPLY.test(normalizedText) || CONNECTED_ACTION_CALENDAR_SELECTION_CLARIFICATION.test(normalizedText) || CONNECTED_ACTION_CALENDAR_INFLIGHT_CONTINUATION.test(normalizedText)));
      if (payload?.status === "needs_clarification" && calendarRequest) {
        recentCalendarClarificationUntil = Date.now() + CONNECTED_ACTION_CALENDAR_CLARIFICATION_TTL_MS;
      } else if (calendarRequest && payload?.handled) {
        recentCalendarClarificationUntil = 0;
      }
      if (payload?.status === "needs_clarification" && activeConnectedActionRoute && activeConnectedActionRoute !== "calendar") {
        recentConnectedActionClarificationRoute = activeConnectedActionRoute;
        recentConnectedActionClarificationUntil = Date.now() + CONNECTED_ACTION_GENERIC_CLARIFICATION_TTL_MS;
        logEvent("connected_action.clarification_context.armed", activeConnectedActionRoute);
      } else if (payload?.handled && recentConnectedActionClarificationRoute === activeConnectedActionRoute) {
        clearGenericConnectedActionClarification("handled");
      }
      if (String(payload?.action?.operation || "").startsWith("task_")) {
        recentTaskContextUntil = Date.now() + CONNECTED_ACTION_TASK_CONTEXT_TTL_MS;
        updateRecentTaskFocusFromAction(payload.action);
        void loadTaskDashboard();
      }
      if (String(payload?.action?.operation || "") === "agenda_list") {
        const agendaTasks = Array.isArray(payload?.action?.result?.tasks) ? payload.action.result.tasks : [];
        const agendaEvents = Array.isArray(payload?.action?.result?.events) ? payload.action.result.events : [];
        if (agendaTasks.length) {
          recentTaskContextUntil = Date.now() + CONNECTED_ACTION_TASK_CONTEXT_TTL_MS;
          updateRecentTaskFocusFromAction(payload.action);
        }
        if (agendaEvents.length) recentCalendarContextUntil = Date.now() + CONNECTED_ACTION_CALENDAR_CONTEXT_TTL_MS;
        void loadTaskDashboard();
      }
      void loadConnectedActionAuditState();
      if (!payload.handled) {
        logEvent("connected_action.routing_fell_through", normalizedText.slice(0, 180));
        clearGenericConnectedActionClarification("routing_fell_through");
        clearConnectedActionVoiceOwnership();
        setStatus("Listening", "listening", {immediate: true});
        return connectedActionFailureResult(userText, "I lost the action context for that one. Try the request once more.");
      }
      if (["routing_failed", "planner_failed", "failed"].includes(String(payload?.status || ""))) {
        clearGenericConnectedActionClarification(String(payload.status));
      }
      logEvent("connected_action.handled", `${payload.status || "handled"}; ${payload.action?.operation || "none"}; ${payload.planner_model || config?.action_model || "planner"}`);
      return payload;
    } catch (error) {
      if (permissionConfirmationCancelled(error)) {
        logEvent("connected_action.cancelled", "trusted permission confirmation denied");
        clearGenericConnectedActionClarification("permission_cancelled");
        clearConnectedActionVoiceOwnership();
        connectedActionPending = false;
        setStatus("Listening", "listening", {immediate: true});
        return {
          handled: true,
          status: "cancelled",
          suppress_speech: true,
          spoken_text: "",
          display_text: "",
          action: null,
          planner_model: config?.action_model || "",
        };
      }
      logEvent("connected_action.failed", error.message || "connected action failed");
      clearGenericConnectedActionClarification("request_failed");
      clearConnectedActionVoiceOwnership();
      setStatus("Listening", "listening", {immediate: true});
      ui.configurationMessage.textContent = error.message || "Connected action failed.";
      return connectedActionFailureResult(userText);
    }
  })();

  connectedActionRequestPromise = requestPromise;
  try {
    const result = await requestPromise;
    if (connectedActionSupersededRequestKeys.delete(requestKey) && result?.status === "needs_clarification") {
      return {...result, suppress_speech: true};
    }
    return result;
  } finally {
    if (connectedActionRequestPromise === requestPromise) {
      connectedActionRequestPromise = null;
      connectedActionRequestKey = "";
      connectedActionRequestRoute = "";
      connectedActionRequestInFlight = false;
      noteActivity();
    }
  }
}

function connectedActionPresentation(result) {
  const action = result?.action || {};
  const operation = String(action.operation || "");
  const actionStatus = String(action.status || "");
  let details = action.result && typeof action.result === "object" ? action.result : {};

  const normalizeReadEmail = (message, index = 0) => {
    const source = message && typeof message === "object" ? message : {};
    const labels = Array.isArray(source.label_ids) ? source.label_ids.map((value) => String(value || "").toUpperCase()) : [];
    return {
      id: normalizeNaturalText(source.id || `email-${index}`),
      from: normalizeDetailedText(source.from || ""),
      to: normalizeDetailedText(source.to || ""),
      subject: normalizeDetailedText(source.subject || "") || "(no subject)",
      date: normalizeDetailedText(source.date || ""),
      body: normalizeDetailedText(source.body || source.snippet || ""),
      unread: labels.includes("UNREAD"),
    };
  };

  const normalizeCalendarAttendees = (value) => (Array.isArray(value) ? value : []).map((item) => {
    if (item && typeof item === "object") {
      return {
        email: normalizeNaturalText(item.email || ""),
        displayName: normalizeDetailedText(item.display_name || item.displayName || ""),
        responseStatus: normalizeNaturalText(item.response_status || item.responseStatus || ""),
        optional: Boolean(item.optional),
        self: Boolean(item.self),
      };
    }
    return {email: normalizeNaturalText(item || ""), displayName: "", responseStatus: "", optional: false, self: false};
  }).filter((item) => item.email || item.displayName);

  const normalizeCalendarEvent = (event, index = 0) => {
    const source = event && typeof event === "object" ? event : {};
    return {
      id: normalizeNaturalText(source.id || source.event_id || `event-${index}`),
      summary: normalizeDetailedText(source.summary || source.event_summary || "") || "Untitled event",
      description: normalizeDetailedText(source.description || source.event_description || ""),
      location: normalizeDetailedText(source.location || source.event_location || ""),
      start: normalizeNaturalText(source.start || ""),
      end: normalizeNaturalText(source.end || ""),
      timezone: normalizeNaturalText(source.timezone || ""),
      allDay: Boolean(source.all_day || source.allDay),
      status: normalizeNaturalText(source.status || ""),
      htmlLink: normalizeNaturalText(source.html_link || source.htmlLink || ""),
      attendees: normalizeCalendarAttendees(source.attendees),
      conflicts: Array.isArray(source.conflicts) ? source.conflicts.map((value, conflictIndex) => normalizeCalendarEvent(value, conflictIndex)) : [],
      availabilityNote: normalizeDetailedText(source.availability_note || ""),
    };
  };

  const normalizeTask = (task, index = 0) => {
    const source = task && typeof task === "object" ? task : {};
    return {
      id: normalizeNaturalText(source.id || `task-${index}`),
      title: normalizeDetailedText(source.title || "") || "Untitled task",
      notes: normalizeDetailedText(source.notes || ""),
      status: normalizeNaturalText(source.status || "open") || "open",
      priority: normalizeNaturalText(source.priority || "normal") || "normal",
      dueAt: normalizeNaturalText(source.due_at || source.dueAt || ""),
      reminderAt: normalizeNaturalText(source.reminder_at || source.reminderAt || ""),
      timezone: normalizeNaturalText(source.timezone || ""),
      recurrence: normalizeNaturalText(source.recurrence || "none") || "none",
      actor: normalizeDetailedText(source.actor || ""),
      recurrenceAdvanced: Boolean(source.recurrence_advanced),
    };
  };

  if (["task_list", "task_context"].includes(operation) && actionStatus === "completed") {
    if (String(details.presentation_mode || "") === "spoken_only") return null;
    const tasks = Array.isArray(details.tasks) ? details.tasks.map(normalizeTask) : [];
    return {type: "tasks", label: operation === "task_context" ? "TASK CONTEXT" : "TASKS", status: `${tasks.length} task${tasks.length === 1 ? "" : "s"}`, tasks};
  }

  if (["task_create", "task_update", "task_complete", "task_reopen", "task_delete"].includes(operation) && actionStatus === "completed") {
    const task = normalizeTask(details);
    return {
      type: "task",
      label: operation === "task_create" ? (task.reminderAt ? "NEW REMINDER" : "NEW TASK")
        : operation === "task_complete" ? "TASK COMPLETED"
          : operation === "task_reopen" ? "TASK REOPENED"
            : operation === "task_delete" ? "TASK REMOVED" : "TASK UPDATED",
      status: task.status === "completed" ? "Completed" : task.status === "cancelled" ? "Removed" : (task.reminderAt ? "Reminder set" : "Open"),
      task,
    };
  }

  if (operation === "gmail_search" && actionStatus === "completed") {
    if (String(details.presentation_mode || "") === "unread_overview") return null;
    const messages = Array.isArray(details.messages)
      ? details.messages.map(normalizeReadEmail).filter((message) => message.from || message.to || message.subject || message.body)
      : [];
    if (!messages.length) return null;
    return {
      type: "email_messages",
      label: messages.length === 1 ? "GMAIL MESSAGE" : "GMAIL MESSAGES",
      status: `${messages.length} message${messages.length === 1 ? "" : "s"}`,
      messages,
    };
  }

  if (operation === "gmail_read_thread" && actionStatus === "completed") {
    const thread = details.thread && typeof details.thread === "object" ? details.thread : {};
    const messages = Array.isArray(thread.messages)
      ? thread.messages.map(normalizeReadEmail).filter((message) => message.from || message.to || message.subject || message.body)
      : [];
    if (!messages.length) return null;
    return {
      type: "email_messages",
      label: messages.length === 1 ? "GMAIL MESSAGE" : "GMAIL THREAD",
      status: `${messages.length} message${messages.length === 1 ? "" : "s"}`,
      messages,
    };
  }

  if (operation === "calendar_list" && actionStatus === "completed") {
    const events = Array.isArray(details.events)
      ? details.events.map(normalizeCalendarEvent).filter((event) => event.start || event.summary)
      : [];
    if (!events.length) return null;
    return {
      type: "calendar_events",
      label: events.length === 1 ? "CALENDAR EVENT" : "CALENDAR EVENTS",
      status: `${events.length} event${events.length === 1 ? "" : "s"}`,
      events,
    };
  }

  if (operation === "calendar_freebusy" && actionStatus === "completed") {
    const slots = Array.isArray(details.available_slots) ? details.available_slots.map((slot) => ({
      start: normalizeNaturalText(slot?.start || ""),
      end: normalizeNaturalText(slot?.end || ""),
    })).filter((slot) => slot.start && slot.end) : [];
    return {
      type: "calendar_availability",
      label: "CALENDAR AVAILABILITY",
      status: slots.length ? `${slots.length} open option${slots.length === 1 ? "" : "s"}` : "No open slots",
      slots,
      timezone: normalizeNaturalText(details.timezone || ""),
      durationMinutes: Number(details.duration_minutes || 30),
    };
  }

  if (["calendar_create", "calendar_update", "calendar_delete"].includes(operation)) {
    const argumentsPayload = action.arguments && typeof action.arguments === "object" ? action.arguments : {};
    const resultPreview = details.event_preview && typeof details.event_preview === "object" ? details.event_preview : {};
    const deletedEvent = details.event && typeof details.event === "object" ? details.event : {};
    let source = {};
    let label = "CALENDAR EVENT";
    let status = "";
    if (actionStatus === "pending_confirmation") {
      source = argumentsPayload.event_preview && typeof argumentsPayload.event_preview === "object"
        ? argumentsPayload.event_preview
        : argumentsPayload;
      if (operation === "calendar_create") {
        label = "NEW CALENDAR EVENT";
        status = "Ready to schedule · Not created";
      } else if (operation === "calendar_update") {
        label = "CALENDAR UPDATE";
        status = "Ready to update · Not changed";
      } else {
        label = "REMOVE CALENDAR EVENT";
        status = "Ready to remove · Still on calendar";
      }
    } else if (actionStatus === "completed") {
      source = operation === "calendar_delete" ? (deletedEvent.id ? deletedEvent : resultPreview) : {...resultPreview, ...details};
      if (operation === "calendar_create") {
        label = "EVENT SCHEDULED";
        status = "Scheduled";
      } else if (operation === "calendar_update") {
        label = "EVENT UPDATED";
        status = "Updated";
      } else {
        label = "EVENT REMOVED";
        status = "Removed";
      }
    } else {
      return null;
    }
    const event = normalizeCalendarEvent(source);
    if (!event.start && !event.summary) return null;
    return {
      type: "calendar_event",
      label,
      status,
      operation,
      event,
    };
  }

  let label = operation === "gmail_reply_draft" ? "REPLY DRAFT" : "EMAIL DRAFT";
  let status = "Draft saved · Not sent";

  if (["gmail_create_draft", "gmail_reply_draft", "gmail_update_draft"].includes(operation)) {
    if (actionStatus !== "completed" && String(result?.status || "") !== "completed") return null;
  } else if (operation === "gmail_send_draft") {
    if (actionStatus === "pending_confirmation") {
      const argumentsPayload = action.arguments && typeof action.arguments === "object" ? action.arguments : {};
      details = argumentsPayload.draft_preview && typeof argumentsPayload.draft_preview === "object"
        ? argumentsPayload.draft_preview
        : {};
      label = "EMAIL DRAFT";
    } else if (actionStatus === "completed") {
      details = details.draft_preview && typeof details.draft_preview === "object" ? details.draft_preview : details;
      label = "EMAIL SENT";
      status = "Sent";
    } else {
      return null;
    }
  } else {
    return null;
  }

  const from = normalizeDetailedText(details.from_email || "");
  const to = Array.isArray(details.to) ? details.to.map((value) => normalizeNaturalText(value)).filter(Boolean) : [];
  const cc = Array.isArray(details.cc) ? details.cc.map((value) => normalizeNaturalText(value)).filter(Boolean) : [];
  const bcc = Array.isArray(details.bcc) ? details.bcc.map((value) => normalizeNaturalText(value)).filter(Boolean) : [];
  const subject = normalizeDetailedText(details.subject || "");
  const body = normalizeDetailedText(details.body || details.draft_body || "");
  if (!from && !to.length && !subject && !body) return null;
  const argumentsPayload = action.arguments && typeof action.arguments === "object" ? action.arguments : {};
  const draftId = normalizeNaturalText(argumentsPayload.draft_id || details.draft_id || "");
  return {
    type: "email_draft",
    label,
    status,
    actionId: normalizeNaturalText(action.id || ""),
    draftId,
    editable: label !== "EMAIL SENT" && actionStatus === "pending_confirmation" && Boolean(action.id && draftId),
    from, to, cc, bcc, subject, body,
  };
}
function emailDraftCsv(value) {
  return String(value || "").split(",").map((item) => item.trim()).filter(Boolean);
}

async function saveEmailDraftEdits(bubble, presentation, values) {
  if (!bubble || !presentation?.actionId) return null;
  const response = await fetch(`/api/actions/${encodeURIComponent(presentation.actionId)}/draft`, {
    method: "POST",
    headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
    body: JSON.stringify({
      recipients: emailDraftCsv(values.to),
      cc: emailDraftCsv(values.cc),
      bcc: emailDraftCsv(values.bcc),
      subject: String(values.subject || ""),
      body: String(values.body || ""),
      actor: isAttributedSpeaker(latestSpeakerRecognition) ? (latestSpeakerRecognition.person_name || null) : null,
      session_id: clientSessionId || "controls",
    }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || `Draft update failed (${response.status})`);
  applyConnectedActionLatency(payload);
  updateConnectedActionPending(payload);
  renderPendingAction(payload.action || null);
  const nextPresentation = connectedActionPresentation(payload);
  if (nextPresentation) {
    const content = bubble.querySelector(".content");
    if (content) content.textContent = normalizeNaturalText(payload.spoken_text || "Updated. The draft is saved and still not sent.");
    renderEmailDraftPreview(bubble, nextPresentation);
  }
  void loadConnectedActionAuditState();
  return payload;
}

function beginEmailDraftEdit(preview, bubble, presentation) {
  if (!preview || !bubble || !presentation?.editable) return;
  preview.classList.add("email-draft-preview-editing");
  bubble.classList.add("email-draft-editing");
  preview.replaceChildren();

  const header = document.createElement("div");
  header.className = "email-draft-preview-head";
  const label = document.createElement("strong");
  label.textContent = "EDIT EMAIL DRAFT";
  const status = document.createElement("span");
  status.textContent = "Changes save to Gmail · Not sent";
  header.append(label, status);

  const form = document.createElement("div");
  form.className = "email-draft-edit-form";
  const fields = document.createElement("div");
  fields.className = "email-draft-edit-fields";
  const controls = {};
  const addInput = (key, labelText, value, {multiline = false, readOnly = false} = {}) => {
    const field = document.createElement("label");
    field.className = `email-draft-edit-field${multiline ? " email-draft-edit-field-message" : ""}`;
    const labelNode = document.createElement("span");
    labelNode.textContent = labelText;
    const control = multiline ? document.createElement("textarea") : document.createElement("input");
    if (!multiline) control.type = "text";
    control.value = String(value || "");
    control.readOnly = readOnly;
    if (readOnly) control.classList.add("read-only");
    if (multiline) control.rows = 10;
    field.append(labelNode, control);
    fields.append(field);
    controls[key] = control;
  };
  addInput("from", "From", presentation.from || "", {readOnly: true});
  addInput("to", "To", (presentation.to || []).join(", "));
  addInput("cc", "Cc", (presentation.cc || []).join(", "));
  addInput("bcc", "Bcc", (presentation.bcc || []).join(", "));
  addInput("subject", "Subject", presentation.subject || "");
  addInput("body", "Message", presentation.body || "", {multiline: true});

  const footer = document.createElement("div");
  footer.className = "email-draft-edit-footer";
  const feedback = document.createElement("div");
  feedback.className = "email-draft-edit-feedback";
  const actions = document.createElement("div");
  actions.className = "email-draft-edit-actions";
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.className = "secondary";
  cancel.textContent = "Cancel";
  const save = document.createElement("button");
  save.type = "button";
  save.className = "primary";
  save.textContent = "Save changes";
  actions.append(cancel, save);
  footer.append(feedback, actions);
  form.append(fields, footer);
  preview.append(header, form);

  cancel.addEventListener("click", () => {
    bubble.classList.remove("email-draft-editing");
    if (activeMessageReaderBubble === bubble && preview.closest("#messageReaderOverlay")) {
      refreshOpenMessageReader();
    } else {
      renderEmailDraftPreview(bubble, presentation);
      if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
    }
  });
  save.addEventListener("click", async () => {
    save.disabled = true;
    cancel.disabled = true;
    feedback.textContent = "Saving changes to Gmail…";
    try {
      await saveEmailDraftEdits(bubble, presentation, {
        to: controls.to.value, cc: controls.cc.value, bcc: controls.bcc.value,
        subject: controls.subject.value, body: controls.body.value,
      });
      bubble.classList.remove("email-draft-editing");
      feedback.textContent = "Saved.";
      if (activeMessageReaderBubble === bubble) refreshOpenMessageReader();
      if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
    } catch (error) {
      feedback.textContent = error.message || "Could not save the draft changes.";
      save.disabled = false;
      cancel.disabled = false;
    }
  });
  controls.subject?.focus();
}

function renderEmailDraftPreview(bubble, presentation) {
  if (!bubble || presentation?.type !== "email_draft") return null;
  bubble.classList.remove("email-draft-editing");
  bubble.querySelector(".connected-action-presentation")?.remove();
  const preview = document.createElement("section");
  preview.className = "connected-action-presentation email-draft-preview";
  preview.setAttribute("aria-label", "Gmail draft preview");

  const header = document.createElement("div");
  header.className = "email-draft-preview-head";
  const label = document.createElement("strong");
  label.textContent = presentation.label || "EMAIL DRAFT";
  const headerActions = document.createElement("div");
  headerActions.className = "email-draft-preview-head-actions";
  const status = document.createElement("span");
  status.textContent = presentation.status || "Not sent";
  headerActions.append(status);
  if (presentation.editable) {
    const edit = document.createElement("button");
    edit.type = "button";
    edit.className = "email-draft-edit-button";
    edit.textContent = "Edit";
    edit.setAttribute("aria-label", "Edit this Gmail draft manually");
    edit.addEventListener("click", () => beginEmailDraftEdit(preview, bubble, presentation));
    headerActions.append(edit);
  }
  header.append(label, headerActions);

  const fields = document.createElement("div");
  fields.className = "email-draft-preview-fields";
  const addField = (name, value) => {
    const normalized = normalizeDetailedText(value || "");
    if (!normalized) return;
    const row = document.createElement("div");
    row.className = "email-draft-preview-field";
    const key = document.createElement("span");
    key.textContent = name;
    const fieldValue = document.createElement("div");
    fieldValue.textContent = normalized;
    row.append(key, fieldValue);
    fields.append(row);
  };
  addField("From", presentation.from || "");
  addField("To", (presentation.to || []).join(", "));
  addField("Cc", (presentation.cc || []).join(", "));
  addField("Bcc", (presentation.bcc || []).join(", "));
  addField("Subject", presentation.subject || "(no subject)");

  const body = document.createElement("div");
  body.className = "email-draft-preview-body";
  const bodyLabel = document.createElement("span");
  bodyLabel.className = "email-draft-preview-body-label";
  bodyLabel.textContent = "Message";
  const bodyText = document.createElement("div");
  bodyText.className = "email-draft-preview-body-text";
  bodyText.textContent = presentation.body || "";
  body.append(bodyLabel, bodyText);

  preview.append(header, fields, body);
  bubble.classList.add("email-draft-answer");
  bubble._emailDraftPresentation = presentation;
  bubble.append(preview);
  bubble.dataset.presentationText = [
    ...(presentation.from ? [`From: ${presentation.from}`] : []),
    `To: ${(presentation.to || []).join(", ")}`,
    ...(presentation.cc?.length ? [`Cc: ${presentation.cc.join(", ")}`] : []),
    ...(presentation.bcc?.length ? [`Bcc: ${presentation.bcc.join(", ")}`] : []),
    `Subject: ${presentation.subject || "(no subject)"}`,
    "",
    presentation.body || "",
  ].join("\n");
  if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
  updateBubbleReaderControl(bubble);
  return preview;
}

function renderEmailMessagesPresentation(bubble, presentation) {
  if (!bubble || presentation?.type !== "email_messages") return null;
  bubble.querySelector(".connected-action-presentation")?.remove();

  const group = document.createElement("section");
  group.className = "connected-action-presentation email-read-presentation";
  group.setAttribute("aria-label", "Gmail message view");

  const messages = Array.isArray(presentation.messages) ? presentation.messages : [];
  messages.forEach((message, index) => {
    const card = document.createElement("article");
    card.className = "email-draft-preview email-read-preview";

    const header = document.createElement("div");
    header.className = "email-draft-preview-head";
    const label = document.createElement("strong");
    label.textContent = messages.length > 1 ? `GMAIL MESSAGE ${index + 1}` : (presentation.label || "GMAIL MESSAGE");
    const status = document.createElement("span");
    const statusParts = [];
    if (message.unread) statusParts.push("Unread");
    if (message.date) statusParts.push(message.date);
    status.textContent = statusParts.join(" · ") || "Gmail";
    header.append(label, status);

    const fields = document.createElement("div");
    fields.className = "email-draft-preview-fields";
    const addField = (name, value) => {
      const normalized = normalizeDetailedText(value || "");
      if (!normalized) return;
      const row = document.createElement("div");
      row.className = "email-draft-preview-field";
      const key = document.createElement("span");
      key.textContent = name;
      const fieldValue = document.createElement("div");
      fieldValue.textContent = normalized;
      row.append(key, fieldValue);
      fields.append(row);
    };
    addField("From", message.from || "");
    addField("To", message.to || "");
    addField("Subject", message.subject || "(no subject)");

    const body = document.createElement("div");
    body.className = "email-draft-preview-body";
    const bodyLabel = document.createElement("span");
    bodyLabel.className = "email-draft-preview-body-label";
    bodyLabel.textContent = "Message";
    const bodyText = document.createElement("div");
    bodyText.className = "email-draft-preview-body-text";
    bodyText.textContent = message.body || "(No message preview available)";
    body.append(bodyLabel, bodyText);

    card.append(header, fields, body);
    group.append(card);
  });

  bubble.classList.add("email-draft-answer", "email-read-answer");
  bubble.append(group);
  bubble.dataset.presentationText = messages.map((message) => [
    `From: ${message.from || ""}`,
    `To: ${message.to || ""}`,
    `Subject: ${message.subject || "(no subject)"}`,
    "",
    message.body || "",
  ].join("\n")).join("\n\n---\n\n");
  if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
  updateBubbleReaderControl(bubble);
  return group;
}


function calendarUsesBrowserLocalZone(timezoneName = "") {
  return /^UTC[+-]\d{2}:\d{2}$/i.test(normalizeNaturalText(timezoneName || ""));
}

function calendarIntlTimezone(timezoneName = "") {
  const zone = normalizeNaturalText(timezoneName || "");
  return calendarUsesBrowserLocalZone(zone) ? "" : zone;
}

function calendarTimezoneLabel(timezoneName = "") {
  const zone = normalizeNaturalText(timezoneName || "");
  return calendarUsesBrowserLocalZone(zone) ? "Local time" : zone;
}

function calendarDisplayDate(value, timezoneName = "") {
  const text = normalizeNaturalText(value || "");
  if (!text) return "";
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return text;
  try {
    return new Intl.DateTimeFormat(undefined, {
      weekday: "long", month: "long", day: "numeric", year: "numeric",
      ...(calendarIntlTimezone(timezoneName) ? {timeZone: calendarIntlTimezone(timezoneName)} : {}),
    }).format(date);
  } catch (_) {
    return new Intl.DateTimeFormat(undefined, {weekday: "long", month: "long", day: "numeric", year: "numeric"}).format(date);
  }
}

function calendarDisplayTime(value, timezoneName = "") {
  const text = normalizeNaturalText(value || "");
  if (!text) return "";
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return text;
  try {
    return new Intl.DateTimeFormat(undefined, {
      hour: "numeric", minute: "2-digit",
      ...(calendarIntlTimezone(timezoneName) ? {timeZone: calendarIntlTimezone(timezoneName)} : {}),
    }).format(date);
  } catch (_) {
    return new Intl.DateTimeFormat(undefined, {hour: "numeric", minute: "2-digit"}).format(date);
  }
}

function calendarTimeRange(event) {
  if (!event) return "";
  if (event.allDay) return "All day";
  const start = calendarDisplayTime(event.start, event.timezone);
  const end = calendarDisplayTime(event.end, event.timezone);
  if (start && end) return `${start} – ${end}`;
  return start || end;
}

function calendarAttendeeLabel(attendee) {
  const name = normalizeDetailedText(attendee?.displayName || "");
  const email = normalizeNaturalText(attendee?.email || "");
  if (name && email) return `${name} <${email}>`;
  return name || email;
}

function renderCalendarEventCard(event, {label = "CALENDAR EVENT", status = "", compact = false} = {}) {
  const card = document.createElement("article");
  card.className = `calendar-event-preview${compact ? " calendar-event-preview-compact" : ""}`;

  const header = document.createElement("div");
  header.className = "calendar-event-preview-head";
  const heading = document.createElement("strong");
  heading.textContent = label;
  const statusNode = document.createElement("span");
  statusNode.textContent = status || "Calendar";
  header.append(heading, statusNode);

  const main = document.createElement("div");
  main.className = "calendar-event-preview-main";
  const title = document.createElement("div");
  title.className = "calendar-event-preview-title";
  title.textContent = normalizeDetailedText(event?.summary || "Untitled event");
  main.append(title);

  const date = calendarDisplayDate(event?.start, event?.timezone);
  const time = calendarTimeRange(event);
  const meta = document.createElement("div");
  meta.className = "calendar-event-preview-meta";
  if (date) {
    const dateNode = document.createElement("div");
    dateNode.className = "calendar-event-preview-date";
    dateNode.textContent = date;
    meta.append(dateNode);
  }
  if (time) {
    const timeNode = document.createElement("div");
    timeNode.className = "calendar-event-preview-time";
    timeNode.textContent = time;
    meta.append(timeNode);
  }
  if (event?.timezone && !event?.allDay) {
    const zone = document.createElement("div");
    zone.className = "calendar-event-preview-zone";
    zone.textContent = calendarTimezoneLabel(event.timezone);
    meta.append(zone);
  }
  if (meta.childElementCount) main.append(meta);

  const detailRows = document.createElement("div");
  detailRows.className = "calendar-event-preview-details";
  const addDetail = (name, value) => {
    const normalized = normalizeDetailedText(value || "");
    if (!normalized) return;
    const row = document.createElement("div");
    row.className = "calendar-event-preview-detail";
    const key = document.createElement("span");
    key.textContent = name;
    const body = document.createElement("div");
    body.textContent = normalized;
    row.append(key, body);
    detailRows.append(row);
  };
  addDetail("Location", event?.location || "");
  const attendees = Array.isArray(event?.attendees)
    ? event.attendees.map(calendarAttendeeLabel).filter(Boolean)
    : [];
  if (attendees.length) addDetail("Attendees", attendees.join(", "));
  if (event?.description) addDetail("Notes", event.description);
  if (detailRows.childElementCount) main.append(detailRows);

  const conflicts = Array.isArray(event?.conflicts) ? event.conflicts : [];
  if (conflicts.length) {
    const warning = document.createElement("div");
    warning.className = "calendar-event-preview-warning";
    const names = conflicts.slice(0, 3).map((item) => normalizeDetailedText(item?.summary || "another event")).filter(Boolean);
    warning.textContent = `Conflict: ${names.join(", ") || "another event"}`;
    main.append(warning);
  }
  if (event?.availabilityNote) {
    const note = document.createElement("div");
    note.className = "calendar-event-preview-note";
    note.textContent = event.availabilityNote;
    main.append(note);
  }

  card.append(header, main);
  return card;
}

function renderCalendarEventPresentation(bubble, presentation) {
  if (!bubble || presentation?.type !== "calendar_event") return null;
  bubble.querySelector(".connected-action-presentation")?.remove();
  const group = document.createElement("section");
  group.className = "connected-action-presentation calendar-event-presentation";
  group.setAttribute("aria-label", "Calendar event preview");
  group.append(renderCalendarEventCard(presentation.event || {}, {
    label: presentation.label || "CALENDAR EVENT",
    status: presentation.status || "Calendar",
  }));
  bubble.classList.add("calendar-event-answer");
  bubble.append(group);
  bubble.dataset.presentationText = [
    presentation.event?.summary || "Untitled event",
    calendarDisplayDate(presentation.event?.start, presentation.event?.timezone),
    calendarTimeRange(presentation.event),
    presentation.event?.location ? `Location: ${presentation.event.location}` : "",
    presentation.event?.attendees?.length ? `Attendees: ${presentation.event.attendees.map(calendarAttendeeLabel).filter(Boolean).join(", ")}` : "",
    presentation.event?.description || "",
  ].filter(Boolean).join("\n");
  recentCalendarContextUntil = Date.now() + CONNECTED_ACTION_CALENDAR_CONTEXT_TTL_MS;
  if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
  updateBubbleReaderControl(bubble);
  return group;
}

function renderCalendarEventsPresentation(bubble, presentation) {
  if (!bubble || presentation?.type !== "calendar_events") return null;
  bubble.querySelector(".connected-action-presentation")?.remove();
  const group = document.createElement("section");
  group.className = "connected-action-presentation calendar-event-presentation calendar-event-list-presentation";
  group.setAttribute("aria-label", "Calendar events");
  const events = Array.isArray(presentation.events) ? presentation.events : [];
  events.forEach((event, index) => {
    group.append(renderCalendarEventCard(event, {
      label: events.length > 1 ? `CALENDAR EVENT ${index + 1}` : (presentation.label || "CALENDAR EVENT"),
      status: event.status && event.status !== "confirmed" ? event.status : "Calendar",
      compact: events.length > 1,
    }));
  });
  bubble.classList.add("calendar-event-answer");
  bubble.append(group);
  bubble.dataset.presentationText = events.map((event) => [
    event.summary || "Untitled event",
    calendarDisplayDate(event.start, event.timezone),
    calendarTimeRange(event),
  ].filter(Boolean).join(" — ")).join("\n");
  recentCalendarContextUntil = Date.now() + CONNECTED_ACTION_CALENDAR_CONTEXT_TTL_MS;
  if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
  updateBubbleReaderControl(bubble);
  return group;
}

function renderCalendarAvailabilityPresentation(bubble, presentation) {
  if (!bubble || presentation?.type !== "calendar_availability") return null;
  bubble.querySelector(".connected-action-presentation")?.remove();
  const group = document.createElement("section");
  group.className = "connected-action-presentation calendar-availability-presentation";
  group.setAttribute("aria-label", "Calendar availability");

  const header = document.createElement("div");
  header.className = "calendar-availability-head";
  const label = document.createElement("strong");
  label.textContent = presentation.label || "CALENDAR AVAILABILITY";
  const status = document.createElement("span");
  status.textContent = presentation.status || "Availability";
  header.append(label, status);
  group.append(header);

  const slots = Array.isArray(presentation.slots) ? presentation.slots : [];
  const list = document.createElement("div");
  list.className = "calendar-availability-slots";
  slots.slice(0, 8).forEach((slot, index) => {
    const row = document.createElement("div");
    row.className = "calendar-availability-slot";
    const number = document.createElement("span");
    number.textContent = String(index + 1).padStart(2, "0");
    const body = document.createElement("div");
    const date = calendarDisplayDate(slot.start, presentation.timezone);
    const start = calendarDisplayTime(slot.start, presentation.timezone);
    const end = calendarDisplayTime(slot.end, presentation.timezone);
    body.textContent = `${date}${date && start ? " · " : ""}${start}${end ? ` – ${end}` : ""}`;
    row.append(number, body);
    list.append(row);
  });
  if (!slots.length) {
    const empty = document.createElement("div");
    empty.className = "calendar-availability-empty";
    empty.textContent = "No open slots in that window.";
    list.append(empty);
  }
  group.append(list);
  bubble.classList.add("calendar-event-answer");
  bubble.append(group);
  bubble.dataset.presentationText = slots.map((slot) => `${calendarDisplayDate(slot.start, presentation.timezone)} · ${calendarDisplayTime(slot.start, presentation.timezone)} – ${calendarDisplayTime(slot.end, presentation.timezone)}`).join("\n");
  recentCalendarContextUntil = Date.now() + CONNECTED_ACTION_CALENDAR_CONTEXT_TTL_MS;
  if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
  updateBubbleReaderControl(bubble);
  return group;
}

function taskDateTimeLabel(value) {
  const normalized = normalizeNaturalText(value || "");
  if (!normalized) return "";
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) return normalized;
  return new Intl.DateTimeFormat(undefined, {weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit"}).format(date);
}

function renderTaskCard(task, {label = "TASK", status = "Open", compact = false} = {}) {
  const card = document.createElement("article");
  card.className = `task-preview${compact ? " task-preview-compact" : ""}`;
  const head = document.createElement("div");
  head.className = "task-preview-head";
  const headLabel = document.createElement("strong");
  headLabel.textContent = label;
  const state = document.createElement("span");
  state.textContent = status;
  head.append(headLabel, state);
  const main = document.createElement("div");
  main.className = "task-preview-main";
  const title = document.createElement("h3");
  title.textContent = task?.title || "Untitled task";
  main.append(title);
  const meta = document.createElement("div");
  meta.className = "task-preview-meta";
  const pieces = [];
  if (task?.priority && task.priority !== "normal") pieces.push(task.priority.toUpperCase());
  if (task?.dueAt) pieces.push(`Due ${taskDateTimeLabel(task.dueAt)}`);
  if (task?.reminderAt) pieces.push(`Remind ${taskDateTimeLabel(task.reminderAt)}`);
  if (task?.recurrence && task.recurrence !== "none") pieces.push(`Repeats ${task.recurrence}`);
  pieces.forEach((piece) => { const span = document.createElement("span"); span.textContent = piece; meta.append(span); });
  if (meta.childElementCount) main.append(meta);
  if (task?.notes) { const notes = document.createElement("p"); notes.className = "task-preview-notes"; notes.textContent = task.notes; main.append(notes); }
  card.append(head, main);
  return card;
}

function renderTaskPresentation(bubble, presentation) {
  if (!bubble || !["task", "tasks"].includes(presentation?.type)) return null;
  bubble.querySelector(".connected-action-presentation")?.remove();
  const group = document.createElement("section");
  group.className = "connected-action-presentation task-presentation";
  group.setAttribute("aria-label", "Tasks");
  const tasks = presentation.type === "task" ? [presentation.task] : (Array.isArray(presentation.tasks) ? presentation.tasks : []);
  tasks.forEach((task, index) => group.append(renderTaskCard(task, {
    label: presentation.type === "task" ? presentation.label : (tasks.length > 1 ? `TASK ${index + 1}` : "TASK"),
    status: presentation.type === "task" ? presentation.status : (task.status === "completed" ? "Completed" : "Open"),
    compact: tasks.length > 1,
  })));
  bubble.classList.add("task-answer");
  bubble.append(group);
  bubble.dataset.presentationText = tasks.map((task) => [task.title, task.dueAt ? `Due ${taskDateTimeLabel(task.dueAt)}` : "", task.reminderAt ? `Reminder ${taskDateTimeLabel(task.reminderAt)}` : "", task.notes || ""].filter(Boolean).join(" — ")).join("\n");
  recentTaskContextUntil = Date.now() + CONNECTED_ACTION_TASK_CONTEXT_TTL_MS;
  updateRecentTaskFocus({tasks});
  if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
  updateBubbleReaderControl(bubble);
  return group;
}


function currentTaskActor() {
  if (isAttributedSpeaker(latestSpeakerRecognition) && latestSpeakerRecognition.person_name) {
    return normalizeNaturalText(latestSpeakerRecognition.person_name);
  }
  return "";
}

function taskApiQuery(extra = {}) {
  const params = new URLSearchParams();
  const actor = currentTaskActor();
  if (actor) params.set("actor", actor);
  params.set("timezone_name", clientTimezoneName());
  params.set("client_local_now", clientLocalNowIso());
  Object.entries(extra || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && String(value) !== "") params.set(key, String(value));
  });
  const query = params.toString();
  return query ? `?${query}` : "";
}

async function taskApiRequest(path, {method = "GET", body = null} = {}) {
  const options = {method, cache: "no-store", headers: {"X-Jarvis-Client": CLIENT_HEADER}};
  if (body !== null) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const response = await fetch(path, options);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || `Task request failed (${response.status})`);
  return payload;
}

function taskDashboardEmpty(target, title, detail) {
  if (!target) return;
  target.textContent = "";
  const empty = document.createElement("div");
  empty.className = "empty-state compact";
  const strong = document.createElement("strong");
  strong.textContent = title;
  const span = document.createElement("span");
  span.textContent = detail;
  empty.append(strong, span);
  target.append(empty);
}

function taskDashboardItem(task, {completed = false} = {}) {
  const item = document.createElement("article");
  item.className = "task-dashboard-item";
  item.dataset.taskId = normalizeNaturalText(task?.id || "");

  const copy = document.createElement("div");
  copy.className = "task-dashboard-copy";
  const title = document.createElement("strong");
  title.textContent = normalizeDetailedText(task?.title || "Task");
  copy.append(title);

  const chips = document.createElement("div");
  chips.className = "task-dashboard-chips";
  const addChip = (text, className = "") => {
    if (!text) return;
    const chip = document.createElement("span");
    chip.className = `task-dashboard-chip ${className}`.trim();
    chip.textContent = text;
    chips.append(chip);
  };
  if (completed) addChip("Completed", "completed");
  else if (task?.priority && task.priority !== "normal") addChip(String(task.priority).toUpperCase(), `priority-${task.priority}`);
  if (task?.due_at || task?.dueAt) addChip(`Due ${taskDateTimeLabel(task.due_at || task.dueAt)}`);
  if (task?.reminder_at || task?.reminderAt) addChip(`Reminder ${taskDateTimeLabel(task.reminder_at || task.reminderAt)}`);
  if (task?.recurrence && task.recurrence !== "none") addChip(`Repeats ${task.recurrence}`);
  if (chips.childElementCount) copy.append(chips);

  if (task?.notes) {
    const notes = document.createElement("p");
    notes.textContent = normalizeDetailedText(task.notes);
    copy.append(notes);
  }

  const actions = document.createElement("div");
  actions.className = "task-dashboard-actions";
  const actionButton = (label, handler, className = "secondary") => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.textContent = label;
    button.addEventListener("click", async () => {
      button.disabled = true;
      try { await handler(); }
      catch (error) { ui.configurationMessage.textContent = error.message || "Task action failed."; }
      finally { button.disabled = false; }
    });
    actions.append(button);
  };
  const id = encodeURIComponent(String(task?.id || ""));
  const actorQuery = taskApiQuery();
  if (completed) {
    actionButton("Reopen", async () => {
      await taskApiRequest(`/api/tasks/${id}/reopen${actorQuery}`, {method: "POST"});
      await loadTaskDashboard();
    });
  } else {
    actionButton("Complete", async () => {
      await taskApiRequest(`/api/tasks/${id}/complete${actorQuery}`, {method: "POST"});
      await loadTaskDashboard();
    }, "primary");
  }
  actionButton("Remove", async () => {
    await taskApiRequest(`/api/tasks/${id}${actorQuery}`, {method: "DELETE"});
    await loadTaskDashboard();
  }, "danger");

  item.append(copy, actions);
  return item;
}

function renderTaskDashboardList(target, tasks, {completed = false} = {}) {
  if (!target) return;
  target.textContent = "";
  const list = Array.isArray(tasks) ? tasks : [];
  if (!list.length) {
    taskDashboardEmpty(
      target,
      completed ? "No completed tasks yet" : "No open tasks",
      completed ? "Completed items will stay available here." : "Say “Jarvis, add…” or “remind me…” to create one.",
    );
    return;
  }
  list.forEach((task) => target.append(taskDashboardItem(task, {completed})));
}

async function loadTaskDashboard() {
  if (!ui.taskOpenList && !ui.homeTaskStatus) return null;
  try {
    const [openPayload, completedPayload] = await Promise.all([
      taskApiRequest(`/api/tasks${taskApiQuery({status: "open", limit: 100})}`),
      taskApiRequest(`/api/tasks${taskApiQuery({status: "completed", limit: 50})}`),
    ]);
    const stats = openPayload?.stats || completedPayload?.stats || {};
    hydrateTaskWorkingContext(openPayload?.working_context || completedPayload?.working_context || null);
    const openTasks = Array.isArray(openPayload?.tasks) ? openPayload.tasks : [];
    const completedTasks = Array.isArray(completedPayload?.tasks) ? completedPayload.tasks : [];
    if (ui.taskOpenMetric) ui.taskOpenMetric.textContent = String(Number(stats.open || 0));
    if (ui.taskOverdueMetric) ui.taskOverdueMetric.textContent = String(Number(stats.overdue || 0));
    if (ui.taskCompletedMetric) ui.taskCompletedMetric.textContent = String(Number(stats.completed || 0));
    renderTaskDashboardList(ui.taskOpenList, openTasks, {completed: false});
    renderTaskDashboardList(ui.taskCompletedList, completedTasks, {completed: true});

    if (ui.homeTaskStatus) {
      const overdue = Number(stats.overdue || 0);
      const open = Number(stats.open || 0);
      ui.homeTaskStatus.textContent = overdue > 0
        ? `${overdue} overdue task${overdue === 1 ? "" : "s"}`
        : `${open} open task${open === 1 ? "" : "s"}`;
    }
    if (ui.homeTaskDetail) {
      const first = openTasks[0];
      ui.homeTaskDetail.textContent = first?.title || "No tasks need your attention";
    }
    return {openTasks, completedTasks, stats};
  } catch (error) {
    logEvent("tasks.dashboard.failed", error.message || "Task dashboard failed");
    if (ui.homeTaskStatus) ui.homeTaskStatus.textContent = "Tasks unavailable";
    if (ui.homeTaskDetail) ui.homeTaskDetail.textContent = "Jarvis could not load the local task store";
    return null;
  }
}

function surfaceTaskReminder(task) {
  const taskId = normalizeNaturalText(task?.id || "");
  if (!taskId || surfacedReminderIds.has(taskId)) return;
  surfacedReminderIds.add(taskId);
  const title = normalizeDetailedText(task?.title || "Task reminder");
  const actor = normalizeNaturalText(task?.actor || "");
  const message = actor && actor !== currentTaskActor() && currentTaskActor()
    ? `Reminder for ${actor}: ${title}`
    : `Reminder: ${title}`;
  const bubble = addBubble("assistant", message, {responsePurpose: "task_reminder"});
  bubble.classList.add("reminder-bubble");
  renderTaskPresentation(bubble, {
    type: "task",
    label: "REMINDER",
    status: "Due now",
    task: {
      id: taskId,
      title,
      notes: normalizeDetailedText(task?.notes || ""),
      status: normalizeNaturalText(task?.status || "open"),
      priority: normalizeNaturalText(task?.priority || "normal"),
      dueAt: normalizeNaturalText(task?.due_at || task?.dueAt || ""),
      reminderAt: normalizeNaturalText(task?.fired_reminder_at || task?.reminder_at || task?.reminderAt || ""),
      recurrence: normalizeNaturalText(task?.recurrence || "none"),
    },
  });
  void window.jarvisDesktop?.notify?.("Jarvis reminder", title);
  logEvent("tasks.reminder.surfaced", title.slice(0, 140));
}

async function claimTaskReminders() {
  try {
    const payload = await taskApiRequest(`/api/tasks/reminders/claim${taskApiQuery({limit: 25})}`, {method: "POST"});
    const reminders = Array.isArray(payload?.reminders) ? payload.reminders : [];
    reminders.forEach(surfaceTaskReminder);
    if (reminders.length) await loadTaskDashboard();
    return reminders;
  } catch (error) {
    logEvent("tasks.reminder_poll.failed", error.message || "Reminder poll failed");
    return [];
  }
}

function startTaskReminderPolling() {
  window.clearInterval(taskReminderPollTimer);
  window.setTimeout(() => void claimTaskReminders(), 1200);
  taskReminderPollTimer = window.setInterval(() => void claimTaskReminders(), 20000);
}

async function openWebIntelligenceCitation(url, statusNode = null) {
  const target = String(url || "").trim();
  if (!/^https?:\/\//i.test(target)) return false;
  if (statusNode) statusNode.textContent = "Opening source…";
  try {
    if (typeof window.jarvisDesktop?.openExternal === "function") {
      await window.jarvisDesktop.openExternal(target);
    } else {
      window.open(target, "_blank", "noopener,noreferrer");
    }
    if (statusNode) statusNode.textContent = "Source opened";
    logEvent("web_intelligence.citation_opened", target.slice(0, 240));
    return true;
  } catch (error) {
    if (statusNode) statusNode.textContent = "Couldn’t open source";
    logEvent("web_intelligence.citation_open_failed", error.message || target.slice(0, 160));
    return false;
  }
}

async function openWebIntelligenceSource(resultId, sourceId, statusNode = null) {
  if (!resultId || !sourceId) return false;
  if (statusNode) statusNode.textContent = "Opening…";
  try {
    const response = await fetch(`/api/web/results/${encodeURIComponent(resultId)}/sources/${encodeURIComponent(sourceId)}/open`, {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify({task_id: `web_open_${Date.now()}`}),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Source open failed (${response.status})`);
    if (statusNode) statusNode.textContent = "Opened in browser";
    logEvent("web_intelligence.source_opened", sourceId);
    return true;
  } catch (error) {
    if (statusNode) statusNode.textContent = error.message || "Couldn’t open source";
    logEvent("web_intelligence.source_open_failed", error.message || sourceId);
    return false;
  }
}

function cleanWebIntelligenceDisplayText(value) {
  return String(value || "")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/__([^_]+)__/g, "$1")
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/gi, "$1")
    .replace(/^\s*#{1,6}\s+/gm, "")
    .replace(/^\s*[-*]\s+/gm, "• ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function webIntelligenceTokenSet(value) {
  const stop = new Set(["the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "with", "is", "are", "was", "were", "as", "at", "by", "from", "this", "that", "it", "i"]);
  return new Set(
    normalizeDetailedText(value || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .split(/\s+/)
      .filter((token) => token.length >= 2 && !stop.has(token))
  );
}

function webIntelligenceOverlap(left, right) {
  const a = webIntelligenceTokenSet(left);
  const b = webIntelligenceTokenSet(right);
  if (!a.size || !b.size) return 0;
  let shared = 0;
  for (const token of a) if (b.has(token)) shared += 1;
  return shared / Math.max(1, Math.min(a.size, b.size));
}

function removeRedundantWebIntelligenceRecap(answerText, spokenSummary) {
  const raw = String(answerText || "").trim();
  const summary = normalizeDetailedText(spokenSummary || "");
  if (!raw || !summary) return raw;
  const paragraphs = raw.split(/\n\s*\n/).map((part) => part.trim()).filter(Boolean);
  if (paragraphs.length < 2) return raw;
  const last = cleanWebIntelligenceDisplayText(paragraphs[paragraphs.length - 1]);
  if (last.length < 70 || last.length > 620) return raw;
  if (webIntelligenceOverlap(last, summary) < 0.58) return raw;
  paragraphs.pop();
  return paragraphs.join("\n\n").trim();
}

function appendWebIntelligenceInlineText(node, value, {emphasizeLead = false} = {}) {
  const text = cleanWebIntelligenceDisplayText(value || "");
  if (!text) return;
  const colon = text.indexOf(":");
  const canEmphasize = emphasizeLead && colon > 0 && colon <= 54 && !/[.!?]/.test(text.slice(0, colon));
  if (!canEmphasize) {
    node.append(document.createTextNode(text));
    return;
  }
  const lead = document.createElement("strong");
  lead.className = "web-intelligence-inline-label";
  lead.textContent = text.slice(0, colon + 1);
  node.append(lead, document.createTextNode(text.slice(colon + 1)));
}

function renderWebIntelligencePresentation(bubble, presentation) {
  if (!bubble || presentation?.type !== "web_search_result") return null;
  bubble.querySelector(".web-intelligence-presentation")?.remove();
  const card = document.createElement("section");
  card.className = "connected-action-presentation web-intelligence-presentation";
  card.setAttribute("aria-label", "Web Intelligence result");

  const head = document.createElement("div");
  head.className = "web-intelligence-head";
  const label = document.createElement("strong");
  label.textContent = presentation.label || "WEB INTELLIGENCE";
  const freshness = document.createElement("span");
  freshness.textContent = presentation.browser_handoff?.status === "opened"
    ? "Opened in a new tab"
    : presentation.cache_hit
      ? "Checked recently"
      : presentation.freshness_verified
        ? "Freshness verified"
        : "Grounded web result";
  head.append(label, freshness);

  const topic = document.createElement("div");
  topic.className = "web-intelligence-topic";
  topic.textContent = normalizeDetailedText(presentation.title || presentation.query || "Web result");

  const answer = document.createElement("div");
  answer.className = "web-intelligence-answer";
  const sources = Array.isArray(presentation.sources) ? presentation.sources : [];
  const displaySources = Array.isArray(presentation.display_sources) && presentation.display_sources.length
    ? presentation.display_sources
    : sources;
  const sourceIndexById = new Map(sources.map((source, index) => [String(source.id || ""), index]));
  const spokenSummary = normalizeDetailedText(bubble.querySelector(".content")?.textContent || "");
  const answerText = removeRedundantWebIntelligenceRecap(
    String(presentation.answer || "").replaceAll("\u0000", ""),
    spokenSummary,
  );
  const citations = (Array.isArray(presentation.citations) ? presentation.citations : [])
    .map((citation) => ({
      sourceId: String(citation?.source_id || ""),
      start: Number(citation?.start || 0),
      end: Number(citation?.end || 0),
    }))
    .filter((citation) => sourceIndexById.has(citation.sourceId) && Number.isFinite(citation.end) && citation.end > 0)
    .sort((left, right) => left.end - right.end);

  const citationButton = (citation) => {
    const sourceIndex = sourceIndexById.get(citation.sourceId);
    const source = sources[sourceIndex];
    const marker = document.createElement("button");
    marker.type = "button";
    marker.className = "web-intelligence-citation";
    marker.dataset.sourceId = citation.sourceId;
    marker.textContent = `[${sourceIndex + 1}]`;
    marker.setAttribute("aria-label", `Open citation ${sourceIndex + 1}: ${normalizeDetailedText(source?.title || source?.domain || "Source")}`);
    marker.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void openWebIntelligenceCitation(source?.url, freshness);
    });
    return marker;
  };

  const lines = answerText.split("\n");
  let rawCursor = 0;
  let list = null;
  let renderedParagraphs = 0;
  for (const rawLine of lines) {
    const lineStart = rawCursor;
    const lineEnd = lineStart + rawLine.length;
    rawCursor = lineEnd + 1;
    const cleanLine = cleanWebIntelligenceDisplayText(rawLine);
    if (!cleanLine) {
      list = null;
      continue;
    }
    const lineCitations = citations.filter((citation) => citation.end > lineStart && citation.start <= lineEnd + 1);
    const bullet = /^•\s+/.test(cleanLine);
    const sectionHeading = !bullet && cleanLine.length <= 110 && /:\s*$/.test(cleanLine);
    let target;
    if (bullet) {
      if (!list) {
        list = document.createElement("ul");
        list.className = "web-intelligence-list";
        answer.append(list);
      }
      target = document.createElement("li");
      appendWebIntelligenceInlineText(target, cleanLine.replace(/^•\s+/, ""), {emphasizeLead: true});
      list.append(target);
    } else if (sectionHeading) {
      list = null;
      target = document.createElement("div");
      target.className = "web-intelligence-section-title";
      target.textContent = cleanLine.replace(/:\s*$/, "");
      answer.append(target);
    } else {
      list = null;
      target = document.createElement("p");
      target.className = `web-intelligence-paragraph${renderedParagraphs === 0 ? " web-intelligence-lead" : ""}`;
      appendWebIntelligenceInlineText(target, cleanLine, {emphasizeLead: false});
      answer.append(target);
      renderedParagraphs += 1;
    }
    for (const citation of lineCitations) target.append(citationButton(citation));
  }

  if (!answer.children.length) {
    const fallback = document.createElement("p");
    fallback.className = "web-intelligence-paragraph web-intelligence-lead";
    fallback.textContent = cleanWebIntelligenceDisplayText(answerText);
    answer.append(fallback);
  }

  const sourceSection = document.createElement("div");
  sourceSection.className = "web-intelligence-sources";
  const sourceTitle = document.createElement("div");
  sourceTitle.className = "web-intelligence-sources-title";
  sourceTitle.textContent = displaySources.length ? `Sources · ${displaySources.length}` : "Sources";
  sourceSection.append(sourceTitle);

  displaySources.slice(0, 6).forEach((source, displayIndex) => {
    const sourceIndex = sourceIndexById.has(String(source?.id || ""))
      ? sourceIndexById.get(String(source.id))
      : displayIndex;
    const row = document.createElement("button");
    row.type = "button";
    row.className = "web-intelligence-source";
    row.setAttribute("aria-label", `Open source ${sourceIndex + 1}: ${normalizeDetailedText(source.title || source.domain || source.url || "Source")}`);
    const marker = document.createElement("span");
    marker.className = "web-intelligence-source-index";
    marker.textContent = String(sourceIndex + 1);
    const body = document.createElement("span");
    body.className = "web-intelligence-source-body";
    const title = document.createElement("strong");
    title.textContent = normalizeDetailedText(source.title || source.domain || `Source ${sourceIndex + 1}`);
    const meta = document.createElement("span");
    meta.textContent = normalizeNaturalText(source.domain || source.url || "");
    body.append(title, meta);
    const arrow = document.createElement("span");
    arrow.className = "web-intelligence-source-arrow";
    arrow.textContent = "↗";
    row.append(marker, body, arrow);
    row.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void openWebIntelligenceCitation(source.url, freshness);
    });
    sourceSection.append(row);
  });

  if (!displaySources.length) {
    const empty = document.createElement("div");
    empty.className = "web-intelligence-source-empty";
    empty.textContent = "No clickable source metadata was returned for this result.";
    sourceSection.append(empty);
  }

  card.append(head, topic, answer, sourceSection);
  bubble.classList.add("web-intelligence-answer-bubble");
  bubble._webIntelligencePresentation = presentation;
  bubble.querySelector(".web-intelligence-full-result-button")?.remove();
  const fullResultButton = document.createElement("button");
  fullResultButton.type = "button";
  fullResultButton.className = "web-intelligence-full-result-button";
  fullResultButton.textContent = "View full result";
  fullResultButton.setAttribute("aria-label", "Open this Web Intelligence result in the fullscreen reader");
  fullResultButton.setAttribute("aria-haspopup", "dialog");
  fullResultButton.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    openMessageReader(bubble);
  });
  bubble.append(card, fullResultButton);
  bubble.dataset.presentationText = [
    cleanWebIntelligenceDisplayText(presentation.answer || ""),
    "Sources:",
    ...displaySources.slice(0, 6).map((source, index) => `${index + 1}. ${source.title || source.domain || "Source"} — ${source.url || ""}`),
  ].filter(Boolean).join("\n");
  if (bubble.classList.contains("message-preview-clamped")) sizeLongAnswerPreview(bubble);
  updateBubbleReaderControl(bubble);
  return card;
}

function renderConnectedActionPresentation(bubble, presentation) {
  if (!bubble || !presentation) return null;
  if (presentation.type === "email_draft") return renderEmailDraftPreview(bubble, presentation);
  if (presentation.type === "email_messages") return renderEmailMessagesPresentation(bubble, presentation);
  if (presentation.type === "calendar_event") return renderCalendarEventPresentation(bubble, presentation);
  if (presentation.type === "calendar_events") return renderCalendarEventsPresentation(bubble, presentation);
  if (presentation.type === "calendar_availability") return renderCalendarAvailabilityPresentation(bubble, presentation);
  if (presentation.type === "task" || presentation.type === "tasks") return renderTaskPresentation(bubble, presentation);
  if (presentation.type === "web_search_result") return renderWebIntelligencePresentation(bubble, presentation);
  return null;
}

function dedicatedSpeechIsActive() {
  return Boolean(dedicatedSpeechResponseId || dedicatedSpeechAbortController || dedicatedSpeechAudio);
}

function clearDedicatedSpeechResources() {
  if (dedicatedSpeechPlaybackResolve) {
    const resolve = dedicatedSpeechPlaybackResolve;
    dedicatedSpeechPlaybackResolve = null;
    try { resolve("cleared"); } catch (_) {}
  }
  if (dedicatedSpeechAudio) {
    dedicatedSpeechAudio.onplay = null;
    dedicatedSpeechAudio.onended = null;
    dedicatedSpeechAudio.onerror = null;
    try { dedicatedSpeechAudio.pause(); } catch (_) {}
  }
  if (dedicatedSpeechObjectUrl) {
    try { URL.revokeObjectURL(dedicatedSpeechObjectUrl); } catch (_) {}
  }
  dedicatedSpeechAudio = null;
  dedicatedSpeechObjectUrl = "";
  dedicatedSpeechAbortController = null;
  dedicatedSpeechStartedAt = 0;
}

function completeDedicatedSpeech({interrupted = false, error = ""} = {}) {
  const responseId = dedicatedSpeechResponseId;
  const purpose = dedicatedSpeechPurpose;
  const bubble = dedicatedSpeechBubble;
  clearDedicatedSpeechResources();
  dedicatedSpeechResponseId = "";
  dedicatedSpeechPurpose = "";
  dedicatedSpeechBubble = null;
  setResponseActive(false);
  awaitingFirstAudibleAudio = false;
  if (activeResponseId === responseId) activeResponseId = "";
  if (activeJarvisBubble === bubble) activeJarvisBubble = null;
  if (jarvisSpeakingStartedAt) finalizeJarvisSpeakingSegment();
  if (interrupted) {
    markBubbleInterrupted(bubble, "voice");
    if (purpose === SPOKEN_SUMMARY_PURPOSE) abortDetailedCompanion("dedicated_speech_interrupted");
  } else if (purpose === SPOKEN_SUMMARY_PURPOSE && pendingDetailedCompanion) {
    pendingDetailedCompanion.voiceDone = true;
    settleDetailedCompanion(pendingDetailedCompanion);
  } else {
    setStatus("Listening", "listening", {immediate: true});
  }
  if (wakeAcknowledgementExpected) {
    wakeAcknowledgementExpected = false;
    wakeAcknowledgementDispatching = false;
    wakeAcknowledgementResponseId = "";
  }
  if (wakeInputGateActive) releaseWakeInputGate(interrupted ? "dedicated_speech_interrupted" : "dedicated_speech_complete");
  if (error) ui.configurationMessage.textContent = error;
  updateUsageMetrics();
  noteActivity();
}

function interruptDedicatedSpeech(reason = "voice") {
  if (!dedicatedSpeechIsActive()) return false;
  const responseId = dedicatedSpeechResponseId;
  if (dedicatedSpeechAbortController) {
    try { dedicatedSpeechAbortController.abort(); } catch (_) {}
  }
  interruptions += 1;
  ui.interruptionMetric.textContent = String(interruptions);
  logEvent("speech.tts.interrupted", `${reason}; ${responseId || "pending"}`);
  completeDedicatedSpeech({interrupted: true});
  setStatus("Listening", "listening", {immediate: true});
  return true;
}

function splitDedicatedSpeechText(text, maxCharacters = 5200) {
  const normalized = normalizeNaturalText(text);
  if (!normalized || normalized.length <= maxCharacters) return normalized ? [normalized] : [];
  const sentences = normalized.match(/[^.!?]+[.!?]+(?:["')\]]+)?|[^.!?]+$/g) || [normalized];
  const chunks = [];
  let current = "";
  const pushCurrent = () => {
    const value = current.trim();
    if (value) chunks.push(value);
    current = "";
  };
  for (const sentence of sentences) {
    const clean = sentence.trim();
    if (!clean) continue;
    if (clean.length > maxCharacters) {
      pushCurrent();
      const words = clean.split(/\s+/);
      let piece = "";
      for (const word of words) {
        const candidate = piece ? `${piece} ${word}` : word;
        if (candidate.length > maxCharacters && piece) { chunks.push(piece); piece = word; }
        else piece = candidate;
      }
      if (piece) chunks.push(piece);
      continue;
    }
    const candidate = current ? `${current} ${clean}` : clean;
    if (candidate.length > maxCharacters) { pushCurrent(); current = clean; }
    else current = candidate;
  }
  pushCurrent();
  return chunks;
}

async function dispatchDedicatedSpeech({
  text,
  responsePurpose = STANDARD_VOICE_PURPOSE,
  bubble = null,
  userText = "",
  source = "voice",
  preparedResponseId = "",
  preparedModel = "",
  preparedProvider = "",
} = {}) {
  const spoken = normalizeNaturalText(text);
  if (!spoken) return null;
  if (dedicatedSpeechIsActive()) interruptDedicatedSpeech("superseded");

  const responseId = `tts_${crypto.randomUUID().replaceAll("-", "").slice(0, 24)}`;
  const targetBubble = bubble || addBubble("jarvis", "", {
    speakerLabel: "JARVIS",
    responsePurpose,
  });
  finalizeBubble(targetBubble, spoken);
  dedicatedSpeechResponseId = responseId;
  dedicatedSpeechPurpose = responsePurpose;
  dedicatedSpeechBubble = targetBubble;
  activeResponseId = responseId;
  activeJarvisBubble = targetBubble;
  responseBubblesById.set(responseId, targetBubble);
  responsePurposesById.set(responseId, responsePurpose);
  if (responsePurpose === SPOKEN_SUMMARY_PURPOSE && pendingDetailedCompanion) {
    pendingDetailedCompanion.audioResponseId = responseId;
    pendingDetailedCompanion.spokenSummary = spoken;
    if (!pendingDetailedCompanion.bubble) pendingDetailedCompanion.bubble = targetBubble;
  }
  setResponseActive(true);
  awaitingFirstAudibleAudio = Boolean(speechStoppedAt);
  // The wake gate exists only to prevent the physical wake utterance from
  // becoming a duplicate first Realtime turn. Once a dedicated response owns
  // that first turn, keeping the microphone disabled would also make the answer
  // impossible to interrupt. Re-arm Realtime input before synthesis/playback so
  // speech_started can barge into Thinking or Speaking exactly like a normal turn.
  if (wakeInputGateActive) {
    releaseWakeInputGate("dedicated_response_owned", {delayMs: WAKE_BARGE_IN_RELEASE_DELAY_MS});
  }
  setStatus("Thinking", "thinking", {immediate: true});
  responseCreatedAt = performance.now();
  if (speechStoppedAt) {
    ui.decisionMetric.textContent = metricMs(responseCreatedAt - speechStoppedAt);
    publishLatency("speech_stop_to_luna_script_ready", responseCreatedAt - speechStoppedAt);
  }

  lastAssistantMemoryText = spoken;
  lastAssistantMemoryAt = Date.now();
  void rememberMemory({
    content: spoken,
    source: "assistant",
    kind: "response",
    actor: "Jarvis",
    sourceEventId: `speech:${clientSessionId || "local"}:${responseId}`,
    metadata: {
      provider_event: "dedicated_speech",
      response_id: responseId,
      response_purpose: responsePurpose,
      presentation: "authoritative_text_then_tts",
      scripted_by: preparedProvider || "jarvis_core",
      script_response_id: preparedResponseId || null,
      script_model: preparedModel || config?.text_model || config?.action_model || null,
      speech_provider: currentSpeechProvider(),
      speech_model: currentSpeechProvider() === "elevenlabs" ? (config?.elevenlabs_model || "eleven_v3") : (config?.speech_model || "gpt-4o-mini-tts"),
      speech_voice: currentSpeechProvider() === "elevenlabs" ? (config?.elevenlabs_voice_id || "configured ElevenLabs voice") : (config?.speech_voice || config?.default_voice || "cedar"),
      source,
      user_text: normalizeNaturalText(userText).slice(0, 500),
    },
  });

  const speechChunks = splitDedicatedSpeechText(spoken);
  try {
    for (let chunkIndex = 0; chunkIndex < speechChunks.length; chunkIndex += 1) {
      if (dedicatedSpeechResponseId !== responseId) return targetBubble;
      const chunk = speechChunks[chunkIndex];
      const controller = new AbortController();
      dedicatedSpeechAbortController = controller;
      let synthesisTimedOut = false;
      const synthesisTimeout = window.setTimeout(() => {
        synthesisTimedOut = true;
        try { controller.abort(); } catch (_) {}
      }, DEDICATED_SPEECH_SYNTHESIS_TIMEOUT_MS);
      let response;
      try {
        response = await fetch("/api/speech/synthesize", {
          method: "POST",
          headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
          signal: controller.signal,
          body: JSON.stringify({
            text: chunk,
            provider: currentSpeechProvider(),
            voice: currentSpeechProvider() === "openai" ? (ui.voice?.value || config?.speech_voice || "cedar") : undefined,
            response_mode: ui.responseMode.value,
            session_id: clientSessionId || `local-${Date.now()}`,
            personality: currentVoicePersonality(),
            user_text: normalizeNaturalText(userText).slice(0, 2000),
            response_purpose: normalizeNaturalText(responsePurpose).slice(0, 120),
          }),
        });
      } catch (error) {
        if (synthesisTimedOut) throw new Error("Dedicated speech generation timed out.");
        throw error;
      } finally {
        window.clearTimeout(synthesisTimeout);
      }
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new Error(payload.detail || `Speech generation failed (${response.status})`);
      }
      if (dedicatedSpeechResponseId !== responseId || controller.signal.aborted) return targetBubble;
      const blob = await response.blob();
      if (!blob.size) throw new Error("Speech generation returned no audio.");
      dedicatedSpeechAbortController = null;
      dedicatedSpeechObjectUrl = URL.createObjectURL(blob);
      const audio = new Audio(dedicatedSpeechObjectUrl);
      dedicatedSpeechAudio = audio;
      audio.preload = "auto";
      const sinkId = ui.speaker?.value || "";
      if (sinkId && typeof audio.setSinkId === "function") {
        try { await audio.setSinkId(sinkId); } catch (error) { logEvent("speech.tts.speaker_selection_failed", error.message); }
      }
      const playbackTimeoutMs = Math.max(
        DEDICATED_SPEECH_PLAYBACK_MIN_TIMEOUT_MS,
        Math.min(DEDICATED_SPEECH_PLAYBACK_MAX_TIMEOUT_MS, chunk.split(/\s+/).length * 1100),
      );
      const playback = new Promise((resolve, reject) => {
        const playbackWatchdog = window.setTimeout(() => {
          dedicatedSpeechPlaybackResolve = null;
          reject(new Error("Dedicated voice playback stalled."));
        }, playbackTimeoutMs);
        dedicatedSpeechPlaybackResolve = resolve;
        audio.onplay = () => {
          if (dedicatedSpeechResponseId !== responseId) return;
          const now = performance.now();
          if (!dedicatedSpeechStartedAt) dedicatedSpeechStartedAt = now;
          if (!firstAudioAt && speechStoppedAt) {
            firstAudioAt = now;
            ui.firstAudioMetric.textContent = metricMs(firstAudioAt - speechStoppedAt);
            publishLatency("speech_stop_to_first_tts_audio", firstAudioAt - speechStoppedAt);
          }
          if (!jarvisSpeakingStartedAt) jarvisSpeakingStartedAt = now;
          setStatus("Speaking", "speaking", {immediate: true});
          logEvent("speech.tts.started", `${currentSpeechProvider()}; ${response.headers.get("X-Jarvis-Speech-Voice") || config?.speech_voice || "voice"}; chunk ${chunkIndex + 1}/${speechChunks.length}; ${chunk.slice(0, 120)}`);
        };
        audio.onended = () => {
          window.clearTimeout(playbackWatchdog);
          if (dedicatedSpeechResponseId !== responseId) { resolve("stale"); return; }
          dedicatedSpeechPlaybackResolve = null;
          resolve("ended");
        };
        audio.onerror = () => {
          window.clearTimeout(playbackWatchdog);
          dedicatedSpeechPlaybackResolve = null;
          reject(new Error("Dedicated voice audio could not play."));
        };
      });
      await audio.play();
      const playbackResult = await playback;
      if (playbackResult !== "ended" || dedicatedSpeechResponseId !== responseId) return targetBubble;
      if (dedicatedSpeechAudio === audio) dedicatedSpeechAudio = null;
      if (dedicatedSpeechObjectUrl) {
        try { URL.revokeObjectURL(dedicatedSpeechObjectUrl); } catch (_) {}
        dedicatedSpeechObjectUrl = "";
      }
    }
    if (dedicatedSpeechResponseId !== responseId) return targetBubble;
    responseCount += 1;
    if (speechStoppedAt) {
      const total = performance.now() - speechStoppedAt;
      ui.totalMetric.textContent = metricMs(total);
      publishLatency("speech_stop_to_tts_done", total);
    }
    logEvent("speech.tts.done", `${responseId}; ${speechChunks.length} chunk${speechChunks.length === 1 ? "" : "s"}`);
    completeDedicatedSpeech();
  } catch (error) {
    const aborted = dedicatedSpeechAbortController?.signal?.aborted;
    if (aborted || dedicatedSpeechResponseId !== responseId) return targetBubble;
    logEvent("speech.tts.failed", error.message || "speech generation failed");
    completeDedicatedSpeech({error: "Jarvis kept the exact answer on screen, but dedicated speech failed: " + (error.message || "unknown error")});
  }
  return targetBubble;
}

// Sound like a real person responding in the moment: Luna authors the natural spoken line, while the selected speech provider only renders it.
async function requestNaturalVoiceScript(userText, recognition, memoryContext = null) {
  const actor = isAttributedSpeaker(recognition) ? (recognition.person_name || null) : null;
  const response = await fetch("/api/voice/reply", {
    method: "POST",
    headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
    body: JSON.stringify({
      user_text: normalizeNaturalText(userText),
      actor,
      speaker_name: actor,
      speaker_entity_id: isAttributedSpeaker(recognition) ? (recognition.person_entity_id || null) : null,
      speaker_status: recognition?.status || "unknown",
      session_speaker_id: recognition?.session_speaker_id || null,
      address_names: addressNamesForRecognition(recognition),
      conversation_context: recentConversationContextForNaturalReply(userText),
      memory_context: normalizeDetailedText(memoryContext?.rendered || ""),
      response_mode: ui.responseMode.value,
      session_id: clientSessionId || `local-${Date.now()}`,
      timezone_name: clientTimezoneName(),
      client_local_now: clientLocalNowIso(),
      personality: currentVoicePersonality(),
    }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || `Natural voice response failed (${response.status})`);
  applyConnectedActionUsage(payload);
  return payload;
}

function naturalConnectedMicroConfirmation(result, recognition) {
  const operation = String(result?.action?.operation || "").trim().toLowerCase();
  const status = String(result?.status || result?.action?.status || "").trim().toLowerCase();
  if (operation !== "gmail_mark_read" || status !== "completed") return "";
  const count = Number(result?.action?.result?.marked_read ?? result?.marked_read ?? 0);
  if (!Number.isFinite(count) || count <= 0) return "";

  const now = Date.now();
  const rapidFollowup = lastConnectedMicroConfirmationAt > 0 && now - lastConnectedMicroConfirmationAt < 20000;
  lastConnectedMicroConfirmationAt = now;
  connectedMicroConfirmationSequence += 1;
  const addresses = addressNamesForRecognition(recognition);
  const preferredAddress = normalizeNaturalText(recognition?.primary_address_name || addresses[0] || "");

  if (rapidFollowup) return connectedMicroConfirmationSequence % 2 === 0 ? "All set." : "Done.";
  if (preferredAddress && connectedMicroConfirmationSequence % 4 === 0) return `Done, ${preferredAddress}.`;
  if (connectedMicroConfirmationSequence % 5 === 0) return "All set. Anything else you'd like me to handle?";
  return ["Done.", "All set.", "Taken care of."][connectedMicroConfirmationSequence % 3];
}

function speakConnectedActionResult(result, recognition, {userText = "", itemId = "", source = "voice"} = {}) {
  if (result?.suppress_speech) {
    logEvent("connected_action.superseded_clarification_suppressed", normalizeNaturalText(userText).slice(0, 120));
    restoreRealtimeInputAfterSilentTurn("connected_action_silent_complete");
    return;
  }
  const microConfirmation = naturalConnectedMicroConfirmation(result, recognition);
  const spoken = normalizeNaturalText(microConfirmation || result?.spoken_text || result?.display_text || "Done.");
  const display = normalizeDetailedText(microConfirmation || result?.display_text || spoken);
  const now = Date.now();
  for (const [key, timestamp] of recentConnectedActionSpeech.entries()) {
    if (now - timestamp > 7000) recentConnectedActionSpeech.delete(key);
  }
  const actionId = String(result?.action?.id || "").trim();
  const speechKey = `${actionId || normalizeNaturalText(userText)}|${transcriptFingerprint(spoken)}`;
  const previousSpeechAt = Number(recentConnectedActionSpeech.get(speechKey) || 0);
  if (previousSpeechAt && now - previousSpeechAt < 4000) {
    logEvent("connected_action.speech_duplicate_suppressed", actionId || normalizeNaturalText(userText).slice(0, 80));
    return;
  }
  recentConnectedActionSpeech.set(speechKey, now);
  const presentation = connectedActionPresentation(result);
  clearConnectedActionVoiceOwnership();
  responseCreateWithSpeaker(recognition, {
    exactReply: spoken,
    preparedDisplayText: presentation ? spoken : display,
    preparedPresentation: presentation,
    preparedResponseId: String(result?.action?.id || ""),
    preparedModel: String(result?.planner_model || config?.action_model || ""),
    preparedProvider: "connected_actions",
    authoritativeSpeech: connectedActionNeedsStrictSpeech(result) ? "connected_action_strict" : "connected_action_dialogue",
    userText,
    itemId,
    source,
    allowDetailedCompanion: false,
  });
}

function responseCreateWithSpeaker(recognition, {
  wake = false,
  additionalInstructions = "",
  userText = "",
  exactReply = "",
  itemId = "",
  source = "voice",
  allowDetailedCompanion = true,
  memoryContext = null,
  preparedDisplayText = "",
  preparedPresentation = null,
  preparedResponseId = "",
  preparedModel = "",
  preparedProvider = "",
  connectedActionResponseToken = "",
  authoritativeSpeech = "",
} = {}) {
  const exact = normalizeNaturalText(exactReply);
  const prepared = normalizeDetailedText(preparedDisplayText);
  const presentation = preparedPresentation && typeof preparedPresentation === "object" ? preparedPresentation : null;
  const hasPreparedPresentation = Boolean(presentation?.type);
  const hasPreparedDetails = Boolean(
    exact && prepared && transcriptFingerprint(prepared) !== transcriptFingerprint(exact)
  );
  const wantsDetailedCompanion = hasPreparedDetails || hasPreparedPresentation || (
    allowDetailedCompanion
    && shouldCreateDetailedTextCompanion(userText, {memoryContext})
  );
  if (!wantsDetailedCompanion) {
    if (pendingDetailedCompanion) abortDetailedCompanion("superseded_by_new_turn");
    pendingDetailedCompanion = null;
    pendingTestAutoSleepAfterDetail = false;
  }
  const responsePurpose = wantsDetailedCompanion ? SPOKEN_SUMMARY_PURPOSE : STANDARD_VOICE_PURPOSE;
  const responseProfile = config?.response_mode_profiles?.[ui.responseMode.value] || {};
  const hardResponseLimit = (() => {
    const words = Number(responseProfile.max_words || 0);
    const sentences = Number(responseProfile.max_sentences || 0);
    const limits = [];
    if (sentences > 0) limits.push(`no more than ${sentences} sentence${sentences === 1 ? "" : "s"}`);
    if (words > 0) limits.push(`no more than ${words} spoken words`);
    return limits.length ? `HARD RESPONSE LIMIT: ${limits.join(" and ")}. This is a strict ceiling, not a target.` : "";
  })();
  const authoritativeSpeechSource = normalizeNaturalText(authoritativeSpeech);
  // repair11: Luna/Jarvis Core owns every final response. Realtime remains the
  // listening/turn-taking layer; a selectable dedicated TTS provider is the mouth.
  const dedicatedSpeech = Boolean(exact && config?.speech_enabled !== false);
  const isolatedAuthoritativeSpeech = Boolean(exact && authoritativeSpeechSource && !dedicatedSpeech);
  const turnInstructions = exact
    ? isolatedAuthoritativeSpeech
      ? [
          "Authoritative application speech renderer. The application has already completed all reasoning and data lookup.",
          "Do not answer the user, reinterpret facts, recalculate dates or times, use conversation history, or paraphrase.",
          `Speak this exact text verbatim and nothing else: ${JSON.stringify(exact)}`,
        ].join(" ")
      : `Say exactly this and nothing else: ${JSON.stringify(exact)} Do not add a greeting, explanation, disclaimer, or follow-up.`
    : [
        authoritativeClientTimeInstructions(),
        speakerRecognitionInstructions(recognition, {wake, userText}),
        hardResponseLimit,
        additionalInstructions,
        wantsDetailedCompanion ? spokenSummaryInstructions() : "",
      ]
      .map((value) => String(value || "").trim())
      .filter(Boolean)
      .join("\n\n");
  if (wantsDetailedCompanion) {
    abortDetailedCompanion("superseded");
    pendingDetailedCompanion = {
      userText: normalizeNaturalText(userText),
      userItemId: itemId || "",
      source,
      actor: isAttributedSpeaker(recognition) ? (recognition.person_name || "") : "",
      responseMode: ui.responseMode.value,
      audioResponseId: "",
      requestedAt: Date.now(),
      bubble: null,
      spokenSummary: exact || "",
      writtenAnswer: hasPreparedDetails ? prepared : (hasPreparedPresentation ? exact : ""),
      writtenResponseId: (hasPreparedDetails || hasPreparedPresentation) ? String(preparedResponseId || "") : "",
      writtenModel: (hasPreparedDetails || hasPreparedPresentation) ? String(preparedModel || config?.action_model || "") : "",
      writtenProvider: (hasPreparedDetails || hasPreparedPresentation) ? String(preparedProvider || "connected_actions") : "responses_api",
      presentation,
      voiceDone: false,
      textDone: hasPreparedDetails || hasPreparedPresentation,
      textError: "",
      memoryStored: false,
      abortController: null,
    };
  }
  if ((hasPreparedDetails || hasPreparedPresentation) && pendingDetailedCompanion) {
    const stableText = hasPreparedDetails
      ? composeHybridWrittenAnswer(pendingDetailedCompanion, prepared)
      : (exact || prepared || "Done.");
    pendingDetailedCompanion.bubble = addBubble("jarvis", "", {
      speakerLabel: "JARVIS",
      responsePurpose: HYBRID_ANSWER_PURPOSE,
    });
    renderUnifiedWrittenAnswer(pendingDetailedCompanion, stableText);
    renderConnectedActionPresentation(pendingDetailedCompanion.bubble, presentation);
  }
  if (dedicatedSpeech) {
    const preparedBubble = pendingDetailedCompanion?.bubble || null;
    void dispatchDedicatedSpeech({
      text: exact,
      responsePurpose,
      bubble: preparedBubble,
      userText,
      source,
      preparedResponseId,
      preparedModel,
      preparedProvider: preparedProvider || authoritativeSpeechSource || "jarvis_core",
    });
    if (wantsDetailedCompanion && pendingDetailedCompanion && !hasPreparedDetails && !hasPreparedPresentation) {
      void requestDetailedTextCompanion(pendingDetailedCompanion);
    }
    return pendingDetailedCompanion?.bubble || preparedBubble;
  }
  if (!isolatedAuthoritativeSpeech) applyRealtimeSessionInstructions(turnInstructions);
  pendingResponsePurposes.push(responsePurpose);
  sendProviderEvent({
    type: "response.create",
    response: {
      metadata: {
        response_purpose: responsePurpose,
        response_mode: ui.responseMode.value,
        ...(connectedActionResponseToken ? {connected_action_token: connectedActionResponseToken} : {}),
        ...(authoritativeSpeechSource ? {authoritative_speech: authoritativeSpeechSource} : {}),
      },
      instructions: turnInstructions,
      ...(isolatedAuthoritativeSpeech ? {
        conversation: "none",
        input: [],
        output_modalities: ["audio"],
        tools: [],
        tool_choice: "none",
      } : (exact ? {tool_choice: "none"} : {})),
    },
  });
  if (wantsDetailedCompanion && pendingDetailedCompanion && !hasPreparedDetails && !hasPreparedPresentation) {
    void requestDetailedTextCompanion(pendingDetailedCompanion);
  }
  return pendingDetailedCompanion?.bubble || null;
}

function createExactReply(reply, recognition = null, {authoritativeSpeech = ""} = {}) {
  const normalized = normalizeNaturalText(reply);
  if (!normalized) return;
  if (isSimulationMode()) {
    startSimulationResponse(normalized, {exactReply: normalized});
    return;
  }
  responseCreateWithSpeaker(recognition, {exactReply: normalized, authoritativeSpeech});
}

async function requestVoiceResponseAfterRecognition({
  itemId = "",
  memoryNavigation = null,
  transcript = "",
  memoryEventPromise = null,
  userBubble = null,
  turnEpoch = voiceTurnEpoch,
} = {}) {
  if (memoryNavigation?.visualOnly || memoryNavigation?.responseRequested) return;
  if (suppressStaleVoiceTurn(turnEpoch, "before_recognition")) return;
  const key = itemId || `voice-turn-${Date.now()}-${providerEventSequence}`;
  if (manuallyRespondedVoiceItems.has(key)) return;
  manuallyRespondedVoiceItems.add(key);
  if (manuallyRespondedVoiceItems.size > 2000) manuallyRespondedVoiceItems.clear();
  const recognition = await resolveSpeakerForMemory();
  if (suppressStaleVoiceTurn(turnEpoch, "after_recognition")) return;
  updateUserBubbleSpeakerLabel(userBubble, recognition);
  if (!channel || channel.readyState !== "open" || !isConnected()) return;

  const onboarding = await handleSpeakerOnboardingTurn(transcript, recognition, userBubble);
  if (suppressStaleVoiceTurn(turnEpoch, "after_speaker_onboarding")) return;
  if (onboarding?.handled) {
    createExactReply(onboarding.reply || "Got it.", recognition);
    return;
  }

  const preferenceCommand = parseAddressPreferenceCommand(transcript);
  if (preferenceCommand) {
    const result = await applyAddressPreferenceCommand(preferenceCommand, recognition, {source: "voice"});
    if (suppressStaleVoiceTurn(turnEpoch, "after_address_preference")) return;
    createExactReply(result.reply, recognition);
    logEvent("speaker.address_preference.response", `${preferenceCommand.action}:${preferenceCommand.names.join("|")}`);
    return;
  }

  if (isNaturalMemoryControlCommand(transcript)) {
    const storedMemory = memoryEventPromise ? await memoryEventPromise : null;
    const result = await applyNaturalMemoryControlCommand(transcript, storedMemory, {
      source: "voice",
      actor: isAttributedSpeaker(recognition) ? recognition.person_name : null,
    });
    if (suppressStaleVoiceTurn(turnEpoch, "after_memory_control")) return;
    createExactReply(result.reply || "Done.", recognition);
    return;
  }

  const identityQuestion = isVoiceIdentityQuestion(transcript);
  const explanationQuestion = isVoiceIdentityExplanationQuestion(transcript);
  if (identityQuestion || explanationQuestion) {
    if (identityQuestion && !recognition?.person_name && !recognition?.candidate_name && recognition?.session_speaker_id) {
      armSpeakerOnboarding(recognition, "awaiting_name");
      createExactReply("I don’t know this voice yet. What should I call you?", recognition);
      logEvent("speaker.identity.onboarding_requested", recognition.session_speaker_id);
      return;
    }
    createExactReply(identityReplyForRecognition(recognition, {explain: explanationQuestion, source: "voice"}), recognition);
    logEvent("speaker.identity.response", recognition?.status || "unknown");
    return;
  }

  const webResearch = await requestWebResearchTurn(transcript, recognition);
  if (suppressStaleVoiceTurn(turnEpoch, "after_web_intelligence")) return;
  if (webResearch?.handled) {
    speakWebIntelligenceResult(webResearch, recognition, {userText: transcript, itemId: key, source: "voice"});
    return;
  }

  const browserAction = await requestBrowserActionTurn(transcript, recognition);
  if (suppressStaleVoiceTurn(turnEpoch, "after_browser_action")) return;
  if (browserAction?.handled) {
    speakBrowserActionResult(browserAction, recognition, {userText: transcript, itemId: key, source: "voice"});
    return;
  }

  const computerAction = await requestComputerActionTurn(transcript, recognition);
  if (suppressStaleVoiceTurn(turnEpoch, "after_computer_action")) return;
  if (computerAction?.handled) {
    speakComputerActionResult(computerAction, recognition);
    return;
  }

  const connectedAction = await requestConnectedActionTurn(transcript, recognition);
  if (suppressStaleVoiceTurn(turnEpoch, "after_connected_action")) return;
  if (connectedAction?.handled) {
    speakConnectedActionResult(connectedAction, recognition, {userText: transcript, itemId: key, source: "voice"});
    return;
  }

  const temporalReply = localTemporalReply(transcript);
  if (temporalReply) {
    createExactReply(temporalReply, recognition, {authoritativeSpeech: "local_time"});
    logEvent("local_time.response", temporalReply);
    return;
  }

  const [storedMemory, memoryContext] = await Promise.all([
    memoryEventPromise || Promise.resolve(null),
    querySpecificMemoryTurnContext(transcript, recognition),
  ]);
  if (suppressStaleVoiceTurn(turnEpoch, "after_memory_context")) return;
  const mergedMemoryContext = {
    ...memoryContext,
    rendered: [durableMemoryTurnInstructions(storedMemory), memoryContext.rendered].filter(Boolean).join("\n\n"),
  };
  try {
    const scripted = await requestNaturalVoiceScript(transcript, recognition, mergedMemoryContext);
    if (suppressStaleVoiceTurn(turnEpoch, "after_luna_script")) return;
    responseCreateWithSpeaker(recognition, {
      exactReply: scripted.spoken_text,
      userText: transcript,
      itemId: key,
      source: "voice",
      allowDetailedCompanion: !memoryContext.ambiguous,
      memoryContext: mergedMemoryContext,
      preparedResponseId: String(scripted.response_id || ""),
      preparedModel: String(scripted.model || config?.text_model || ""),
      preparedProvider: "luna_voice_script",
      authoritativeSpeech: "luna_voice_script",
    });
    logEvent(
      "speaker.luna_script.sent",
      isAttributedSpeaker(recognition) ? `${recognition.person_name} ${Math.round(Number(recognition.confidence || 0) * 100)}%` : (recognition?.status || "unknown"),
    );
  } catch (error) {
    logEvent("speaker.luna_script.failed", error.message || "natural voice response failed");
    if (suppressStaleVoiceTurn(turnEpoch, "luna_script_error")) return;
    createExactReply("I hit a problem putting that response together.", recognition, {authoritativeSpeech: "local_error"});
  }
}

async function loadMemorySummary() {
  if (!ui.memorySummaryContent) return;
  if (ui.memorySummaryDate && !ui.memorySummaryDate.value) ui.memorySummaryDate.value = new Date().toISOString().slice(0, 10);
  const selected = ui.memorySummaryDate?.value || "";
  ui.memorySummaryContent.textContent = "Building local summary…";
  try {
    const response = await fetch(`/api/memory/summary?date=${encodeURIComponent(selected)}`, {cache: "no-store"});
    if (!response.ok) throw new Error(`Summary failed (${response.status})`);
    const summary = await response.json();
    ui.memorySummaryContent.replaceChildren();
    const hero = document.createElement("div");
    hero.className = "memory-summary-hero";
    const title = document.createElement("strong");
    title.textContent = `${summary.event_count || 0} events on ${summary.date}`;
    const range = document.createElement("span");
    range.textContent = summary.first_event && summary.last_event
      ? `${memoryDisplayTime(summary.first_event.local_timestamp)} through ${memoryDisplayTime(summary.last_event.local_timestamp)}`
      : "No memories recorded for this date.";
    hero.append(title, range);
    ui.memorySummaryContent.append(hero);
    const columns = document.createElement("div");
    columns.className = "memory-summary-columns";
    for (const [heading, values] of [["Categories", summary.categories || []], ["People & actors", summary.actors || []]]) {
      const section = document.createElement("section");
      const h3 = document.createElement("h3");
      h3.textContent = heading;
      section.append(h3);
      if (!values.length) section.append(createMemoryChip("None recorded", "memory-muted"));
      for (const [label, count] of values) {
        const row = document.createElement("div");
        row.className = "memory-summary-row";
        const name = document.createElement("span"); name.textContent = label;
        const value = document.createElement("strong"); value.textContent = count;
        row.append(name, value); section.append(row);
      }
      columns.append(section);
    }
    ui.memorySummaryContent.append(columns);
    if ((summary.important || []).length) {
      const heading = document.createElement("h3");
      heading.textContent = "Important moments";
      ui.memorySummaryContent.append(heading);
      const list = document.createElement("div"); list.className = "memory-summary-important";
      for (const memory of summary.important) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = `${memoryDisplayTime(memory.local_timestamp)} — ${memory.content}`;
        button.addEventListener("click", () => openMemoryEvent(memory.event_id));
        list.append(button);
      }
      ui.memorySummaryContent.append(list);
    }
  } catch (error) {
    ui.memorySummaryContent.textContent = error.message;
  }
}

function permissionErrorMessage(payload, fallback = "Permission request failed.") {
  const detail = payload?.detail;
  if (typeof detail === "string" && detail.trim()) return detail;
  if (detail && typeof detail === "object" && typeof detail.message === "string" && detail.message.trim()) return detail.message;
  return fallback;
}

async function waitForPermissionReauth(pending) {
  if (!pending?.attempt_id || !pending?.poll_token) throw new Error("Permission reauthentication could not be started.");
  const expiresAt = Date.parse(String(pending.expires_at || ""));
  while (true) {
    const query = new URLSearchParams({attempt_id: pending.attempt_id, poll_token: pending.poll_token});
    const state = await accountFetch(`/api/account/web-auth/status?${query.toString()}`);
    if (state.mode !== "reauth") throw new Error("The browser authentication response was not bound to this permission challenge.");
    if (state.ready) return;
    if (Number.isFinite(expiresAt) && Date.now() >= expiresAt) throw new Error("Permission reauthentication expired. Try the action again.");
    await new Promise((resolve) => window.setTimeout(resolve, 800));
  }
}

function trustedPermissionPromptActive() {
  return Boolean(trustedPermissionPrompt?.challengeId);
}

async function requestTrustedPermissionConfirmation(challengeId) {
  const id = String(challengeId || "").trim();
  if (!id) throw new Error("The exact permission confirmation challenge is unavailable.");
  if (trustedPermissionPromptActive()) throw new Error("Another trusted permission confirmation is already active.");
  if (typeof window.jarvisDesktop?.confirmPermission !== "function") {
    throw new Error("Trusted desktop permission confirmation is unavailable in this build.");
  }
  const state = {challengeId: id, startedAt: Date.now()};
  trustedPermissionPrompt = state;
  relayEvent("client.permission.trusted_prompt_open", {challenge_id: id});
  try {
    return await window.jarvisDesktop.confirmPermission(id);
  } finally {
    if (trustedPermissionPrompt === state) trustedPermissionPrompt = null;
    relayEvent("client.permission.trusted_prompt_closed", {challenge_id: id});
  }
}

function permissionConfirmationCancelled(error) {
  return String(error?.message || "").trim() === "Permission confirmation cancelled.";
}

async function beginPermissionReauth(challengeId) {
  const response = await fetch(`/api/permissions/challenges/${encodeURIComponent(challengeId)}/reauth/start`, {
    method: "POST",
    cache: "no-store",
    headers: {"X-Jarvis-Client": CLIENT_HEADER},
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(permissionErrorMessage(payload, `Permission reauthentication failed (${response.status}).`));

  if (!payload.recent_auth) {
    if (typeof window.jarvisDesktop?.openExternal !== "function") throw new Error("Browser authentication is unavailable in this desktop build.");
    await window.jarvisDesktop.openExternal(payload.authorization_url);
    await waitForPermissionReauth(payload);
  }

  // Fresh password proof is identity assurance, not permission authority. Even
  // during the short reuse window, every authenticated challenge must still be
  // reviewed and approved in the trusted Electron-main-process surface.
  if (typeof window.jarvisDesktop?.confirmPermission !== "function") {
    throw new Error("Trusted desktop permission confirmation is unavailable in this build.");
  }
  const confirmation = await requestTrustedPermissionConfirmation(challengeId);
  if (!confirmation?.approved) throw new Error("Permission confirmation cancelled.");
  const attestation = String(confirmation?.attestation || "").trim();
  const choice = String(confirmation?.choice || "").trim();
  if (!attestation || !choice) throw new Error("Permission confirmation could not be attested by the desktop app.");

  const confirmResponse = await fetch(`/api/permissions/challenges/${encodeURIComponent(challengeId)}/reauth/confirm`, {
    method: "POST",
    cache: "no-store",
    headers: {
      "X-Jarvis-Client": CLIENT_HEADER,
      "X-Permission-Native-Attestation": attestation,
      "X-Permission-Native-Choice": choice,
    },
  });
  const confirmPayload = await confirmResponse.json().catch(() => ({}));
  if (!confirmResponse.ok) {
    throw new Error(permissionErrorMessage(confirmPayload, `Permission confirmation failed (${confirmResponse.status}).`));
  }
  return confirmPayload;
}

function executorPermissionPolicyInfo(payload = {}) {
  const browserPending = payload?.pending_confirmation;
  if (browserPending?.confirmation_source === "permission_policy") {
    const challengeId = String(browserPending.permission_challenge_id || "").trim();
    if (!challengeId) return null;
    return {
      challengeId,
      requiresAuthentication: Boolean(browserPending.requires_authentication),
    };
  }
  const permission = payload?.permission;
  if (permission?.confirmation_source === "permission_policy") {
    const challengeId = String(permission.challenge_id || "").trim();
    if (!challengeId) return null;
    return {
      challengeId,
      requiresAuthentication: Boolean(permission.requires_authentication),
    };
  }
  return null;
}

async function approveExecutorPermissionPolicy(info) {
  const challengeId = String(info?.challengeId || "").trim();
  if (!challengeId) throw new Error("The exact permission confirmation challenge is unavailable.");
  try {
    if (info?.requiresAuthentication) {
      await beginPermissionReauth(challengeId);
      return {approved: true, attestation: "", choice: "allow_once"};
    }
    if (typeof window.jarvisDesktop?.confirmPermission !== "function") {
      throw new Error("Trusted desktop permission confirmation is unavailable in this build.");
    }
    const confirmation = await requestTrustedPermissionConfirmation(challengeId);
    if (!confirmation?.approved) return {approved: false, attestation: "", choice: "cancel"};
    const attestation = String(confirmation?.attestation || "").trim();
    const choice = String(confirmation?.choice || "").trim();
    if (!attestation || !choice) throw new Error("Permission confirmation could not be attested by the desktop app.");
    return {approved: true, attestation, choice};
  } catch (error) {
    if (String(error?.message || "") === "Permission confirmation cancelled.") {
      return {approved: false, attestation: "", choice: "cancel"};
    }
    throw error;
  }
}

async function permissionAwareFetch(url, options = {}, {confirmationMessage = ""} = {}) {
  const {permissionRetryWithoutSignal = false, ...fetchOptions} = options;
  const baseHeaders = new Headers(fetchOptions.headers || {});
  if (!baseHeaders.has("X-Jarvis-Client")) baseHeaders.set("X-Jarvis-Client", CLIENT_HEADER);
  const requestOptions = {...fetchOptions, headers: baseHeaders};
  let response = await fetch(url, requestOptions);
  if (response.status !== 409) return response;

  const payload = await response.clone().json().catch(() => ({}));
  const detail = payload?.detail;
  const challengeId = String(detail?.challenge_id || "").trim();
  const code = String(detail?.code || "").trim();
  if (!challengeId || !["permission_confirmation_required", "permission_authentication_required"].includes(code)) return response;

  let nativeAttestation = "";
  let nativeChoice = "";
  if (code === "permission_authentication_required" || detail?.requires_authentication) {
    await beginPermissionReauth(challengeId);
  } else if (typeof window.jarvisDesktop?.confirmPermission === "function") {
    const confirmation = await requestTrustedPermissionConfirmation(challengeId);
    if (!confirmation?.approved) throw new Error("Permission confirmation cancelled.");
    nativeAttestation = String(confirmation?.attestation || "").trim();
    nativeChoice = String(confirmation?.choice || "").trim();
    if (!nativeAttestation || !nativeChoice) throw new Error("Permission confirmation could not be attested by the desktop app.");
  } else {
    const prompt = confirmationMessage || String(detail?.message || "Jarvis needs your confirmation before performing this action.");
    if (!window.confirm(prompt)) throw new Error("Permission confirmation cancelled.");
  }

  const retryHeaders = new Headers(baseHeaders);
  retryHeaders.set("X-Permission-Challenge", challengeId);
  if (nativeAttestation) retryHeaders.set("X-Permission-Native-Attestation", nativeAttestation);
  if (nativeChoice) retryHeaders.set("X-Permission-Native-Choice", nativeChoice);
  const retryOptions = {...fetchOptions, headers: retryHeaders};
  if (permissionRetryWithoutSignal) delete retryOptions.signal;
  response = await fetch(url, retryOptions);
  return response;
}

async function memoryWrite(url, {method = "POST", body = null, confirmationMessage = ""} = {}) {
  const response = await permissionAwareFetch(url, {
    method,
    headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
    body: body === null ? null : JSON.stringify(body),
  }, {confirmationMessage});
  if (!response.ok) {
    let detail = `Memory operation failed (${response.status})`;
    try { detail = permissionErrorMessage(await response.json(), detail); } catch (_) {}
    throw new Error(detail);
  }
  return response.json();
}

function closeMemoryDetail() {
  if (ui.memoryDetailOverlay) ui.memoryDetailOverlay.hidden = true;
  if (ui.memoryDetailContent) ui.memoryDetailContent.replaceChildren();
}

function showMemoryDetail({kicker, title, content}) {
  if (!ui.memoryDetailOverlay || !ui.memoryDetailContent) return;
  ui.memoryDetailKicker.textContent = kicker;
  ui.memoryDetailTitle.textContent = title;
  ui.memoryDetailContent.replaceChildren(content);
  ui.memoryDetailOverlay.hidden = false;
}

function detailSection(title, values = []) {
  const section = document.createElement("section");
  section.className = "memory-detail-section";
  const heading = document.createElement("h3");
  heading.textContent = title;
  section.append(heading, ...values);
  return section;
}

function detailField(label, value) {
  const row = document.createElement("div");
  row.className = "memory-detail-field";
  const key = document.createElement("span"); key.textContent = label;
  const text = document.createElement("strong"); text.textContent = value ?? "—";
  row.append(key, text);
  return row;
}

async function patchMemoryEvent(eventId, body, statusMessage) {
  try {
    const payload = await memoryWrite(`/api/memory/events/${encodeURIComponent(eventId)}`, {method: "PATCH", body});
    renderMemoryStats(payload.stats || {});
    if (ui.memoryStatus) ui.memoryStatus.textContent = statusMessage;
    await loadMemoryDashboard();
    await openMemoryEvent(eventId);
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  }
}


async function setMemoryEventLifecycle(eventId, status, statusMessage) {
  try {
    const payload = await memoryWrite(`/api/memory/events/${encodeURIComponent(eventId)}/lifecycle`, {
      body: {status, reason: "memory_explorer_control"},
    });
    renderMemoryStats(payload.stats || {});
    if (ui.memoryStatus) ui.memoryStatus.textContent = statusMessage;
    await loadMemoryDashboard();
    await openMemoryEvent(eventId);
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  }
}

async function setMemoryFactLifecycle(factId, status, entityId = "") {
  try {
    const payload = await memoryWrite(`/api/memory/facts/${encodeURIComponent(factId)}/lifecycle`, {
      body: {status, reason: "memory_explorer_control"},
    });
    renderMemoryStats(payload.stats || {});
    if (ui.memoryStatus) ui.memoryStatus.textContent = `Fact marked ${status}.`;
    await loadMemoryDashboard();
    if (entityId) await openMemoryEntity(entityId);
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  }
}

async function setMemoryRelationshipLifecycle(relationshipId, status, personId = "") {
  try {
    const payload = await memoryWrite(`/api/memory/relationships/${encodeURIComponent(relationshipId)}/lifecycle`, {
      body: {status, reason: "memory_explorer_control"},
    });
    renderMemoryStats(payload.stats || {});
    if (ui.memoryStatus) ui.memoryStatus.textContent = `Relationship marked ${status}.`;
    await loadMemoryDashboard();
    if (personId) await openMemoryPerson(personId);
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  }
}


function showMemoryEventEditor(memory, title, fields, submitLabel, onSubmit, {danger = false} = {}) {
  const form = document.createElement("form");
  form.className = "memory-identity-form memory-event-control-form";
  for (const field of fields) form.append(field.node);
  const status = document.createElement("div");
  status.className = "memory-identity-form-status";
  status.setAttribute("aria-live", "polite");
  const actions = document.createElement("div");
  actions.className = "memory-detail-actions";
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.className = "secondary";
  cancel.textContent = "Cancel";
  cancel.addEventListener("click", () => void openMemoryEvent(memory.event_id));
  const submit = document.createElement("button");
  submit.type = "submit";
  submit.className = danger ? "danger" : "";
  submit.textContent = submitLabel;
  actions.append(cancel, submit);
  form.append(status, actions);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    submit.disabled = true;
    cancel.disabled = true;
    status.textContent = "Saving…";
    try {
      const result = await onSubmit(Object.fromEntries(fields.map((field) => [field.name, field.control])));
      await loadMemoryDashboard();
      if (result?.deleted) {
        closeMemoryDetail();
      } else {
        await openMemoryEvent(memory.event_id);
      }
      if (ui.memoryStatus) ui.memoryStatus.textContent = result?.message || `${title} saved.`;
    } catch (error) {
      status.textContent = error.message;
      submit.disabled = false;
      cancel.disabled = false;
    }
  });
  showMemoryDetail({kicker: "MEMORY CONTROL", title, content: form});
}

function openMemoryTextEditor(memory) {
  const content = identityTextControl(memory.content || "", {multiline: true, required: true});
  const fields = [{name: "content", control: content, node: identityControlField("Exact memory text", content, "The original value remains in audit history.")}];
  showMemoryEventEditor(memory, "Edit exact text", fields, "Save correction", async (controls) => {
    const value = controls.content.value.trim();
    if (!value) throw new Error("Memory text cannot be empty.");
    await memoryWrite(`/api/memory/events/${encodeURIComponent(memory.event_id)}`, {method: "PATCH", body: {content: value}});
    return {message: "Memory text corrected with audit history."};
  });
}

async function openMemorySpeakerEditor(memory) {
  const response = await fetch("/api/memory/people?limit=250", {cache: "no-store"});
  if (!response.ok) throw new Error(`People list failed (${response.status})`);
  const people = (await response.json()).people || [];
  if (!people.length) throw new Error("No person profiles are available for attribution.");
  const select = document.createElement("select");
  for (const person of people) {
    const option = document.createElement("option");
    option.value = person.id;
    option.textContent = `${person.name} — ${String(person.relationship_to_owner || "known person").replaceAll("_", " ")}`;
    option.selected = String(person.name || "").toLowerCase() === String(memory.actor || "").toLowerCase();
    select.append(option);
  }
  const reason = identityTextControl("User corrected the speaker attribution.", {required: true});
  const fields = [
    {name: "person", control: select, node: identityControlField("Correct speaker / actor", select)},
    {name: "reason", control: reason, node: identityControlField("Reason", reason, "This is preserved in attribution history.")},
  ];
  showMemoryEventEditor(memory, "Correct speaker", fields, "Save attribution", async (controls) => {
    await memoryWrite(`/api/memory/events/${encodeURIComponent(memory.event_id)}/attribute`, {body: {
      person_entity_id: controls.person.value,
      reason: controls.reason.value.trim() || "user_correction",
      confidence: 1,
    }});
    return {message: "Speaker attribution corrected with provenance."};
  });
}

function openMemoryCategoryEditor(memory) {
  const category = identityTextControl(memory.category || "", {required: true, placeholder: "Conversations/User Statements"});
  const fields = [{name: "category", control: category, node: identityControlField("Category path", category, "Use / between category levels.")}];
  showMemoryEventEditor(memory, "Move category", fields, "Move memory", async (controls) => {
    const path = controls.category.value.split("/").map((part) => part.trim()).filter(Boolean);
    if (!path.length) throw new Error("Enter at least one category level.");
    await memoryWrite(`/api/memory/events/${encodeURIComponent(memory.event_id)}`, {method: "PATCH", body: {category_path: path}});
    return {message: "Memory category updated."};
  });
}

function openMemoryPrivacyEditor(memory) {
  const privacy = identitySelectControl(["private", "shared", "confidential"], memory.privacy || "private");
  const fields = [{name: "privacy", control: privacy, node: identityControlField("Privacy", privacy)}];
  showMemoryEventEditor(memory, "Set privacy", fields, "Save privacy", async (controls) => {
    await memoryWrite(`/api/memory/events/${encodeURIComponent(memory.event_id)}`, {method: "PATCH", body: {privacy: controls.privacy.value}});
    return {message: "Memory privacy updated."};
  });
}

function openMemoryDeleteEditor(memory) {
  const confirm = document.createElement("input");
  confirm.type = "checkbox";
  confirm.required = true;
  const fields = [{name: "confirm", control: confirm, node: identityControlField("Delete from active recall", confirm, "The deletion is audit logged and can be undone from Memory maintenance.")}];
  showMemoryEventEditor(memory, "Delete memory", fields, "Delete memory", async (controls) => {
    if (!controls.confirm.checked) throw new Error("Confirm the deletion first.");
    await memoryWrite(`/api/memory/events/${encodeURIComponent(memory.event_id)}`, {method: "DELETE", confirmationMessage: "Delete this memory? This cannot be undone."});
    return {deleted: true, message: "Memory deleted. Undo is available."};
  }, {danger: true});
}

async function openMemoryEvent(eventId) {
  try {
    const [response, historyResponse] = await Promise.all([
      fetch(`/api/memory/events/${encodeURIComponent(eventId)}`, {cache: "no-store"}),
      fetch(`/api/memory/events/${encodeURIComponent(eventId)}/history?limit=30`, {cache: "no-store"}),
    ]);
    if (!response.ok) throw new Error(`Memory detail failed (${response.status})`);
    const memory = (await response.json()).memory;
    const history = historyResponse.ok ? ((await historyResponse.json()).history || []) : [];
    const root = document.createElement("div");
    root.className = "memory-event-detail";
    const exact = document.createElement("blockquote");
    exact.textContent = memory.content;
    root.append(exact);

    const provenance = [
      detailField("Exact local time", memory.local_timestamp),
      detailField("Timezone", memory.timezone_name),
      detailField("Speaker / actor", memory.actor),
      detailField("Source", memory.source),
      detailField("Kind", memory.kind),
      detailField("Category", memory.category),
      detailField("Privacy", memory.privacy),
      detailField("Status", memory.status || "active"),
      detailField("Confidence", Number(memory.confidence || 0).toFixed(2)),
      detailField("Event ID", memory.event_id),
    ];
    root.append(detailSection("Provenance", provenance));

    if ((memory.entities || []).length) {
      const entityWrap = document.createElement("div"); entityWrap.className = "memory-detail-chips";
      for (const entity of memory.entities) {
        const button = document.createElement("button"); button.type = "button"; button.className = "memory-entity-chip"; button.textContent = `${entity.name} · ${entity.type}`;
        button.addEventListener("click", () => openMemoryEntity(entity.id)); entityWrap.append(button);
      }
      root.append(detailSection("Connected entities", [entityWrap]));
    }
    if ((memory.facts || []).length) {
      const facts = memory.facts.map((fact) => detailField("Organized fact", `${fact.subject} ${String(fact.predicate).replaceAll("_", " ")} ${fact.object || ""} · support ${fact.support_count}`));
      root.append(detailSection("Facts derived from this evidence", facts));
    }

    const actions = document.createElement("div");
    actions.className = "memory-detail-actions";
    const action = (label, handler, className = "secondary") => {
      const button = document.createElement("button"); button.type = "button"; button.className = className; button.textContent = label; button.addEventListener("click", handler); actions.append(button);
    };
    action("Edit exact text", () => openMemoryTextEditor(memory));
    action("Correct speaker", () => void openMemorySpeakerEditor(memory));
    action("Move category", () => openMemoryCategoryEditor(memory));
    action(memory.important ? "Remove important mark" : "Mark important", () => void patchMemoryEvent(memory.event_id, {important: !memory.important}, memory.important ? "Important mark removed." : "Memory marked important."));
    action("Set privacy", () => openMemoryPrivacyEditor(memory));
    if (memory.status !== "active") {
      action("Restore as current", () => void setMemoryEventLifecycle(memory.event_id, "active", "Memory restored to current recall."));
    }
    if (memory.status !== "completed") action("Mark completed", () => void setMemoryEventLifecycle(memory.event_id, "completed", "Memory marked completed."));
    if (memory.status !== "dismissed") action("Dismiss", () => void setMemoryEventLifecycle(memory.event_id, "dismissed", "Memory dismissed from current recall."));
    if (memory.status !== "superseded") action("Mark superseded", () => void setMemoryEventLifecycle(memory.event_id, "superseded", "Memory marked superseded."));
    if (memory.status !== "outdated") action("Mark outdated", () => void setMemoryEventLifecycle(memory.event_id, "outdated", "Memory marked outdated."));
    if (memory.status !== "incorrect") action("Mark incorrect", () => void setMemoryEventLifecycle(memory.event_id, "incorrect", "Memory marked incorrect."));
    if (memory.status !== "forgotten") action("Forget", () => void setMemoryEventLifecycle(memory.event_id, "forgotten", "Memory removed from current recall but kept in history."), "danger");
    action("Delete memory", () => openMemoryDeleteEditor(memory), "danger");
    root.append(detailSection("Correct and control", [actions]));

    if (history.length) {
      const lifecycle = document.createElement("div");
      lifecycle.className = "memory-lifecycle-history";
      for (const change of history) {
        const row = document.createElement("div");
        row.className = "memory-lifecycle-row";
        const label = document.createElement("strong");
        const status = change.after?.status || change.operation_type?.replaceAll("_", " ") || "change";
        label.textContent = String(status).replaceAll("_", " ");
        const detail = document.createElement("span");
        const reason = change.after?.reason ? ` · ${String(change.after.reason).replaceAll("_", " ")}` : "";
        detail.textContent = `${memoryDisplayTime(change.created_at)}${reason}${change.undone_at ? " · undone" : ""}`;
        row.append(label, detail);
        lifecycle.append(row);
      }
      root.append(detailSection("Lifecycle history", [lifecycle]));
    }
    showMemoryDetail({kicker: "EXACT EVENT & PROVENANCE", title: memory.summary || "Memory detail", content: root});
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  }
}

async function openMemoryEntity(entityId) {
  try {
    const response = await fetch(`/api/memory/entities/${encodeURIComponent(entityId)}?event_limit=100`, {cache: "no-store"});
    if (!response.ok) throw new Error(`Entity detail failed (${response.status})`);
    const entity = (await response.json()).entity;
    const root = document.createElement("div"); root.className = "memory-entity-detail";
    root.append(detailSection("Identity", [
      detailField("Type", String(entity.type || "concept").replaceAll("_", " ")),
      detailField("Category", entity.category), detailField("First seen", memoryDisplayTime(entity.first_seen_at)),
      detailField("Last seen", memoryDisplayTime(entity.last_seen_at)), detailField("Confidence", Number(entity.confidence || 0).toFixed(2)),
    ]));
    const aliases = document.createElement("div"); aliases.className = "memory-detail-chips";
    for (const alias of entity.aliases || []) aliases.append(createMemoryChip(alias.alias));
    if (!aliases.childElementCount) aliases.append(createMemoryChip(entity.name || "No aliases", "memory-muted"));
    root.append(detailSection("Names and aliases", [aliases]));
    if (entity.type === "person") {
      const addressNames = document.createElement("div"); addressNames.className = "memory-detail-chips";
      for (const name of entity.active_address_names || []) addressNames.append(createMemoryChip(name));
      if (!addressNames.childElementCount) addressNames.append(createMemoryChip("None active", "memory-muted"));
      root.append(detailSection("Preferred forms of address", [addressNames]));
    }

    if (entity.profile) {
      const profile = document.createElement("div"); profile.className = "memory-entity-profile";
      const summary = document.createElement("p"); summary.textContent = entity.profile.summary || ""; profile.append(summary);
      for (const [label, values] of [["Key facts", entity.profile.key_facts], ["Open items", entity.profile.open_items], ["Decisions", entity.profile.decisions], ["Goals", entity.profile.goals]]) {
        if (!(values || []).length) continue;
        const heading = document.createElement("strong"); heading.textContent = label; profile.append(heading);
        const list = document.createElement("ul");
        for (const value of values) { const item = document.createElement("li"); item.textContent = value; list.append(item); }
        profile.append(list);
      }
      root.append(detailSection("Consolidated understanding", [profile]));
    }

    const relationships = document.createElement("div"); relationships.className = "memory-relationship-list";
    if (!(entity.relationships || []).length) relationships.append(createMemoryChip("No structured relationships yet", "memory-muted"));
    for (const relation of entity.relationships || []) {
      const row = document.createElement("div"); row.className = "memory-relationship-row";
      const statement = document.createElement("strong"); statement.textContent = `${relation.subject} ${String(relation.predicate).replaceAll("_", " ")} ${relation.object || ""}`;
      const support = document.createElement("span"); support.textContent = `${relation.status} · confidence ${Number(relation.confidence || 0).toFixed(2)} · ${relation.support_count} evidence`;
      const controls = document.createElement("div"); controls.className = "memory-inline-controls";
      const control = (label, status) => {
        const button = document.createElement("button"); button.type = "button"; button.className = "text-button"; button.textContent = label;
        button.disabled = relation.status === status;
        button.addEventListener("click", () => void setMemoryFactLifecycle(relation.fact_id, status, entity.id));
        controls.append(button);
      };
      control("Current", "current");
      control("Complete", "completed");
      control("Dismiss", "dismissed");
      control("Incorrect", "incorrect");
      row.append(statement, support, controls); relationships.append(row);
    }
    root.append(detailSection("Relationships", [relationships]));

    if ((entity.merged_members || []).length) {
      const merged = document.createElement("div"); merged.className = "memory-merged-list";
      for (const member of entity.merged_members) {
        const row = document.createElement("div"); row.className = "memory-merged-row";
        const label = document.createElement("span"); label.textContent = `${member.canonical_name} · ${member.entity_type}`;
        const split = document.createElement("button"); split.type = "button"; split.className = "text-button"; split.textContent = "Split";
        split.addEventListener("click", async () => {
          try { await memoryWrite(`/api/memory/entities/${encodeURIComponent(member.id)}/split`, {body: {}}); await loadMemoryEntities(); await openMemoryEntity(entity.id); }
          catch (error) { if (ui.memoryStatus) ui.memoryStatus.textContent = error.message; }
        });
        row.append(label, split); merged.append(row);
      }
      root.append(detailSection("Merged entity records", [merged]));
    }

    const events = document.createElement("div"); events.className = "memory-related-events";
    if (!(entity.events || []).length) events.append(createMemoryChip("No source events linked yet", "memory-muted"));
    for (const memory of (entity.events || []).slice(0, 30)) {
      const button = document.createElement("button"); button.type = "button";
      button.textContent = `${memoryDisplayTime(memory.local_timestamp)} — ${memory.content}`;
      button.addEventListener("click", () => openMemoryEvent(memory.event_id)); events.append(button);
    }
    root.append(detailSection(`Source timeline (${(entity.events || []).length})`, [events]));

    const mentions = document.createElement("div"); mentions.className = "memory-related-events memory-conversation-mentions";
    if (!(entity.mentions || []).length) mentions.append(createMemoryChip("No Jarvis conversation mentions", "memory-muted"));
    for (const memory of (entity.mentions || []).slice(0, 20)) {
      const button = document.createElement("button"); button.type = "button";
      button.textContent = `${memoryDisplayTime(memory.local_timestamp)} — ${memory.content}`;
      button.addEventListener("click", () => openMemoryEvent(memory.event_id)); mentions.append(button);
    }
    root.append(detailSection(`Jarvis conversation mentions (${(entity.mentions || []).length})`, [mentions]));

    const actions = document.createElement("div"); actions.className = "memory-detail-actions";
    const merge = document.createElement("button"); merge.type = "button"; merge.className = "secondary"; merge.textContent = "Merge another entity into this one";
    merge.addEventListener("click", async () => {
      const name = window.prompt(`Enter the exact name of the duplicate entity to merge into ${entity.name}:`);
      if (!name?.trim()) return;
      try {
        const result = await fetch(`/api/memory/entities?q=${encodeURIComponent(name.trim())}&limit=20`, {cache: "no-store"});
        const candidates = (await result.json()).entities || [];
        const source = candidates.find((candidate) => candidate.name.toLowerCase() === name.trim().toLowerCase() && candidate.id !== entity.id);
        if (!source) throw new Error("No separate entity with that exact name was found.");
        if (!window.confirm(`Merge ${source.name} into ${entity.name}? This is reversible.`)) return;
        await memoryWrite("/api/memory/entities/merge", {body: {source_id: source.id, target_id: entity.id}});
        await loadMemoryEntities(); await openMemoryEntity(entity.id);
        if (ui.memoryStatus) ui.memoryStatus.textContent = `${source.name} merged into ${entity.name}.`;
      } catch (error) { if (ui.memoryStatus) ui.memoryStatus.textContent = error.message; }
    });
    actions.append(merge); root.append(detailSection("Entity maintenance", [actions]));
    showMemoryDetail({kicker: "ENTITY & RELATIONSHIP GRAPH", title: entity.name, content: root});
    return entity;
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
    return null;
  }
}

async function undoMemoryChange() {
  if (!ui.memoryUndoButton || ui.memoryUndoButton.disabled) return;
  ui.memoryUndoButton.disabled = true;
  try {
    const payload = await memoryWrite("/api/memory/undo", {body: {operation_id: null}});
    renderMemoryStats(payload.stats || {});
    closeMemoryDetail(); await loadMemoryDashboard(); await loadMemoryEntities();
    if (ui.memoryStatus) ui.memoryStatus.textContent = `Undid ${String(payload.operation_type || "memory change").replaceAll("_", " ")}.`;
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  } finally {
    if (ui.memoryUndoButton) ui.memoryUndoButton.disabled = false;
  }
}

function exportMemory(format) {
  const params = memorySearchParams();
  params.set("format", format);
  const anchor = document.createElement("a");
  anchor.href = `/api/memory/export?${params}`;
  anchor.download = "";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  if (ui.memoryStatus) ui.memoryStatus.textContent = `Preparing ${format === "json" ? "JSON" : "Markdown"} memory export…`;
}

async function loadMemoryConsolidation() {
  if (!ui.memoryConsolidationRuns || !ui.memoryConsolidationFindings) return;
  try {
    const [runsResponse, findingsResponse] = await Promise.all([
      fetch("/api/memory/consolidation/runs?limit=12", {cache: "no-store"}),
      fetch("/api/memory/consolidation/findings?status=open&limit=50", {cache: "no-store"}),
    ]);
    if (!runsResponse.ok || !findingsResponse.ok) throw new Error("Consolidation status is unavailable.");
    const runsPayload = await runsResponse.json();
    const findingsPayload = await findingsResponse.json();
    renderMemoryStats(runsPayload.stats || {});
    const runs = runsPayload.runs || [];
    const findings = findingsPayload.findings || [];
    ui.memoryConsolidationRuns.replaceChildren();
    if (!runs.length) ui.memoryConsolidationRuns.append(createMemoryChip("No consolidation runs yet", "memory-muted"));
    for (const run of runs) {
      const row = document.createElement("article"); row.className = "memory-consolidation-row";
      const title = document.createElement("strong"); title.textContent = `${memoryDisplayTime(run.completed_at)} · ${String(run.reason || "manual").replaceAll("_", " ")}`;
      const detail = document.createElement("span"); detail.textContent = `${run.profiles_updated || 0} profiles · ${run.findings_created || 0} findings · ${run.exact_duplicates || 0} duplicate events · ${run.duration_ms || 0} ms`;
      row.append(title, detail); ui.memoryConsolidationRuns.append(row);
    }
    ui.memoryConsolidationFindings.replaceChildren();
    if (!findings.length) ui.memoryConsolidationFindings.append(createMemoryChip("No unresolved findings", "memory-muted"));
    for (const finding of findings) {
      const row = document.createElement("article"); row.className = `memory-consolidation-row severity-${finding.severity || 1}`;
      const title = document.createElement("strong"); title.textContent = finding.title;
      const detail = document.createElement("span"); detail.textContent = `${String(finding.finding_type || "review").replaceAll("_", " ")} · confidence ${Number(finding.confidence || 0).toFixed(2)}`;
      row.append(title, detail); ui.memoryConsolidationFindings.append(row);
    }
    if (ui.memoryConsolidationOverview) {
      const latest = runs[0];
      ui.memoryConsolidationOverview.textContent = latest
        ? `Last run ${memoryDisplayTime(latest.completed_at)}. Jarvis scanned ${latest.events_scanned || 0} events, updated ${latest.profiles_updated || 0} entity profiles, and preserved the exact source ledger.`
        : "Jarvis will consolidate after enough new events are recorded or the configured interval passes.";
    }
  } catch (error) {
    if (ui.memoryConsolidationOverview) ui.memoryConsolidationOverview.textContent = error.message;
  }
}


function proactiveTypeLabel(value) {
  return ({
    confirmed_commitment: "Confirmed commitment",
    pending_reply: "Pending reply",
    goal: "Active goal",
    decision_followup: "Decision",
    possible_task: "Possible next step",
    pattern: "Possible pattern",
  })[value] || String(value || "proactive memory").replaceAll("_", " ");
}

function renderHomeProactiveStatus(stats = {}) {
  if (!ui.homeProactiveStatus || !ui.homeProactiveDetail) return;
  const high = Number(stats.proactive_high_priority || 0);
  const open = Number(stats.proactive_open || 0);
  if (high > 0) {
    ui.homeProactiveStatus.textContent = `${high} high-priority item${high === 1 ? "" : "s"}`;
    ui.homeProactiveDetail.textContent = latestRelevantProactiveItems[0]?.title || `${open} open proactive memories`;
  } else if (open > 0) {
    ui.homeProactiveStatus.textContent = `${open} open item${open === 1 ? "" : "s"}`;
    ui.homeProactiveDetail.textContent = latestRelevantProactiveItems[0]?.title || "No urgent interruption needed";
  } else {
    ui.homeProactiveStatus.textContent = "No urgent items";
    ui.homeProactiveDetail.textContent = "Jarvis is watching commitments locally";
  }
}

function proactivePriorityClass(priority) {
  if (priority >= 0.86) return "priority-critical";
  if (priority >= 0.68) return "priority-high";
  return "";
}

function renderMemoryProactiveItems(items = []) {
  if (!ui.memoryProactiveList) return;
  ui.memoryProactiveList.replaceChildren();
  if (!items.length) {
    memoryEmpty(ui.memoryProactiveList, "No matching proactive items", "Jarvis will list confirmed commitments, pending replies, goals, possible next steps, and patterns here.");
    return;
  }
  for (const item of items) {
    const card = document.createElement("article");
    card.className = `memory-proactive-item ${proactivePriorityClass(Number(item.priority || 0))}`.trim();
    const head = document.createElement("div"); head.className = "memory-proactive-head";
    const copy = document.createElement("div");
    const type = document.createElement("small"); type.textContent = proactiveTypeLabel(item.item_type);
    const title = document.createElement("strong"); title.textContent = item.title;
    copy.append(type, title);
    const priority = document.createElement("span"); priority.className = "memory-priority-pill"; priority.textContent = `Priority ${Number(item.priority || 0).toFixed(2)}`;
    head.append(copy, priority);
    const detail = document.createElement("div"); detail.className = "memory-proactive-copy"; detail.textContent = item.detail || "Source-backed proactive memory.";
    const meta = document.createElement("div"); meta.className = "memory-proactive-meta";
    meta.append(createMemoryChip(item.status || "open", "memory-review-pill"));
    if (item.entity_name) meta.append(createMemoryChip(item.entity_name));
    if (item.due_at) meta.append(createMemoryChip(`Due ${memoryDisplayTime(item.due_at)}`, "memory-important-pill"));
    if (item.metadata?.classification) meta.append(createMemoryChip(item.metadata.classification, "memory-source-pill"));
    const why = document.createElement("div"); why.className = "memory-proactive-explanation";
    why.textContent = item.metadata?.why || `Confidence ${Number(item.confidence || 0).toFixed(2)}. Open details to see the exact evidence.`;
    const actions = document.createElement("div"); actions.className = "memory-proactive-actions";
    const action = (label, handler, className = "text-button") => {
      const button = document.createElement("button"); button.type = "button"; button.className = className; button.textContent = label;
      button.addEventListener("click", handler); actions.append(button);
    };
    action("Why this?", () => openProactiveMemoryItem(item.id));
    if (item.status === "open") {
      action("Complete", () => updateProactiveMemoryItem(item.id, "complete"), "secondary");
      action("Snooze 1 day", () => updateProactiveMemoryItem(item.id, "snooze", 1440));
      action("Dismiss", () => updateProactiveMemoryItem(item.id, "dismiss"));
    } else {
      action("Reopen", () => updateProactiveMemoryItem(item.id, "reopen"), "secondary");
    }
    card.append(head, detail, meta, why, actions);
    ui.memoryProactiveList.append(card);
  }
}

async function loadMemoryProactive() {
  if (!ui.memoryProactiveList) return null;
  const status = ui.memoryProactiveStatusFilter?.value ?? "open";
  const minimumPriority = Number(ui.memoryProactivePriorityFilter?.value || 0);
  if (ui.memoryProactivePriorityOutput) ui.memoryProactivePriorityOutput.value = minimumPriority.toFixed(2);
  try {
    const params = new URLSearchParams({status, limit: "100", minimum_priority: String(minimumPriority)});
    const response = await fetch(`/api/memory/proactive/inbox?${params}`, {cache: "no-store"});
    if (!response.ok) throw new Error(`Proactive memory failed (${response.status})`);
    const payload = await response.json();
    renderMemoryStats(payload.stats || {});
    renderMemoryProactiveItems(payload.items || []);
    const latest = (payload.runs || [])[0];
    if (ui.memoryProactiveOverview) {
      ui.memoryProactiveOverview.textContent = latest
        ? `Last local refresh ${memoryDisplayTime(latest.completed_at)}. Jarvis scanned ${latest.candidates_scanned || 0} candidates, created ${latest.items_created || 0}, updated ${latest.items_updated || 0}, and completed ${latest.items_completed || 0}.`
        : "Jarvis has not run proactive-memory analysis yet.";
    }
    return payload;
  } catch (error) {
    if (ui.memoryProactiveOverview) ui.memoryProactiveOverview.textContent = error.message;
    return null;
  }
}

async function refreshMemoryProactive(reason = "manual_memory_explorer") {
  if (ui.memoryProactiveRefreshButton) ui.memoryProactiveRefreshButton.disabled = true;
  try {
    const response = await fetch("/api/memory/proactive/refresh", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify({reason}),
    });
    if (!response.ok) throw new Error(`Proactive refresh failed (${response.status})`);
    const payload = await response.json();
    renderMemoryStats(payload.stats || {});
    await loadMemoryProactive();
    return payload;
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
    return null;
  } finally {
    if (ui.memoryProactiveRefreshButton) ui.memoryProactiveRefreshButton.disabled = false;
  }
}

async function updateProactiveMemoryItem(itemId, action, snoozeMinutes = null) {
  try {
    const payload = await memoryWrite(`/api/memory/proactive/items/${encodeURIComponent(itemId)}`, {
      method: "PATCH",
      body: {action, snooze_minutes: snoozeMinutes},
    });
    renderMemoryStats(payload.stats || {});
    await loadMemoryProactive();
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  }
}

async function openProactiveMemoryItem(itemId) {
  try {
    const response = await fetch(`/api/memory/proactive/items/${encodeURIComponent(itemId)}`, {cache: "no-store"});
    if (!response.ok) throw new Error(`Proactive detail failed (${response.status})`);
    const {item} = await response.json();
    const root = document.createElement("div"); root.className = "memory-entity-profile";
    const summary = document.createElement("p"); summary.textContent = item.detail || item.title; root.append(summary);
    const score = document.createElement("p"); score.textContent = `Priority ${Number(item.priority || 0).toFixed(2)} · confidence ${Number(item.confidence || 0).toFixed(2)} · urgency ${Number(item.urgency || 0).toFixed(2)}.`; root.append(score);
    const whyTitle = document.createElement("strong"); whyTitle.textContent = "Why Jarvis surfaced it"; root.append(whyTitle);
    const why = document.createElement("p"); why.textContent = item.metadata?.why || "It is connected to an active commitment or project state."; root.append(why);
    const evidenceTitle = document.createElement("strong"); evidenceTitle.textContent = "Exact evidence"; root.append(evidenceTitle);
    const list = document.createElement("ul");
    for (const evidence of item.evidence || []) {
      const row = document.createElement("li"); row.textContent = `${memoryDisplayTime(evidence.local_timestamp)} — ${evidence.actor_label}: ${evidence.content}`; list.append(row);
    }
    if (!list.children.length) { const row = document.createElement("li"); row.textContent = "No exact event is attached; this may be a multi-day pattern inference."; list.append(row); }
    root.append(list);
    showMemoryDetail({kicker: "PROACTIVE MEMORY & EVIDENCE", title: item.title, content: root});
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  }
}

async function loadRelevantProactive(query, {markSurfaced = false} = {}) {
  const normalized = normalizeNaturalText(query || "");
  if (!normalized || config?.memory_proactive_enabled === false) return [];
  try {
    const params = new URLSearchParams({q: normalized, limit: "3", mark_surfaced: String(markSurfaced)});
    const response = await fetch(`/api/memory/proactive/relevant?${params}`, {cache: "no-store"});
    if (!response.ok) return [];
    const payload = await response.json();
    latestRelevantProactiveItems = payload.items || [];
    if (latestRelevantProactiveItems.length && ui.homeProactiveDetail) {
      ui.homeProactiveDetail.textContent = latestRelevantProactiveItems[0].title;
    }
    return latestRelevantProactiveItems;
  } catch (_) {
    return [];
  }
}

function scheduleProactiveRefresh(query = "") {
  window.clearTimeout(proactiveRefreshTimer);
  const delay = Math.max(900, Number(config?.memory_proactive_event_debounce_ms || 700) + 450);
  proactiveRefreshTimer = window.setTimeout(async () => {
    // The core refreshes proactive memory automatically after user-authored events.
    // The desktop only reloads the resulting state; users never need to press Refresh locally.
    if (memoryExplorerMode === "proactive" && document.querySelector('[data-view="memory"]')?.classList.contains("active")) {
      await loadMemoryProactive();
    } else {
      fetch("/api/memory/stats", {cache: "no-store"})
        .then((response) => response.ok ? response.json() : null)
        .then((stats) => { if (stats) renderMemoryStats(stats); })
        .catch(() => {});
    }
    if (query) await loadRelevantProactive(query);
  }, delay);
}

async function runMemoryConsolidation() {
  if (!ui.memoryConsolidateButton) return;
  ui.memoryConsolidateButton.disabled = true;
  if (ui.memoryStatus) ui.memoryStatus.textContent = "Consolidating entities, facts, categories, corrections, and profiles…";
  try {
    const response = await fetch("/api/memory/consolidate", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: JSON.stringify({reason: "manual_memory_explorer", mode: "safe"}),
    });
    if (!response.ok) throw new Error(`Consolidation failed (${response.status})`);
    const payload = await response.json();
    renderMemoryStats(payload.stats || {});
    if (ui.memoryStatus) ui.memoryStatus.textContent = `Consolidation complete: ${payload.profiles_updated || 0} profiles updated, ${payload.findings_created || 0} review findings, ${payload.exact_duplicates || 0} exact duplicates merged.`;
    await loadMemoryDashboard();
    await loadMemoryConsolidation();
  } catch (error) {
    if (ui.memoryStatus) ui.memoryStatus.textContent = error.message;
  } finally {
    ui.memoryConsolidateButton.disabled = false;
  }
}

function nextProviderEventId(prefix) {
  providerEventSequence += 1;
  return `jarvis_${prefix}_${Date.now()}_${providerEventSequence}`;
}

function isHostedRealtimeMode() {
  return config?.provider_mode === "hosted";
}

function stopRealtimeControlHeartbeat() {
  clearInterval(realtimeControlHeartbeatTimer);
  realtimeControlHeartbeatTimer = null;
}

function createHostedRealtimeChannel(sessionId) {
  const cleanSessionId = normalizeNaturalText(sessionId);
  if (!/^rts_[A-Za-z0-9_-]{8,96}$/.test(cleanSessionId)) throw new Error("Jarvis Cloud returned an invalid Realtime session ID.");
  const scheme = window.location.protocol === "https:" ? "wss:" : "ws:";
  const socket = new WebSocket(`${scheme}//${window.location.host}/api/realtime/events?session_id=${encodeURIComponent(cleanSessionId)}`);
  const adapter = {
    get readyState() {
      if (socket.readyState === WebSocket.OPEN) return "open";
      if (socket.readyState === WebSocket.CONNECTING) return "connecting";
      if (socket.readyState === WebSocket.CLOSING) return "closing";
      return "closed";
    },
    send(data) { socket.send(data); },
    close() {
      stopRealtimeControlHeartbeat();
      if (socket.readyState === WebSocket.OPEN) {
        try { socket.send(JSON.stringify({type: "jarvis.session.hangup"})); } catch (_) {}
      }
      socket.close();
    },
    addEventListener(type, handler) { socket.addEventListener(type, handler); },
  };
  socket.addEventListener("open", () => {
    stopRealtimeControlHeartbeat();
    realtimeControlHeartbeatTimer = setInterval(() => {
      if (adapter.readyState !== "open") return;
      try { adapter.send(JSON.stringify({type: "jarvis.control.ping"})); } catch (_) {}
    }, 5000);
  });
  socket.addEventListener("close", stopRealtimeControlHeartbeat);
  return adapter;
}

function waitForRealtimeControlOpen(control, timeoutMs = 10000) {
  if (control?.readyState === "open") return Promise.resolve();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Jarvis Cloud Realtime control channel timed out.")), timeoutMs);
    control.addEventListener("open", () => { clearTimeout(timer); resolve(); }, {once: true});
    control.addEventListener("close", () => { clearTimeout(timer); reject(new Error("Jarvis Cloud Realtime control channel closed during startup.")); }, {once: true});
  });
}

function sendProviderEvent(event) {
  if (!channel || channel.readyState !== "open") throw new Error("Realtime control channel is not open");
  const payload = {...event, event_id: event.event_id || nextProviderEventId(event.type.replaceAll(".", "_"))};
  if (isHostedRealtimeMode()) {
    const type = String(payload.type || "");
    if (type === "input_audio_buffer.clear") {
      channel.send(JSON.stringify({type}));
    } else if (type === "jarvis.control.ping" || type === "jarvis.session.hangup") {
      channel.send(JSON.stringify({type}));
    } else if (new Set([
      "response.cancel", "output_audio_buffer.clear", "session.update",
      "response.create", "conversation.item.create",
    ]).has(type)) {
      // Hosted Realtime is microphone/transcription transport only. Luna authors
      // answers and dedicated TTS speaks them; these legacy provider-control
      // events intentionally have no hosted effect. Jarvis Cloud independently
      // rejects them if a modified desktop attempts to send them directly.
      logEvent("realtime.hosted.legacy_control_suppressed", type);
    } else {
      throw new Error(`Realtime control is not allowed in hosted mode: ${type}`);
    }
    return payload.event_id;
  }
  channel.send(JSON.stringify(payload));
  return payload.event_id;
}

function loadPreferences() {
  try {
    const current = JSON.parse(localStorage.getItem(PREFERENCES_KEY) || "null");
    if (current) {
      if (current.responseMode === "medium") current.responseMode = "high";
      return current;
    }
    const legacy = JSON.parse(localStorage.getItem(LEGACY_PREFERENCES_KEY) || "{}");
    return {
      voice: legacy.voice,
      turnDetection: legacy.turnDetection,
      microphone: legacy.microphone,
      speaker: legacy.speaker,
      responseMode: legacy.responseMode === "medium" ? "high" : legacy.responseMode,
      wakeProfile: legacy.wakeProfile,
      connectionMode: legacy.connectionMode,
      voicePersonality: legacy.voicePersonality,
      speechProvider: legacy.speechProvider,
      testAutoSleep: legacy.testAutoSleep,
    };
  } catch (_) {
    return {};
  }
}

function savePreferences() {
  const preferences = {
    voice: ui.voice.value,
    turnDetection: ui.turnDetection.value,
    microphone: ui.microphone.value,
    speaker: ui.speaker.value,
    responseMode: ui.responseMode.value,
    wakeProfile: ui.wakeProfile.value,
    connectionMode: ui.connectionMode.value,
    voicePersonality: ui.voicePersonality?.value || config?.voice_personality || "classic",
    speechProvider: currentSpeechProvider(),
    testAutoSleep: ui.testAutoSleep.checked,
  };
  localStorage.setItem(PREFERENCES_KEY, JSON.stringify(preferences));
}

function currentVoicePersonality() {
  const selected = normalizeNaturalText(ui.voicePersonality?.value || config?.voice_personality || "classic").toLowerCase();
  return (config?.voice_personalities || ["classic"]).includes(selected) ? selected : "classic";
}

function isHostedProviderMode() {
  return config?.provider_mode === "hosted";
}

function providerReadyForLive() {
  // key_configured is retained as a compatibility field in the local UI contract.
  // In hosted mode it means the verified Jarvis Cloud provider lane is connected;
  // it never means a customer OpenAI key is present.
  return Boolean(config?.key_configured);
}

function configureProviderModeUi() {
  const hosted = isHostedProviderMode();
  document.querySelectorAll(".direct-provider-only").forEach((node) => {
    node.hidden = hosted;
  });
  if (ui.connectionMode) {
    const liveOption = [...ui.connectionMode.options].find((option) => option.value === "live");
    if (liveOption) liveOption.textContent = hosted ? "Live Jarvis Cloud" : "Live development provider";
    const simulationOption = [...ui.connectionMode.options].find((option) => option.value === "simulation");
    if (hosted && simulationOption) simulationOption.remove();
  }
  if (ui.setupProviderIntro) {
    ui.setupProviderIntro.textContent = hosted
      ? "Jarvis Cloud authorizes hosted AI services. No customer provider API key is required."
      : "Direct provider access is development-only. Any development OpenAI key is encrypted by the operating system and never returned to this interface.";
  }
  if (ui.alphaProviderLabel) ui.alphaProviderLabel.textContent = hosted ? "Provider authority" : "Development provider";
  if (ui.openSetup) ui.openSetup.textContent = hosted ? "Desktop settings" : "Development settings";
}

function currentSpeechProvider() {
  const allowed = config?.speech_providers || ["openai"];
  const ready = config?.speech_provider_ready || {};
  const fallback = allowed.find((value) => ready[value] !== false) || allowed[0] || "openai";
  const selected = normalizeNaturalText(ui.speechProvider?.value || config?.speech_provider || fallback).toLowerCase();
  if (!allowed.includes(selected)) return fallback;
  if (ready[selected] === false) return fallback;
  return selected;
}

function isSimulationMode() {
  return ui.connectionMode?.value === "simulation";
}

function isConnected() {
  return simulationConnected || peer?.connectionState === "connected";
}

function isElectronDesktop() {
  return Boolean(window.jarvisDesktop?.isElectron);
}

function currentWakeProfile() {
  const selected = ui.wakeProfile?.value || config?.default_wake_profile || "fast";
  return WAKE_PROFILES[selected] || WAKE_PROFILES.fast;
}

function newClientSessionId() {
  if (window.crypto?.randomUUID) return window.crypto.randomUUID();
  return `session_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}


function pcmRms(samples) {
  let energy = 0;
  for (let index = 0; index < samples.length; index += 1) energy += samples[index] * samples[index];
  return Math.sqrt(energy / Math.max(1, samples.length));
}

function writeAscii(view, offset, value) {
  for (let index = 0; index < value.length; index += 1) view.setUint8(offset + index, value.charCodeAt(index));
}

function encodePcm16Wav(chunks, sampleRate) {
  const sampleCount = chunks.reduce((total, chunk) => total + chunk.length, 0);
  const buffer = new ArrayBuffer(44 + sampleCount * 2);
  const view = new DataView(buffer);
  writeAscii(view, 0, "RIFF");
  view.setUint32(4, 36 + sampleCount * 2, true);
  writeAscii(view, 8, "WAVE");
  writeAscii(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeAscii(view, 36, "data");
  view.setUint32(40, sampleCount * 2, true);
  let offset = 44;
  for (const chunk of chunks) {
    for (let index = 0; index < chunk.length; index += 1) {
      const sample = Math.max(-1, Math.min(1, chunk[index]));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
      offset += 2;
    }
  }
  return new Blob([buffer], {type: "audio/wav"});
}

function resamplePcmMono(chunks, inputRate, targetRate = WAKE_TRANSCRIPTION_SAMPLE_RATE) {
  const totalSamples = chunks.reduce((total, chunk) => total + chunk.length, 0);
  const input = new Float32Array(totalSamples);
  let writeOffset = 0;
  for (const chunk of chunks) {
    input.set(chunk, writeOffset);
    writeOffset += chunk.length;
  }
  if (inputRate <= targetRate || input.length === 0) return {samples: input, sampleRate: inputRate};
  const ratio = inputRate / targetRate;
  const outputLength = Math.max(1, Math.floor(input.length / ratio));
  const output = new Float32Array(outputLength);
  for (let index = 0; index < outputLength; index += 1) {
    const start = Math.floor(index * ratio);
    const end = Math.min(input.length, Math.max(start + 1, Math.floor((index + 1) * ratio)));
    let sum = 0;
    for (let sourceIndex = start; sourceIndex < end; sourceIndex += 1) sum += input[sourceIndex];
    output[index] = sum / Math.max(1, end - start);
  }
  return {samples: output, sampleRate: targetRate};
}

async function stopModelWakeListener({disable = false, preserveStream = false} = {}) {
  const preservedStream = preserveStream ? modelWakeStream : null;
  modelWakeSpeechActive = false;
  modelWakeFrames = [];
  modelWakePreroll = [];
  modelWakePrerollSamples = 0;
  modelWakeCapturedSamples = 0;
  modelWakeConsecutiveSignalFrames = 0;
  modelWakeVoicedSamples = 0;
  modelWakePeakRms = 0;
  modelWakeEffectiveThreshold = 0;
  modelWakeCalibrationStartedAt = 0;
  if (modelWakeProcessor) {
    modelWakeProcessor.onaudioprocess = null;
    try { modelWakeProcessor.disconnect(); } catch (_) {}
  }
  try { modelWakeSource?.disconnect(); } catch (_) {}
  try { modelWakeSilentGain?.disconnect(); } catch (_) {}
  if (!preserveStream) modelWakeStream?.getTracks().forEach((track) => track.stop());
  try { await modelWakeContext?.close(); } catch (_) {}
  modelWakeProcessor = null;
  modelWakeSource = null;
  modelWakeSilentGain = null;
  modelWakeStream = null;
  modelWakeContext = null;
  if (disable) ui.wakeListenerStatus.textContent = "Disabled";
  return preservedStream;
}

async function cancelSpeculativeWake(reason) {
  if (!speculativeWakeActive && !connectPromise && !peer) return;
  logEvent("wake.preconnect.cancelled", reason);
  speculativeWakeActive = false;
  speculativeWakeAccepted = false;
  speculativeWakeConnectPromise = null;
  intentionalSleep = true;
  queuedWakePrompt = "";
  queuedWakeAcknowledgement = false;
  queuedWakeMemoryRecorded = false;
  wakeAcknowledgementExpected = false;
  wakeAcknowledgementDispatching = false;
  wakeAcknowledgementResponseId = "";
  await cleanupConnection({status: "Sleeping"});
  wakeDetectionTriggered = false;
  wakeListeningArmed = true;
}

async function submitWakeUtterance(chunks, sampleRate, durationSeconds) {
  if (!chunks.length) return;
  modelWakeInFlight = true;
  ui.wakeListenerStatus.textContent = "Understanding while Jarvis connects…";
  if (!clientSessionId) clientSessionId = newClientSessionId();
  let acceptedWake = false;
  try {
    const resampled = resamplePcmMono(chunks, sampleRate);
    const wav = encodePcm16Wav([resampled.samples], resampled.sampleRate);
    const wakeRecognitionSourceId = `wake:${clientSessionId || "pending"}:${wakeSpeechEndedAt || Date.now()}`;
    const wakeRecognitionPromise = recognizeVoiceWav(wav, wakeRecognitionSourceId).then((recognition) => {
      if (recognition) {
        wakeSpeakerRecognition = recognition;
        latestSpeakerRecognition = recognition;
      }
      return recognition;
    });
    const query = new URLSearchParams({session_id: clientSessionId});
    const transcriptionStartedAt = performance.now();
    const response = await fetch(`/api/wake/transcribe?${query}`, {
      method: "POST",
      headers: {"Content-Type": "audio/wav", "X-Jarvis-Client": CLIENT_HEADER},
      body: wav,
    });
    if (!response.ok) {
      let message = `Wake transcription failed (${response.status})`;
      try { message = (await response.json()).detail || message; } catch (_) {}
      throw new Error(message);
    }
    const payload = await response.json();
    wakeSpeakerRecognition = await Promise.race([
      wakeRecognitionPromise,
      new Promise((resolve) => setTimeout(() => resolve(null), 1200)),
    ]);
    if (wakeSpeakerRecognition) latestSpeakerRecognition = wakeSpeakerRecognition;
    usageSummary = payload.summary || usageSummary;
    budgetState = payload.budget || budgetState;
    lastUsageSummaryAt = Date.now();
    updateUsageMetrics();
    const transcript = normalizeNaturalText(payload.transcript || "");
    wakeTranscriptionCompletedAt = performance.now();
    const transcriptionDurationMs = wakeTranscriptionCompletedAt - transcriptionStartedAt;
    if (ui.wakeTranscriptionMetric) ui.wakeTranscriptionMetric.textContent = metricMs(transcriptionDurationMs);
    publishLatency("wake_transcription", transcriptionDurationMs);
    logEvent(
      "wake.transcription.completed",
      `${Math.round(transcriptionDurationMs)} ms; ${durationSeconds.toFixed(2)} s audio${transcript ? ` — ${transcript}` : " — no clear speech"}`,
    );
    const detected = extractWakePrompt(transcript);
    if (detected) {
      acceptedWake = true;
      await beginWakeFromDetected(detected, config?.wake_transcription_model || "model_transcription");
      return;
    }
    await cancelSpeculativeWake(transcript ? "wake_keyword_absent" : "no_clear_speech");
    ui.wakeListenerStatus.textContent = `Listening locally for “${config.wake_keyword}”`;
    ui.configurationMessage.textContent = transcript
      ? "The phrase was transcribed, but it did not contain the Jarvis wake keyword."
      : "No clear wake phrase was detected.";
  } catch (error) {
    logEvent("wake.transcription.failed", error.message);
    await cancelSpeculativeWake("transcription_failed");
    ui.configurationMessage.textContent = error.message;
    ui.wakeListenerStatus.textContent = "Wake transcription unavailable";
  } finally {
    modelWakeInFlight = false;
    if (!acceptedWake && !wakeDetectionTriggered && !isConnected() && !connectPromise && wakeListeningArmed) {
      window.setTimeout(() => startModelWakeListener(), WAKE_NEGATIVE_COOLDOWN_MS);
    }
  }
}

async function finishModelWakeUtterance(reason) {
  if (!modelWakeSpeechActive || modelWakeInFlight) return;
  modelWakeSpeechActive = false;
  modelWakeInFlight = true;
  const chunks = modelWakeFrames;
  const sampleRate = modelWakeSampleRate;
  const durationSeconds = modelWakeCapturedSamples / Math.max(1, sampleRate);
  const voicedMs = modelWakeVoicedSamples / Math.max(1, sampleRate) * 1000;
  const threshold = Math.max(Number(config.wake_vad_threshold || 0.018), modelWakeEffectiveThreshold || 0);
  const profile = currentWakeProfile();
  const peakRequired = threshold * profile.minPeakMultiplier;
  const peak = modelWakePeakRms;
  modelWakeFrames = [];
  modelWakeCapturedSamples = 0;
  modelWakeVoicedSamples = 0;
  modelWakePeakRms = 0;
  wakeSpeechEndedAt = performance.now();
  logEvent("wake.audio.captured", `${durationSeconds.toFixed(2)} s, voiced ${Math.round(voicedMs)} ms, peak ${peak.toFixed(4)} (${reason})`);
  const minimumDurationMs = Number(config.wake_vad_min_speech_ms || 250);
  if (durationSeconds * 1000 < minimumDurationMs || voicedMs < profile.minVoicedMs || peak < peakRequired) {
    logEvent("wake.audio.rejected", `insufficient speech evidence; threshold ${threshold.toFixed(4)}`);
    modelWakeInFlight = false;
    await stopModelWakeListener();
    if (wakeListeningArmed) window.setTimeout(() => startModelWakeListener(), WAKE_NEGATIVE_COOLDOWN_MS);
    return;
  }

  wakeHandoffStream = await stopModelWakeListener({preserveStream: true});
  speculativeWakeActive = true;
  speculativeWakeAccepted = false;
  ui.wakeListenerStatus.textContent = "Understanding while Jarvis connects…";
  speculativeWakeConnectPromise = connect({
    automatic: false,
    wakeTriggered: true,
    speculativeWake: true,
    reuseStream: wakeHandoffStream,
  });
  void speculativeWakeConnectPromise?.catch((error) => logEvent("wake.preconnect.failed", error.message));
  await submitWakeUtterance(chunks, sampleRate, durationSeconds);
}

async function startModelWakeListener() {
  if (sleepSequenceActive || sleepShutdownInProgress) return;
  if (!isElectronDesktop() || isSimulationMode() || isConnected() || connectPromise || modelWakeStream || modelWakeInFlight) return;
  if (!providerReadyForLive()) {
    ui.wakeListenerStatus.textContent = isHostedProviderMode() ? "Waiting for Jarvis Cloud" : "Waiting for development provider";
    return;
  }
  wakeListeningArmed = true;
  wakeDetectionTriggered = false;
  wakeCandidateText = "";
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: ui.microphone.value ? {exact: ui.microphone.value} : undefined,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1,
      },
    });
    if (!wakeListeningArmed || isConnected() || connectPromise) {
      stream.getTracks().forEach((track) => track.stop());
      return;
    }
    const Context = window.AudioContext || window.webkitAudioContext;
    if (!Context) throw new Error("Web Audio is unavailable for local wake detection.");
    modelWakeStream = stream;
    modelWakeContext = new Context();
    await modelWakeContext.resume();
    modelWakeSampleRate = modelWakeContext.sampleRate;
    modelWakeSource = modelWakeContext.createMediaStreamSource(stream);
    modelWakeProcessor = modelWakeContext.createScriptProcessor(WAKE_VAD_PROCESSOR_SIZE, 1, 1);
    modelWakeSilentGain = modelWakeContext.createGain();
    modelWakeSilentGain.gain.value = 0;
    modelWakeSource.connect(modelWakeProcessor);
    modelWakeProcessor.connect(modelWakeSilentGain);
    modelWakeSilentGain.connect(modelWakeContext.destination);
    modelWakePreroll = [];
    modelWakePrerollSamples = 0;
    modelWakeFrames = [];
    modelWakeCapturedSamples = 0;
    modelWakeSpeechActive = false;
    modelWakeNoiseFloor = modelWakeRememberedNoiseFloor;
    modelWakeCalibrationStartedAt = performance.now();
    modelWakeConsecutiveSignalFrames = 0;
    modelWakeVoicedSamples = 0;
    modelWakePeakRms = 0;
    modelWakeEffectiveThreshold = Number(config.wake_vad_threshold || 0.018);
    const configuredThreshold = Number(config.wake_vad_threshold || 0.018);
    const configuredSilenceMs = Number(config.wake_vad_silence_ms || 650);
    const profile = currentWakeProfile();
    const silenceMs = Math.min(
      profile.maxSilenceMs,
      Math.max(profile.minSilenceMs, configuredSilenceMs),
    );
    const maxSpeechMs = Number(config.wake_vad_max_speech_ms || 12000);
    const prerollLimit = Math.floor(modelWakeSampleRate * Number(config.wake_vad_preroll_ms || 350) / 1000);
    ui.wakeListenerStatus.textContent = "Preparing fast local wake detection…";
    modelWakeProcessor.onaudioprocess = (event) => {
      if (!wakeListeningArmed || modelWakeInFlight || isConnected() || connectPromise) return;
      const source = event.inputBuffer.getChannelData(0);
      const chunk = new Float32Array(source.length);
      chunk.set(source);
      const now = performance.now();
      const rms = pcmRms(chunk);

      const calibrationMs = modelWakeRememberedNoiseFloor > 0 ? 30 : profile.calibrationMs;
      if (!modelWakeSpeechActive && now - modelWakeCalibrationStartedAt < calibrationMs) {
        modelWakeNoiseFloor = modelWakeNoiseFloor === 0 ? rms : (modelWakeNoiseFloor * 0.88 + rms * 0.12);
        modelWakeRememberedNoiseFloor = modelWakeNoiseFloor;
        modelWakeEffectiveThreshold = Math.max(configuredThreshold, modelWakeNoiseFloor * profile.noiseMultiplier);
        return;
      }

      modelWakeEffectiveThreshold = Math.max(configuredThreshold, modelWakeNoiseFloor * profile.noiseMultiplier);
      if (ui.wakeListenerStatus.textContent.startsWith("Preparing")) {
        ui.wakeListenerStatus.textContent = `Listening locally for “${config.wake_keyword}”`;
        logEvent("wake.listener.calibrated", `noise ${modelWakeNoiseFloor.toFixed(4)}, threshold ${modelWakeEffectiveThreshold.toFixed(4)}`);
      }

      if (!modelWakeSpeechActive) {
        modelWakePreroll.push(chunk);
        modelWakePrerollSamples += chunk.length;
        while (modelWakePrerollSamples > prerollLimit && modelWakePreroll.length > 1) {
          const removed = modelWakePreroll.shift();
          modelWakePrerollSamples -= removed.length;
        }
        if (rms >= modelWakeEffectiveThreshold) {
          modelWakeConsecutiveSignalFrames += 1;
        } else {
          modelWakeConsecutiveSignalFrames = 0;
          modelWakeNoiseFloor = modelWakeNoiseFloor === 0 ? rms : (modelWakeNoiseFloor * 0.995 + rms * 0.005);
        }
        if (modelWakeConsecutiveSignalFrames >= profile.startFrames) {
          resetWakeStageMetrics();
          modelWakeSpeechActive = true;
          modelWakeFrames = [...modelWakePreroll];
          modelWakeCapturedSamples = modelWakeFrames.reduce((total, frame) => total + frame.length, 0);
          modelWakeVoicedSamples = chunk.length * profile.startFrames;
          modelWakePeakRms = rms;
          modelWakePreroll = [];
          modelWakePrerollSamples = 0;
          modelWakeLastSignalAt = now;
          ui.wakeListenerStatus.textContent = "Capturing wake request locally…";
          logEvent("wake.audio.speech_started", `rms ${rms.toFixed(4)}, threshold ${modelWakeEffectiveThreshold.toFixed(4)}`);
        }
        return;
      }
      modelWakeFrames.push(chunk);
      modelWakeCapturedSamples += chunk.length;
      modelWakePeakRms = Math.max(modelWakePeakRms, rms);
      if (rms >= modelWakeEffectiveThreshold) {
        modelWakeLastSignalAt = now;
        modelWakeVoicedSamples += chunk.length;
      }
      const durationMs = modelWakeCapturedSamples / modelWakeSampleRate * 1000;
      const adaptiveSilenceMs = durationMs < 900
        ? profile.minSilenceMs
        : Math.min(silenceMs, profile.maxSilenceMs);
      if (durationMs >= maxSpeechMs) {
        finishModelWakeUtterance("maximum_duration");
      } else if (now - modelWakeLastSignalAt >= adaptiveSilenceMs) {
        finishModelWakeUtterance("adaptive_silence");
      }
    };
    ui.configurationMessage.textContent = "Sleeping audio stays local until clear speech ends; only that short utterance is sent for wake transcription.";
    logEvent("wake.listener.armed", `${config.wake_transcription_model}; ${ui.wakeProfile?.value || "fast"} profile`);
  } catch (error) {
    await stopModelWakeListener();
    ui.wakeListenerStatus.textContent = "Wake microphone unavailable";
    ui.configurationMessage.textContent = `Local wake microphone failed: ${error.message}`;
    logEvent("wake.listener.failed", error.message);
  }
}

function clearPlaceholder() {
  const placeholder = ui.transcript.querySelector(".placeholder");
  if (placeholder) placeholder.remove();
}

function addBubble(role, text = "", {speakerLabel = "", responsePurpose = ""} = {}) {
  const shouldFollow = transcriptStickToBottom || isTranscriptNearBottom() || role === "user";
  clearPlaceholder();
  const bubble = document.createElement("div");
  bubble.className = `bubble ${role}`;
  if (responsePurpose) {
    bubble.dataset.responsePurpose = responsePurpose;
    if (responsePurpose === SPOKEN_SUMMARY_PURPOSE) {
      bubble.classList.add("unified-answer", "pending-written-answer");
    }
  }
  const speaker = document.createElement("span");
  speaker.className = "speaker";
  speaker.textContent = speakerLabel || (role === "user" ? "Unknown speaker" : "JARVIS");
  const content = document.createElement("span");
  content.className = "content";
  content.textContent = text;
  bubble.append(speaker, content);
  ui.transcript.appendChild(bubble);
  if (shouldFollow) transcriptStickToBottom = true;
  scrollTranscriptToLatest({behavior: role === "user" ? "smooth" : "auto"});
  return bubble;
}

function appendBubble(bubble, text) {
  if (!bubble) return;
  const content = bubble.querySelector(".content");
  if (!content) return;
  content.textContent += text || "";
  updateBubbleReaderControl(bubble);
  scrollTranscriptToLatest({behavior: "auto"});
}

function composeHybridWrittenAnswer(pending, detailedText, {fallback = false} = {}) {
  const spoken = normalizeDetailedText(pending?.spokenSummary || "");
  const detail = normalizeDetailedText(detailedText || "");
  if (fallback) return detail || spoken;
  if (pending?.writtenProvider === "connected_actions" && detail) return detail;
  if (!spoken) return detail;
  if (!detail) return spoken;
  const spokenFingerprint = transcriptFingerprint(spoken);
  const detailFingerprint = transcriptFingerprint(detail);
  if (spokenFingerprint && detailFingerprint.startsWith(spokenFingerprint)) return detail;
  return `${spoken}\n\n${detail}`;
}

function renderUnifiedWrittenAnswer(pending, text, {fallback = false} = {}) {
  if (!pending) return null;
  const finalText = normalizeDetailedText(text);
  if (!finalText) return pending.bubble || null;
  const bubble = pending.bubble;
  if (!bubble) return null;
  bubble.dataset.responsePurpose = HYBRID_ANSWER_PURPOSE;
  bubble.classList.remove("pending-written-answer");
  bubble.classList.add("unified-answer", "detailed-answer");
  bubble.classList.toggle("written-answer-fallback", fallback);
  const speaker = bubble.querySelector(".speaker");
  if (speaker) speaker.textContent = "JARVIS";
  finalizeBubble(bubble, finalText);
  return bubble;
}

function sizeLongAnswerPreview(bubble) {
  if (!ui.transcript || !bubble?.classList.contains("message-preview-clamped")) return false;
  const viewportSizedHeight = Math.floor(ui.transcript.clientHeight * LONG_ANSWER_PREVIEW_VIEWPORT_RATIO);
  const availableHeight = Math.min(
    LONG_ANSWER_PREVIEW_MAX_HEIGHT_PX,
    Math.max(LONG_ANSWER_PREVIEW_MIN_HEIGHT_PX, viewportSizedHeight),
  );
  bubble.style.setProperty("--message-preview-max-height", `${availableHeight}px`);
  const content = bubble.querySelector(".content");
  const overflowing = Boolean(
    (content && content.scrollHeight > content.clientHeight + 1)
      || bubble.scrollHeight > bubble.clientHeight + 1,
  );
  bubble.classList.toggle("message-preview-overflowing", overflowing);
  updateBubbleReaderControl(bubble);
  return overflowing;
}

function resizeLongAnswerPreviews() {
  if (!ui.transcript) return;
  ui.transcript.querySelectorAll(".bubble.jarvis.message-preview-clamped").forEach(sizeLongAnswerPreview);
}

function revealLongAnswerPreview(bubble, {behavior = "smooth"} = {}) {
  if (!ui.transcript || !bubble) return;
  bubble.classList.add("message-preview-clamped");
  if (!sizeLongAnswerPreview(bubble)) {
    scrollTranscriptToLatest({behavior});
    return;
  }
  transcriptStickToBottom = false;
  window.requestAnimationFrame(() => {
    sizeLongAnswerPreview(bubble);
    const transcriptRect = ui.transcript.getBoundingClientRect();
    const bubbleRect = bubble.getBoundingClientRect();
    const targetTop = Math.max(0, ui.transcript.scrollTop + bubbleRect.top - transcriptRect.top - 8);
    ui.transcript.scrollTo({top: targetTop, behavior});
    window.requestAnimationFrame(() => {
      transcriptStickToBottom = false;
      updateJumpLatestVisibility();
    });
  });
}

function messageTextForReader(bubble) {
  const content = normalizeDetailedText(bubble?.querySelector(".content")?.textContent || "");
  const presentation = normalizeDetailedText(bubble?.dataset?.presentationText || "");
  return [content, presentation].filter(Boolean).join("\n\n");
}

function renderMessageReaderContent(bubble) {
  if (!ui.messageReaderContent || !bubble) return;
  ui.messageReaderContent.replaceChildren();
  ui.messageReaderContent.classList.remove("email-message-reader", "calendar-message-reader", "task-message-reader");

  const taskPresentation = bubble.querySelector(".task-presentation");
  if (taskPresentation) {
    ui.messageReaderContent.classList.add("task-message-reader");
    const summary = normalizeDetailedText(bubble.querySelector(".content")?.textContent || "");
    if (summary) { const summaryNode = document.createElement("p"); summaryNode.className = "message-reader-calendar-summary"; summaryNode.textContent = summary; ui.messageReaderContent.append(summaryNode); }
    const clone = taskPresentation.cloneNode(true);
    clone.classList.add("task-presentation-fullscreen");
    ui.messageReaderContent.append(clone);
    if (ui.messageReaderTitle) ui.messageReaderTitle.textContent = "Tasks";
    return;
  }

  const calendarPresentation = bubble.querySelector(".calendar-event-presentation, .calendar-availability-presentation");
  if (calendarPresentation) {
    ui.messageReaderContent.classList.add("calendar-message-reader");
    const summary = normalizeDetailedText(bubble.querySelector(".content")?.textContent || "");
    if (summary) {
      const summaryNode = document.createElement("p");
      summaryNode.className = "message-reader-calendar-summary";
      summaryNode.textContent = summary;
      ui.messageReaderContent.append(summaryNode);
    }
    const calendarClone = calendarPresentation.cloneNode(true);
    calendarClone.classList.add("calendar-event-presentation-fullscreen");
    calendarClone.querySelectorAll(".calendar-event-preview").forEach((card) => card.classList.add("calendar-event-preview-fullscreen"));
    ui.messageReaderContent.append(calendarClone);
    if (ui.messageReaderTitle) ui.messageReaderTitle.textContent = "Calendar";
    return;
  }

  const emailReadPresentation = bubble.querySelector(".email-read-presentation");
  if (emailReadPresentation) {
    ui.messageReaderContent.classList.add("email-message-reader");
    const summary = normalizeDetailedText(bubble.querySelector(".content")?.textContent || "");
    if (summary) {
      const summaryNode = document.createElement("p");
      summaryNode.className = "message-reader-email-summary";
      summaryNode.textContent = summary;
      ui.messageReaderContent.append(summaryNode);
    }
    const readClone = emailReadPresentation.cloneNode(true);
    readClone.classList.add("email-read-presentation-fullscreen");
    readClone.removeAttribute("aria-label");
    readClone.querySelectorAll(".email-draft-preview").forEach((card) => card.classList.add("email-draft-preview-fullscreen"));
    ui.messageReaderContent.append(readClone);
    if (ui.messageReaderTitle) ui.messageReaderTitle.textContent = "Gmail";
    return;
  }

  const emailPreview = bubble.querySelector(".email-draft-preview");
  if (emailPreview) {
    ui.messageReaderContent.classList.add("email-message-reader");
    const summary = normalizeDetailedText(bubble.querySelector(".content")?.textContent || "");
    if (summary) {
      const summaryNode = document.createElement("p");
      summaryNode.className = "message-reader-email-summary";
      summaryNode.textContent = summary;
      ui.messageReaderContent.append(summaryNode);
    }
    const previewClone = emailPreview.cloneNode(true);
    previewClone.classList.add("email-draft-preview-fullscreen");
    previewClone.removeAttribute("aria-label");
    const fullscreenEdit = previewClone.querySelector(".email-draft-edit-button");
    if (fullscreenEdit && bubble._emailDraftPresentation?.editable) {
      fullscreenEdit.addEventListener("click", () => beginEmailDraftEdit(previewClone, bubble, bubble._emailDraftPresentation));
    }
    ui.messageReaderContent.append(previewClone);
    const label = normalizeNaturalText(emailPreview.querySelector(".email-draft-preview-head strong")?.textContent || "");
    if (ui.messageReaderTitle) ui.messageReaderTitle.textContent = label === "EMAIL SENT" ? "Email sent" : "Email draft";
    return;
  }

  const webPresentation = bubble.querySelector(".web-intelligence-presentation");
  if (webPresentation) {
    const summary = normalizeDetailedText(bubble.querySelector(".content")?.textContent || "");
    if (summary) {
      const summaryNode = document.createElement("p");
      summaryNode.className = "message-reader-web-summary";
      summaryNode.textContent = summary;
      ui.messageReaderContent.append(summaryNode);
    }
    const clone = webPresentation.cloneNode(true);
    clone.classList.add("web-intelligence-presentation-fullscreen");
    // Fullscreen clones cannot safely retain the original event listeners. Rebind
    // source buttons from their stable source order and cached result id.
    const sourceData = activeMessageReaderBubble?._webIntelligencePresentation || null;
    if (sourceData) {
      clone.querySelectorAll(".web-intelligence-source").forEach((button, index) => {
        const source = sourceData.sources?.[index];
        if (!source) return;
        button.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          const status = clone.querySelector(".web-intelligence-head span");
          void openWebIntelligenceCitation(source.url, status);
        });
      });
      clone.querySelectorAll(".web-intelligence-citation").forEach((button) => {
        const sourceId = String(button.dataset.sourceId || "");
        if (!sourceId) return;
        button.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          const status = clone.querySelector(".web-intelligence-head span");
          const source = sourceData.sources?.find((candidate) => String(candidate?.id || "") === sourceId);
          void openWebIntelligenceCitation(source?.url, status);
        });
      });
    }
    ui.messageReaderContent.append(clone);
    if (ui.messageReaderTitle) ui.messageReaderTitle.textContent = "Web Intelligence";
    return;
  }

  ui.messageReaderContent.textContent = messageTextForReader(bubble);
  if (ui.messageReaderTitle) ui.messageReaderTitle.textContent = "Jarvis answer";
}

function closeMessageReader() {
  if (!ui.messageReaderOverlay || ui.messageReaderOverlay.hidden) return;
  ui.messageReaderOverlay.hidden = true;
  document.body.classList.remove("message-reader-open");
  activeMessageReaderBubble = null;
  const focusTarget = messageReaderPreviousFocus;
  messageReaderPreviousFocus = null;
  if (focusTarget?.isConnected && typeof focusTarget.focus === "function") focusTarget.focus();
}

function refreshOpenMessageReader() {
  if (!activeMessageReaderBubble || !ui.messageReaderContent) return;
  renderMessageReaderContent(activeMessageReaderBubble);
}

function openMessageReader(bubble) {
  if (!ui.messageReaderOverlay || !ui.messageReaderContent || !bubble) return;
  activeMessageReaderBubble = bubble;
  messageReaderPreviousFocus = document.activeElement;
  refreshOpenMessageReader();
  ui.messageReaderOverlay.hidden = false;
  document.body.classList.add("message-reader-open");
  ui.messageReaderClose?.focus();
}

function updateBubbleReaderControl(bubble) {
  if (!bubble?.classList.contains("jarvis")) return;
  const isClampedDetail = bubble.classList.contains("detailed-answer")
    || bubble.classList.contains("message-preview-clamped");
  const actualOverflow = bubble.classList.contains("message-preview-overflowing");
  const viewportHeight = Math.max(0, Number(ui.transcript?.clientHeight || 0));
  const tallThreshold = Math.max(
    MESSAGE_READER_MIN_HEIGHT_PX,
    Math.floor(viewportHeight * MESSAGE_READER_VIEWPORT_RATIO),
  );
  const naturallyTall = !isClampedDetail && bubble.scrollHeight > tallThreshold;
  const hasPresentationCard = Boolean(bubble.querySelector(".connected-action-presentation, .web-intelligence-presentation"));
  const eligible = actualOverflow || naturallyTall || hasPresentationCard;
  let button = bubble.querySelector(".message-reader-button");
  let overflowButton = bubble.querySelector(".message-reader-overflow-button");
  if (!eligible) {
    button?.remove();
    overflowButton?.remove();
    return;
  }
  if (!button) {
    button = document.createElement("button");
    button.type = "button";
    button.className = "message-reader-button";
    button.textContent = "Fullscreen";
    button.setAttribute("aria-label", "Open this Jarvis answer in the fullscreen reader");
    button.setAttribute("aria-haspopup", "dialog");
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      openMessageReader(bubble);
    });
    bubble.appendChild(button);
  }
  if (actualOverflow) {
    if (!overflowButton) {
      overflowButton = document.createElement("button");
      overflowButton.type = "button";
      overflowButton.className = "message-reader-overflow-button";
      overflowButton.textContent = "Answer continues — Open fullscreen";
      overflowButton.setAttribute("aria-label", "Open this complete Jarvis result in the fullscreen reader");
      overflowButton.setAttribute("aria-haspopup", "dialog");
      overflowButton.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        openMessageReader(bubble);
      });
      bubble.appendChild(overflowButton);
    }
  } else {
    overflowButton?.remove();
  }
  if (activeMessageReaderBubble === bubble) refreshOpenMessageReader();
}

function finalizeBubble(bubble, finalText) {
  if (!bubble) return;
  if (finalText) bubble.querySelector(".content").textContent = finalText;
  updateBubbleReaderControl(bubble);
  if (bubble.classList.contains("detailed-answer")) {
    revealLongAnswerPreview(bubble);
    return;
  }
  scrollTranscriptToLatest({behavior: "smooth"});
}

function isVoiceTurnPlaceholder(text) {
  const normalized = normalizeNaturalText(text).toLowerCase();
  return !normalized
    || normalized === "listening..."
    || normalized === "listening…"
    || normalized === "processing speech..."
    || normalized === "processing speech…";
}

function providerVoiceItemId(event = {}) {
  return event.item_id || event.item?.id || "";
}

function registerVoiceTranscriptTurn(bubble, turnEpoch = voiceTurnEpoch, {permissionQuarantined = false} = {}) {
  const turn = {
    bubble,
    itemId: "",
    resolved: false,
    fallbackTimer: null,
    falseVadRecoveryTimer: null,
    bufferedTranscript: "",
    turnEpoch,
    bargeInCommitted: false,
    permissionQuarantined: Boolean(permissionQuarantined),
  };
  pendingVoiceTranscriptTurns.push(turn);
  while (pendingVoiceTranscriptTurns.length > 12) {
    const stale = pendingVoiceTranscriptTurns.shift();
    if (!stale) break;
    clearTimeout(stale.fallbackTimer);
    clearTimeout(stale.falseVadRecoveryTimer);
    if (!stale.resolved && stale.bubble?.isConnected) {
      const current = stale.bubble.querySelector(".content")?.textContent || "";
      if (isVoiceTurnPlaceholder(current)) stale.bubble.remove();
    }
  }
  return turn;
}

function voiceTranscriptTurnForBubble(bubble) {
  return pendingVoiceTranscriptTurns.find((turn) => !turn.resolved && turn.bubble === bubble) || null;
}

function claimVoiceTranscriptTurn(event = {}) {
  const itemId = providerVoiceItemId(event);
  let turn = itemId
    ? pendingVoiceTranscriptTurns.find((candidate) => !candidate.resolved && candidate.itemId === itemId)
    : null;
  if (!turn) turn = pendingVoiceTranscriptTurns.find((candidate) => !candidate.resolved && !candidate.itemId) || null;
  if (!turn && activeUserBubble) turn = voiceTranscriptTurnForBubble(activeUserBubble) || registerVoiceTranscriptTurn(activeUserBubble);
  if (turn && itemId) turn.itemId = itemId;
  return turn;
}

function finishVoiceTranscriptTurn(turn, {text = "", remove = false} = {}) {
  if (!turn || turn.resolved) return;
  clearTimeout(turn.fallbackTimer);
  clearTimeout(turn.falseVadRecoveryTimer);
  turn.fallbackTimer = null;
  turn.falseVadRecoveryTimer = null;
  turn.resolved = true;
  if (remove) turn.bubble?.remove();
  else if (text && turn.bubble?.isConnected) finalizeBubble(turn.bubble, text);
  if (activeUserBubble === turn.bubble) activeUserBubble = null;
  pendingVoiceTranscriptTurns = pendingVoiceTranscriptTurns.filter((candidate) => candidate !== turn);
}

function settleOlderVoiceTurnsBeforeNewSpeech() {
  for (const turn of pendingVoiceTranscriptTurns) {
    if (turn.resolved) continue;
    clearTimeout(turn.fallbackTimer);
    clearTimeout(turn.falseVadRecoveryTimer);
    const current = turn.bubble?.querySelector(".content")?.textContent || "";
    if (turn.bubble?.isConnected && isVoiceTurnPlaceholder(current)) turn.bubble.remove();
    turn.resolved = true;
  }
  pendingVoiceTranscriptTurns = [];
}

function clearVoiceBargeInCandidate() {
  clearTimeout(voiceBargeInTimer);
  voiceBargeInTimer = null;
  voiceBargeInEpoch = 0;
}

function currentVoiceTurnForEpoch(turnEpoch = voiceTurnEpoch) {
  return [...pendingVoiceTranscriptTurns].reverse().find((candidate) => !candidate.resolved && candidate.turnEpoch === turnEpoch) || null;
}

function commitVoiceBargeIn(turnEpoch = voiceTurnEpoch, reason = "sustained_vad") {
  if (Number(turnEpoch || 0) !== Number(voiceTurnEpoch || 0) || trustedPermissionPromptActive()) return false;
  const turn = currentVoiceTurnForEpoch(turnEpoch);
  if (turn) turn.bargeInCommitted = true;
  clearVoiceBargeInCandidate();
  // Do not let a single provider VAD edge kill work or speech. Only a sustained
  // microphone turn reaches this point, filtering clicks, fan bursts, controller
  // noise, and other short false starts while keeping real barge-in responsive.
  void cancelWebResearch(`voice_barge_in:${reason}`);
  void cancelBrowserAction(`voice_barge_in:${reason}`);
  if (dedicatedSpeechIsActive() || responseActive || remoteAudioActive || jarvisSpeakingStartedAt) {
    interruptResponse("voice", false);
  }
  setStatus("Listening", "listening", {immediate: true});
  relayEvent("client.voice.barge_in.confirmed", {turn_epoch: Number(turnEpoch || 0), reason});
  return true;
}

function armVoiceBargeInCandidate(turnEpoch = voiceTurnEpoch) {
  clearVoiceBargeInCandidate();
  voiceBargeInEpoch = Number(turnEpoch || 0);
  voiceBargeInTimer = window.setTimeout(() => {
    const epoch = voiceBargeInEpoch;
    if (!epoch) return;
    commitVoiceBargeIn(epoch, "sustained_vad");
  }, VOICE_BARGE_IN_CONFIRM_MS);
}

function restoreStatusAfterFalseVad() {
  if (dedicatedSpeechIsActive() || remoteAudioActive || jarvisSpeakingStartedAt) {
    setStatus("Speaking", "speaking", {immediate: true});
  } else if (responseActive) {
    setStatus("Thinking", "thinking", {immediate: true});
  } else {
    setStatus("Listening", "listening", {immediate: true});
  }
}

function armFalseVadRecovery(turn, reason = "short_vad_without_transcript") {
  if (!turn || turn.resolved || turn.permissionQuarantined) return;
  clearTimeout(turn.falseVadRecoveryTimer);
  turn.falseVadRecoveryTimer = window.setTimeout(() => {
    if (turn.resolved) return;
    const current = turn.bubble?.querySelector(".content")?.textContent || "";
    if (turn.bubble?.isConnected && isVoiceTurnPlaceholder(current)) turn.bubble.remove();
    turn.resolved = true;
    pendingVoiceTranscriptTurns = pendingVoiceTranscriptTurns.filter((candidate) => candidate !== turn);
    if (activeUserBubble === turn.bubble) activeUserBubble = null;
    restoreStatusAfterFalseVad();
    relayEvent("client.voice.false_vad.recovered", {reason, turn_epoch: Number(turn.turnEpoch || 0)});
  }, VOICE_FALSE_VAD_RECOVERY_MS);
  relayEvent("client.voice.false_vad.pending", {reason, turn_epoch: Number(turn.turnEpoch || 0), grace_ms: VOICE_FALSE_VAD_RECOVERY_MS});
}

function transcriptFingerprint(text) {
  return normalizeNaturalText(text).toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function isInternalTranscriptionArtifact(text) {
  const candidate = transcriptFingerprint(text);
  const guidance = transcriptFingerprint(INTERNAL_TRANSCRIPTION_GUIDANCE);
  if (!candidate) return false;
  if (candidate === guidance) return true;
  // Low-information audio can echo only part of the private transcription prompt.
  // Suppress substantial prompt prefixes/suffixes before they ever reach chat or memory.
  return candidate.length >= 48 && (guidance.includes(candidate) || candidate.includes(guidance));
}

function isRecentDuplicateVoiceTranscript(text, turnEpoch = voiceTurnEpoch) {
  const content = transcriptFingerprint(text);
  if (!content) return false;
  // Provider duplicate completion events belong to the same microphone turn.
  // A user intentionally repeating the same words starts a new turn epoch and
  // must never be swallowed as a content duplicate.
  const signature = `${Number(turnEpoch || 0)}|${content}`;
  const now = Date.now();
  for (const [key, timestamp] of recentVoiceTranscriptSignatures) {
    if (now - timestamp > VOICE_TRANSCRIPT_DEDUPE_WINDOW_MS) recentVoiceTranscriptSignatures.delete(key);
  }
  const prior = recentVoiceTranscriptSignatures.get(signature) || 0;
  recentVoiceTranscriptSignatures.set(signature, now);
  return prior > 0 && now - prior <= VOICE_TRANSCRIPT_DEDUPE_WINDOW_MS;
}

function voiceTurnIsCurrent(turnEpoch) {
  return Number(turnEpoch || 0) === Number(voiceTurnEpoch || 0);
}

function suppressStaleVoiceTurn(turnEpoch, stage) {
  if (voiceTurnIsCurrent(turnEpoch)) return false;
  logEvent("voice.turn.stale_response_suppressed", `${stage}; turn ${turnEpoch}; current ${voiceTurnEpoch}`);
  relayEvent("client.voice.turn.stale_response_suppressed", {
    stage,
    turn_epoch: Number(turnEpoch || 0),
    current_turn_epoch: Number(voiceTurnEpoch || 0),
  });
  return true;
}

function finalizeUntranscribedVoiceTurn(reason) {
  if (!activeUserBubble) return false;
  const current = activeUserBubble.querySelector(".content")?.textContent || "";
  if (!isVoiceTurnPlaceholder(current)) return false;
  const turn = voiceTranscriptTurnForBubble(activeUserBubble) || registerVoiceTranscriptTurn(activeUserBubble);
  if (turn.fallbackTimer) return true;
  activeUserBubble = null;
  turn.fallbackTimer = setTimeout(() => {
    if (turn.resolved || !turn.bubble?.isConnected) return;
    const latest = turn.bubble.querySelector(".content")?.textContent || "";
    if (isVoiceTurnPlaceholder(latest)) turn.bubble.remove();
    relayEvent("client.voice.transcript.unavailable", {reason});
    turn.fallbackTimer = null;
  }, VOICE_TRANSCRIPT_FALLBACK_DELAY_MS);
  relayEvent("client.voice.transcript.pending", {reason, grace_ms: VOICE_TRANSCRIPT_FALLBACK_DELAY_MS});
  return true;
}

function markBubbleInterrupted(bubble, reason) {
  if (!bubble || bubble.querySelector(".marker")) return;
  bubble.classList.add("interrupted");
  const marker = document.createElement("span");
  marker.className = "marker";
  marker.textContent = reason === "manual" ? "Stopped by user" : "Interrupted by user";
  bubble.appendChild(marker);
}

function extractInputTranscript(event) {
  if (typeof event.transcript === "string") return event.transcript;
  const content = event.item?.content;
  if (!Array.isArray(content)) return "";
  return content.map((part) => part.transcript || part.text || "").filter(Boolean).join(" ");
}

function extractResponseTranscript(response = {}) {
  const output = Array.isArray(response.output) ? response.output : [];
  const parts = [];
  for (const item of output) {
    const content = Array.isArray(item?.content) ? item.content : [];
    for (const part of content) {
      const text = part?.transcript || part?.text || "";
      if (typeof text === "string" && text.trim()) parts.push(text.trim());
    }
  }
  return normalizeNaturalText(parts.join(" "));
}

function normalizeNaturalText(text) {
  return (text || "").replace(/\s+/g, " ").trim();
}

function decodeHtmlEntities(text) {
  let value = String(text || "");
  if (!value.includes("&")) return value;
  const textarea = document.createElement("textarea");
  for (let pass = 0; pass < 3; pass += 1) {
    textarea.innerHTML = value;
    const decoded = textarea.value;
    if (decoded === value) break;
    value = decoded;
  }
  return value.replace(/\u00a0/g, " ");
}

function normalizeDetailedText(text) {
  return decodeHtmlEntities(String(text || ""))
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{4,}/g, "\n\n\n")
    .trim();
}

function responsePurposeFromEvent(event = {}, {claimPending = false} = {}) {
  const responseId = resolvedResponseId(event) || providerResponseId(event);
  const direct = event.response?.metadata?.response_purpose || event.metadata?.response_purpose || "";
  if (direct && responseId) responsePurposesById.set(responseId, direct);
  let queued = "";
  if (claimPending && responseId && !direct && !responsePurposesById.has(responseId) && pendingResponsePurposes.length) {
    queued = pendingResponsePurposes.shift() || "";
    if (queued) responsePurposesById.set(responseId, queued);
  } else if (claimPending && direct && pendingResponsePurposes[0] === direct) {
    pendingResponsePurposes.shift();
  }
  const activePurpose = activeResponseId ? responsePurposesById.get(activeResponseId) : "";
  return direct
    || queued
    || (responseId ? responsePurposesById.get(responseId) : "")
    || activePurpose
    || STANDARD_VOICE_PURPOSE;
}

function isSpokenSummaryEvent(event = {}) {
  return responsePurposeFromEvent(event) === SPOKEN_SUMMARY_PURPOSE;
}

function explicitlyRequestsDetailedAnswer(text) {
  return /\b(in detail|detailed|deep dive|thorough|comprehensive|step[- ]by[- ]step|walk me through|break it down|analy[sz]e|compare|research|strategy|architecture|limitations?|capabilit(?:y|ies)|from the inside out|pros and cons|write|draft|outline|build me|help me understand)\b/i.test(normalizeNaturalText(text));
}

function memoryIntentPrefersOneNaturalReply(memoryContext = null) {
  const intent = String(memoryContext?.intent || "").trim();
  return new Set([
    "source_explanation",
    "history",
    "open_work",
    "recall",
    "identity_or_relationship",
    "decision",
  ]).has(intent);
}

function shouldCreateDetailedTextCompanion(text, {memoryContext = null} = {}) {
  if (!config?.dual_channel_answers_enabled) return false;
  if (ui.responseMode?.value === "full") return false;
  const normalized = normalizeNaturalText(text);
  if (!normalized) return false;
  if (isSleepCommand(normalized) || parseAddressPreferenceCommand(normalized)) return false;
  if (isVoiceIdentityQuestion(normalized) || isVoiceIdentityExplanationQuestion(normalized)) return false;
  if (parseMemoryNavigationIntent(normalized)) return false;
  if (memoryContext?.ambiguous) return false;
  const explicit = explicitlyRequestsDetailedAnswer(normalized);
  if (memoryIntentPrefersOneNaturalReply(memoryContext) && !explicit) return false;
  if (/^(thanks|thank you|okay|ok|yes|no|sure|got it|hello|hey|hi|goodbye|bye)[.!?]*$/i.test(normalized)) return false;
  if (/^(what time is it|what(?:'s| is) my name|who am i|are you there|can you hear me)[?!.]*$/i.test(normalized)) return false;
  const words = normalized.split(/\s+/).filter(Boolean).length;
  const explanatory = /\b(explain|plan|what can you do|who are you|how do you work)\b/i.test(normalized);
  const openQuestion = /^(how|why|what|which|where|when|who|could you|would you|can you|tell me|describe)\b/i.test(normalized);
  return explicit || explanatory || (openQuestion && words >= 9) || words >= 18;
}

function recentConversationContextForDetail() {
  const rows = [...ui.transcript.querySelectorAll(".bubble")].slice(-12);
  const lines = [];
  for (const bubble of rows) {
    const purpose = bubble.dataset.responsePurpose || "";
    if (purpose === SPOKEN_SUMMARY_PURPOSE) continue;
    const rawLabel = normalizeNaturalText(bubble.querySelector(".speaker")?.textContent || "");
    const speaker = bubble.classList.contains("user")
      ? ((rawLabel && !["YOU", "LISTENING"].includes(rawLabel.toUpperCase())) ? rawLabel : "User")
      : "Jarvis";
    const content = normalizeDetailedText(bubble.querySelector(".content")?.textContent || "");
    if (content) lines.push(`${speaker}: ${content}`);
  }
  const joined = lines.join("\n");
  return joined.length > DETAILED_CONTEXT_MAX_CHARACTERS
    ? joined.slice(joined.length - DETAILED_CONTEXT_MAX_CHARACTERS)
    : joined;
}

function spokenSummaryInstructions() {
  const profile = config?.response_mode_profiles?.[ui.responseMode.value] || {};
  const maxSentences = Number(profile.max_sentences || 0);
  const limits = [];
  if (maxSentences > 0) limits.push(`${maxSentences} sentence${maxSentences === 1 ? "" : "s"}`);
  if (Number(profile.max_words || 0) > 0) limits.push(`${profile.max_words} spoken words`);
  const handoff = maxSentences === 1
    ? "Within that same sentence and inside the hard word limit, end with a brief clause saying the full details are in the written answer."
    : "Reserve the final short sentence, still inside every active limit, for a natural handoff such as: ‘I’ve included the full details in the written answer.’";
  return [
    "This is a longer-form request. Speak one concise, useful summary of the answer.",
    limits.length ? `Hard spoken limit: ${limits.join(" and ")}.` : "Obey the active spoken response mode.",
    "Start with the answer itself. Do not begin with filler such as ‘Okay,’ ‘Let me think,’ or ‘Let me give you.’ Do not read headings, long lists, implementation details, or the full written explanation aloud.",
    handoff,
    "Do not mention internal routing, model names, token limits, a separate model, or that you are capped.",
  ].join(" ");
}

function abortDetailedCompanion(reason = "cancelled") {
  const pending = pendingDetailedCompanion;
  if (!pending) return false;
  pending.abortController?.abort();
  pending.abortController = null;
  pending.textError = reason;
  detailedCompanionInProgress = false;
  pendingTestAutoSleepAfterDetail = false;
  pendingDetailedCompanion = null;
  logEvent("response.hybrid_text.aborted", reason);
  return true;
}

function rememberUnifiedWrittenAnswer(pending, text, {fallback = false} = {}) {
  if (!pending || pending.memoryStored) return;
  const finalText = normalizeDetailedText(text);
  if (!finalText) return;
  pending.memoryStored = true;
  lastAssistantMemoryText = normalizeNaturalText(finalText);
  lastAssistantMemoryAt = Date.now();
  const responseId = pending.writtenResponseId || pending.audioResponseId || `${clientSessionId}:${pending.requestedAt}`;
  const writtenProvider = fallback ? "realtime" : (pending.writtenProvider || "responses_api");
  void rememberMemory({
    content: finalText,
    source: "assistant",
    kind: "response",
    actor: "Jarvis",
    sourceEventId: `${fallback ? "hybrid_spoken_fallback" : writtenProvider}:${responseId}`,
    metadata: {
      response_purpose: HYBRID_ANSWER_PURPOSE,
      presentation: fallback ? "spoken_summary_fallback" : "written_detail",
      provider: writtenProvider,
      model: fallback ? config?.model : pending.writtenModel,
      parent_response_id: pending.audioResponseId || null,
    },
  });
}

function scheduleTestAutoSleepAfterHybrid() {
  if (ui.responseMode.value !== "test" || !ui.testAutoSleep.checked) return;
  pendingTestAutoSleepAfterDetail = false;
  testAutoSleepPending = true;
  window.setTimeout(() => {
    if (testAutoSleepPending) {
      testAutoSleepPending = false;
      sleepJarvis("test_auto_sleep");
    }
  }, 1200);
}

function settleDetailedCompanion(pending) {
  if (!pending || pending !== pendingDetailedCompanion || !pending.voiceDone) return false;
  if (!pending.textDone && !pending.textError) {
    setStatus("Writing", "thinking", {immediate: true});
    return false;
  }
  if (pending.textDone && pending.writtenAnswer) {
    const combined = composeHybridWrittenAnswer(pending, pending.writtenAnswer);
    renderUnifiedWrittenAnswer(pending, combined);
    rememberUnifiedWrittenAnswer(pending, combined);
  } else {
    const fallback = pending.spokenSummary
      || "I finished the spoken answer, but I couldn’t generate the complete written version.";
    const combinedFallback = composeHybridWrittenAnswer(pending, fallback, {fallback: true});
    renderUnifiedWrittenAnswer(pending, combinedFallback, {fallback: true});
    rememberUnifiedWrittenAnswer(pending, combinedFallback, {fallback: true});
    ui.configurationMessage.textContent = "The detailed text model was unavailable, so Jarvis kept the spoken summary as the written answer.";
  }
  pendingDetailedCompanion = null;
  detailedCompanionInProgress = false;
  setStatus("Listening", "listening", {immediate: true});
  scheduleTestAutoSleepAfterHybrid();
  return true;
}

async function requestDetailedTextCompanion(pending) {
  if (!pending || isSimulationMode() || !clientSessionId) return false;
  if (pending !== pendingDetailedCompanion || pending.abortController) return false;
  const controller = new AbortController();
  pending.abortController = controller;
  detailedCompanionInProgress = true;
  const context = recentConversationContextForDetail();
  logEvent("response.hybrid_text.requested", `${pending.responseMode}; ${config?.text_model || "configured text model"}; ${pending.userText.slice(0, 120)}`);
  void relayEvent("client.response.hybrid_text.requested", {
    response_mode: pending.responseMode,
    text_model: config?.text_model || null,
    characters: pending.userText.length,
  });
  try {
    const response = await fetch("/api/text/detailed-answer", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      signal: controller.signal,
      body: JSON.stringify({
        user_text: pending.userText,
        actor: pending.actor || null,
        conversation_context: context,
        response_mode: pending.responseMode,
        session_id: clientSessionId,
      }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Detailed written answer failed (${response.status})`);
    if (pending !== pendingDetailedCompanion || controller.signal.aborted) return false;
    pending.textDone = true;
    pending.textError = "";
    pending.writtenAnswer = normalizeDetailedText(payload.answer || "");
    pending.writtenResponseId = String(payload.response_id || "");
    pending.writtenModel = String(payload.model || config?.text_model || "");
    pending.abortController = null;
    detailedCompanionInProgress = false;
    if (payload.summary) usageSummary = payload.summary;
    if (payload.budget) budgetState = payload.budget;
    latestResponseCostUsd = Number(payload.record?.cost_usd?.total || latestResponseCostUsd || 0);
    sessionCostUsd = moneyFromSummary("session");
    updateUsageMetrics();
    logEvent("response.hybrid_text.completed", `${pending.writtenModel}; ${pending.writtenAnswer.length} characters`);
    void relayEvent("client.response.hybrid_text.completed", {
      response_id: pending.writtenResponseId || null,
      model: pending.writtenModel || null,
      characters: pending.writtenAnswer.length,
    });
    settleDetailedCompanion(pending);
    return true;
  } catch (error) {
    if (error?.name === "AbortError" || controller.signal.aborted) return false;
    if (pending !== pendingDetailedCompanion) return false;
    pending.abortController = null;
    pending.textDone = false;
    pending.textError = error.message || "Detailed written answer failed";
    detailedCompanionInProgress = false;
    logEvent("response.hybrid_text.failed", pending.textError);
    void relayEvent("client.response.hybrid_text.failed", {message: pending.textError});
    settleDetailedCompanion(pending);
    return false;
  }
}

function isTypedUserItem(item) {
  return item?.role === "user" && Array.isArray(item.content)
    && item.content.some((part) => part.type === "input_text");
}

function consumeTypedEcho(event) {
  if (!isTypedUserItem(event.item)) return false;
  const echoedText = extractInputTranscript(event).trim();
  const index = pendingTypedMessages.findIndex((pending) => pending.text === echoedText);
  if (index < 0) return false;
  const [pending] = pendingTypedMessages.splice(index, 1);
  finalizeBubble(pending.bubble, echoedText);
  relayEvent("client.typed.echo.acknowledged", {
    item_id: event.item?.id || null,
    characters: echoedText.length,
  });
  return true;
}

function metricMs(value) {
  return value > 0 ? `${Math.round(value)} ms` : "—";
}

function publishLatency(kind, durationMs) {
  if (!Number.isFinite(durationMs) || durationMs < 0) return;
  relayEvent("client.latency.measured", {metric: kind, duration_ms: Math.round(durationMs)});
}

function formatShortDuration(totalMs) {
  const seconds = Math.max(0, Math.floor(totalMs / 1000));
  const minutes = Math.floor(seconds / 60);
  const remaining = seconds % 60;
  return `${minutes}:${String(remaining).padStart(2, "0")}`;
}

function formatLongDuration(totalMs) {
  const seconds = Math.max(0, Math.floor(totalMs / 1000));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remaining = seconds % 60;
  if (hours > 0) return `${hours}:${String(minutes).padStart(2, "0")}:${String(remaining).padStart(2, "0")}`;
  return `${minutes}:${String(remaining).padStart(2, "0")}`;
}

function formatUsd(value) {
  return `$${(value || 0).toFixed(4)}`;
}

function resetWakeStageMetrics() {
  wakeTranscriptionCompletedAt = 0;
  wakePreconnectReadyAt = 0;
  wakeFirstAudioObservedAt = 0;
  if (ui.wakeTranscriptionMetric) ui.wakeTranscriptionMetric.textContent = "—";
  if (ui.wakePreconnectMetric) ui.wakePreconnectMetric.textContent = "—";
  if (ui.wakeFirstAudioMetric) ui.wakeFirstAudioMetric.textContent = "—";
}

function applyDesktopPresence(snapshot) {
  if (!snapshot || typeof snapshot !== "object") return;
  desktopPresence = snapshot;
  const now = Date.now();
  const appUptime = snapshot.appStartedAt ? now - snapshot.appStartedAt : 0;
  const coreUptime = snapshot.coreStartedAt ? now - snapshot.coreStartedAt : 0;
  ui.presenceAppUptime.textContent = appUptime > 0 ? formatLongDuration(appUptime) : "—";
  ui.presenceCoreState.textContent = snapshot.coreState || "unknown";
  ui.presenceCoreUptime.textContent = coreUptime > 0 ? formatLongDuration(coreUptime) : "—";
  ui.presenceCoreRestarts.textContent = String(snapshot.coreRestarts || 0);
  ui.presenceRendererRecoveries.textContent = String(snapshot.rendererRecoveries || 0);
  ui.presenceHeartbeat.textContent = snapshot.lastHeartbeatAt
    ? `${Math.max(0, Math.round((now - snapshot.lastHeartbeatAt) / 1000))} s ago`
    : "—";
  ui.startWithWindows.checked = Boolean(snapshot.startWithWindows);
  ui.desktopNotifications.checked = snapshot.notificationsEnabled !== false;
  const state = snapshot.supervisorState || "unknown";
  ui.presenceBadge.textContent = state.charAt(0).toUpperCase() + state.slice(1);
  ui.presenceBadge.className = `presence-badge ${state}`;
  if (ui.homePresenceState) ui.homePresenceState.textContent = ui.presenceBadge.textContent;
  if (ui.homePresenceDetail) ui.homePresenceDetail.textContent = snapshot.lastHeartbeatAt
    ? `Heartbeat ${Math.max(0, Math.round((now - snapshot.lastHeartbeatAt) / 1000))} s ago`
    : "Waiting for heartbeat";
  ui.restartCore.disabled = state === "starting" || state === "recovering" || state === "suspended";
}

async function initializeDesktopPresence() {
  if (!window.jarvisDesktop?.isElectron) {
    ui.presenceBadge.textContent = "Browser mode";
    ui.startWithWindows.disabled = true;
    ui.desktopNotifications.disabled = true;
    ui.restartCore.disabled = true;
    return;
  }
  try {
    applyDesktopPresence(await window.jarvisDesktop.getPresence());
    window.jarvisDesktop.onPresence?.(applyDesktopPresence);
    clearInterval(presenceUiTimer);
    presenceUiTimer = setInterval(() => applyDesktopPresence(desktopPresence), 1000);
  } catch (error) {
    ui.presenceBadge.textContent = "Unavailable";
    logEvent("desktop.presence.failed", error.message);
  }
}

function noteActivity() {
  lastActivityAt = Date.now();
  idleWarningSent = false;
  updateUsageMetrics();
}

function moneyFromSummary(scope, key = "total") {
  return Number(usageSummary?.[scope]?.cost_usd?.[key] || 0);
}

function renderBudgetStatus() {
  const hardStops = budgetState?.hard_stops || [];
  const warnings = budgetState?.warnings || [];
  ui.budgetStatus.className = "budget-badge";
  if (hardStops.length) {
    ui.budgetStatus.classList.add("hard");
    ui.budgetStatus.textContent = `Hard stop: ${hardStops.join(", ")}`;
  } else if (warnings.length) {
    ui.budgetStatus.classList.add("warning");
    ui.budgetStatus.textContent = `Warning: ${warnings.join(", ")}`;
  } else {
    ui.budgetStatus.textContent = "Within budget";
  }
  syncInterfaceSummary();
}

function updateUsageMetrics() {
  const now = Date.now();
  const awakeMs = sessionStartedAt ? now - sessionStartedAt : 0;
  const liveJarvisMs = jarvisSpeakingStartedAt ? (performance.now() - jarvisSpeakingStartedAt) : 0;
  ui.awakeMetric.textContent = awakeMs > 0 ? formatLongDuration(awakeMs) : "—";
  ui.connectedMetric.textContent = isConnected() ? (isSimulationMode() ? "Simulation" : "Yes") : "No";
  ui.userSpeakingMetric.textContent = userSpeakingTotalMs > 0 ? formatLongDuration(userSpeakingTotalMs) : "—";
  ui.jarvisSpeakingMetric.textContent = (jarvisSpeakingTotalMs + liveJarvisMs) > 0
    ? formatLongDuration(jarvisSpeakingTotalMs + liveJarvisMs) : "—";
  ui.responsesMetric.textContent = String(responseCount);
  const providerCalls = usageSummary?.session?.providers || {};
  if (ui.paidCallsMetric) ui.paidCallsMetric.textContent = String(Number(usageSummary?.session?.paid_calls || 0));
  if (ui.textCallsMetric) ui.textCallsMetric.textContent = String(Number(providerCalls.responses_api || 0));
  if (ui.realtimeCallsMetric) ui.realtimeCallsMetric.textContent = String(Number(providerCalls.realtime || 0));
  if (isConnected() && config) {
    const idleElapsedMs = Math.max(0, now - lastActivityAt);
    const idleRemainingMs = Math.max(0, (config.idle_sleep_seconds * 1000) - idleElapsedMs);
    ui.idleMetric.textContent = `${Math.ceil(idleRemainingMs / 1000)} s`;
  } else {
    ui.idleMetric.textContent = "—";
  }
  const ledgerSessionCost = moneyFromSummary("session");
  const displayedSessionCost = isSimulationMode() ? 0 : Math.max(sessionCostUsd, ledgerSessionCost);
  ui.responseCostMetric.textContent = formatUsd(isSimulationMode() ? 0 : latestResponseCostUsd);
  ui.sessionCostMetric.textContent = formatUsd(displayedSessionCost);
  ui.todayCostMetric.textContent = formatUsd(moneyFromSummary("today"));
  ui.monthCostMetric.textContent = formatUsd(moneyFromSummary("month_to_date"));
  ui.cachedSavingsMetric.textContent = formatUsd(moneyFromSummary("session", "cached_savings"));
  ui.audioInputCostMetric.textContent = formatUsd(moneyFromSummary("session", "audio_input") + moneyFromSummary("session", "cached_audio_input"));
  ui.audioOutputCostMetric.textContent = formatUsd(moneyFromSummary("session", "audio_output"));
  ui.textCostMetric.textContent = formatUsd(
    moneyFromSummary("session", "text_input")
    + moneyFromSummary("session", "cached_text_input")
    + moneyFromSummary("session", "text_output")
  );
  if (ui.wakeTranscriptionCostMetric) {
    ui.wakeTranscriptionCostMetric.textContent = formatUsd(moneyFromSummary("session", "transcription"));
  }
  const awakeMinutes = awakeMs / 60000;
  ui.costPerMinuteMetric.textContent = awakeMinutes > 0 ? formatUsd(displayedSessionCost / awakeMinutes) : "—";
  renderBudgetStatus();
  syncInterfaceSummary();
}

async function refreshUsageSummary() {
  try {
    const query = clientSessionId ? `?session_id=${encodeURIComponent(clientSessionId)}` : "";
    const response = await fetch(`/api/usage/summary${query}`, {cache: "no-store"});
    if (!response.ok) throw new Error(`Usage summary failed (${response.status})`);
    const payload = await response.json();
    usageSummary = payload.summary;
    budgetState = payload.budget;
    lastUsageSummaryAt = Date.now();
    sessionCostUsd = moneyFromSummary("session");
    updateUsageMetrics();
    return payload;
  } catch (error) {
    logEvent("usage.summary.failed", error.message);
    return null;
  }
}

async function recordProviderUsage(event) {
  const response = event.response || {};
  const usage = response.usage || event.usage;
  if (!usage || !response.id || !clientSessionId || isSimulationMode()) return null;
  const result = await fetch("/api/usage/record", {
    method: "POST",
    headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
    body: JSON.stringify({
      response_id: response.id,
      session_id: clientSessionId,
      model: config.model,
      response_mode: ui.responseMode.value,
      usage,
    }),
  });
  if (!result.ok) {
    let message = `Usage record failed (${result.status})`;
    try { message = (await result.json()).detail || message; } catch (_) {}
    throw new Error(message);
  }
  const payload = await result.json();
  usageSummary = payload.summary;
  budgetState = payload.budget;
  latestResponseCostUsd = Number(payload.record?.cost_usd?.total || 0);
  sessionCostUsd = moneyFromSummary("session");
  updateUsageMetrics();
  const hardStops = budgetState?.hard_stops || [];
  const warnings = budgetState?.warnings || [];
  if (warnings.length) {
    ui.configurationMessage.textContent = `Budget warning reached for: ${warnings.join(", ")}.`;
  }
  if (hardStops.length) {
    ui.configurationMessage.textContent = `Budget hard limit reached for: ${hardStops.join(", ")}. Jarvis is returning to sleep.`;
    window.setTimeout(() => sleepJarvis("budget_hard_stop"), 250);
  }
  return payload;
}

function resetTurnMetrics() {
  ui.speechMetric.textContent = "—";
  ui.decisionMetric.textContent = "—";
  ui.firstAudioMetric.textContent = "—";
  ui.totalMetric.textContent = "—";
  speechStartedAt = 0;
  speechStoppedAt = 0;
  responseCreatedAt = 0;
  firstAudioAt = 0;
  awaitingFirstAudibleAudio = false;
}

function resetSessionUsage() {
  userSpeakingTotalMs = 0;
  jarvisSpeakingTotalMs = 0;
  jarvisSpeakingStartedAt = 0;
  responseCount = 0;
  sessionCostUsd = 0;
  latestResponseCostUsd = 0;
  if (ui.sleepIntentMetric) ui.sleepIntentMetric.textContent = "—";
  if (ui.sleepAckMetric) ui.sleepAckMetric.textContent = "—";
  if (ui.sleepCompleteMetric) ui.sleepCompleteMetric.textContent = "—";
  resetSleepSequence();
  if (!clientSessionId) clientSessionId = newClientSessionId();
  updateUsageMetrics();
}

function updateConnectedControls(state) {
  const connecting = state === "waking";
  const awake = state === "awake";
  const liveRequiresProvider = !isSimulationMode() && !providerReadyForLive();
  const accountBlocked = !accountReady;
  ui.wake.disabled = connecting || awake || liveRequiresProvider || accountBlocked;
  ui.sleep.disabled = !connecting && !awake;
  ui.mute.disabled = !awake || isSimulationMode();
  ui.stopSpeaking.disabled = !awake || !responseActive;
  ui.voice.disabled = connecting || awake;
  ui.turnDetection.disabled = connecting || awake;
  ui.responseMode.disabled = connecting;
  ui.wakeProfile.disabled = connecting || awake;
  ui.connectionMode.disabled = connecting || awake;
  ui.testAutoSleep.disabled = connecting || awake || ui.responseMode.value !== "test";
  ui.microphone.disabled = connecting || awake;
  ui.textInput.disabled = !awake || accountBlocked;
  ui.sendText.disabled = !awake || typedSubmitInProgress || accountBlocked;
  if (ui.orbWake) ui.orbWake.disabled = ui.wake.disabled;
  if (ui.orbSleep) ui.orbSleep.disabled = ui.sleep.disabled;
  if (ui.orbStop) ui.orbStop.disabled = ui.stopSpeaking.disabled;
  syncInterfaceSummary();
}

function setResponseActive(active) {
  responseActive = active;
  ui.stopSpeaking.disabled = !active || !isConnected();
  if (ui.orbStop) ui.orbStop.disabled = ui.stopSpeaking.disabled;
}

function normalizeRemoteSdp(raw) {
  const withoutBom = raw.replace(/^\uFEFF/, "");
  const lines = withoutBom.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
  if (!lines.length || lines[0].trim() !== "v=0") {
    throw new Error("The local core returned an invalid SDP answer.");
  }
  const normalized = lines.map((line, index) => {
    const cleaned = line.replace(/[ \t]+$/g, "");
    if (!cleaned || /^\s/.test(cleaned)) {
      throw new Error(`The SDP answer contains invalid framing at line ${index + 1}.`);
    }
    return cleaned;
  }).join("\r\n") + "\r\n";
  return normalized;
}

function waitForIceGatheringComplete(connection, timeoutMs = 2500) {
  if (connection.iceGatheringState === "complete") return Promise.resolve();
  return new Promise((resolve) => {
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      connection.removeEventListener("icegatheringstatechange", checkState);
      resolve();
    };
    const checkState = () => {
      if (connection.iceGatheringState === "complete") finish();
    };
    const timer = setTimeout(finish, timeoutMs);
    connection.addEventListener("icegatheringstatechange", checkState);
  });
}

function finalizeJarvisSpeakingSegment(now = performance.now()) {
  if (!jarvisSpeakingStartedAt) {
    remoteAudioActive = false;
    lastRemoteSignalAt = 0;
    return;
  }
  jarvisSpeakingTotalMs += Math.max(0, now - jarvisSpeakingStartedAt);
  jarvisSpeakingStartedAt = 0;
  remoteAudioActive = false;
  lastRemoteSignalAt = 0;
  updateUsageMetrics();
  if (wakeInputGateActive && wakeOpeningResponseDone && wakeOpeningAudioObserved) {
    releaseWakeInputGate("opening_audio_complete");
  }
  if (sleepSequenceActive && sleepAcknowledgementResponseDone && sleepAcknowledgementAudioObserved) {
    armSleepAcknowledgementPlaybackCompletion("audible_acknowledgement_complete");
    return;
  }
  if (testAutoSleepPending && !responseActive) {
    testAutoSleepPending = false;
    window.setTimeout(() => sleepJarvis("test_auto_sleep"), 250);
  }
}

function stopAnalyser() {
  if (analyserFrame) cancelAnimationFrame(analyserFrame);
  analyserFrame = null;
  finalizeJarvisSpeakingSegment();
  remoteAnalyser = null;
  remoteSamples = null;
  if (audioContext) audioContext.close().catch(() => {});
  audioContext = null;
}

async function setupRemoteAnalyser(stream) {
  stopAnalyser();
  const Context = window.AudioContext || window.webkitAudioContext;
  if (!Context) return;
  audioContext = new Context();
  await audioContext.resume();
  const source = audioContext.createMediaStreamSource(stream);
  remoteAnalyser = audioContext.createAnalyser();
  remoteAnalyser.fftSize = 1024;
  remoteAnalyser.smoothingTimeConstant = 0.2;
  remoteSamples = new Float32Array(remoteAnalyser.fftSize);
  source.connect(remoteAnalyser);

  const detect = () => {
    if (!remoteAnalyser || !remoteSamples) return;
    remoteAnalyser.getFloatTimeDomainData(remoteSamples);
    let energy = 0;
    for (const sample of remoteSamples) energy += sample * sample;
    const rms = Math.sqrt(energy / remoteSamples.length);
    const now = performance.now();

    if (rms > REMOTE_AUDIO_THRESHOLD) {
      lastActivityAt = Date.now();
      idleWarningSent = false;
      if (!remoteAudioActive) {
        remoteAudioActive = true;
        jarvisSpeakingStartedAt = now;
        if (sleepSequenceActive && sleepAcknowledgementPending) {
          clearTimeout(sleepAcknowledgementPlaybackTimer);
          sleepAcknowledgementPlaybackTimer = null;
          sleepAcknowledgementAudioObserved = true;
          sleepAcknowledgementAudioStartedAt = sleepAcknowledgementAudioStartedAt || now;
          sleepAcknowledgementLastSignalAt = now;
          armSleepAcknowledgementFallback(SLEEP_ACK_MAX_WAIT_MS);
          if (sleepIntentStartedAt && ui.sleepAckMetric) {
            const ackMs = now - sleepIntentStartedAt;
            ui.sleepAckMetric.textContent = metricMs(ackMs);
            publishLatency("sleep_intent_to_first_ack_audio", ackMs);
          }
          logEvent("sleep.acknowledgement.audio_started");
        }
        if (wakeSpeechEndedAt && !wakeFirstAudioObservedAt) {
          wakeFirstAudioObservedAt = now;
          const wakeToAudioMs = wakeFirstAudioObservedAt - wakeSpeechEndedAt;
          if (ui.wakeFirstAudioMetric) ui.wakeFirstAudioMetric.textContent = metricMs(wakeToAudioMs);
          publishLatency("wake_speech_end_to_first_audio", wakeToAudioMs);
          logEvent("wake.first_audio", `${Math.round(wakeToAudioMs)} ms after speech ended`);
        }
        if (wakeInputGateActive) {
          wakeOpeningAudioObserved = true;
          clearTimeout(wakeNoAudioReleaseTimer);
          wakeNoAudioReleaseTimer = null;
          logEvent("wake.opening.audio.observed");
        }
        setStatus("Speaking", "speaking");
        relayEvent("response.output_audio.started");
      }
      lastRemoteSignalAt = now;
      if (sleepSequenceActive && sleepAcknowledgementAudioObserved) {
        sleepAcknowledgementLastSignalAt = now;
      }
      if (awaitingFirstAudibleAudio) {
        awaitingFirstAudibleAudio = false;
        firstAudioAt = now;
        ui.firstAudioMetric.textContent = metricMs(firstAudioAt - speechStoppedAt);
        publishLatency("speech_stop_to_first_audible_audio", firstAudioAt - speechStoppedAt);
      }
    } else if (remoteAudioActive) {
      const requiredSilenceMs = sleepSequenceActive && sleepAcknowledgementAudioObserved
        ? SLEEP_ACK_AUDIO_SILENCE_MS
        : REMOTE_AUDIO_SILENCE_MS;
      if (now - lastRemoteSignalAt >= requiredSilenceMs) {
        finalizeJarvisSpeakingSegment(now);
        if (!responseActive && !sleepSequenceActive) setStatus("Listening", "listening");
      }
    }

    analyserFrame = requestAnimationFrame(detect);
  };
  detect();
}

function startIdleMonitor() {
  clearInterval(idleTimer);
  lastActivityAt = Date.now();
  idleWarningSent = false;
  idleTimer = setInterval(() => {
    if (!isConnected() || !config) return;
    if (connectedActionRequestInFlight || detailedCompanionInProgress || responseActive) {
      lastActivityAt = Date.now();
      idleWarningSent = false;
      return;
    }
    const idleMs = Date.now() - lastActivityAt;
    const remainingMs = (config.idle_sleep_seconds * 1000) - idleMs;
    if (!idleWarningSent && remainingMs <= config.idle_warning_seconds * 1000 && remainingMs > 0) {
      idleWarningSent = true;
      const seconds = Math.ceil(remainingMs / 1000);
      ui.configurationMessage.textContent = `Jarvis will go back to sleep in about ${seconds} seconds if the session stays idle.`;
      logEvent("idle.sleep.warning", `${seconds} seconds remaining`);
    }
    if (remainingMs <= 0) {
      logEvent("idle.sleep.timeout", `${config.idle_sleep_seconds} seconds idle`);
      sleepJarvis("idle_timeout");
    }
    updateUsageMetrics();
  }, 1000);
}

function stopIdleMonitor() {
  clearInterval(idleTimer);
  idleTimer = null;
}

function startSessionTimers() {
  clearSessionTimers();
  sessionStartedAt = Date.now();
  resetSessionUsage();
  refreshUsageSummary();
  noteActivity();
  const maxMs = config.session_max_minutes * 60 * 1000;
  const warningDelay = Math.max(1000, maxMs - 5 * 60 * 1000);
  sessionWarningTimer = setTimeout(() => {
    ui.configurationMessage.textContent = "Jarvis will sleep in five minutes so the Realtime session can close cleanly.";
    logEvent("session.timeout.warning", "5 minutes remaining");
    relayEvent("client.session.timeout.warning", {remaining_minutes: 5});
  }, warningDelay);
  sessionTimeoutTimer = setTimeout(() => {
    logEvent("session.timeout", `${config.session_max_minutes} minute safety limit`);
    relayEvent("client.session.timeout", {session_minutes: config.session_max_minutes});
    sleepJarvis("session_timeout");
  }, maxMs);
  sessionClockTimer = setInterval(() => {
    const elapsedMs = Date.now() - sessionStartedAt;
    ui.sessionAge.textContent = `Awake ${formatShortDuration(elapsedMs)}`;
    updateUsageMetrics();
  }, 1000);
  startIdleMonitor();
}

function clearSessionTimers() {
  clearTimeout(sessionWarningTimer);
  clearTimeout(sessionTimeoutTimer);
  clearInterval(sessionClockTimer);
  stopIdleMonitor();
  sessionWarningTimer = null;
  sessionTimeoutTimer = null;
  sessionClockTimer = null;
  sessionStartedAt = 0;
  ui.sessionAge.textContent = "Sleeping";
  updateUsageMetrics();
}

function clearReconnectTimers() {
  clearTimeout(reconnectTimer);
  clearTimeout(stableConnectionTimer);
  reconnectTimer = null;
  stableConnectionTimer = null;
}

function interruptResponse(reason = "voice", manual = false) {
  void cancelWebResearch(manual ? "manual_stop" : `interrupt_${reason}`);
  void cancelBrowserAction(manual ? "manual_stop" : `interrupt_${reason}`);
  if (dedicatedSpeechIsActive()) {
    interruptDedicatedSpeech(reason);
    return;
  }
  // Playback can outlive responseActive briefly (for example when a provider
  // completion races the browser's audio buffer). A user barge-in must still
  // clear anything that is audibly playing instead of trusting only the model
  // response flag.
  const audibleOrPendingResponse = responseActive || remoteAudioActive || Boolean(jarvisSpeakingStartedAt);
  if (!audibleOrPendingResponse || !isConnected()) return;
  const interruptedResponseId = activeResponseId;
  const interruptedPurpose = interruptedResponseId
    ? (responsePurposesById.get(interruptedResponseId) || STANDARD_VOICE_PURPOSE)
    : STANDARD_VOICE_PURPOSE;
  const interruptedBubble = interruptedResponseId
    ? (responseBubblesById.get(interruptedResponseId) || activeJarvisBubble)
    : activeJarvisBubble;
  const authoritativeSpeechActive = Boolean(
    interruptedResponseId && authoritativeSpeechResponseIds.has(interruptedResponseId)
  );
  trackInterruptedResponse(interruptedResponseId);
  interruptedAudioMuteOwnerResponseId = interruptedResponseId || "__unbound_interruption__";
  if (isSimulationMode()) {
    clearTimeout(simulationResponseTimer);
    simulationResponseTimer = null;
  } else {
    if (!channel || channel.readyState !== "open") return;
    ui.remoteAudio.muted = true;
    try {
      if (authoritativeSpeechActive && interruptedResponseId) {
        sendProviderEvent({type: "response.cancel", response_id: interruptedResponseId});
      } else if (manual) {
        sendProviderEvent({type: "response.cancel"});
      }
      sendProviderEvent({type: "output_audio_buffer.clear"});
    } catch (error) {
      logEvent("interruption.control.failed", error.message);
    }
  }
  setResponseActive(false);
  awaitingFirstAudibleAudio = false;
  interruptions += 1;
  ui.interruptionMetric.textContent = String(interruptions);
  if (jarvisSpeakingStartedAt) {
    jarvisSpeakingTotalMs += performance.now() - jarvisSpeakingStartedAt;
    jarvisSpeakingStartedAt = 0;
  }
  markBubbleInterrupted(interruptedBubble, manual ? "manual" : "voice");
  if (interruptedResponseId) {
    logEvent("response.interrupted.bound", interruptedResponseId);
    responsePurposesById.delete(interruptedResponseId);
    authoritativeSpeechResponseIds.delete(interruptedResponseId);
  }
  if (interruptedPurpose === SPOKEN_SUMMARY_PURPOSE) {
    abortDetailedCompanion("interrupted");
  }
  activeResponseId = "";
  activeJarvisBubble = null;
  relayEvent("client.response.interrupted", {
    reason,
    response_id: interruptedResponseId || null,
    interruption_count: interruptions,
    simulation: isSimulationMode(),
  });
  logEvent("response.interrupted", reason);
  setStatus("Listening", "listening", {immediate: true});
  noteActivity();
}

function extractWakePrompt(transcript) {
  const keyword = normalizeNaturalText(config?.wake_keyword || ui.wakeKeyword.textContent || "jarvis");
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = normalizeNaturalText(transcript).match(new RegExp(`\\b${escaped}\\b`, "i"));
  if (!match) return null;
  const normalized = normalizeNaturalText(transcript);
  const after = normalized.slice((match.index || 0) + match[0].length).replace(/^[\s,.:;!?-]+/, "").trim();
  return {full: normalized, prompt: after};
}

function isExplicitSilenceCommand(text) {
  const normalized = normalizeNaturalText(text)
    .toLowerCase()
    .replace(/[’]/g, "'")
    .replace(/[^a-z0-9' ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!normalized) return false;
  return /^(?:jarvis\s+)?(?:please\s+)?(?:don't|do not)\s+(?:say anything|respond|reply|answer)(?:\s+to me)?$/.test(normalized)
    || /^(?:jarvis\s+)?you\s+(?:don't|do not)\s+(?:have|need)\s+to\s+(?:say anything|respond|reply|answer)$/.test(normalized)
    || /^(?:jarvis\s+)?(?:there(?:'s| is)\s+)?no\s+need\s+to\s+(?:say anything|respond|reply|answer)$/.test(normalized)
    || /^(?:jarvis\s+)?no\s+(?:response|reply|answer)\s+(?:is\s+)?needed$/.test(normalized)
    || /^(?:jarvis\s+)?(?:please\s+)?(?:stay|be)\s+quiet$/.test(normalized);
}

function stripSleepSilenceTail(text) {
  return String(text || "").replace(
    /\s+(?:(?:please\s+)?(?:don't|do not)\s+(?:say anything|respond|reply|answer)|you\s+(?:don't|do not)\s+(?:have|need)\s+to\s+(?:say anything|respond|reply|answer)|(?:there(?:'s| is)\s+)?no\s+need\s+to\s+(?:say anything|respond|reply|answer)|no\s+(?:response|reply|answer)\s+(?:is\s+)?needed)\s*$/,
    "",
  ).trim();
}

function isJarvisLikeSleepToken(token) {
  return new Set(["jarvis", "jervis", "dervis", "darvis", "jarvus", "jarviss", "jarviz", "jarves", "jarvas"]).has(String(token || "").toLowerCase());
}

function isSleepCommand(text) {
  let normalized = normalizeNaturalText(text)
    .toLowerCase()
    .replace(/[’]/g, "'")
    .replace(/[^a-z0-9' ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!normalized) return false;
  normalized = stripSleepSilenceTail(normalized);
  const words = normalized.split(" ").filter(Boolean);
  if (words.length > 1 && isJarvisLikeSleepToken(words[words.length - 1])) {
    words[words.length - 1] = "jarvis";
    normalized = words.join(" ");
  }
  const exact = new Set([
    "that's all", "thats all", "that is all", "that's all jarvis", "thats all jarvis", "that is all jarvis",
    "that'll be all", "thatll be all", "that'll be all jarvis", "thatll be all jarvis",
    "that's it", "thats it", "that is it", "that's it jarvis", "thats it jarvis", "that is it jarvis",
    "that's everything", "thats everything", "that is everything", "that's everything jarvis", "thats everything jarvis", "that is everything jarvis",
    "jarvis go to sleep", "go to sleep jarvis", "go to sleep", "jarvis sleep",
    "you can go back to sleep", "never mind jarvis", "nevermind jarvis",
  ]);
  if (exact.has(normalized)) return true;
  if (/^(?:that's|thats|that is) (?:all|it|everything)(?: jarvis)?$/.test(normalized)) return true;
  if (/\b(?:jarvis )?(?:that's|thats|that is) (?:all|it|everything)$/.test(normalized)) return true;
  if (/\b(?:thanks|thank you)(?: though)?(?: jarvis)? (?:that's|thats|that is) (?:all|it|everything)$/.test(normalized)) return true;
  return false;
}

function handleSilentSleepCommand(transcript, source = "voice") {
  if (lifecycleSleepTriggered || sleepShutdownInProgress) return true;
  lifecycleSleepTriggered = true;
  pendingVoiceEnrollmentOffer = null;
  pendingSpeakerOnboarding = null;
  logEvent("sleep.command.detected.local", `${source}: ${normalizeNaturalText(transcript)}`);
  relayEvent("client.sleeping", {reason: "voice_command", detector: "deterministic_transcript"});
  if (responseActive) interruptResponse("voice_sleep", true);
  localStream?.getAudioTracks().forEach((track) => { track.enabled = false; });
  ui.remoteAudio.muted = true;
  try { ui.remoteAudio.pause(); } catch (_) {}
  try {
    if (channel?.readyState === "open") {
      sendProviderEvent({type: "response.cancel"});
      sendProviderEvent({type: "output_audio_buffer.clear"});
      sendProviderEvent({type: "input_audio_buffer.clear"});
    }
  } catch (error) {
    logEvent("sleep.command.clear.failed", error.message);
  }
  if (ui.sleepAckMetric) ui.sleepAckMetric.textContent = "Silent";
  ui.configurationMessage.textContent = "";
  void sleepJarvis("voice_command");
  return true;
}

async function beginWakeFromDetected(detected, detector = "browser") {
  if (!detected || wakeDetectionTriggered || (isConnected() && !speculativeWakeActive)) return;
  wakeVisualHoldUntil = performance.now() + WAKE_VISUAL_MIN_MS;
  setStatus("Waking", "waking", {immediate: true});
  wakeDetectionTriggered = true;
  wakeListeningArmed = false;
  speculativeWakeAccepted = speculativeWakeActive;
  queuedWakePrompt = detected.prompt;
  queuedWakeAcknowledgement = !Boolean(normalizeNaturalText(detected.prompt));
  wakeAcknowledgementExpected = queuedWakeAcknowledgement;
  wakeAcknowledgementDispatching = false;
  wakeAcknowledgementResponseId = "";
  wakePromptDispatchStartedAt = 0;
  if (queuedWakeAcknowledgement) logEvent("wake.acknowledgement.queued", detected.full);
  ui.wakeListenerStatus.textContent = `Detected “${config.wake_keyword}”`;
  logEvent("wake.keyword.detected", `${detected.full} (${detector})`);
  queuedWakeMemoryRecorded = true;
  const wakeRecognition = wakeSpeakerRecognition || latestSpeakerRecognition;
  const wakeActor = isAttributedSpeaker(wakeRecognition) && wakeRecognition.person_name
    ? wakeRecognition.person_name
    : "Unknown speaker";
  const wakeMetadata = {detector, wake_keyword: config?.wake_keyword || "jarvis", preserved_prompt: detected.prompt || ""};
  if (wakeRecognition) {
    wakeMetadata.speaker_recognition = {
      status: wakeRecognition.status,
      confidence: wakeRecognition.confidence,
      threshold: wakeRecognition.threshold,
      person_entity_id: wakeRecognition.person_entity_id || null,
      candidate_person_id: wakeRecognition.candidate_person_id || null,
      candidate_name: wakeRecognition.candidate_name || null,
      local_model: "jarvis-local-voice-v1",
      wake_utterance: true,
    };
  }
  void rememberMemory({
    content: detected.full,
    source: "wake_voice",
    kind: "utterance",
    actor: wakeActor,
    sourceEventId: `wake:${clientSessionId || "pending"}:${wakeSpeechEndedAt || Date.now()}`,
    confidence: isAttributedSpeaker(wakeRecognition) ? Number(wakeRecognition.confidence || 1) : 1,
    metadata: wakeMetadata,
  });

  if (speculativeWakeActive) {
    speculativeWakePresentation?.();
    speculativeWakeActivation?.();
    maybeDispatchQueuedWakePrompt();
    if (speculativeWakeConnectPromise) await speculativeWakeConnectPromise;
    speculativeWakeActivation?.();
    maybeDispatchQueuedWakePrompt();
    if (wakeSpeechEndedAt) {
      logEvent("wake.fast_path.ready", `${Math.round(performance.now() - wakeSpeechEndedAt)} ms after speech ended`);
    }
    return;
  }

  await stopWakeListening();
  await connect({automatic: false, wakeTriggered: true});
}

function stopLifecycleListening({disable = false} = {}) {
  if (disable) lifecycleListeningArmed = false;
  if (!lifecycleRecognition) return;
  lifecycleRecognition.onend = null;
  lifecycleRecognition.onerror = null;
  lifecycleRecognition.onresult = null;
  try { lifecycleRecognition.stop(); } catch (_) {}
  try { lifecycleRecognition.abort(); } catch (_) {}
  lifecycleRecognition = null;
}

async function handleLifecycleSleepCommand(transcript) {
  if (lifecycleSleepTriggered) return;
  lifecycleSleepTriggered = true;
  lifecycleListeningArmed = false;
  stopLifecycleListening();
  logEvent("sleep.command.detected.local", transcript);
  relayEvent("client.sleeping", {reason: "voice_command", detector: "desktop_lifecycle"});
  if (responseActive) interruptResponse("voice_sleep", true);
  localStream?.getAudioTracks().forEach((track) => { track.enabled = false; });
  try {
    if (channel?.readyState === "open") sendProviderEvent({type: "input_audio_buffer.clear"});
  } catch (error) {
    logEvent("sleep.command.clear.failed", error.message);
  }
  addBubble("user", "Sleep command");
  addBubble("jarvis", "Of course.");
  ui.configurationMessage.textContent = "Jarvis is returning to local sleep.";
  window.setTimeout(() => sleepJarvis("voice_command"), 250);
}

function armLifecycleListening() {
  if (isElectronDesktop()) {
    lifecycleListeningArmed = false;
    lifecycleSleepTriggered = false;
    if (isSimulationMode()) {
      ui.wakeListenerStatus.textContent = "Manual sleep in development simulation";
      logEvent("lifecycle.listener.disabled", "simulation avoids speech services");
    } else {
      ui.wakeListenerStatus.textContent = "Realtime model handles sleep intent";
      logEvent("lifecycle.listener.armed", "sleep_jarvis model tool");
    }
    return;
  }
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition || !isConnected() || lifecycleRecognition || lifecycleSleepTriggered) return;
  lifecycleListeningArmed = true;
  const recognition = new Recognition();
  lifecycleRecognition = recognition;
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";
  recognition.onresult = (event) => {
    let combined = "";
    for (let index = event.resultIndex; index < event.results.length; index += 1) {
      combined += `${event.results[index][0].transcript} `;
    }
    const phrase = normalizeNaturalText(combined);
    if (phrase && isSleepCommand(phrase)) handleLifecycleSleepCommand(phrase);
  };
  recognition.onerror = (event) => {
    logEvent("lifecycle.listener.error", event.error || "unknown");
  };
  recognition.onend = () => {
    lifecycleRecognition = null;
    if (lifecycleListeningArmed && isConnected() && !lifecycleSleepTriggered) {
      window.setTimeout(armLifecycleListening, LIFECYCLE_RESTART_MS);
    }
  };
  try {
    recognition.start();
    logEvent("lifecycle.listener.armed", "spoken sleep commands");
  } catch (error) {
    lifecycleRecognition = null;
    logEvent("lifecycle.listener.failed", error.message);
  }
}

function simulationReplyFor(text, acknowledgement = false) {
  if (acknowledgement) {
    const address = config?.local_user_primary_address_name || "";
    return address ? `Yes, ${address}?` : "Yes?";
  }
  const mode = ui.responseMode.value;
  const normalized = normalizeNaturalText(text);
  if (mode === "test") return "Simulation received.";
  if (mode === "full") {
    return `Simulation mode received “${normalized}.” This free local response confirms the wake, transcript, timer, interruption, and sleep flow without contacting OpenAI.`;
  }
  return `Simulation received “${normalized}.”`;
}

function simulationDetailedReplyFor(text) {
  const normalized = normalizeNaturalText(text);
  return [
    "I am running in simulation mode, so this unified answer was generated locally without contacting OpenAI.",
    "",
    `Original request: ${normalized}`,
    "",
    "In a live session, I speak a response-mode-sized summary while this same response card updates to the complete written answer.",
  ].join("\n");
}

function completeSimulationResponse() {
  if (!responseActive) return;
  if (jarvisSpeakingStartedAt) {
    jarvisSpeakingTotalMs += performance.now() - jarvisSpeakingStartedAt;
    jarvisSpeakingStartedAt = 0;
  }
  responseCount += 1;
  latestResponseCostUsd = 0;
  setResponseActive(false);
  activeJarvisBubble = null;
  noteActivity();
  updateUsageMetrics();
  logEvent("simulation.response.done", "zero API cost");
  if (wakeAcknowledgementExpected) {
    wakeAcknowledgementExpected = false;
    wakeAcknowledgementDispatching = false;
    wakeAcknowledgementResponseId = "";
  }
  if (wakeInputGateActive) releaseWakeInputGate("simulation_response_complete");
  const detail = pendingDetailedCompanion;
  if (detail) {
    detail.voiceDone = true;
    detailedCompanionInProgress = true;
    setStatus("Writing", "thinking", {immediate: true});
    simulationResponseTimer = window.setTimeout(() => {
      detail.textDone = true;
      detail.writtenAnswer = simulationDetailedReplyFor(detail.userText);
      detail.writtenResponseId = `simulation_text:${clientSessionId}:${simulationResponseId}`;
      detail.writtenModel = "local-simulation";
      renderUnifiedWrittenAnswer(detail, detail.writtenAnswer);
      rememberUnifiedWrittenAnswer(detail, detail.writtenAnswer);
      responseCount += 1;
      updateUsageMetrics();
      logEvent("simulation.hybrid_text.done", "zero API cost");
      settleDetailedCompanion(detail);
    }, 220);
    return;
  }
  setStatus("Listening", "listening");
  if (ui.responseMode.value === "test" && ui.testAutoSleep.checked) {
    window.setTimeout(() => sleepJarvis("test_auto_sleep"), 250);
  }
}

function startSimulationResponse(text, {acknowledgement = false, exactReply = ""} = {}) {
  clearTimeout(simulationResponseTimer);
  noteActivity();
  responseCreatedAt = performance.now();
  const detailed = !acknowledgement && !normalizeNaturalText(exactReply) && shouldCreateDetailedTextCompanion(text);
  pendingDetailedCompanion = detailed ? {
    userText: normalizeNaturalText(text),
    responseMode: ui.responseMode.value,
    source: "simulation",
    requestedAt: Date.now(),
    bubble: null,
    spokenSummary: "",
    writtenAnswer: "",
    writtenResponseId: "",
    writtenModel: "",
    voiceDone: false,
    textDone: false,
    textError: "",
    memoryStored: false,
    abortController: null,
  } : null;
  const purpose = detailed ? SPOKEN_SUMMARY_PURPOSE : STANDARD_VOICE_PURPOSE;
  activeJarvisBubble = addBubble("jarvis", detailed ? "Preparing the complete answer…" : "", {
    speakerLabel: "JARVIS",
    responsePurpose: purpose,
  });
  if (detailed && pendingDetailedCompanion) pendingDetailedCompanion.bubble = activeJarvisBubble;
  setResponseActive(true);
  setStatus("Thinking", "thinking");
  logEvent("simulation.response.created", ui.responseMode.value);
  const reply = normalizeNaturalText(exactReply) || simulationReplyFor(text, acknowledgement);
  simulationResponseTimer = setTimeout(() => {
    if (!responseActive) return;
    setStatus("Speaking", "speaking");
    jarvisSpeakingStartedAt = performance.now();
    if (detailed && pendingDetailedCompanion) {
      pendingDetailedCompanion.spokenSummary = reply;
    } else {
      finalizeBubble(activeJarvisBubble, reply);
      lastAssistantMemoryText = reply;
      lastAssistantMemoryAt = Date.now();
      void rememberMemory({
        content: reply,
        source: "assistant",
        kind: "response",
        actor: "Jarvis",
        sourceEventId: `simulation_response:${clientSessionId}:${simulationResponseId += 1}`,
        metadata: {simulation: true, acknowledgement, response_purpose: purpose},
      });
    }
    const duration = Math.max(450, Math.min(5000, reply.length * 28));
    simulationResponseTimer = setTimeout(completeSimulationResponse, duration);
  }, 180);
}

async function connectSimulation({wakeTriggered = false} = {}) {
  intentionalSleep = false;
  stopWakeListening();
  simulationConnected = true;
  clientSessionId = newClientSessionId();
  setStatus("Listening", "listening");
  ui.handshakeMetric.textContent = "0 ms";
  updateConnectedControls("awake");
  startSessionTimers();
  relayEvent("client.connected", {simulation: true, wake_triggered: wakeTriggered});
  logEvent("simulation.connected", "no OpenAI session created");
  maybeDispatchQueuedWakePrompt();
  lifecycleSleepTriggered = false;
  armLifecycleListening();
}

async function stopWakeListening({disable = false, preserveStream = false} = {}) {
  clearTimeout(wakeFinalizeTimer);
  wakeFinalizeTimer = null;
  if (disable) wakeListeningArmed = false;
  const preservedStream = await stopModelWakeListener({disable, preserveStream});
  if (!wakeRecognition) return preservedStream;
  wakeRecognition.onend = null;
  wakeRecognition.onerror = null;
  wakeRecognition.onresult = null;
  try { wakeRecognition.stop(); } catch (_) {}
  try { wakeRecognition.abort(); } catch (_) {}
  wakeRecognition = null;
  if (disable) ui.wakeListenerStatus.textContent = "Disabled";
  return preservedStream;
}

function finalizeWakeDetection() {
  clearTimeout(wakeFinalizeTimer);
  wakeFinalizeTimer = null;
  void beginWakeFromDetected(extractWakePrompt(wakeCandidateText), "browser_fallback");
}

function armWakeListening() {
  if (!accountReady) {
    wakeListeningArmed = false;
    ui.wakeListenerStatus.textContent = "Verified account required";
    return;
  }
  if (sleepSequenceActive || sleepShutdownInProgress) {
    ui.wakeListenerStatus.textContent = "Finishing Jarvis sign-off…";
    return;
  }
  if (!providerReadyForLive() && !isSimulationMode()) {
    ui.wakeListenerStatus.textContent = isHostedProviderMode() ? "Waiting for Jarvis Cloud" : "Waiting for development provider or simulation";
    return;
  }
  if (isConnected() || connectPromise) return;
  if (isElectronDesktop()) {
    if (isSimulationMode()) {
      wakeListeningArmed = false;
      ui.wakeListenerStatus.textContent = "Manual wake in development simulation";
      ui.configurationMessage.textContent = "Development simulation avoids hosted wake transcription; use Wake Jarvis or the tray Wake command.";
      return;
    }
    startModelWakeListener();
    return;
  }
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    ui.wakeListenerStatus.textContent = "Browser wake listener unsupported";
    logEvent("wake.listener.unavailable", "SpeechRecognition not supported outside Electron");
    return;
  }
  if (wakeRecognition) return;
  wakeListeningArmed = true;
  wakeDetectionTriggered = false;
  wakeCandidateText = "";
  const recognition = new Recognition();
  wakeRecognition = recognition;
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";
  recognition.onstart = () => {
    ui.wakeListenerStatus.textContent = `Listening for “${config.wake_keyword}”`;
    logEvent("wake.listener.armed", config.wake_keyword);
  };
  recognition.onerror = (event) => {
    logEvent("wake.listener.error", event.error || "unknown");
    if (event.error === "not-allowed" || event.error === "service-not-allowed") {
      ui.wakeListenerStatus.textContent = "Microphone permission denied";
      wakeListeningArmed = false;
      stopWakeListening({disable: true});
      return;
    }
    ui.wakeListenerStatus.textContent = "Restarting…";
  };
  recognition.onend = () => {
    wakeRecognition = null;
    if (wakeListeningArmed && !isConnected() && !connectPromise && !wakeDetectionTriggered) {
      ui.wakeListenerStatus.textContent = "Restarting…";
      window.setTimeout(() => armWakeListening(), WAKE_RESTART_MS);
    }
  };
  recognition.onresult = (event) => {
    let combined = "";
    let hasFinalResult = false;
    for (let index = 0; index < event.results.length; index += 1) {
      combined += `${event.results[index][0].transcript} `;
      if (event.results[index].isFinal) hasFinalResult = true;
    }
    const detected = extractWakePrompt(combined);
    if (!detected) return;
    wakeCandidateText = detected.full;
    ui.wakeListenerStatus.textContent = `Heard “${config.wake_keyword}” — capturing request…`;
    clearTimeout(wakeFinalizeTimer);
    wakeFinalizeTimer = setTimeout(finalizeWakeDetection, hasFinalResult ? WAKE_FINAL_DELAY_MS : WAKE_CAPTURE_DELAY_MS);
  };
  try {
    recognition.start();
  } catch (error) {
    wakeRecognition = null;
    ui.wakeListenerStatus.textContent = "Failed to start";
    logEvent("wake.listener.failed", error.message);
  }
}

function activateWakeInputGate() {
  clearTimeout(wakeInputGateTimer);
  clearTimeout(wakeNoAudioReleaseTimer);
  wakeInputGateActive = true;
  wakePromptResponsePending = true;
  wakeOpeningResponseDone = false;
  wakeOpeningAudioObserved = false;
  wakeNoAudioReleaseTimer = null;
  localStream?.getAudioTracks().forEach((track) => { track.enabled = false; });
  wakeInputGateTimer = setTimeout(() => {
    releaseWakeInputGate("safety_timeout");
  }, WAKE_INPUT_GATE_MAX_MS);
  logEvent("wake.input.gated", "opening request owns the first turn");
}

function releaseWakeInputGate(
  reason,
  {enableMicrophone = true, delayMs = WAKE_INPUT_GATE_RELEASE_DELAY_MS} = {},
) {
  clearTimeout(wakeInputGateTimer);
  clearTimeout(wakeNoAudioReleaseTimer);
  wakeInputGateTimer = null;
  wakeNoAudioReleaseTimer = null;
  if (!wakeInputGateActive) return;
  wakeInputGateActive = false;
  wakePromptResponsePending = false;
  wakeOpeningResponseDone = false;
  wakeOpeningAudioObserved = false;
  try {
    if (channel?.readyState === "open") sendProviderEvent({type: "input_audio_buffer.clear"});
  } catch (error) {
    logEvent("wake.input.clear.failed", error.message);
  }
  const enable = () => {
    if (!enableMicrophone) return;
    localStream?.getAudioTracks().forEach((track) => { track.enabled = !muted && !wakeInputGateActive; });
    logEvent("wake.input.released", reason);
  };
  if (enableMicrophone) {
    window.setTimeout(enable, Math.max(0, Number(delayMs) || 0));
  }
}

function maybeDispatchQueuedWakePrompt() {
  const pending = normalizeNaturalText(queuedWakePrompt);
  const acknowledgement = queuedWakeAcknowledgement
    && !wakeAcknowledgementDispatching
    && !wakeAcknowledgementResponseId;
  if (!pending && !acknowledgement) return;

  if (isSimulationMode() && simulationConnected) {
    if (acknowledgement) {
      queuedWakeAcknowledgement = false;
      wakeAcknowledgementDispatching = true;
      startSimulationResponse("", {acknowledgement: true});
      logEvent("wake.acknowledgement.dispatched", "simulation");
    } else {
      const result = sendText(pending, {
        remember: !queuedWakeMemoryRecorded,
        source: "wake_voice",
        speakerRecognition: wakeSpeakerRecognition || latestSpeakerRecognition,
      });
      logEvent("wake.prompt.dispatched", `${pending} (simulation${result?.responseRequested === false ? "; local action" : ""})`);
    }
    queuedWakePrompt = "";
    queuedWakeMemoryRecorded = false;
    wakePromptDispatchStartedAt = 0;
    return;
  }

  if (!wakePromptDispatchStartedAt) wakePromptDispatchStartedAt = performance.now();
  if (!channel || channel.readyState !== "open") {
    if (performance.now() - wakePromptDispatchStartedAt >= WAKE_PROMPT_MAX_WAIT_MS) {
      ui.configurationMessage.textContent = "Jarvis woke, but the opening request could not be sent. Please speak again.";
      logEvent("wake.prompt.failed", "data channel did not open in time");
      queuedWakePrompt = "";
      queuedWakeAcknowledgement = false;
      queuedWakeMemoryRecorded = false;
      wakePromptDispatchStartedAt = 0;
      releaseWakeInputGate("dispatch_timeout");
      return;
    }
    clearTimeout(wakePromptDispatchTimer);
    wakePromptDispatchTimer = setTimeout(maybeDispatchQueuedWakePrompt, WAKE_PROMPT_RETRY_MS);
    return;
  }

  clearTimeout(wakePromptDispatchTimer);
  wakePromptDispatchTimer = null;
  try {
    let responseRequested = true;
    if (acknowledgement) {
      // Claim the acknowledgement before sending provider events. Connection-open
      // and connected-state callbacks can both reach this function; claiming first
      // guarantees that only one paid response.create is emitted.
      queuedWakeAcknowledgement = false;
      wakeAcknowledgementDispatching = true;
      responseCreateWithSpeaker(wakeSpeakerRecognition || latestSpeakerRecognition, {
        wake: true,
        exactReply: "Yes?",
        authoritativeSpeech: "wake_acknowledgement",
        source: "wake_voice",
      });
      logEvent("wake.acknowledgement.dispatched", config?.wake_keyword || "jarvis");
    } else {
      const result = sendText(pending, {
        remember: !queuedWakeMemoryRecorded,
        source: "wake_voice",
        speakerRecognition: wakeSpeakerRecognition || latestSpeakerRecognition,
      });
      responseRequested = result?.responseRequested !== false;
      logEvent("wake.prompt.dispatched", `${pending}${responseRequested ? "" : " (local action only)"}`);
    }
    wakePromptResponsePending = wakeInputGateActive && responseRequested;
    if (wakeInputGateActive && !responseRequested) releaseWakeInputGate("visual_memory_navigation");
    queuedWakePrompt = "";
    queuedWakeMemoryRecorded = false;
    wakePromptDispatchStartedAt = 0;
    wakeSpeakerRecognition = null;
  } catch (error) {
    if (acknowledgement && wakeAcknowledgementExpected && !wakeAcknowledgementResponseId) {
      wakeAcknowledgementDispatching = false;
      queuedWakeAcknowledgement = true;
    }
    logEvent("wake.prompt.retry", error.message);
    wakePromptDispatchTimer = setTimeout(maybeDispatchQueuedWakePrompt, WAKE_PROMPT_RETRY_MS);
  }
}

function resetSleepSequence() {
  clearTimeout(sleepAcknowledgementTimer);
  clearTimeout(sleepAcknowledgementPlaybackTimer);
  sleepAcknowledgementTimer = null;
  sleepAcknowledgementPlaybackTimer = null;
  sleepSequenceActive = false;
  sleepAcknowledgementPending = false;
  sleepAcknowledgementResponseDone = false;
  sleepAcknowledgementAudioObserved = false;
  sleepAcknowledgementBufferStarted = false;
  sleepAcknowledgementBufferStopped = false;
  sleepAcknowledgementAudioStartedAt = 0;
  sleepAcknowledgementLastSignalAt = 0;
  sleepAcknowledgementResponseId = "";
  sleepAcknowledgementRequestEventId = "";
  sleepAcknowledgementAwaitingResponseCreated = false;
  sleepAcknowledgementResponseCreatedAt = 0;
  sleepAcknowledgementProviderStoppedAt = 0;
  sleepIntentStartedAt = 0;
  sleepAcknowledgementStartedAt = 0;
}

function providerResponseId(event) {
  return event?.response_id || event?.response?.id || "";
}

function providerOutputItemId(event) {
  return event?.item_id || event?.item?.id || "";
}

function trimTrackedCollection(collection, maximum = 256) {
  while (collection.size > maximum) {
    const oldest = collection.keys().next().value;
    collection.delete(oldest);
  }
}

function rememberResponseAssociations(event, explicitResponseId = "") {
  const responseId = explicitResponseId || providerResponseId(event);
  if (!responseId) return "";
  const itemIds = new Set();
  const directItemId = providerOutputItemId(event);
  if (directItemId) itemIds.add(directItemId);
  for (const item of event?.response?.output || []) {
    if (item?.id) itemIds.add(item.id);
  }
  for (const itemId of itemIds) responseItemOwners.set(itemId, responseId);
  trimTrackedCollection(responseItemOwners, 512);
  return responseId;
}

function resolvedResponseId(event) {
  const direct = providerResponseId(event);
  if (direct) {
    rememberResponseAssociations(event, direct);
    return direct;
  }
  const itemId = providerOutputItemId(event);
  return itemId ? (responseItemOwners.get(itemId) || "") : "";
}

function trackInterruptedResponse(responseId) {
  if (!responseId) return;
  interruptedResponseIds.add(responseId);
  trimTrackedCollection(interruptedResponseIds, 256);
}

function restoreRemoteAudioForResponse(responseId = "", reason = "response_boundary") {
  const resolved = responseId || activeResponseId || "";
  if (resolved && interruptedResponseIds.has(resolved)) {
    logEvent("response.interrupted.audio_restore_ignored", resolved);
    return false;
  }
  if (interruptedAudioMuteOwnerResponseId && resolved === interruptedAudioMuteOwnerResponseId) {
    logEvent("response.interrupted.audio_restore_owner_ignored", resolved || "unbound");
    return false;
  }
  if (!resolved && interruptedAudioMuteOwnerResponseId) return false;
  interruptedAudioMuteOwnerResponseId = "";
  ui.remoteAudio.muted = false;
  ui.remoteAudio.play().catch((error) => logEvent("response.audio.resume_failed", error.message));
  logEvent("response.audio.resumed", `${reason}; ${resolved || "current response"}`);
  return true;
}

function responseEventIsInterrupted(event) {
  const responseId = resolvedResponseId(event);
  return Boolean(responseId && interruptedResponseIds.has(responseId));
}

function responseBubbleForEvent(event, {createForCurrent = false} = {}) {
  const responseId = resolvedResponseId(event);
  if (responseId && responseBubblesById.has(responseId)) return responseBubblesById.get(responseId);
  if (responseId && activeResponseId && responseId !== activeResponseId) return null;
  if (!activeJarvisBubble && createForCurrent) {
    activeJarvisBubble = addBubble("jarvis");
    if (responseId) responseBubblesById.set(responseId, activeJarvisBubble);
  }
  return activeJarvisBubble;
}

function releaseResponseTracking(responseId) {
  if (!responseId) return;
  responseBubblesById.delete(responseId);
  for (const [itemId, owner] of responseItemOwners.entries()) {
    if (owner === responseId) responseItemOwners.delete(itemId);
  }
}

function rememberSleepAcknowledgementResponse(event) {
  const responseId = providerResponseId(event);
  if (!responseId) return false;
  if (!sleepAcknowledgementResponseId) {
    sleepAcknowledgementResponseId = responseId;
    logEvent("sleep.acknowledgement.response_bound", responseId);
  }
  return responseId === sleepAcknowledgementResponseId;
}

function isCurrentSleepAcknowledgementEvent(event) {
  const responseId = providerResponseId(event);
  return Boolean(sleepAcknowledgementResponseId && responseId === sleepAcknowledgementResponseId);
}

function logIgnoredSleepBufferEvent(event) {
  const responseId = providerResponseId(event) || "missing response id";
  logEvent("sleep.acknowledgement.stale_buffer_ignored", `${event.type}: ${responseId}`);
}

function armSleepAcknowledgementPlaybackCompletion(reason = "playback_drained", {allowNoAudioFallback = false} = {}) {
  if (!sleepSequenceActive || !sleepAcknowledgementResponseDone || sleepShutdownInProgress) return;
  clearTimeout(sleepAcknowledgementPlaybackTimer);
  sleepAcknowledgementPlaybackTimer = null;

  const now = performance.now();
  if (sleepAcknowledgementAudioObserved) {
    const earliestPlaybackCloseAt = Math.max(
      sleepAcknowledgementAudioStartedAt + SLEEP_ACK_LOCAL_MIN_PLAYBACK_MS,
      sleepAcknowledgementLastSignalAt + SLEEP_ACK_AUDIO_SILENCE_MS,
    );
    const localPlaybackStillActive = remoteAudioActive || Boolean(jarvisSpeakingStartedAt);
    if (localPlaybackStillActive || now < earliestPlaybackCloseAt) {
      const remainingMs = Math.max(0, earliestPlaybackCloseAt - now);
      const retryMs = Math.max(
        SLEEP_ACK_COMPLETION_POLL_MS,
        Math.min(500, remainingMs || SLEEP_ACK_COMPLETION_POLL_MS),
      );
      sleepAcknowledgementPlaybackTimer = setTimeout(() => {
        armSleepAcknowledgementPlaybackCompletion(reason, {allowNoAudioFallback});
      }, retryMs);
      return;
    }
    finishSpokenSleep(`${reason}_local_playback_settled`);
    return;
  }

  const responseReferenceAt = sleepAcknowledgementResponseCreatedAt
    || sleepAcknowledgementStartedAt
    || now;
  const fallbackAt = responseReferenceAt + SLEEP_ACK_NO_AUDIO_FALLBACK_MS;
  if (!allowNoAudioFallback || now < fallbackAt) {
    const remainingMs = Math.max(SLEEP_ACK_COMPLETION_POLL_MS, fallbackAt - now);
    sleepAcknowledgementPlaybackTimer = setTimeout(() => {
      armSleepAcknowledgementPlaybackCompletion(reason, {allowNoAudioFallback: true});
    }, Math.min(500, remainingMs));
    return;
  }
  finishSpokenSleep(`${reason}_no_local_audio_fallback`);
}

function finishSpokenSleep(reason = "spoken_ack_complete") {
  if (!sleepSequenceActive || sleepShutdownInProgress) return;
  sleepShutdownInProgress = true;
  const completedAt = performance.now();
  if (sleepIntentStartedAt && ui.sleepCompleteMetric) {
    const duration = completedAt - sleepIntentStartedAt;
    ui.sleepCompleteMetric.textContent = metricMs(duration);
    publishLatency("sleep_intent_to_sleep_complete", duration);
  }
  logEvent("sleep.acknowledgement.complete", reason);
  resetSleepSequence();
  window.setTimeout(async () => {
    try {
      await sleepJarvis("model_tool");
    } finally {
      sleepShutdownInProgress = false;
      armWakeListening();
    }
  }, 40);
}

function armSleepAcknowledgementFallback(delayMs = SLEEP_ACK_MAX_WAIT_MS) {
  clearTimeout(sleepAcknowledgementTimer);
  sleepAcknowledgementTimer = setTimeout(() => {
    if (!sleepSequenceActive || sleepShutdownInProgress) return;
    logEvent("sleep.acknowledgement.timeout", `${delayMs} ms`);
    if (!sleepAcknowledgementResponseDone) {
      armSleepAcknowledgementFallback(2000);
      return;
    }
    armSleepAcknowledgementPlaybackCompletion("acknowledgement_timeout", {allowNoAudioFallback: true});
  }, delayMs);
}

function findSleepToolCall(response) {
  const output = Array.isArray(response?.output) ? response.output : [];
  return output.find((item) => item?.type === "function_call" && item?.name === "sleep_jarvis") || null;
}

function handleSleepToolCall(call, event) {
  const callId = call?.call_id || call?.id || event?.call_id || event?.item_id || "sleep_without_id";
  if (handledSleepToolCallIds.has(callId) || sleepShutdownInProgress) {
    logEvent("sleep.tool.duplicate_ignored", callId);
    return;
  }
  handledSleepToolCallIds.add(callId);
  sleepSequenceActive = true;
  sleepShutdownInProgress = true;
  sleepIntentStartedAt = performance.now();
  lifecycleSleepTriggered = true;
  logEvent("sleep.tool.called", callId);
  if (speechStoppedAt && ui.sleepIntentMetric) {
    const intentMs = sleepIntentStartedAt - speechStoppedAt;
    ui.sleepIntentMetric.textContent = metricMs(intentMs);
    publishLatency("speech_stop_to_sleep_intent", intentMs);
  }

  localStream?.getAudioTracks().forEach((track) => { track.enabled = false; });
  ui.remoteAudio.muted = true;
  try {
    if (channel?.readyState === "open") {
      sendProviderEvent({type: "response.cancel"});
      sendProviderEvent({type: "output_audio_buffer.clear"});
      sendProviderEvent({type: "input_audio_buffer.clear"});
      if (call?.call_id) {
        sendProviderEvent({
          type: "conversation.item.create",
          item: {
            type: "function_call_output",
            call_id: call.call_id,
            output: JSON.stringify({status: "accepted", action: "sleeping_silently"}),
          },
        });
      }
    }
  } catch (error) {
    logEvent("sleep.tool.shutdown_signal_failed", error.message);
  }

  finalizeUntranscribedVoiceTurn("sleep_tool_called");
  if (event?.response?.usage) {
    recordProviderUsage(event).catch((error) => logEvent("usage.record.failed", error.message));
  }
  setResponseActive(false);
  awaitingFirstAudibleAudio = false;
  if (activeJarvisBubble) activeJarvisBubble.remove();
  activeJarvisBubble = null;
  ui.configurationMessage.textContent = "Jarvis is returning to sleep.";
  if (ui.sleepAckMetric) ui.sleepAckMetric.textContent = "Silent";
  logEvent("sleep.silent_shutdown", "model tool accepted; no sign-off response requested");

  window.setTimeout(async () => {
    const shutdownStartedAt = sleepIntentStartedAt;
    try {
      await sleepJarvis("model_tool");
      if (shutdownStartedAt && ui.sleepCompleteMetric) {
        const duration = performance.now() - shutdownStartedAt;
        ui.sleepCompleteMetric.textContent = metricMs(duration);
        publishLatency("sleep_intent_to_sleep_complete", duration);
      }
    } finally {
      resetSleepSequence();
      sleepShutdownInProgress = false;
      armWakeListening();
    }
  }, 0);
}

function handleProviderEvent(event) {
  const type = event.type || "unknown";
  const compact = event.error?.message || event.response?.status || "";
  logEvent(type, compact);

  if (type === "jarvis.realtime.ready") {
    logEvent("realtime.hosted.control_ready", event.session_id || "ready");
    return;
  }
  if (type === "jarvis.realtime.closed") {
    logEvent("realtime.hosted.closed", event.reason || "closed");
    if (!intentionalSleep) {
      setStatus("Reconnecting", "waking");
      attemptAutoReconnect(connectionEpoch);
    }
    return;
  }

  if (type === "response.function_call_arguments.done" && event.name === "sleep_jarvis") {
    handleSleepToolCall({name: event.name, call_id: event.call_id, id: event.item_id}, event);
    return;
  }

  if (type === "session.created") relayEvent("session.created", {session_id: event.session?.id || null});
  if (wakeInputGateActive && (
    type.startsWith("input_audio_buffer.") || type.includes("input_audio_transcription")
  )) {
    logEvent("wake.input.phantom.suppressed", type);
    try {
      if (channel?.readyState === "open") sendProviderEvent({type: "input_audio_buffer.clear"});
    } catch (error) {
      logEvent("wake.input.clear.failed", error.message);
    }
    return;
  }
  if (type === "input_audio_buffer.speech_started") {
    noteActivity();
    const permissionQuarantined = trustedPermissionPromptActive();
    // A trusted permission prompt is a modal authorization boundary. Keep the
    // microphone transport alive to avoid reconnect churn, but treat prompt-time
    // speech as fully inert: it cannot approve, deny, mutate, queue behind, or
    // conversationally compete with the exact pending action.
    beginSpeakerUtteranceCapture();
    // Provider VAD is useful evidence, but one speech_started edge is not enough to
    // prove a real interruption. Arm a short confirmation window so mic bumps/noise
    // cannot kill Jarvis speech, browser work, or leave the UI stranded in Thinking.
    voiceTurnEpoch += 1;
    resetTurnMetrics();
    speechStartedAt = performance.now();
    settleOlderVoiceTurnsBeforeNewSpeech();
    activeUserBubble = permissionQuarantined ? null : addBubble("user", "Listening…");
    const startedVoiceTurn = registerVoiceTranscriptTurn(activeUserBubble, voiceTurnEpoch, {permissionQuarantined});
    if (!permissionQuarantined) armVoiceBargeInCandidate(startedVoiceTurn.turnEpoch);
    if (permissionQuarantined) setStatus("Waiting for permission", "thinking", {immediate: true});
    else if (!dedicatedSpeechIsActive() && !responseActive && !remoteAudioActive && !jarvisSpeakingStartedAt) setStatus("Listening", "listening", {immediate: true});
    relayEvent(type, {turn_epoch: voiceTurnEpoch, permission_quarantined: permissionQuarantined});
  }
  if (type === "input_audio_buffer.speech_stopped") {
    noteActivity();
    finishSpeakerUtteranceCapture();
    speechStoppedAt = performance.now();
    if (speechStartedAt) userSpeakingTotalMs += speechStoppedAt - speechStartedAt;
    updateUsageMetrics();
    ui.speechMetric.textContent = metricMs(speechStoppedAt - speechStartedAt);
    publishLatency("speech_duration", speechStoppedAt - speechStartedAt);
    const currentVoiceTurn = currentVoiceTurnForEpoch(voiceTurnEpoch);
    clearVoiceBargeInCandidate();
    if (currentVoiceTurn?.permissionQuarantined) {
      setStatus("Waiting for permission", "thinking", {immediate: true});
      relayEvent(type, {permission_quarantined: true});
    } else {
      const speechDurationMs = Math.max(0, speechStoppedAt - speechStartedAt);
      const shortUnconfirmedVad = Boolean(currentVoiceTurn && !currentVoiceTurn.bargeInCommitted && speechDurationMs < VOICE_BARGE_IN_CONFIRM_MS);
      ui.decisionMetric.textContent = "waiting…";
      ui.firstAudioMetric.textContent = "waiting…";
      ui.totalMetric.textContent = "waiting…";
      if (activeUserBubble?.querySelector(".content").textContent === "Listening…") {
        activeUserBubble.querySelector(".content").textContent = "Processing speech…";
      }
      const hasTranscriptEvidence = Boolean(normalizeNaturalText(currentVoiceTurn?.bufferedTranscript || ""));
      if (currentVoiceTurn && !hasTranscriptEvidence) {
        // Every transcript-less VAD turn gets a bounded cleanup, even if ambient
        // noise lasted long enough to cross the barge-in debounce. A real transcript
        // cancels this timer when the turn resolves; phantom audio can no longer
        // strand Jarvis in Thinking indefinitely.
        armFalseVadRecovery(
          currentVoiceTurn,
          currentVoiceTurn.bargeInCommitted ? "committed_vad_without_transcript" : "vad_without_transcript",
        );
      }
      if (shortUnconfirmedVad) {
        restoreStatusAfterFalseVad();
        relayEvent("client.voice.false_vad.candidate", {turn_epoch: voiceTurnEpoch, duration_ms: speechDurationMs});
      } else {
        setStatus("Thinking", "thinking");
      }
      relayEvent(type, {duration_ms: speechDurationMs, false_vad_candidate: shortUnconfirmedVad, transcript_evidence: hasTranscriptEvidence});
    }
  }
  if (type.includes("input_audio_transcription.delta")) {
    // Provider deltas are untrusted intermediate text. Buffer them privately and
    // render only a completed transcript after artifact filtering. This prevents
    // the transcription prompt itself from ever flashing into the user's chat.
    let turn = claimVoiceTranscriptTurn(event);
    if (!turn) {
      const permissionQuarantined = trustedPermissionPromptActive();
      activeUserBubble = permissionQuarantined ? null : (activeUserBubble || addBubble("user", "Processing speech…"));
      turn = registerVoiceTranscriptTurn(activeUserBubble, voiceTurnEpoch, {permissionQuarantined});
      const itemId = providerVoiceItemId(event);
      if (itemId) turn.itemId = itemId;
    }
    turn.bufferedTranscript += String(event.delta || "");
    if (!turn.permissionQuarantined) {
      const partialTranscript = normalizeNaturalText(turn.bufferedTranscript);
      if (partialTranscript && !isInternalTranscriptionArtifact(partialTranscript) && !turn.bargeInCommitted) {
        commitVoiceBargeIn(turn.turnEpoch, "transcript_evidence");
      }
      const partialMemoryIntent = isInternalTranscriptionArtifact(partialTranscript)
        ? null
        : parseMemoryNavigationIntent(partialTranscript);
      if (partialMemoryIntent && !partialMemoryIntent.responseRequested) {
        armVisualOnlyResponseSuppression(partialMemoryIntent, {source: "voice", phase: "buffered_partial_transcript"});
      }
    }
  }
  if (type.includes("input_audio_transcription.completed") || (type === "conversation.item.done" && event.item?.role === "user")) {
    const typedEcho = consumeTypedEcho(event);
    if (!typedEcho) {
      const itemId = providerVoiceItemId(event);
      if (itemId && renderedVoiceTranscriptItemIds.has(itemId)) {
        relayEvent("client.voice.transcript.duplicate_ignored", {item_id: itemId});
        return;
      }
      const turn = claimVoiceTranscriptTurn(event);
      const transcript = extractInputTranscript(event) || turn?.bufferedTranscript || "";
      const normalized = normalizeNaturalText(transcript);
      if (turn?.permissionQuarantined || trustedPermissionPromptActive()) {
        const quarantinedTurn = turn || registerVoiceTranscriptTurn(null, voiceTurnEpoch, {permissionQuarantined: true});
        finishVoiceTranscriptTurn(quarantinedTurn, {remove: true});
        if (itemId) {
          renderedVoiceTranscriptItemIds.add(itemId);
          if (renderedVoiceTranscriptItemIds.size > 2000) renderedVoiceTranscriptItemIds.clear();
        }
        // Trusted permission review is deliberately voice-inert. Prompt-time
        // speech is discarded wholesale: it cannot approve, deny, mutate, queue,
        // enter chat/memory, or trigger a conversational response. The user must
        // choose Allow/Cancel on the trusted surface (or change the permission policy).
        relayEvent("client.voice.permission_quarantined", {item_id: itemId || null, characters: normalized.length});
        return;
      }
      if (isInternalTranscriptionArtifact(normalized)) {
        finishVoiceTranscriptTurn(turn, {remove: true});
        if (itemId) renderedVoiceTranscriptItemIds.add(itemId);
        relayEvent("client.voice.transcript.internal_artifact_suppressed", {item_id: itemId || null});
        return;
      }
      if (normalized && !isVoiceTurnPlaceholder(normalized)) {
        const resolvedTurn = turn || registerVoiceTranscriptTurn(activeUserBubble || addBubble("user"));
        if (!resolvedTurn.permissionQuarantined && !resolvedTurn.bargeInCommitted) {
          commitVoiceBargeIn(resolvedTurn.turnEpoch || voiceTurnEpoch, "completed_transcript");
        }
        if (isRecentDuplicateVoiceTranscript(normalized, resolvedTurn?.turnEpoch || voiceTurnEpoch)) {
          finishVoiceTranscriptTurn(resolvedTurn, {remove: true});
          if (itemId) renderedVoiceTranscriptItemIds.add(itemId);
          if (!responseActive && !dedicatedSpeechIsActive() && !remoteAudioActive) {
            setStatus("Listening", "listening", {immediate: true});
          }
          relayEvent("client.voice.transcript.content_duplicate_ignored", {
            item_id: itemId || null,
            turn_epoch: Number(resolvedTurn?.turnEpoch || voiceTurnEpoch || 0),
          });
          return;
        }
        finishVoiceTranscriptTurn(resolvedTurn, {text: normalized});
        const memoryNavigation = navigateMemoryFromNaturalLanguage(normalized, {source: "voice"});
        if (memoryNavigation?.visualOnly) {
          armVisualOnlyResponseSuppression(memoryNavigation, {source: "voice", phase: "completed_transcript"});
        } else if (memoryNavigation?.responseRequested) {
          void requestMemoryNarrationAfterNavigation(memoryNavigation, {source: "voice"});
        }
        if (itemId) {
          renderedVoiceTranscriptItemIds.add(itemId);
          if (renderedVoiceTranscriptItemIds.size > 2000) renderedVoiceTranscriptItemIds.clear();
        }
        const memoryId = memorySourceEventId("realtime_input", event);
        let memoryEventPromise = Promise.resolve(null);
        if (!rememberedProviderMemoryIds.has(memoryId)) {
          rememberedProviderMemoryIds.add(memoryId);
          if (rememberedProviderMemoryIds.size > 2000) rememberedProviderMemoryIds.clear();
          memoryEventPromise = rememberRecognizedVoiceMemory({
            content: normalized,
            sourceEventId: memoryId,
            providerEvent: type,
            providerItemId: itemId || null,
          });
        }
        if (isSleepCommand(normalized)) {
          handleSilentSleepCommand(normalized, "voice");
          return;
        }
        if (isExplicitSilenceCommand(normalized)) {
          relayEvent("client.voice.response_suppressed", {reason: "explicit_silence"});
          setStatus("Listening", "listening", {immediate: true});
          noteActivity();
          return;
        }
        if (consumeVoiceEnrollmentReply(normalized)) {
          setStatus("Listening", "listening", {immediate: true});
          return;
        }
        void requestVoiceResponseAfterRecognition({
          itemId: itemId || memoryId,
          memoryNavigation,
          transcript: normalized,
          memoryEventPromise,
          userBubble: resolvedTurn?.bubble || null,
          turnEpoch: resolvedTurn?.turnEpoch || voiceTurnEpoch,
        });
      } else if (turn?.bubble === activeUserBubble) {
        finalizeUntranscribedVoiceTurn("completed_without_transcript");
      }
    }
  }
  if (type === "output_audio_buffer.started") {
    const startedResponseId = resolvedResponseId(event) || activeResponseId;
    restoreRemoteAudioForResponse(startedResponseId, "output_audio_buffer.started");
    if (sleepSequenceActive && sleepAcknowledgementPending) {
      if (isCurrentSleepAcknowledgementEvent(event)) {
        sleepAcknowledgementBufferStarted = true;
        sleepAcknowledgementBufferStopped = false;
        logEvent("sleep.acknowledgement.buffer_started", sleepAcknowledgementResponseId);
      } else {
        logIgnoredSleepBufferEvent(event);
      }
    }
  }
  if (type === "output_audio_buffer.stopped") {
    if (sleepSequenceActive && sleepAcknowledgementPending) {
      if (isCurrentSleepAcknowledgementEvent(event)) {
        sleepAcknowledgementBufferStopped = true;
        sleepAcknowledgementProviderStoppedAt = performance.now();
        logEvent("sleep.acknowledgement.buffer_stopped", `${sleepAcknowledgementResponseId}; awaiting local playback`);
        if (sleepAcknowledgementResponseDone) {
          armSleepAcknowledgementPlaybackCompletion("provider_output_buffer_stopped", {allowNoAudioFallback: true});
        }
      } else {
        logIgnoredSleepBufferEvent(event);
      }
    }
  }
  if (type === "response.created") {
    if (suppressUnownedConnectedActionResponse(event)) return;
    noteActivity();
    finalizeUntranscribedVoiceTurn("response_started_without_transcript");
    if (visualOnlySuppressionMatches(event)) {
      const responseId = providerResponseId(event);
      if (visualOnlyResponseSuppression && responseId) visualOnlyResponseSuppression.responseId = responseId;
      try {
        if (channel?.readyState === "open") {
          sendProviderEvent({type: "response.cancel"});
          sendProviderEvent({type: "output_audio_buffer.clear"});
        }
      } catch (error) {
        logEvent("memory.navigation.silent_cancel_failed", error.message);
      }
      setResponseActive(false);
      awaitingFirstAudibleAudio = false;
      removeSilentMemoryResponseBubble();
      setStatus("Listening", "listening", {immediate: true});
      logEvent("memory.navigation.silent_response_cancelled", responseId || "pending response");
      relayEvent("client.memory.navigation.response_suppressed", {response_id: responseId || null});
      return;
    }
    const responsePurpose = responsePurposeFromEvent(event, {claimPending: true});
    if (wakeAcknowledgementExpected && wakeInputGateActive) {
      const acknowledgementResponseId = providerResponseId(event);
      if (!wakeAcknowledgementResponseId && acknowledgementResponseId) {
        wakeAcknowledgementResponseId = acknowledgementResponseId;
        wakeAcknowledgementDispatching = false;
        logEvent("wake.acknowledgement.response_bound", acknowledgementResponseId);
      } else if (
        acknowledgementResponseId
        && wakeAcknowledgementResponseId
        && acknowledgementResponseId !== wakeAcknowledgementResponseId
      ) {
        // A duplicate response.create during the opening wake turn would speak and
        // bill twice even though the transcript renderer keeps only one bubble.
        // Cancel the newest response before any audio is allowed through.
        interruptedResponseIds.add(acknowledgementResponseId);
        try {
          if (channel?.readyState === "open") sendProviderEvent({type: "response.cancel"});
        } catch (error) {
          logEvent("wake.acknowledgement.duplicate_cancel_failed", error.message);
        }
        logEvent("wake.acknowledgement.duplicate_suppressed", acknowledgementResponseId);
        relayEvent("client.wake.acknowledgement.duplicate_suppressed", {response_id: acknowledgementResponseId});
        return;
      }
    }
    if (sleepSequenceActive && sleepAcknowledgementPending && sleepAcknowledgementAwaitingResponseCreated) {
      if (rememberSleepAcknowledgementResponse(event)) {
        sleepAcknowledgementAwaitingResponseCreated = false;
        sleepAcknowledgementResponseCreatedAt = performance.now();
        logEvent("sleep.acknowledgement.response_created", sleepAcknowledgementResponseId);
      }
    }
    if (sleepSequenceActive && sleepAcknowledgementPending && !sleepAcknowledgementStartedAt) {
      sleepAcknowledgementStartedAt = performance.now();
    }
    responseCreatedAt = performance.now();
    if (speechStoppedAt) {
      ui.decisionMetric.textContent = metricMs(responseCreatedAt - speechStoppedAt);
      publishLatency("speech_stop_to_response_created", responseCreatedAt - speechStoppedAt);
    }
    activeResponseId = rememberResponseAssociations(event) || providerResponseId(event);
    if (activeResponseId) responsePurposesById.set(activeResponseId, responsePurpose);
    if (activeResponseId && normalizeNaturalText(event.response?.metadata?.authoritative_speech || "")) {
      authoritativeSpeechResponseIds.add(activeResponseId);
      trimTrackedCollection(authoritativeSpeechResponseIds, 256);
    }
    if (responsePurpose === SPOKEN_SUMMARY_PURPOSE && pendingDetailedCompanion) {
      pendingDetailedCompanion.audioResponseId = activeResponseId || "";
    }
    restoreRemoteAudioForResponse(activeResponseId, "response.created");
    const preparedBubble = responsePurpose === SPOKEN_SUMMARY_PURPOSE
      ? pendingDetailedCompanion?.bubble
      : null;
    activeJarvisBubble = preparedBubble || addBubble("jarvis", responsePurpose === SPOKEN_SUMMARY_PURPOSE
      ? "Preparing the complete answer…"
      : "", {
      speakerLabel: "JARVIS",
      responsePurpose,
    });
    if (responsePurpose === SPOKEN_SUMMARY_PURPOSE && pendingDetailedCompanion && !pendingDetailedCompanion.bubble) {
      pendingDetailedCompanion.bubble = activeJarvisBubble;
    }
    if (activeResponseId) responseBubblesById.set(activeResponseId, activeJarvisBubble);
    trimTrackedCollection(responseBubblesById, 256);
    trimTrackedCollection(responsePurposesById, 256);
    awaitingFirstAudibleAudio = Boolean(speechStoppedAt);
    setResponseActive(true);
    setStatus("Thinking", "thinking");
    relayEvent(type, {response_id: activeResponseId || null, response_purpose: responsePurpose});
  }
  if (type === "response.output_audio.delta") {
    rememberResponseAssociations(event);
    if (responseEventIsInterrupted(event)) {
      logEvent("response.interrupted.audio_ignored", resolvedResponseId(event) || "unknown response");
      return;
    }
    const responseId = resolvedResponseId(event);
    if (responseId && activeResponseId && responseId !== activeResponseId) {
      logEvent("response.stale.audio_ignored", responseId);
      return;
    }
    if (visualOnlySuppressionMatches(event)) {
      try { if (channel?.readyState === "open") sendProviderEvent({type: "output_audio_buffer.clear"}); } catch (_) {}
      return;
    }
    noteActivity();
    if (!firstAudioAt && speechStoppedAt && !remoteAnalyser) {
      firstAudioAt = performance.now();
      ui.firstAudioMetric.textContent = metricMs(firstAudioAt - speechStoppedAt);
      publishLatency("speech_stop_to_first_audio_event", firstAudioAt - speechStoppedAt);
    }
    restoreRemoteAudioForResponse(responseId, "response.output_audio.delta");
    setStatus("Speaking", "speaking");
    relayEvent("response.output_audio.started", {response_id: responseId || null});
  }
  if (type === "response.output_audio_transcript.delta" || type === "response.output_text.delta") {
    rememberResponseAssociations(event);
    if (responseEventIsInterrupted(event)) {
      logEvent("response.interrupted.transcript_delta_ignored", resolvedResponseId(event) || "unknown response");
      return;
    }
    if (visualOnlySuppressionMatches(event)) return;
    if (isSpokenSummaryEvent(event) && pendingDetailedCompanion) {
      pendingDetailedCompanion.spokenSummary += event.delta || "";
      return;
    }
    const responseBubble = responseBubbleForEvent(event, {createForCurrent: true});
    if (!responseBubble) {
      logEvent("response.stale.transcript_delta_ignored", resolvedResponseId(event) || "unknown response");
      return;
    }
    appendBubble(responseBubble, event.delta || "");
  }
  if (type === "response.output_audio_transcript.done" || type === "response.output_text.done") {
    rememberResponseAssociations(event);
    if (responseEventIsInterrupted(event)) {
      logEvent("response.interrupted.transcript_done_ignored", resolvedResponseId(event) || "unknown response");
      return;
    }
    if (visualOnlySuppressionMatches(event)) {
      removeSilentMemoryResponseBubble();
      return;
    }
    const responseBubble = responseBubbleForEvent(event);
    if (!responseBubble) {
      logEvent("response.stale.transcript_done_ignored", resolvedResponseId(event) || "unknown response");
      return;
    }
    if (isSpokenSummaryEvent(event) && pendingDetailedCompanion) {
      const summaryText = normalizeNaturalText(event.transcript || event.text || pendingDetailedCompanion.spokenSummary);
      if (summaryText) pendingDetailedCompanion.spokenSummary = summaryText;
      return;
    }
    const finalResponseText = normalizeNaturalText(event.transcript || event.text || responseBubble.querySelector(".content")?.textContent || "");
    finalizeBubble(responseBubble, finalResponseText);
    if (finalResponseText) {
      lastAssistantMemoryText = finalResponseText;
      lastAssistantMemoryAt = Date.now();
      const memoryId = memorySourceEventId("realtime_output", event);
      if (!rememberedProviderMemoryIds.has(memoryId)) {
        rememberedProviderMemoryIds.add(memoryId);
        if (rememberedProviderMemoryIds.size > 2000) rememberedProviderMemoryIds.clear();
        void rememberMemory({
          content: finalResponseText,
          source: "assistant",
          kind: "response",
          actor: "Jarvis",
          sourceEventId: memoryId,
          metadata: {
            provider_event: type,
            response_id: resolvedResponseId(event) || null,
            response_purpose: responsePurposeFromEvent(event),
            presentation: "spoken_transcript",
          },
        });
      }
    }
  }
  if (type === "response.done") {
    noteActivity();
    const completedResponseId = rememberResponseAssociations(event) || providerResponseId(event);
    if (completedResponseId) authoritativeSpeechResponseIds.delete(completedResponseId);
    if (completedResponseId && completedResponseId === connectedActionAuthorizedResponseId) {
      clearConnectedActionVoiceOwnership(completedResponseId);
    }
    if (
      wakeAcknowledgementExpected
      && wakeAcknowledgementResponseId
      && completedResponseId === wakeAcknowledgementResponseId
    ) {
      wakeAcknowledgementExpected = false;
      wakeAcknowledgementDispatching = false;
      wakeAcknowledgementResponseId = "";
      logEvent("wake.acknowledgement.completed_once", completedResponseId);
    }
    finalizeUntranscribedVoiceTurn("response_completed_without_transcript");
    const sleepToolCall = findSleepToolCall(event.response);
    if (sleepToolCall) {
      handleSleepToolCall(sleepToolCall, event);
      return;
    }
    if (visualOnlySuppressionMatches(event)) {
      if (event.response?.usage) recordProviderUsage(event).catch((error) => logEvent("usage.record.failed", error.message));
      setResponseActive(false);
      awaitingFirstAudibleAudio = false;
      removeSilentMemoryResponseBubble();
      setStatus("Listening", "listening", {immediate: true});
      relayEvent("client.memory.navigation.response_done_suppressed", {
        response_id: providerResponseId(event) || null,
        status: event.response?.status || null,
      });
      clearVisualOnlyResponseSuppression("response_done");
      updateUsageMetrics();
      return;
    }
    const completedResponsePurpose = responsePurposeFromEvent(event);
    if (sleepSequenceActive && sleepAcknowledgementPending) {
      if (!sleepAcknowledgementResponseId) rememberSleepAcknowledgementResponse(event);
      if (!isCurrentSleepAcknowledgementEvent(event)) {
        logEvent("sleep.acknowledgement.unrelated_response_done_ignored", providerResponseId(event) || "missing response id");
        return;
      }
      const status = event.response?.status || null;
      sleepAcknowledgementResponseDone = true;
      responseCount += 1;
      recordProviderUsage(event).catch((error) => logEvent("usage.record.failed", error.message));
      setResponseActive(false);
      awaitingFirstAudibleAudio = false;
      updateUsageMetrics();
      relayEvent(type, {status, lifecycle: "sleep_acknowledgement"});
      if (!sleepAcknowledgementBufferStopped) {
        logEvent("sleep.acknowledgement.waiting_for_buffer_stop", sleepAcknowledgementBufferStarted ? "buffer started" : "buffer start pending");
      }
      armSleepAcknowledgementPlaybackCompletion("acknowledgement_response_complete", {allowNoAudioFallback: true});
      armSleepAcknowledgementFallback(SLEEP_ACK_BUFFER_STOP_FALLBACK_MS);
      return;
    }
    const status = event.response?.status || null;
    const completedBubble = completedResponseId
      ? (responseBubblesById.get(completedResponseId) || null)
      : activeJarvisBubble;
    const interruptedResponse = status === "cancelled"
      || Boolean(completedResponseId && interruptedResponseIds.has(completedResponseId));
    const currentResponse = !completedResponseId || completedResponseId === activeResponseId;
    if (interruptedResponse) {
      markBubbleInterrupted(completedBubble, "voice");
      responseCount += 1;
      recordProviderUsage(event).catch((error) => logEvent("usage.record.failed", error.message));
      releaseResponseTracking(completedResponseId);
      if (completedResponseId) responsePurposesById.delete(completedResponseId);
      if (completedResponsePurpose === SPOKEN_SUMMARY_PURPOSE) {
        abortDetailedCompanion("realtime_response_cancelled");
      }
      if (currentResponse) {
        setResponseActive(false);
        awaitingFirstAudibleAudio = false;
        activeResponseId = "";
        activeJarvisBubble = null;
        if (!remoteAnalyser && jarvisSpeakingStartedAt) finalizeJarvisSpeakingSegment();
        setStatus("Listening", "listening", {immediate: true});
      }
      updateUsageMetrics();
      relayEvent(type, {status, response_id: completedResponseId || null, interrupted: true});
      return;
    }
    if (completedResponseId && activeResponseId && completedResponseId !== activeResponseId) {
      responseCount += 1;
      recordProviderUsage(event).catch((error) => logEvent("usage.record.failed", error.message));
      releaseResponseTracking(completedResponseId);
      responsePurposesById.delete(completedResponseId);
      updateUsageMetrics();
      relayEvent("client.response.stale_done_ignored", {response_id: completedResponseId, status});
      return;
    }
    if (speechStoppedAt) {
      const total = performance.now() - speechStoppedAt;
      ui.totalMetric.textContent = metricMs(total);
      publishLatency("speech_stop_to_response_done", total);
    }
    if (!remoteAnalyser && jarvisSpeakingStartedAt) finalizeJarvisSpeakingSegment();
    responseCount += 1;
    recordProviderUsage(event).catch((error) => {
      logEvent("usage.record.failed", error.message);
      ui.configurationMessage.textContent = "Jarvis answered, but the local usage ledger could not record this response.";
    });
    updateUsageMetrics();
    if (wakeInputGateActive && wakePromptResponsePending) {
      wakePromptResponsePending = false;
      wakeOpeningResponseDone = true;
      if (wakeOpeningAudioObserved && !remoteAudioActive && !jarvisSpeakingStartedAt) {
        releaseWakeInputGate("opening_audio_already_complete");
      } else if (!wakeOpeningAudioObserved) {
        clearTimeout(wakeNoAudioReleaseTimer);
        wakeNoAudioReleaseTimer = setTimeout(() => {
          if (wakeInputGateActive && wakeOpeningResponseDone && !wakeOpeningAudioObserved) {
            releaseWakeInputGate("opening_response_no_audio_fallback");
          }
        }, WAKE_RESPONSE_AUDIO_START_GRACE_MS);
        logEvent("wake.input.waiting_for_audio", `${WAKE_RESPONSE_AUDIO_START_GRACE_MS} ms grace`);
      }
    }
    setResponseActive(false);
    awaitingFirstAudibleAudio = false;
    releaseResponseTracking(completedResponseId);
    if (completedResponseId) responsePurposesById.delete(completedResponseId);
    activeResponseId = "";
    activeJarvisBubble = null;
    const detailRequest = completedResponsePurpose === SPOKEN_SUMMARY_PURPOSE
      ? pendingDetailedCompanion
      : null;
    if (detailRequest && status !== "cancelled") {
      const completedTranscript = extractResponseTranscript(event.response || {});
      if (completedTranscript) detailRequest.spokenSummary = completedTranscript;
      detailRequest.voiceDone = true;
      settleDetailedCompanion(detailRequest);
    } else {
      setStatus("Listening", "listening");
    }
    relayEvent(type, {
      status,
      response_id: completedResponseId || null,
      response_mode: ui.responseMode.value,
      response_purpose: completedResponsePurpose,
      hybrid_text_pending: Boolean(detailRequest && !detailRequest.textDone && !detailRequest.textError),
    });
    if (ui.responseMode.value === "test" && ui.testAutoSleep.checked && status !== "cancelled" && !detailRequest) {
      testAutoSleepPending = true;
      if (!remoteAnalyser) window.setTimeout(() => {
        if (testAutoSleepPending) {
          testAutoSleepPending = false;
          sleepJarvis("test_auto_sleep");
        }
      }, 1200);
    }
  }
  if (type === "error") {
    const message = event.error?.message || "Realtime provider error";
    if (pendingDetailedCompanion) abortDetailedCompanion("realtime_provider_error");
    setStatus("Degraded", "degraded");
    ui.configurationMessage.textContent = message;
    relayEvent("client.error", {message, event_id: event.event_id || null});
    if (wakeAcknowledgementExpected) {
      wakeAcknowledgementExpected = false;
      wakeAcknowledgementDispatching = false;
      wakeAcknowledgementResponseId = "";
    }
    if (wakeInputGateActive) releaseWakeInputGate("provider_error");
  }
}

async function refreshDevices(requestPermission = false) {
  let temporary = null;
  try {
    if (requestPermission) temporary = await navigator.mediaDevices.getUserMedia({audio: true});
    const devices = await navigator.mediaDevices.enumerateDevices();
    const preferences = loadPreferences();
    const selectedInput = ui.microphone.value || preferences.microphone;
    const selectedOutput = ui.speaker.value || preferences.speaker;
    ui.microphone.replaceChildren();
    ui.speaker.replaceChildren();
    devices.filter((device) => device.kind === "audioinput").forEach((device, index) => {
      ui.microphone.add(new Option(device.label || `Microphone ${index + 1}`, device.deviceId));
    });
    devices.filter((device) => device.kind === "audiooutput").forEach((device, index) => {
      ui.speaker.add(new Option(device.label || `Speaker ${index + 1}`, device.deviceId));
    });
    if ([...ui.microphone.options].some((option) => option.value === selectedInput)) ui.microphone.value = selectedInput;
    if ([...ui.speaker.options].some((option) => option.value === selectedOutput)) ui.speaker.value = selectedOutput;
    savePreferences();
  } catch (error) {
    ui.configurationMessage.textContent = `Audio device access failed: ${error.message}`;
  } finally {
    temporary?.getTracks().forEach((track) => track.stop());
  }
}

async function applySpeaker() {
  const sinkId = ui.speaker.value;
  savePreferences();
  if (sinkId && typeof ui.remoteAudio.setSinkId === "function") {
    try { await ui.remoteAudio.setSinkId(sinkId); } catch (error) { logEvent("speaker.selection.failed", error.message); }
  }
}

async function cleanupConnection({relayDisconnected = false, status = "Sleeping"} = {}) {
  stopLifecycleListening({disable: true});
  lifecycleSleepTriggered = false;
  connectionEpoch += 1;
  clearReconnectTimers();
  clearSessionTimers();
  clearTimeout(wakeNoAudioReleaseTimer);
  wakeNoAudioReleaseTimer = null;
  handshakeAbort?.abort();
  handshakeAbort = null;
  if (relayDisconnected) relayEvent("client.disconnected");
  clearTimeout(simulationResponseTimer);
  simulationResponseTimer = null;
  if (dedicatedSpeechIsActive()) interruptDedicatedSpeech("connection_cleanup");
  clearDedicatedSpeechResources();
  dedicatedSpeechResponseId = "";
  dedicatedSpeechPurpose = "";
  dedicatedSpeechBubble = null;
  simulationConnected = false;
  testAutoSleepPending = false;
  speculativeWakeActive = false;
  speculativeWakeAccepted = false;
  speculativeWakeConnectPromise = null;
  speculativeWakePresentation = null;
  speculativeWakeActivation = null;
  wakeHandoffStream = null;
  wakeAcknowledgementExpected = false;
  wakeAcknowledgementDispatching = false;
  wakeAcknowledgementResponseId = "";
  stopRealtimeControlHeartbeat();
  try { channel?.close(); } catch (_) {}
  try { peer?.close(); } catch (_) {}
  releaseWakeInputGate("connection_cleanup", {enableMicrophone: false});
  stopSpeakerCapture();
  localStream?.getTracks().forEach((track) => track.stop());
  channel = null;
  peer = null;
  localStream = null;
  connectPromise = null;
  ui.remoteAudio.srcObject = null;
  ui.remoteAudio.muted = false;
  stopAnalyser();
  muted = false;
  ui.mute.textContent = "Mute";
  setResponseActive(false);
  activeResponseId = "";
  activeJarvisBubble = null;
  responseBubblesById.clear();
  responseItemOwners.clear();
  responsePurposesById.clear();
  pendingResponsePurposes.length = 0;
  clearConnectedActionVoiceOwnership();
  abortDetailedCompanion("connection_cleanup");
  pendingDetailedCompanion = null;
  detailedCompanionInProgress = false;
  pendingTestAutoSleepAfterDetail = false;
  interruptedResponseIds.clear();
  interruptedAudioMuteOwnerResponseId = "";
  if (jarvisSpeakingStartedAt) {
    jarvisSpeakingStartedAt = 0;
  }
  clearVoiceBargeInCandidate();
  for (const turn of pendingVoiceTranscriptTurns) {
    clearTimeout(turn.fallbackTimer);
    clearTimeout(turn.falseVadRecoveryTimer);
  }
  pendingVoiceTranscriptTurns = [];
  activeUserBubble = null;
  pendingTypedMessages = [];
  typedSubmitInProgress = false;
  setStatus(status, status === "Sleeping" ? "sleeping" : "degraded");
  updateConnectedControls("sleeping");
  updateUsageMetrics();
}

async function attemptAutoReconnect(epoch) {
  if (intentionalSleep || epoch !== connectionEpoch || autoReconnectAttempts >= MAX_AUTO_RECONNECTS) return;
  autoReconnectAttempts += 1;
  logEvent("client.reconnecting", `attempt ${autoReconnectAttempts}`);
  relayEvent("client.reconnecting", {attempt: autoReconnectAttempts});
  await cleanupConnection({status: "Reconnecting"});
  intentionalSleep = false;
  await new Promise((resolve) => setTimeout(resolve, 750));
  await connect({automatic: true});
}

async function connect({automatic = false, wakeTriggered = false, speculativeWake = false, reuseStream = null} = {}) {
  if (!accountReady) {
    setConversationFocus(false);
    setActiveWorkspaceView("account", {force: true});
    ui.configurationMessage.textContent = "Sign in and verify your Jarvis account before using the assistant.";
    updateConnectedControls("sleeping");
    return null;
  }
  if (sleepSequenceActive || sleepShutdownInProgress) {
    logEvent("wake.connection.blocked", "sleep acknowledgement is still draining locally");
    return null;
  }
  if (connectPromise || isConnected()) return connectPromise;
  if (isSimulationMode()) {
    setStatus("Waking", "waking");
    updateConnectedControls("waking");
    connectPromise = connectSimulation({wakeTriggered}).finally(() => { connectPromise = null; });
    return connectPromise;
  }
  const cachedUsageIsFresh = lastUsageSummaryAt > 0 && Date.now() - lastUsageSummaryAt < 30000;
  const preflight = speculativeWake
    ? {budget: budgetState || {hard_stops: []}}
    : (cachedUsageIsFresh ? {budget: budgetState} : await refreshUsageSummary());
  const accountHardStops = (preflight?.budget?.hard_stops || []).filter((scope) => scope === "daily" || scope === "monthly");
  if (accountHardStops.length) {
    ui.configurationMessage.textContent = `Live connection blocked by ${accountHardStops.join(" and ")} budget hard limit.`;
    setStatus("Budget stopped", "degraded");
    updateConnectedControls("sleeping");
    armWakeListening();
    return null;
  }
  intentionalSleep = false;
  await stopWakeListening({preserveStream: Boolean(reuseStream)});
  if (speculativeWake && !speculativeWakeActive) {
    reuseStream?.getTracks?.().forEach((track) => track.stop());
    return null;
  }
  const gateOpeningRequest = wakeTriggered && (
    speculativeWake || Boolean(normalizeNaturalText(queuedWakePrompt)) || queuedWakeAcknowledgement
  );
  if (gateOpeningRequest) activateWakeInputGate();
  const epoch = ++connectionEpoch;
  connectStartedAt = performance.now();
  resetTurnMetrics();
  ui.handshakeMetric.textContent = "waiting…";
  let lifecyclePresented = false;
  const presentConnectionLifecycle = () => {
    if (lifecyclePresented || epoch !== connectionEpoch) return;
    lifecyclePresented = true;
    if (!automatic) {
      wakeVisualHoldUntil = Math.max(wakeVisualHoldUntil, performance.now() + WAKE_VISUAL_MIN_MS);
    }
    setStatus(automatic ? "Reconnecting" : "Waking", "waking", {immediate: !automatic});
    ui.configurationMessage.textContent = "";
    updateConnectedControls("waking");
    relayEvent(automatic ? "client.reconnecting" : "client.waking", {voice: ui.voice.value, turn_detection_profile: ui.turnDetection.value, response_mode: ui.responseMode.value, wake_triggered: wakeTriggered});
    relayEvent("client.connecting", {voice: ui.voice.value, turn_detection_profile: ui.turnDetection.value, response_mode: ui.responseMode.value});
  };
  if (speculativeWake) {
    speculativeWakePresentation = presentConnectionLifecycle;
    logEvent("wake.preconnect.hidden", "Realtime is preparing while the orb remains asleep until Jarvis is confirmed");
  } else {
    presentConnectionLifecycle();
  }
  savePreferences();

  connectPromise = (async () => {
    try {
      await loadRealtimeProfile(ui.responseMode.value);
      const reusableTracks = reuseStream?.getAudioTracks?.() || [];
      localStream = reusableTracks.some((track) => track.readyState === "live")
        ? reuseStream
        : await navigator.mediaDevices.getUserMedia({
          audio: {
            deviceId: ui.microphone.value ? {exact: ui.microphone.value} : undefined,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
      if (localStream === reuseStream) logEvent("wake.microphone.reused", "wake stream handed directly to Realtime");
      wakeHandoffStream = null;
      if (speculativeWake && !speculativeWakeActive) {
        localStream?.getTracks().forEach((track) => track.stop());
        localStream = null;
        return;
      }
      if (epoch !== connectionEpoch) return;
      localStream.getAudioTracks().forEach((track) => {
        track.enabled = !gateOpeningRequest && !muted;
      });
      await setupSpeakerCapture(localStream);
      peer = new RTCPeerConnection();
      const currentPeer = peer;
      let connectedSessionActivated = false;
      const activateConnectedSession = () => {
        if (connectedSessionActivated || epoch !== connectionEpoch || currentPeer.connectionState !== "connected") return;
        if (speculativeWake && !speculativeWakeAccepted) {
          logEvent("wake.preconnect.ready.hidden", "Connection ready; waiting for confirmed Jarvis keyword");
          return;
        }
        presentConnectionLifecycle();
        connectedSessionActivated = true;
        clearReconnectTimers();
        setStatus("Listening", "listening");
        ui.handshakeMetric.textContent = metricMs(performance.now() - connectStartedAt);
        publishLatency("webrtc_handshake", performance.now() - connectStartedAt);
        updateConnectedControls("awake");
        startSessionTimers();
        relayEvent("client.connected", {automatic, speculative_wake: speculativeWake});
        stableConnectionTimer = setTimeout(() => { autoReconnectAttempts = 0; }, 10000);
        window.setTimeout(() => refreshDevices(false), 0);
        maybeDispatchQueuedWakePrompt();
        lifecycleSleepTriggered = false;
        armLifecycleListening();
      };
      if (speculativeWake) speculativeWakeActivation = activateConnectedSession;
      currentPeer.ontrack = async (event) => {
        if (epoch !== connectionEpoch) return;
        const stream = event.streams[0];
        ui.remoteAudio.srcObject = stream;
        await applySpeaker();
        await setupRemoteAnalyser(stream);
        await ui.remoteAudio.play().catch(() => {});
      };
      currentPeer.onconnectionstatechange = () => {
        if (epoch !== connectionEpoch) return;
        const state = currentPeer.connectionState;
        logEvent("webrtc.connection", state);
        if (state === "connected") {
          if (speculativeWake && wakeSpeechEndedAt && !wakePreconnectReadyAt) {
            wakePreconnectReadyAt = performance.now();
            const preconnectDurationMs = wakePreconnectReadyAt - wakeSpeechEndedAt;
            if (ui.wakePreconnectMetric) ui.wakePreconnectMetric.textContent = metricMs(preconnectDurationMs);
            publishLatency("wake_preconnect", preconnectDurationMs);
            logEvent("wake.preconnect.ready", `${Math.round(preconnectDurationMs)} ms after speech ended`);
          }
          activateConnectedSession();
        } else if (state === "disconnected") {
          if (speculativeWake && !speculativeWakeAccepted) {
            logEvent("wake.preconnect.disconnected", "Hidden preconnect disconnected before keyword confirmation");
            return;
          }
          setStatus("Reconnecting", "waking");
          clearTimeout(reconnectTimer);
          reconnectTimer = setTimeout(() => {
            if (currentPeer.connectionState === "disconnected") attemptAutoReconnect(epoch);
          }, DISCONNECT_GRACE_MS);
        } else if (state === "failed") {
          if (speculativeWake && !speculativeWakeAccepted) {
            void cancelSpeculativeWake("preconnect_failed");
            return;
          }
          setStatus("Connection failed", "error");
          attemptAutoReconnect(epoch);
        }
      };
      localStream.getTracks().forEach((track) => currentPeer.addTrack(track, localStream));
      if (!isHostedRealtimeMode()) {
        channel = currentPeer.createDataChannel("oai-events");
        channel.addEventListener("open", () => {
          logEvent("datachannel.open");
          if (wakeInputGateActive) {
            try { sendProviderEvent({type: "input_audio_buffer.clear"}); } catch (_) {}
          }
          maybeDispatchQueuedWakePrompt();
        });
        channel.addEventListener("close", () => logEvent("datachannel.close"));
        channel.addEventListener("message", (message) => {
          try { handleProviderEvent(JSON.parse(message.data)); } catch (error) { logEvent("event.parse.failed", error.message); }
        });
      }

      const offer = await currentPeer.createOffer();
      await currentPeer.setLocalDescription(offer);
      await waitForIceGatheringComplete(currentPeer);
      const localOffer = currentPeer.localDescription?.sdp;
      if (!localOffer || !localOffer.startsWith("v=0")) throw new Error("The browser did not produce a valid WebRTC SDP offer.");
      logEvent("webrtc.offer.ready", `${new TextEncoder().encode(localOffer).byteLength} bytes`);

      handshakeAbort = new AbortController();
      const timeout = setTimeout(() => handshakeAbort.abort(), HANDSHAKE_TIMEOUT_MS);
      let response;
      try {
        const query = new URLSearchParams({
          voice: ui.voice.value,
          turn_detection_profile: ui.turnDetection.value,
          response_mode: ui.responseMode.value,
          timezone_name: clientTimezoneName(),
          client_local_now: clientLocalNowIso(),
        });
        response = await fetch(`/api/realtime/session?${query}`, {
          method: "POST",
          headers: {"Content-Type": "application/sdp", "X-Jarvis-Client": CLIENT_HEADER},
          body: localOffer,
          signal: handshakeAbort.signal,
        });
      } finally {
        clearTimeout(timeout);
        handshakeAbort = null;
      }
      if (!response.ok) {
        let message = `Session request failed (${response.status})`;
        try { const data = await response.json(); message = data.detail || data.error || message; } catch (_) {}
        throw new Error(message);
      }
      if (isHostedRealtimeMode()) {
        const hostedSessionId = response.headers.get("X-Jarvis-Realtime-Session") || "";
        channel = createHostedRealtimeChannel(hostedSessionId);
        channel.addEventListener("open", () => {
          logEvent("realtime.control.open");
          if (wakeInputGateActive) {
            try { sendProviderEvent({type: "input_audio_buffer.clear"}); } catch (_) {}
          }
          maybeDispatchQueuedWakePrompt();
        });
        channel.addEventListener("close", () => logEvent("realtime.control.close"));
        channel.addEventListener("message", (message) => {
          try { handleProviderEvent(JSON.parse(message.data)); } catch (error) { logEvent("event.parse.failed", error.message); }
        });
        await waitForRealtimeControlOpen(channel);
      }
      const rawAnswer = await response.text();
      const answerSdp = normalizeRemoteSdp(rawAnswer);
      logEvent("webrtc.answer.ready", `${new TextEncoder().encode(answerSdp).byteLength} bytes, ${answerSdp.split("\r\n").filter(Boolean).length} lines`);
      await currentPeer.setRemoteDescription({type: "answer", sdp: answerSdp});
    } catch (error) {
      if (epoch !== connectionEpoch) return;
      const message = error.name === "AbortError" ? "Realtime handshake timed out after 30 seconds." : error.message;
      if (speculativeWake && !speculativeWakeAccepted) {
        logEvent("wake.preconnect.failed.hidden", message);
        await cleanupConnection({status: "Sleeping"});
        armWakeListening();
        return;
      }
      logEvent("client.connect.failed", message);
      ui.configurationMessage.textContent = message;
      setStatus("Connection failed", "error");
      await relayEvent("client.error", {message});
      await cleanupConnection({status: "Connection failed"});
      armWakeListening();
    } finally {
      if (epoch === connectionEpoch) connectPromise = null;
    }
  })();
  return connectPromise;
}

async function sleepJarvis(reason = "manual") {
  intentionalSleep = true;
  if (reason !== "model_tool") resetSleepSequence();
  if (responseActive) interruptResponse(reason, true);
  relayEvent("client.sleeping", {reason});
  await cleanupConnection({relayDisconnected: true, status: "Sleeping"});
  wakeDetectionTriggered = false;
  wakeCandidateText = "";
  queuedWakePrompt = "";
  queuedWakeAcknowledgement = false;
  queuedWakeMemoryRecorded = false;
  wakeAcknowledgementExpected = false;
  wakeAcknowledgementDispatching = false;
  wakeAcknowledgementResponseId = "";
  wakePromptDispatchStartedAt = 0;
  releaseWakeInputGate("sleep", {enableMicrophone: false});
  clearTimeout(wakePromptDispatchTimer);
  wakePromptDispatchTimer = null;
  ui.configurationMessage.textContent = reason === "session_timeout"
    ? "Jarvis slept before the provider session limit. Wake him to begin a fresh session."
    : (reason === "idle_timeout" ? "Jarvis returned to sleep after being idle." : "");
  clientSessionId = "";
  if (!sleepShutdownInProgress) armWakeListening();
}

function sendText(text, {remember = true, source = "typed", speakerRecognition = null} = {}) {
  const normalized = text.trim();
  if (!normalized) return {handledLocally: false, responseRequested: false};
  if (!accountReady) throw new Error("Sign in and verify your Jarvis account first.");
  if (!isConnected()) throw new Error("Jarvis is not awake");
  noteActivity();
  const memoryNavigation = navigateMemoryFromNaturalLanguage(normalized, {source});
  const preferenceCommand = parseAddressPreferenceCommand(normalized);
  const identityQuestion = isVoiceIdentityQuestion(normalized);
  const identityExplanation = isVoiceIdentityExplanationQuestion(normalized);
  const turnRecognition = turnSpeakerRecognition(speakerRecognition, source);
  const userSpeakerLabel = speakerLabelForRecognition(turnRecognition);
  const memoryEventPromise = remember
    ? rememberMemory({
        content: normalized,
        source,
        kind: "utterance",
        sourceEventId: `${source}:${clientSessionId || "local"}:${Date.now()}:${providerEventSequence}`,
        metadata: {transport: isSimulationMode() ? "simulation" : "realtime_text"},
      })
    : Promise.resolve(null);

  if (isSleepCommand(normalized)) {
    addBubble("user", normalized, {speakerLabel: userSpeakerLabel});
    handleSilentSleepCommand(normalized, source);
    return {handledLocally: true, responseRequested: false, action: "sleep"};
  }

  if (isExplicitSilenceCommand(normalized)) {
    addBubble("user", normalized, {speakerLabel: userSpeakerLabel});
    relayEvent("client.typed.response_suppressed", {reason: "explicit_silence"});
    setStatus("Listening", "listening", {immediate: true});
    noteActivity();
    return {handledLocally: true, responseRequested: false, action: "silence"};
  }

  if (consumeVoiceEnrollmentReply(normalized)) {
    addBubble("user", normalized, {speakerLabel: userSpeakerLabel});
    return {handledLocally: true, responseRequested: false, action: "voice_enrollment"};
  }

  if (memoryNavigation?.visualOnly) {
    addBubble("user", normalized, {speakerLabel: userSpeakerLabel});
    relayEvent("client.typed.local_action", {
      characters: normalized.length,
      action: "show_memory",
      subject: memoryNavigation.subject || null,
    });
    ui.configurationMessage.textContent = memoryNavigation.subject
      ? `Showing everything connected to ${memoryNavigation.subject}.`
      : "Memory Explorer opened.";
    return {handledLocally: true, responseRequested: false, memoryNavigation};
  }

  if (isSimulationMode()) {
    addBubble("user", normalized, {speakerLabel: userSpeakerLabel});
    relayEvent("client.typed.sent", {characters: normalized.length, simulation: true});
    if (memoryNavigation?.responseRequested) {
      void requestMemoryNarrationAfterNavigation(memoryNavigation, {source});
    } else if (preferenceCommand) {
      void applyAddressPreferenceCommand(preferenceCommand, turnRecognition, {source}).then((result) => {
        startSimulationResponse(result.reply, {exactReply: result.reply});
      });
    } else if (isNaturalMemoryControlCommand(normalized)) {
      void memoryEventPromise
        .then((storedMemory) => applyNaturalMemoryControlCommand(normalized, storedMemory, {source}))
        .then((result) => startSimulationResponse(result.reply || "Done.", {exactReply: result.reply || "Done."}));
    } else if (identityQuestion || identityExplanation) {
      startSimulationResponse("", {exactReply: identityReplyForRecognition(turnRecognition, {explain: identityExplanation, source})});
    } else {
      startSimulationResponse(normalized);
    }
    return {handledLocally: false, responseRequested: true, memoryNavigation};
  }
  if (!channel || channel.readyState !== "open") throw new Error("Realtime data channel is not open");
  const bubble = addBubble("user", normalized, {speakerLabel: userSpeakerLabel});
  const itemId = `item_${crypto.randomUUID().replaceAll("-", "").slice(0, 24)}`;
  const pending = {text: normalized, bubble, itemId};
  pendingTypedMessages.push(pending);
  if (pendingTypedMessages.length > 20) pendingTypedMessages.shift();
  try {
    sendProviderEvent({
      type: "conversation.item.create",
      item: {id: itemId, type: "message", role: "user", content: [{type: "input_text", text: normalized}]},
    });
    if (memoryNavigation?.responseRequested) {
      void requestMemoryNarrationAfterNavigation(memoryNavigation, {source});
    } else if (preferenceCommand) {
      void applyAddressPreferenceCommand(preferenceCommand, turnRecognition, {source}).then((result) => {
        if (channel?.readyState === "open" && isConnected()) createExactReply(result.reply, turnRecognition);
      });
    } else if (isNaturalMemoryControlCommand(normalized)) {
      void memoryEventPromise
        .then((storedMemory) => applyNaturalMemoryControlCommand(normalized, storedMemory, {source}))
        .then((result) => {
          if (channel?.readyState === "open" && isConnected()) createExactReply(result.reply || "Done.", turnRecognition);
        });
    } else if (identityQuestion || identityExplanation) {
      createExactReply(identityReplyForRecognition(turnRecognition, {explain: identityExplanation, source}), turnRecognition);
    } else {
      void (async () => {
        const webResearch = await requestWebResearchTurn(normalized, turnRecognition);
        if (channel?.readyState !== "open" || !isConnected()) return;
        if (webResearch?.handled) {
          speakWebIntelligenceResult(webResearch, turnRecognition, {userText: normalized, itemId: pending.itemId || "", source});
          return;
        }
        const browserAction = await requestBrowserActionTurn(normalized, turnRecognition, {source});
        if (channel?.readyState !== "open" || !isConnected()) return;
        if (browserAction?.handled) {
          speakBrowserActionResult(browserAction, turnRecognition, {userText: normalized, itemId: pending.itemId || "", source});
          return;
        }
        const computerAction = await requestComputerActionTurn(normalized, turnRecognition, {source});
        if (channel?.readyState !== "open" || !isConnected()) return;
        if (computerAction?.handled) {
          speakComputerActionResult(computerAction, turnRecognition);
          return;
        }
        const connectedAction = await requestConnectedActionTurn(normalized, turnRecognition);
        if (channel?.readyState !== "open" || !isConnected()) return;
        if (connectedAction?.handled) {
          speakConnectedActionResult(connectedAction, turnRecognition, {
            userText: normalized,
            itemId: pending.itemId || "",
            source,
          });
          return;
        }
        const temporalReply = localTemporalReply(normalized);
        if (temporalReply) {
          createExactReply(temporalReply, turnRecognition, {authoritativeSpeech: "local_time"});
          logEvent("local_time.response", temporalReply);
          return;
        }
        const [storedMemory, memoryContext] = await Promise.all([
          memoryEventPromise,
          querySpecificMemoryTurnContext(normalized, turnRecognition),
        ]);
        if (channel?.readyState !== "open" || !isConnected()) return;
        const mergedMemoryContext = {
          ...memoryContext,
          rendered: [durableMemoryTurnInstructions(storedMemory), memoryContext.rendered].filter(Boolean).join("\n\n"),
        };
        try {
          const scripted = await requestNaturalVoiceScript(normalized, turnRecognition, mergedMemoryContext);
          responseCreateWithSpeaker(turnRecognition, {
            wake: source === "wake_voice",
            exactReply: scripted.spoken_text,
            userText: normalized,
            itemId: pending.itemId || "",
            source,
            allowDetailedCompanion: !memoryContext.ambiguous,
            memoryContext: mergedMemoryContext,
            preparedResponseId: String(scripted.response_id || ""),
            preparedModel: String(scripted.model || config?.text_model || ""),
            preparedProvider: "luna_voice_script",
            authoritativeSpeech: "luna_voice_script",
          });
        } catch (error) {
          logEvent("typed.luna_script.failed", error.message || "natural voice response failed");
          createExactReply("I hit a problem putting that response together.", turnRecognition, {authoritativeSpeech: "local_error"});
        }
      })();
    }
  } catch (error) {
    pendingTypedMessages = pendingTypedMessages.filter((entry) => entry !== pending);
    bubble.remove();
    throw error;
  }
  relayEvent("client.typed.sent", {
    characters: normalized.length,
    response_mode: ui.responseMode.value,
    memory_narration: Boolean(memoryNavigation?.responseRequested),
  });
  return {handledLocally: false, responseRequested: true, memoryNavigation};
}

async function prewarmProviderConnections() {
  if (!providerReadyForLive() || isSimulationMode()) return;
  try {
    const response = await fetch("/api/providers/prewarm", {
      method: "POST",
      headers: {"X-Jarvis-Client": CLIENT_HEADER},
    });
    const payload = response.ok ? await response.json() : null;
    logEvent("provider.prewarm", payload?.ready ? "ready" : "best effort");
  } catch (error) {
    logEvent("provider.prewarm.failed", error.message);
  }
}


function replaceSelectOptions(target, source, preferredValue = "") {
  if (!target || !source) return;
  target.replaceChildren(...[...source.options].map((option) => new Option(option.textContent, option.value)));
  if ([...target.options].some((option) => option.value === preferredValue)) target.value = preferredValue;
}

function showSetupOverlay({required = false} = {}) {
  if (!ui.firstRunOverlay) return;
  configureProviderModeUi();
  ui.firstRunOverlay.hidden = false;
  ui.setupCancel.hidden = required;
  ui.setupApiKey.value = "";
  ui.setupApiKey.placeholder = alphaSetupStatus?.providerKeyConfigured ? "Leave blank to keep the saved development key" : "sk-…";
  window.setTimeout(() => {
    if (isHostedProviderMode()) ui.setupVoice?.focus();
    else ui.setupApiKey?.focus();
  }, 50);
}

function hideSetupOverlay() {
  if (ui.firstRunOverlay) ui.firstRunOverlay.hidden = true;
  if (ui.setupMessage) ui.setupMessage.textContent = "";
}

function renderAlphaStatus(status) {
  if (!status) return;
  alphaSetupStatus = status;
  if (ui.alphaBuildBadge) ui.alphaBuildBadge.textContent = status.packaged ? "Installed alpha" : "Development";
  if (ui.alphaAppVersion) ui.alphaAppVersion.textContent = status.appVersion || config?.version || "0.1.0";
  if (ui.alphaElectronVersion) ui.alphaElectronVersion.textContent = status.electronVersion || "—";
  if (ui.alphaPythonVersion) ui.alphaPythonVersion.textContent = status.pythonVersion || "—";
  if (ui.alphaKeyStatus) {
    ui.alphaKeyStatus.textContent = isHostedProviderMode()
      ? (providerReadyForLive() ? "Jarvis Cloud" : "Cloud sign-in required")
      : (status.providerKeyConfigured ? "Development key ready" : "Development key missing");
  }
  if (ui.alphaInstallPath) ui.alphaInstallPath.textContent = status.installationPath || "Development source";
  if (ui.alphaDataPath) ui.alphaDataPath.textContent = status.dataPath || "Project data directory";
  if (ui.alphaLogPath) ui.alphaLogPath.textContent = status.logPath || "Project logs directory";

  const preferences = status.preferences || {};
  replaceSelectOptions(ui.setupVoice, ui.voice, preferences.voice || ui.voice.value);
  replaceSelectOptions(ui.setupWakeProfile, ui.wakeProfile, preferences.wakeProfile || ui.wakeProfile.value);
  replaceSelectOptions(ui.setupResponseMode, ui.responseMode, preferences.responseMode || ui.responseMode.value);
  replaceSelectOptions(ui.setupMicrophone, ui.microphone, ui.microphone.value);
  replaceSelectOptions(ui.setupSpeaker, ui.speaker, ui.speaker.value);
  ui.setupDailyWarning.value = preferences.budgetDailyWarningUsd ?? 0.50;
  ui.setupDailyHard.value = preferences.budgetDailyHardUsd ?? 1.00;
  ui.setupMonthlyWarning.value = preferences.budgetMonthlyWarningUsd ?? 5.00;
  ui.setupMonthlyHard.value = preferences.budgetMonthlyHardUsd ?? 10.00;
  ui.setupStartWithWindows.checked = Boolean(status.startWithWindows);
  ui.setupNotifications.checked = status.notificationsEnabled !== false;
}

async function initializeAlphaSetup() {
  if (!window.jarvisDesktop?.getSetupStatus) return {required: false};
  try {
    const status = await window.jarvisDesktop.getSetupStatus();
    renderAlphaStatus(status);
    if (!status.configured && !isHostedProviderMode()) {
      showSetupOverlay({required: true});
      setStatus("Development setup required", "degraded");
      ui.wakeListenerStatus.textContent = "Complete development setup";
      return {required: true};
    }
    // Hosted customer setup is account-first. Provider credentials live on Cloud,
    // so absence of a legacy local API-key settings file must never block the account gate.
  } catch (error) {
    logEvent("desktop.setup_status.failed", error.message);
  }
  return {required: false};
}

async function submitAlphaSetup(event) {
  event.preventDefault();
  if (!window.jarvisDesktop?.saveSetup) return;
  ui.setupSave.disabled = true;
  ui.setupMessage.textContent = "Encrypting settings and restarting the local core…";
  try {
    const existing = alphaSetupStatus?.preferences || {};
    const payload = {
      apiKey: isHostedProviderMode() ? "" : ui.setupApiKey.value.trim(),
      preferences: {
        voice: ui.setupVoice.value,
        wakeProfile: ui.setupWakeProfile.value,
        responseMode: ui.setupResponseMode.value,
        budgetSessionWarningUsd: existing.budgetSessionWarningUsd ?? 0.10,
        budgetSessionHardUsd: existing.budgetSessionHardUsd ?? 0.25,
        budgetDailyWarningUsd: Number(ui.setupDailyWarning.value),
        budgetDailyHardUsd: Number(ui.setupDailyHard.value),
        budgetMonthlyWarningUsd: Number(ui.setupMonthlyWarning.value),
        budgetMonthlyHardUsd: Number(ui.setupMonthlyHard.value),
      },
      startWithWindows: ui.setupStartWithWindows.checked,
      notificationsEnabled: ui.setupNotifications.checked,
    };
    ui.voice.value = payload.preferences.voice;
    ui.wakeProfile.value = payload.preferences.wakeProfile;
    ui.responseMode.value = payload.preferences.responseMode;
    if ([...ui.microphone.options].some((option) => option.value === ui.setupMicrophone.value)) ui.microphone.value = ui.setupMicrophone.value;
    if ([...ui.speaker.options].some((option) => option.value === ui.setupSpeaker.value)) ui.speaker.value = ui.setupSpeaker.value;
    savePreferences();
    const status = await window.jarvisDesktop.saveSetup(payload);
    renderAlphaStatus(status);
    hideSetupOverlay();
  } catch (error) {
    ui.setupMessage.textContent = error.message;
  } finally {
    ui.setupSave.disabled = false;
  }
}

async function refreshAlphaStatus() {
  if (!window.jarvisDesktop?.getSetupStatus) return;
  try { renderAlphaStatus(await window.jarvisDesktop.getSetupStatus()); } catch (error) { logEvent("desktop.alpha_status.failed", error.message); }
}

function renderGoogleConnectionStatus(payload) {
  const status = payload?.google || {};
  if (ui.actionPlannerModel) ui.actionPlannerModel.textContent = payload?.action_model || config?.action_model || "—";
  if (!ui.googleConnectionStatus || !ui.googleConnectionBadge) return;
  ui.googleConnectionBadge.className = "connection-badge";
  if (!status.configured) {
    ui.googleConnectionStatus.textContent = "OAuth setup required";
    ui.googleConnectionDetail.textContent = "Add the Google desktop OAuth client ID to .env, then restart Jarvis.";
    ui.googleConnectionBadge.textContent = "Setup needed";
    ui.googleConnectionBadge.classList.add("error");
    ui.googleConnectButton.disabled = true;
    ui.googleDisconnectButton.hidden = true;
    return;
  }
  ui.googleConnectButton.disabled = false;
  if (status.connected) {
    ui.googleConnectionStatus.textContent = status.email ? `Connected as ${status.email}` : "Google connected";
    const contactsReady = Boolean(status.contacts_ready);
    const missingScopes = Array.isArray(status.missing_scopes) ? status.missing_scopes : [];
    const gmailModifyReady = !missingScopes.includes("https://www.googleapis.com/auth/gmail.modify");
    const calendarAvailabilityReady = !missingScopes.includes("https://www.googleapis.com/auth/calendar.events.freebusy");
    const calendarTimezoneReady = !missingScopes.includes("https://www.googleapis.com/auth/calendar.settings.readonly");
    ui.googleConnectionDetail.textContent = !gmailModifyReady
      ? "Reconnect Google once to let Jarvis manage Gmail read state while keeping your existing Google access."
      : !calendarAvailabilityReady
        ? "Reconnect Google once to enable live Calendar availability checks and smart scheduling."
        : !calendarTimezoneReady
          ? "Reconnect Google once so Jarvis can match the local timezone you use in Google Calendar."
          : contactsReady
            ? `Gmail, Calendar, and Contacts are connected. OAuth tokens are protected locally using ${status.protection || "local protection"}.`
            : `Gmail and Calendar are connected. Reconnect once to add Google Contacts lookup.`;
    if (ui.googleContactsStatus) ui.googleContactsStatus.textContent = contactsReady ? "Available" : "Reconnect needed";
    ui.googleConnectionBadge.textContent = "Connected";
    ui.googleConnectionBadge.classList.add("connected");
    ui.googleConnectButton.hidden = contactsReady && gmailModifyReady && calendarAvailabilityReady && calendarTimezoneReady;
    ui.googleConnectButton.textContent = !gmailModifyReady
      ? "Enable Gmail Actions"
      : !calendarAvailabilityReady
        ? "Enable Calendar Availability"
        : !calendarTimezoneReady
          ? "Enable Calendar Timezone"
          : (contactsReady ? "Connect Google" : "Enable Contacts");
    ui.googleDisconnectButton.hidden = false;
  } else {
    if (ui.googleContactsStatus) ui.googleContactsStatus.textContent = "Unavailable";
    ui.googleConnectButton.textContent = "Connect Google";
    ui.googleConnectionStatus.textContent = status.needs_reconnect ? "Reconnect Google" : "Not connected";
    ui.googleConnectionDetail.textContent = status.detail || "Connect Gmail and Calendar through Google's sign-in page.";
    ui.googleConnectionBadge.textContent = status.needs_reconnect ? "Reconnect" : "Disconnected";
    if (status.needs_reconnect) ui.googleConnectionBadge.classList.add("error");
    ui.googleConnectButton.hidden = false;
    ui.googleDisconnectButton.hidden = true;
  }
}

async function loadGoogleConnectionStatus({validate = false} = {}) {
  try {
    const response = await fetch(`/api/integrations/google/status?validate=${validate ? "true" : "false"}`, {cache: "no-store"});
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Google status failed (${response.status})`);
    renderGoogleConnectionStatus(payload);
    return payload;
  } catch (error) {
    if (ui.googleConnectionStatus) ui.googleConnectionStatus.textContent = "Connection status unavailable";
    if (ui.googleConnectionDetail) ui.googleConnectionDetail.textContent = error.message;
    if (ui.googleConnectionBadge) {
      ui.googleConnectionBadge.textContent = "Error";
      ui.googleConnectionBadge.className = "connection-badge error";
    }
    logEvent("google.status.failed", error.message);
    return null;
  }
}

function pendingActionSafeDetails(action) {
  if (!action) return "";
  const args = action.arguments || {};
  const draft = args.draft_preview || {};
  const lines = [];
  if (action.operation) lines.push(`Action: ${String(action.operation).replaceAll("_", " ")}`);
  const recipients = args.recipients?.length ? args.recipients : (draft.to || []);
  if (draft.from_email) lines.push(`From: ${draft.from_email}`);
  if (recipients.length) lines.push(`To: ${recipients.join(", ")}`);
  if (draft.cc?.length) lines.push(`Cc: ${draft.cc.join(", ")}`);
  if (draft.bcc?.length) lines.push(`Bcc: ${draft.bcc.join(", ")}`);
  const subject = args.subject || draft.subject || "";
  if (subject) lines.push(`Subject: ${subject}`);
  if (draft.body) lines.push(`Message:\n${draft.body}`);
  if (args.event_summary) lines.push(`Event: ${args.event_summary}`);
  if (args.start) lines.push(`Starts: ${args.start}`);
  if (args.end) lines.push(`Ends: ${args.end}`);
  if (args.event_location) lines.push(`Location: ${args.event_location}`);
  return lines.join("\n");
}

function renderPendingAction(action) {
  const has = Boolean(action?.id && action?.status === "pending_confirmation");
  connectedActionPending = has;
  if (!ui.pendingActionPanel) return;
  ui.pendingActionPanel.hidden = !has;
  if (!has) {
    ui.pendingActionDetails.hidden = true;
    ui.pendingActionDetails.textContent = "";
    return;
  }
  ui.pendingActionPanel.dataset.actionId = action.id;
  ui.pendingActionTitle.textContent = String(action.operation || "Pending action").replaceAll("_", " ");
  ui.pendingActionSummary.textContent = action.summary || "Review this action before Jarvis performs it.";
  ui.pendingActionRisk.textContent = action.risk === "external_write" ? "Confirmation required" : "Review";
  ui.pendingActionDetails.textContent = pendingActionSafeDetails(action);
  ui.pendingActionDetails.hidden = true;
}

function permissionModeOptions(permission) {
  // Default is the product policy: routine/reversible actions run automatically,
  // while consequential or security-sensitive actions still require review.
  const options = [{value: "default", label: "Default"}];
  if (permission.user_can_always_allow) options.push({value: "allow", label: "Always allow"});
  if (!["forbidden", "restricted"].includes(permission.level)) options.push({value: "ask", label: "Always ask"});
  if (permission.user_can_disable) options.push({value: "deny", label: "Block"});
  return options;
}

function renderPermissions(payload) {
  if (!ui.permissionList) return;
  const rows = Array.isArray(payload?.permissions) ? payload.permissions : [];
  if (!rows.length) {
    ui.permissionList.innerHTML = '<div class="empty-state compact"><strong>No permission policy available</strong><span>Jarvis could not load the device permission catalog.</span></div>';
    return;
  }
  const fragment = document.createDocumentFragment();
  for (const permission of rows) {
    const row = document.createElement("div");
    row.className = "permission-row";
    const copy = document.createElement("div");
    copy.className = "permission-row-copy";
    const title = document.createElement("div");
    title.className = "permission-row-title";
    const strong = document.createElement("strong");
    strong.textContent = permission.title || permission.key;
    const badge = document.createElement("span");
    badge.className = "permission-policy-badge";
    badge.textContent = String(permission.level || "policy").replaceAll("_", " ");
    title.append(strong, badge);
    const detail = document.createElement("small");
    detail.textContent = permission.description || permission.key;
    copy.append(title, detail);

    const select = document.createElement("select");
    select.setAttribute("aria-label", `${permission.title || permission.key} permission`);
    for (const option of permissionModeOptions(permission)) {
      const element = document.createElement("option");
      element.value = option.value;
      element.textContent = option.label;
      element.selected = option.value === String(permission.preference || "default");
      select.appendChild(element);
    }
    select.addEventListener("change", async () => {
      const prior = String(permission.preference || "default");
      select.disabled = true;
      if (ui.permissionMessage) ui.permissionMessage.textContent = "Saving permission…";
      try {
        const response = await permissionAwareFetch(`/api/permissions/${encodeURIComponent(permission.key)}`, {
          method: "PUT",
          headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
          body: JSON.stringify({mode: select.value}),
        });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.detail || `Permission update failed (${response.status})`);
        permission.preference = body.preference || select.value;
        if (ui.permissionMessage) ui.permissionMessage.textContent = "Permission saved for this device.";
      } catch (error) {
        select.value = prior;
        if (ui.permissionMessage) ui.permissionMessage.textContent = error?.message || "Permission update failed.";
      } finally {
        select.disabled = false;
      }
    });
    row.append(copy, select);
    fragment.appendChild(row);
  }
  ui.permissionList.replaceChildren(fragment);
}

async function loadPermissions() {
  if (!ui.permissionList || !accountReady) return;
  if (ui.permissionMessage) ui.permissionMessage.textContent = "Loading device permission policy…";
  try {
    const response = await fetch("/api/permissions", {cache: "no-store"});
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Permission policy unavailable (${response.status})`);
    renderPermissions(payload);
    if (ui.permissionMessage) ui.permissionMessage.textContent = payload.cloud_connected
      ? "Default follows Jarvis policy. Always allow removes permission popups for that capability, while consequential actions can still require Jarvis's separate conversational review. Device preferences cannot bypass Cloud or system safety."
      : "Cloud identity is not connected. Cloud-authoritative actions remain unavailable.";
  } catch (error) {
    if (ui.permissionMessage) ui.permissionMessage.textContent = error?.message || "Permission policy unavailable.";
  }
}

async function loadConnectedActionAuditState() {
  try {
    const [auditResponse, pendingResponse] = await Promise.all([
      fetch("/api/actions/audit?limit=10", {cache: "no-store"}),
      fetch("/api/actions/pending", {cache: "no-store"}),
    ]);
    if (auditResponse.ok) await auditResponse.json();
    if (!pendingResponse.ok) return;
    const pendingPayload = await pendingResponse.json();
    renderPendingAction((pendingPayload.actions || [])[0] || null);
  } catch (_) {}
}

async function decidePendingAction(decision) {
  const actionId = ui.pendingActionPanel?.dataset.actionId || "";
  if (!actionId) return;
  const button = decision === "confirm" ? ui.pendingActionConfirm : ui.pendingActionCancel;
  if (button) button.disabled = true;
  try {
    const requestOptions = {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Jarvis-Client": CLIENT_HEADER},
      body: decision === "confirm" ? JSON.stringify({response_mode: ui.responseMode.value, user_text: "Confirmed from the Pending Action card.", session_id: clientSessionId || "controls"}) : undefined,
    };
    const response = decision === "confirm"
      ? await permissionAwareFetch(`/api/actions/${encodeURIComponent(actionId)}/confirm`, requestOptions)
      : await fetch(`/api/actions/${encodeURIComponent(actionId)}/cancel`, requestOptions);
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Action ${decision} failed (${response.status})`);
    if (decision === "confirm") applyConnectedActionUsage(payload);
    ui.connectedAppsMessage.textContent = payload.display_text || payload.spoken_text || (decision === "confirm" ? "Action completed." : "Action cancelled.");
    renderPendingAction(null);
    await loadConnectedActionAuditState();
  } catch (error) {
    ui.connectedAppsMessage.textContent = error.message || "Pending action update failed.";
  } finally {
    if (button) button.disabled = false;
  }
}

async function connectGoogleAccount() {
  if (!ui.googleConnectButton) return;
  ui.googleConnectButton.disabled = true;
  ui.connectedAppsMessage.textContent = "Opening Google's secure sign-in page…";
  try {
    const response = await fetch("/api/integrations/google/connect", {
      method: "POST",
      headers: {"X-Jarvis-Client": CLIENT_HEADER},
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Google connection failed (${response.status})`);
    ui.connectedAppsMessage.textContent = "Finish signing in in your browser. Jarvis will detect the connection automatically.";
    window.clearInterval(googleConnectionPollTimer);
    let attempts = 0;
    googleConnectionPollTimer = window.setInterval(async () => {
      attempts += 1;
      const latest = await loadGoogleConnectionStatus({validate: false});
      if (latest?.google?.connected || attempts >= 60) {
        window.clearInterval(googleConnectionPollTimer);
        googleConnectionPollTimer = null;
        ui.connectedAppsMessage.textContent = latest?.google?.connected
          ? "Google is connected. Gmail and Calendar actions are ready."
          : "Sign-in is still pending. Use Refresh after completing it.";
      }
    }, 2000);
  } catch (error) {
    ui.connectedAppsMessage.textContent = error.message;
  } finally {
    ui.googleConnectButton.disabled = false;
  }
}

async function disconnectGoogleAccount() {
  if (!ui.googleDisconnectButton || !window.confirm("Disconnect Google from Jarvis on this device?")) return;
  ui.googleDisconnectButton.disabled = true;
  try {
    const response = await fetch("/api/integrations/google/disconnect", {
      method: "POST",
      headers: {"X-Jarvis-Client": CLIENT_HEADER},
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Google disconnect failed (${response.status})`);
    connectedActionPending = false;
    ui.connectedAppsMessage.textContent = "Google was disconnected and the local token was removed.";
    await loadGoogleConnectionStatus();
  } catch (error) {
    ui.connectedAppsMessage.textContent = error.message;
  } finally {
    ui.googleDisconnectButton.disabled = false;
  }
}


function compactIdentity(value) {
  const text = String(value || "");
  if (!text) return "—";
  return text.length <= 22 ? text : `${text.slice(0, 12)}…${text.slice(-6)}`;
}

function renderAccountGate(state = {}) {
  const gated = !accountReady;
  document.body.classList.toggle("account-gated", gated);
  if (ui.accountGate) ui.accountGate.hidden = !gated;
  if (!gated) {
    if (ui.accountGateStatus) ui.accountGateStatus.textContent = "";
    return;
  }
  const binding = state.installation || {};
  const signedIn = Boolean(state.signed_in);
  const verified = Boolean(state.account?.verified);
  const connected = Boolean(state.cloud_sync?.connected);
  if (ui.accountGateTitle) {
    ui.accountGateTitle.textContent = binding.bound
      ? "Connect your Jarvis account"
      : "Sign in to continue";
  }
  if (ui.accountGateDetail) {
    ui.accountGateDetail.textContent = binding.bound
      ? `Existing Jarvis data is linked to ${binding.bound_display_name || "this installation"}. Create an online account to upgrade it, or sign in to the matching cloud account.`
      : "Jarvis is an online service. Create or sign in to your verified account to unlock this device.";
    if (signedIn && !verified) ui.accountGateDetail.textContent = "Finish account verification in your browser to unlock Jarvis.";
    if (signedIn && verified && !connected) ui.accountGateDetail.textContent = "Reconnect this device to your Jarvis cloud account to continue.";
  }
}

function savePendingBrowserAuth(value) {
  pendingBrowserAuthEphemeral = value?.attempt_id && value?.poll_token
    ? {attempt_id: String(value.attempt_id), poll_token: String(value.poll_token)}
    : null;
  // Browser auth poll capabilities are single-purpose bearer secrets. Never persist
  // them in Web Storage; also erase any legacy 0.3.5/early-0.3.6 value.
  try { sessionStorage.removeItem(BROWSER_AUTH_STATE_KEY); } catch (_) {}
}

function loadPendingBrowserAuth() {
  try { sessionStorage.removeItem(BROWSER_AUTH_STATE_KEY); } catch (_) {}
  return pendingBrowserAuthEphemeral ? {...pendingBrowserAuthEphemeral} : null;
}

function stopBrowserAuthPolling() {
  if (browserAuthPollTimer) window.clearTimeout(browserAuthPollTimer);
  browserAuthPollTimer = null;
}

async function pollBrowserAccountAuth(pending) {
  stopBrowserAuthPolling();
  if (!pending?.attempt_id || !pending?.poll_token) return;
  try {
    const query = new URLSearchParams({attempt_id: pending.attempt_id, poll_token: pending.poll_token});
    const state = await accountFetch(`/api/account/web-auth/status?${query.toString()}`);
    if (ui.accountGateStatus) ui.accountGateStatus.textContent = state.message || "Complete authentication in your browser.";
    if (state.ready) {
      const status = await accountFetch("/api/account/web-auth/complete", {
        method: "POST",
        payload: {attempt_id: pending.attempt_id, poll_token: pending.poll_token},
      });
      savePendingBrowserAuth(null);
      renderAccountStatus(status);
      if (accountReady) {
        setActiveWorkspaceView("home", {force: true});
        if (ui.accountMessage) ui.accountMessage.textContent = "Account connected through your browser.";
      }
      return;
    }
    browserAuthPollTimer = window.setTimeout(() => void pollBrowserAccountAuth(pending), 800);
  } catch (error) {
    savePendingBrowserAuth(null);
    if (ui.accountGateStatus) ui.accountGateStatus.textContent = error.message;
  }
}

async function beginBrowserAccountAuth(mode = "signin") {
  if (ui.accountGateStatus) ui.accountGateStatus.textContent = "Opening secure browser authentication…";
  try {
    const query = new URLSearchParams({mode});
    const pending = await accountFetch(`/api/account/web-auth/start?${query.toString()}`, {method: "POST"});
    savePendingBrowserAuth(pending);
    if (typeof window.jarvisDesktop?.openExternal !== "function") throw new Error("Browser authentication is unavailable in this desktop build.");
    await window.jarvisDesktop.openExternal(pending.authorization_url);
    if (ui.accountGateStatus) ui.accountGateStatus.textContent = "Finish authentication in your browser. Jarvis will unlock automatically.";
    void pollBrowserAccountAuth(pending);
  } catch (error) {
    savePendingBrowserAuth(null);
    if (ui.accountGateStatus) ui.accountGateStatus.textContent = error.message;
    if (ui.accountMessage) ui.accountMessage.textContent = error.message;
  }
}

function formatAccountDate(value) {
  if (!value) return "—";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return String(value);
  return parsed.toLocaleString([], {dateStyle: "medium", timeStyle: "short"});
}

function renderAccountStatus(status) {
  const state = status || {};
  accountStatusState = state;
  const wasReady = accountReady;
  const signedIn = Boolean(state.signed_in && state.account && state.tenant && state.session);
  const verified = Boolean(signedIn && state.account?.verified);
  const cloudConnected = Boolean(state.cloud_sync?.connected);
  accountReady = Boolean(signedIn && verified && cloudConnected);
  renderAccountGate(state);
  if (ui.accountStatusBadge) {
    ui.accountStatusBadge.textContent = accountReady
      ? "Ready"
      : (signedIn ? (verified ? "Cloud sign-in required" : "Verification required") : (state.installation?.bound ? "Sign-in required" : "Account required"));
  }
  if (ui.accountSignedOutPanel) ui.accountSignedOutPanel.hidden = signedIn;
  if (ui.accountSignedInPanel) ui.accountSignedInPanel.hidden = !signedIn;
  if (ui.accountBillingPanel) ui.accountBillingPanel.hidden = !signedIn;
  if (ui.accountCloudSyncPanel) ui.accountCloudSyncPanel.hidden = !signedIn;
  const binding = state.installation || {};
  if (ui.accountBindingNotice) {
    ui.accountBindingNotice.textContent = binding.bound
      ? `This installation is linked to ${binding.bound_display_name || "an account"}. Sign in with that account to continue.`
      : "Create a Jarvis account with a verified email address or phone number. Normal assistant features stay locked until verification is complete.";
  }
  if (!signedIn) {
    stopWakeListening({disable: true});
    updateConnectedControls("sleeping");
    setConversationFocus(false);
    return;
  }
  const account = state.account || {};
  const tenant = state.tenant || {};
  const device = state.device || {};
  const session = state.session || {};
  if (ui.accountDisplayName) ui.accountDisplayName.textContent = account.display_name || "Jarvis account";
  if (ui.accountEmail) {
    const contacts = [account.email, account.phone].filter(Boolean);
    ui.accountEmail.textContent = contacts.join(" · ") || "—";
  }
  if (ui.accountTenantName) ui.accountTenantName.textContent = tenant.display_name || "—";
  if (ui.accountId) { ui.accountId.textContent = compactIdentity(account.id); ui.accountId.title = account.id || ""; }
  if (ui.accountTenantId) { ui.accountTenantId.textContent = compactIdentity(tenant.id); ui.accountTenantId.title = tenant.id || ""; }
  if (ui.accountDeviceLabel) ui.accountDeviceLabel.textContent = device.label || "This device";
  if (ui.accountSessionExpiry) ui.accountSessionExpiry.textContent = formatAccountDate(session.expires_at);
  if (ui.accountDataNamespace) ui.accountDataNamespace.textContent = binding.data_namespace || "local-default";
  if (ui.accountVerificationStatus) ui.accountVerificationStatus.textContent = verified ? "Verified" : "Required";
  if (ui.accountCloudStatus) ui.accountCloudStatus.textContent = cloudConnected ? (state.cloud_sync?.enabled ? "Connected · Sync on" : "Connected") : (state.cloud_sync?.available ? "Sign-in required" : "Service unavailable");
  if (ui.accountProfileName) ui.accountProfileName.value = account.display_name || "";
  if (!accountReady) {
    if (isConnected()) void sleepJarvis("account_not_ready");
    stopWakeListening({disable: true});
    updateConnectedControls("sleeping");
    setConversationFocus(false);
    ui.configurationMessage.textContent = verified
      ? "Reconnect this device to your online Jarvis account to continue."
      : "Verify your Jarvis account before using the assistant.";
  } else if (!isConnected() && !connectPromise) {
    updateConnectedControls("sleeping");
    if (config) armWakeListening();
  }
  if (signedIn && cloudConnected) void refreshAccountBilling();
  else renderAccountBilling(null);
  if (!wasReady && accountReady) setActiveWorkspaceView("home", {force: true});
}

async function accountFetch(path, {method = "GET", payload = null} = {}) {
  const options = {method, cache: "no-store", headers: {"X-Jarvis-Client": CLIENT_HEADER}};
  if (payload !== null) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(payload);
  }
  const response = await fetch(path, options);
  let body = null;
  try { body = await response.json(); } catch (_) { body = null; }
  if (!response.ok) throw new Error(body?.detail || `Account request failed (${response.status}).`);
  return body || {};
}

async function refreshAccountStatus() {
  try {
    const status = await accountFetch("/api/account/status");
    renderAccountStatus(status);
    if (status?.signed_in) void refreshCloudSyncStatus();
    return status;
  } catch (error) {
    if (ui.accountStatusBadge) ui.accountStatusBadge.textContent = "Unavailable";
    if (ui.accountMessage) ui.accountMessage.textContent = error.message;
    return null;
  }
}

function renderAccountBilling(summary) {
  const state = summary && typeof summary === "object" ? summary : null;
  const plan = state?.plan || {};
  const subscription = state?.subscription || {};
  const usage = state?.monthly_usage || {};
  const extra = state?.additional_usage || {};
  const devices = state?.devices || {};
  if (ui.accountPlanName) ui.accountPlanName.textContent = state ? (plan.display_name || "—") : "—";
  if (ui.accountSubscriptionStatus) ui.accountSubscriptionStatus.textContent = state ? (subscription.status || "—") : "—";
  if (ui.accountMonthlyUsage) ui.accountMonthlyUsage.textContent = state ? `${Number(usage.percent || 0).toFixed(1)}%` : "—";
  if (ui.accountBillingReset) ui.accountBillingReset.textContent = state ? formatAccountDate(subscription.reset_or_renewal_at) : "—";
  if (ui.accountAdditionalUsage) ui.accountAdditionalUsage.textContent = state ? (extra.status === "available" ? "Available" : "None") : "—";
  if (ui.accountDeviceAllowance) ui.accountDeviceAllowance.textContent = state ? `${Number(devices.active || 0)} of ${Number(devices.allowed || 0)}` : "—";
  if (ui.accountBillingBadge) ui.accountBillingBadge.textContent = state ? (usage.exhausted ? "Included usage exhausted" : "Cloud verified") : "Unavailable";
  if (ui.accountBillingMessage) {
    ui.accountBillingMessage.textContent = state
      ? "Jarvis Cloud is authoritative for plan access, included usage, additional usage, and device allowance."
      : "Billing status is unavailable until this device is connected to Jarvis Cloud.";
  }
}

async function refreshAccountBilling() {
  try {
    const summary = await accountFetch("/api/account/billing");
    renderAccountBilling(summary);
    return summary;
  } catch (error) {
    renderAccountBilling(null);
    if (ui.accountBillingMessage) ui.accountBillingMessage.textContent = error.message;
    return null;
  }
}

function renderCloudSyncStatus(status) {
  const state = status || {};
  const policies = new Map((state.policies || []).map((item) => [String(item.scope || ""), item]));
  const available = Boolean(state.available);
  const connected = Boolean(state.connected);
  const enabled = Boolean(state.enabled);
  const verification = state.verification || null;
  if (ui.accountCloudBadge) ui.accountCloudBadge.textContent = enabled ? "On" : (connected ? "Connected · Paused" : (verification ? "Verification required" : (available ? "Not connected" : "Unavailable")));
  if (ui.accountCloudMessage) ui.accountCloudMessage.textContent = state.message || "Jarvis Cloud account status.";
  if (ui.accountCloudEnabled) {
    ui.accountCloudEnabled.checked = enabled;
    ui.accountCloudEnabled.disabled = !available || !connected;
  }
  if (ui.accountCloudTasks) {
    ui.accountCloudTasks.checked = Boolean(policies.get("tasks")?.enabled);
    ui.accountCloudTasks.disabled = !available || !connected;
  }
  if (ui.accountCloudMemory) {
    ui.accountCloudMemory.checked = false;
    ui.accountCloudMemory.disabled = true;
  }
  const run = state.last_run || null;
  if (ui.accountCloudLastSync) ui.accountCloudLastSync.textContent = run?.completed_at ? formatAccountDate(run.completed_at) : "Never";
  if (ui.accountCloudConflicts) ui.accountCloudConflicts.textContent = String(state.open_conflicts || 0);
  if (ui.accountCloudTransport) {
    const transport = String(state.service?.transport || "");
    ui.accountCloudTransport.textContent = transport === "development_local_vault" ? "Development relay" : (transport === "https" ? "Jarvis Cloud" : "—");
  }
  if (ui.accountCloudSyncNow) ui.accountCloudSyncNow.disabled = !available || !connected || !enabled;
}

function renderAccountDevices(devices) {
  if (!ui.accountDeviceList) return;
  const rows = Array.isArray(devices) ? devices : [];
  if (!rows.length) {
    ui.accountDeviceList.innerHTML = '<p class="field-help">No authorized cloud devices are available yet.</p>';
    return;
  }
  ui.accountDeviceList.replaceChildren(...rows.map((device) => {
    const row = document.createElement("div");
    row.className = `account-device-row${String(device.status || "active") === "revoked" ? " revoked" : ""}`;
    const copy = document.createElement("div");
    copy.className = "device-copy";
    const title = document.createElement("strong");
    title.textContent = `${device.label || "Jarvis device"}${device.current ? " · This device" : ""}`;
    const detail = document.createElement("small");
    detail.textContent = `${String(device.status || "active")} · Last seen ${formatAccountDate(device.last_seen_at)}`;
    copy.append(title, detail);
    row.append(copy);
    if (!device.current && String(device.status || "active") !== "revoked") {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "danger compact";
      button.textContent = "Revoke";
      button.addEventListener("click", async () => {
        if (!window.confirm(`Revoke ${device.label || "this device"}? It will lose access to Jarvis Cloud.`)) return;
        button.disabled = true;
        try {
          const result = await accountFetch(`/api/account/devices/${encodeURIComponent(device.id)}/revoke`, {method: "POST"});
          renderAccountDevices(result.devices || []);
        } catch (error) {
          if (ui.accountCloudMessage) ui.accountCloudMessage.textContent = error.message;
        } finally { button.disabled = false; }
      });
      row.append(button);
    }
    return row;
  }));
}

async function refreshAccountDevices() {
  if (!ui.accountDeviceList || !accountStatusState?.cloud_sync?.connected) {
    renderAccountDevices([]);
    return [];
  }
  try {
    const payload = await accountFetch("/api/account/devices");
    renderAccountDevices(payload.devices || []);
    return payload.devices || [];
  } catch (error) {
    ui.accountDeviceList.innerHTML = `<p class="field-help">${escapeHtml(error.message)}</p>`;
    return [];
  }
}

async function refreshCloudSyncStatus() {
  try {
    const status = await accountFetch("/api/sync/status");
    renderCloudSyncStatus(status);
    if (status?.connected) void refreshAccountDevices();
    else renderAccountDevices([]);
    return status;
  } catch (error) {
    if (ui.accountCloudMessage) ui.accountCloudMessage.textContent = error.message;
    return null;
  }
}

async function setCloudSyncEnabled() {
  if (!ui.accountCloudEnabled) return;
  const requested = Boolean(ui.accountCloudEnabled.checked);
  ui.accountCloudEnabled.disabled = true;
  try {
    const status = await accountFetch("/api/sync/enabled", {method: "PATCH", payload: {enabled: requested}});
    renderCloudSyncStatus(status);
  } catch (error) {
    ui.accountCloudEnabled.checked = !requested;
    if (ui.accountCloudMessage) ui.accountCloudMessage.textContent = error.message;
  } finally {
    ui.accountCloudEnabled.disabled = false;
  }
}

async function setCloudSyncScope(scope, enabled) {
  try {
    const status = await accountFetch(`/api/sync/scopes/${encodeURIComponent(scope)}`, {method: "PATCH", payload: {enabled}});
    renderCloudSyncStatus(status);
  } catch (error) {
    if (ui.accountCloudMessage) ui.accountCloudMessage.textContent = error.message;
    await refreshCloudSyncStatus();
  }
}

async function runCloudSyncNow() {
  if (!ui.accountCloudSyncNow) return;
  ui.accountCloudSyncNow.disabled = true;
  if (ui.accountCloudMessage) ui.accountCloudMessage.textContent = "Syncing approved local data…";
  try {
    const status = await accountFetch("/api/sync/run", {method: "POST"});
    renderCloudSyncStatus(status);
    const result = status.sync_result || {};
    if (ui.accountCloudMessage) {
      ui.accountCloudMessage.textContent = `Sync complete: ${Number(result.pushed || 0)} pushed, ${Number(result.pulled || 0)} merged, ${Number(result.conflicts || 0)} conflicts.`;
    }
    void loadTaskDashboard();
    if (config?.memory_enabled) {
      fetch("/api/memory/stats", {cache: "no-store"}).then((response) => response.ok ? response.json() : null).then((stats) => { if (stats) renderMemoryStats(stats); }).catch(() => {});
    }
  } catch (error) {
    if (ui.accountCloudMessage) ui.accountCloudMessage.textContent = error.message;
  } finally {
    await refreshCloudSyncStatus();
  }
}

async function submitAccountProfile(event) {
  event.preventDefault();
  if (!ui.accountProfileSave) return;
  ui.accountProfileSave.disabled = true;
  try {
    const status = await accountFetch("/api/account/profile", {
      method: "PATCH",
      payload: {display_name: ui.accountProfileName?.value || ""},
    });
    if (ui.accountProfileMessage) ui.accountProfileMessage.textContent = "Display name saved.";
    renderAccountStatus(status);
  } catch (error) {
    if (ui.accountProfileMessage) ui.accountProfileMessage.textContent = error.message;
  } finally {
    ui.accountProfileSave.disabled = false;
  }
}

async function logoutAccount() {
  if (!ui.accountLogoutButton) return;
  ui.accountLogoutButton.disabled = true;
  try {
    const status = await accountFetch("/api/account/logout", {method: "POST"});
    if (ui.accountMessage) ui.accountMessage.textContent = "Signed out. Your local data and installation binding were preserved.";
    renderAccountStatus(status);
  } catch (error) {
    if (ui.accountProfileMessage) ui.accountProfileMessage.textContent = error.message;
  } finally {
    ui.accountLogoutButton.disabled = false;
  }
}

async function initialize() {
  initializeInterfaceFoundation();
  try {
    config = await fetch("/api/config", {cache: "no-store"}).then((response) => response.json());
    configureProviderModeUi();
    ui.version.textContent = config.version;
    ui.model.textContent = config.model;
    const initialAccountStatus = await refreshAccountStatus();
    const pendingBrowserAuth = loadPendingBrowserAuth();
    if (pendingBrowserAuth) void pollBrowserAccountAuth(pendingBrowserAuth);
    if (config.memory_enabled && initialAccountStatus?.signed_in) {
      fetch("/api/memory/stats", {cache: "no-store"})
        .then((response) => response.ok ? response.json() : null)
        .then((stats) => { if (stats) renderMemoryStats(stats); })
        .catch((error) => logEvent("memory.stats.failed", error.message));
    } else if (ui.memoryHealthBadge) {
      ui.memoryHealthBadge.textContent = "Disabled";
    }
    if (config.memory_proactive_enabled) {
      window.clearInterval(proactivePollTimer);
      proactivePollTimer = window.setInterval(() => {
        fetch("/api/memory/stats", {cache: "no-store"})
          .then((response) => response.ok ? response.json() : null)
          .then((stats) => { if (stats) renderMemoryStats(stats); })
          .catch(() => {});
        if (memoryExplorerMode === "proactive" && document.querySelector('[data-view="memory"]')?.classList.contains("active")) {
          void loadMemoryProactive();
        }
      }, Math.max(60000, Number(config.memory_proactive_interval_minutes || 5) * 60000));
    }
    ui.wakeKeyword.textContent = config.wake_keyword || "jarvis";
    if (ui.actionPlannerModel) ui.actionPlannerModel.textContent = config.action_model || "—";
    void loadGoogleConnectionStatus();
    void loadConnectedActionAuditState();
    void loadTaskDashboard();
    startTaskReminderPolling();
    startGameModePolling();
    const preferences = loadPreferences();
    config.voices.forEach((voice) => ui.voice.add(new Option(voice, voice)));
    const turnDetectionLabels = {
      provider_default: "Provider default (recommended)",
      semantic_auto: "Semantic — auto",
      semantic_low: "Semantic — low (longer pauses)",
      semantic_medium: "Semantic — medium",
      semantic_high: "Semantic — high (faster)",
    };
    const responseModeLabels = {
      test: "Test",
      short: "Short",
      normal: "Normal",
      high: "High",
      full: "Full",
    };
    const responseModeLabel = (value) => {
      const profile = config.response_mode_profiles?.[value] || {};
      const words = Number(profile.max_words || 0);
      const sentences = Number(profile.max_sentences || 0);
      if (value === "full") return "Full — complete detail, no fixed cap";
      const parts = [];
      if (sentences > 0) parts.push(`≤${sentences} sentence${sentences === 1 ? "" : "s"}`);
      if (words > 0) parts.push(`≤${words} words`);
      return `${responseModeLabels[value] || value} — ${parts.join(" / ") || "adaptive"}`;
    };
    const wakeProfileLabels = {
      fast: "Fast — lowest latency",
      balanced: "Balanced — recommended",
      strict: "Strict — noisy room",
    };
    const voicePersonalityLabels = {
      classic: "Classic — composed & natural",
      casual: "Casual — relaxed",
      warm: "Warm — friendly",
      direct: "Direct — concise",
      witty: "Witty — subtle humor",
    };
    config.turn_detection_profiles.forEach((value) => {
      ui.turnDetection.add(new Option(turnDetectionLabels[value] || value, value));
    });
    config.response_modes.forEach((value) => {
      ui.responseMode.add(new Option(responseModeLabel(value), value));
    });
    config.wake_profiles.forEach((value) => {
      ui.wakeProfile.add(new Option(wakeProfileLabels[value] || value, value));
    });
    (config.voice_personalities || ["classic"]).forEach((value) => {
      ui.voicePersonality?.add(new Option(voicePersonalityLabels[value] || value, value));
    });
    const speechProviderLabels = {
      "jarvis-cloud": "Jarvis Cloud — authorized voice",
      openai: "OpenAI — development",
      elevenlabs: "ElevenLabs — development",
    };
    (config.speech_providers || ["openai"]).forEach((value) => {
      if (!ui.speechProvider) return;
      const ready = config.speech_provider_ready?.[value] !== false;
      const option = new Option(
        `${speechProviderLabels[value] || value}${ready ? "" : " — not configured"}`,
        value,
      );
      option.disabled = !ready;
      ui.speechProvider.add(option);
    });
    if (!config.simulation_enabled) {
      [...ui.connectionMode.options].find((option) => option.value === "simulation")?.remove();
    }
    ui.voice.value = config.voices.includes(preferences.voice) ? preferences.voice : config.default_voice;
    ui.turnDetection.value = config.turn_detection_profiles.includes(preferences.turnDetection)
      ? preferences.turnDetection : config.default_turn_detection_profile;
    ui.responseMode.value = config.response_modes.includes(preferences.responseMode)
      ? preferences.responseMode : config.default_response_mode;
    ui.wakeProfile.value = config.wake_profiles.includes(preferences.wakeProfile)
      ? preferences.wakeProfile : config.default_wake_profile;
    if (ui.voicePersonality) {
      ui.voicePersonality.value = (config.voice_personalities || []).includes(preferences.voicePersonality)
        ? preferences.voicePersonality : (config.voice_personality || "classic");
    }
    if (ui.speechProvider) {
      const preferredSpeechProvider = normalizeNaturalText(preferences.speechProvider || config.speech_provider || "openai").toLowerCase();
      const preferredOption = [...ui.speechProvider.options].find((option) => option.value === preferredSpeechProvider && !option.disabled);
      const firstReadySpeechProvider = [...ui.speechProvider.options].find((option) => !option.disabled)?.value || "";
      ui.speechProvider.value = preferredOption ? preferredSpeechProvider : firstReadySpeechProvider;
    }
    ui.connectionMode.value = [...ui.connectionMode.options].some((option) => option.value === preferences.connectionMode)
      ? preferences.connectionMode : "live";
    void prewarmProviderConnections();
    ui.testAutoSleep.checked = typeof preferences.testAutoSleep === "boolean"
      ? preferences.testAutoSleep : Boolean(config.test_auto_sleep);
    if (!providerReadyForLive() && ui.connectionMode.value === "live") {
      ui.configurationMessage.textContent = isHostedProviderMode()
        ? "Sign in to your verified Jarvis account so Jarvis Cloud can authorize hosted services."
        : "Development provider access is not configured. Add the development key or use simulation.";
      ui.wakeListenerStatus.textContent = isHostedProviderMode() ? "Cloud sign-in required" : "Simulation available";
    }
    setStatus("Sleeping", "sleeping");
    updateConnectedControls("sleeping");
    await refreshDevices(false);
    await refreshUsageSummary();
    updateUsageMetrics();
    await initializeDesktopPresence();
    const alphaSetup = await initializeAlphaSetup();
    if (!alphaSetup.required && accountReady) armWakeListening();
    if (!accountReady) {
      setConversationFocus(false);
      ui.wakeListenerStatus.textContent = "Verified account required";
      ui.configurationMessage.textContent = "Create or sign in to your Jarvis account in the browser to use the assistant.";
    }
  } catch (error) {
    setStatus("Core unavailable", "error");
    ui.configurationMessage.textContent = error.message;
    ui.wakeListenerStatus.textContent = "Unavailable";
  }
}

ui.wake.addEventListener("click", () => connect({automatic: false}));
ui.sleep.addEventListener("click", () => sleepJarvis("manual"));
ui.stopSpeaking.addEventListener("click", () => interruptResponse("manual", true));
ui.refreshDevices.addEventListener("click", async () => {
  await refreshDevices(true);
  if (!isConnected() && !connectPromise) armWakeListening();
});
ui.speaker.addEventListener("change", applySpeaker);
ui.voice.addEventListener("change", savePreferences);
ui.turnDetection.addEventListener("change", savePreferences);
ui.wakeProfile.addEventListener("change", async () => {
  savePreferences();
  if (!isConnected() && !connectPromise) {
    await stopWakeListening();
    armWakeListening();
  }
});
ui.responseMode.addEventListener("change", async () => {
  savePreferences();
  updateConnectedControls(isConnected() ? "awake" : "sleeping");
  try {
    await refreshRealtimeProfile({apply: isConnected() && !isSimulationMode()});
    ui.configurationMessage.textContent = isConnected()
      ? `${ui.responseMode.options[ui.responseMode.selectedIndex]?.text || ui.responseMode.value} response mode is active now.`
      : "Response mode saved for the next session.";
  } catch (error) {
    ui.configurationMessage.textContent = error.message;
    logEvent("response.profile.failed", error.message);
  }
});
ui.connectionMode.addEventListener("change", () => {
  savePreferences();
  ui.configurationMessage.textContent = isSimulationMode()
    ? "Development simulation avoids provider work."
    : (!providerReadyForLive()
      ? (isHostedProviderMode() ? "Jarvis Cloud authorization is required for live mode." : "Development provider access is missing for live mode.")
      : "");
  stopWakeListening();
  armWakeListening();
  updateConnectedControls("sleeping");
});
ui.testAutoSleep.addEventListener("change", savePreferences);
ui.startWithWindows?.addEventListener("change", async () => {
  try {
    const enabled = await window.jarvisDesktop?.setStartWithWindows?.(ui.startWithWindows.checked);
    if (typeof enabled === "boolean") ui.startWithWindows.checked = enabled;
  } catch (error) {
    ui.startWithWindows.checked = !ui.startWithWindows.checked;
    logEvent("desktop.startup_setting.failed", error.message);
  }
});
ui.desktopNotifications?.addEventListener("change", async () => {
  try {
    const enabled = await window.jarvisDesktop?.setNotifications?.(ui.desktopNotifications.checked);
    if (typeof enabled === "boolean") ui.desktopNotifications.checked = enabled;
  } catch (error) {
    ui.desktopNotifications.checked = !ui.desktopNotifications.checked;
    logEvent("desktop.notification_setting.failed", error.message);
  }
});
ui.restartCore?.addEventListener("click", async () => {
  ui.restartCore.disabled = true;
  ui.configurationMessage.textContent = "Restarting the local Jarvis core…";
  try {
    await sleepJarvis("core_restart");
    await window.jarvisDesktop?.restartCore?.();
  } catch (error) {
    logEvent("desktop.core_restart.failed", error.message);
    ui.configurationMessage.textContent = error.message;
  }
});
ui.microphone.addEventListener("change", savePreferences);
ui.voicePersonality?.addEventListener("change", savePreferences);
ui.speechProvider?.addEventListener("change", () => {
  savePreferences();
  const selected = currentSpeechProvider();
  ui.configurationMessage.textContent = selected === "elevenlabs"
    ? "ElevenLabs is now Jarvis's speech renderer. Luna still owns every word."
    : "OpenAI speech is now Jarvis's speech renderer. Luna still owns every word.";
});
ui.mute.addEventListener("click", () => {
  muted = !muted;
  localStream?.getAudioTracks().forEach((track) => { track.enabled = !muted && !wakeInputGateActive; });
  ui.mute.textContent = muted ? "Unmute" : "Mute";
  logEvent(muted ? "microphone.muted" : "microphone.unmuted");
});
ui.textForm.addEventListener("submit", (event) => {
  event.preventDefault();
  if (typedSubmitInProgress) return;
  const text = ui.textInput.value.trim();
  if (!text) return;
  typedSubmitInProgress = true;
  ui.sendText.disabled = true;
  try {
    sendText(text);
    ui.textInput.value = "";
    resizeComposer();
  } catch (error) {
    ui.configurationMessage.textContent = error.message;
  } finally {
    window.setTimeout(() => {
      typedSubmitInProgress = false;
      updateConnectedControls(isConnected() ? "awake" : "sleeping");
    }, 0);
  }
});
ui.memoryCaptureForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const content = ui.memoryCaptureInput?.value.trim() || "";
  if (!content || ui.memoryCaptureButton.disabled) return;
  ui.memoryCaptureButton.disabled = true;
  if (ui.memoryStatus) ui.memoryStatus.textContent = "Organizing new memory…";
  try {
    const stored = await rememberMemory({
      content,
      source: "typed",
      kind: "fact",
      sourceEventId: `manual_memory:${Date.now()}`,
      metadata: {manual_memory_explorer: true},
    });
    if (stored) {
      ui.memoryCaptureInput.value = "";
      if (ui.memoryStatus) ui.memoryStatus.textContent = `Remembered under ${stored.category}.`;
      await loadMemoryDashboard();
    }
  } finally {
    ui.memoryCaptureButton.disabled = false;
  }
});
ui.memorySearchForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  setMemoryExplorerMode("timeline");
  void loadMemoryDashboard();
});
ui.taskRefreshButton?.addEventListener("click", () => loadTaskDashboard());
ui.homeTaskCard?.addEventListener("click", () => {
  setConversationFocus(false);
  setActiveWorkspaceView("tasks", {force: true});
});
ui.memoryRefreshButton?.addEventListener("click", () => loadMemoryDashboard());
ui.memoryClearFilters?.addEventListener("click", () => {
  resetMemoryExplorerFilters();
  setMemoryExplorerMode("timeline");
  void loadMemoryDashboard();
});
for (const filter of [ui.memoryCategoryFilter, ui.memoryDateFromFilter, ui.memoryDateToFilter, ui.memorySourceFilter, ui.memoryStatusFilter, ui.memoryImportantFilter]) {
  filter?.addEventListener("change", () => loadMemoryDashboard());
}
for (const button of document.querySelectorAll("[data-memory-mode]")) {
  button.addEventListener("click", () => setMemoryExplorerMode(button.dataset.memoryMode));
}
ui.memoryEntitySearchForm?.addEventListener("submit", (event) => { event.preventDefault(); void loadMemoryEntities(); });
ui.memoryPeopleSearchForm?.addEventListener("submit", (event) => { event.preventDefault(); void loadMemoryPeople(); });
ui.memoryAppSearchForm?.addEventListener("submit", (event) => { event.preventDefault(); void loadMemoryApps(); });
ui.memoryAppRefreshButton?.addEventListener("click", () => loadMemoryApps());
ui.voiceProfilePersonSelect?.addEventListener("change", () => renderVoiceEnrollmentGuide(ui.voiceProfilePersonSelect.value));
ui.voiceProfileUploadButton?.addEventListener("click", () => {
  if (!ui.voiceProfilePersonSelect?.value) { ui.voiceProfileStatus.textContent = "Choose a person profile first."; return; }
  ui.voiceProfileFileInput?.click();
});
ui.voiceProfileFileInput?.addEventListener("change", async () => {
  const file = ui.voiceProfileFileInput.files?.[0];
  if (!file) return;
  try { await uploadVoiceSample(ui.voiceProfilePersonSelect.value, file, file.name); }
  catch (error) { if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = error.message; }
  finally { ui.voiceProfileFileInput.value = ""; }
});
ui.voiceProfileRecordButton?.addEventListener("click", () => {
  recordVoiceProfileSample().catch((error) => { if (ui.voiceProfileStatus) ui.voiceProfileStatus.textContent = error.message; });
});
ui.memorySummaryDate?.addEventListener("change", loadMemorySummary);
ui.memoryDetailClose?.addEventListener("click", closeMemoryDetail);
ui.memoryDetailOverlay?.addEventListener("click", (event) => { if (event.target === ui.memoryDetailOverlay) closeMemoryDetail(); });
ui.messageReaderClose?.addEventListener("click", closeMessageReader);
ui.messageReaderOverlay?.addEventListener("click", (event) => { if (event.target === ui.messageReaderOverlay) closeMessageReader(); });
ui.memoryUndoButton?.addEventListener("click", undoMemoryChange);
ui.memoryExportJson?.addEventListener("click", () => exportMemory("json"));
ui.memoryExportMarkdown?.addEventListener("click", () => exportMemory("markdown"));
ui.memoryConsolidateButton?.addEventListener("click", runMemoryConsolidation);
ui.memoryProactiveRefreshButton?.addEventListener("click", () => refreshMemoryProactive());
ui.memoryProactiveStatusFilter?.addEventListener("change", loadMemoryProactive);
ui.memoryProactivePriorityFilter?.addEventListener("input", () => {
  if (ui.memoryProactivePriorityOutput) ui.memoryProactivePriorityOutput.value = Number(ui.memoryProactivePriorityFilter.value || 0).toFixed(2);
});
ui.memoryProactivePriorityFilter?.addEventListener("change", loadMemoryProactive);
ui.homeProactiveCard?.addEventListener("click", () => {
  setConversationFocus(false);
  setActiveWorkspaceView("memory", {force: true});
  setMemoryExplorerMode("proactive");
});
ui.accountGateCreate?.addEventListener("click", () => void beginBrowserAccountAuth("signup"));
ui.accountGateSignIn?.addEventListener("click", () => void beginBrowserAccountAuth("signin"));
ui.accountGateRecovery?.addEventListener("click", () => void beginBrowserAccountAuth("recovery"));
ui.accountBrowserCreate?.addEventListener("click", () => void beginBrowserAccountAuth("signup"));
ui.accountBrowserSignIn?.addEventListener("click", () => void beginBrowserAccountAuth("signin"));
ui.accountBrowserRecovery?.addEventListener("click", () => void beginBrowserAccountAuth("recovery"));
ui.accountManageButton?.addEventListener("click", () => void beginBrowserAccountAuth("recovery"));
ui.accountProfileForm?.addEventListener("submit", submitAccountProfile);
ui.accountLogoutButton?.addEventListener("click", () => void logoutAccount());
ui.accountCloudEnabled?.addEventListener("change", () => void setCloudSyncEnabled());
ui.accountCloudTasks?.addEventListener("change", () => void setCloudSyncScope("tasks", Boolean(ui.accountCloudTasks?.checked)));

ui.accountCloudSyncNow?.addEventListener("click", () => void runCloudSyncNow());
ui.accountCloudRefresh?.addEventListener("click", () => void refreshCloudSyncStatus());
ui.accountDeviceRefresh?.addEventListener("click", () => void refreshAccountDevices());
ui.firstRunForm?.addEventListener("submit", submitAlphaSetup);
ui.setupCancel?.addEventListener("click", hideSetupOverlay);
ui.openSetup?.addEventListener("click", async () => {
  await refreshAlphaStatus();
  showSetupOverlay({required: !alphaSetupStatus?.configured});
});
ui.exportDiagnostics?.addEventListener("click", async () => {
  ui.exportDiagnostics.disabled = true;
  try {
    const result = await window.jarvisDesktop?.exportDiagnostics?.();
    ui.alphaUpdateStatus.textContent = result?.canceled ? "Diagnostic export canceled." : `Diagnostics saved to ${result?.path || "the selected file"}.`;
  } catch (error) {
    ui.alphaUpdateStatus.textContent = `Diagnostic export failed: ${error.message}`;
  } finally { ui.exportDiagnostics.disabled = false; }
});
ui.checkUpdates?.addEventListener("click", async () => {
  ui.checkUpdates.disabled = true;
  ui.alphaUpdateStatus.textContent = "Checking GitHub releases…";
  try {
    const result = await window.jarvisDesktop?.checkForUpdates?.();
    if (!result?.ok) throw new Error(result?.message || "Update check failed");
    pendingReleaseUrl = result.releaseUrl || "";
    ui.openRelease.hidden = !result.updateAvailable;
    ui.alphaUpdateStatus.textContent = result.updateAvailable
      ? `Version ${result.latest} is available.`
      : `Jarvis ${result.current} is the latest available release.`;
  } catch (error) {
    ui.openRelease.hidden = true;
    ui.alphaUpdateStatus.textContent = `Update check failed: ${error.message}`;
  } finally { ui.checkUpdates.disabled = false; }
});
ui.openRelease?.addEventListener("click", () => window.jarvisDesktop?.openRelease?.(pendingReleaseUrl));
ui.pendingActionReview?.addEventListener("click", () => { if (ui.pendingActionDetails) ui.pendingActionDetails.hidden = !ui.pendingActionDetails.hidden; });
ui.pendingActionEdit?.addEventListener("click", () => { if (ui.textInput) { ui.textInput.focus(); ui.textInput.placeholder = "Tell Jarvis what to change about the pending action…"; } });
ui.pendingActionConfirm?.addEventListener("click", () => void decidePendingAction("confirm"));
ui.pendingActionCancel?.addEventListener("click", () => void decidePendingAction("cancel"));
ui.googleConnectButton?.addEventListener("click", connectGoogleAccount);
ui.googleDisconnectButton?.addEventListener("click", disconnectGoogleAccount);
ui.refreshConnectedAppsButton?.addEventListener("click", async () => { await loadGoogleConnectionStatus({validate: true}); await loadConnectedActionAuditState(); });
ui.permissionRefreshButton?.addEventListener("click", () => { void loadPermissions(); });
ui.clearEvents.addEventListener("click", () => { ui.events.textContent = ""; });
window.addEventListener("beforeunload", () => {
  window.clearInterval(gameModePollTimer);
  clearInterval(presenceUiTimer);
  clearInterval(googleConnectionPollTimer);
  clearInterval(taskReminderPollTimer);
  abortDetailedCompanion("window_unload");
  intentionalSleep = true;
  stopWakeListening({disable: true});
  stopLifecycleListening({disable: true});
  channel?.close();
  peer?.close();
  localStream?.getTracks().forEach((track) => track.stop());
});
navigator.mediaDevices?.addEventListener?.("devicechange", () => refreshDevices(false));
window.jarvisDesktop?.onCommand?.((command) => {
  if (command === "wake" && !isConnected()) connect({automatic: false});
  if (command === "sleep" && isConnected()) sleepJarvis("desktop_tray");
  if (command === "resume-presence" && !isConnected()) {
    stopWakeListening();
    window.setTimeout(() => armWakeListening(), 250);
  }
});
initialize();
