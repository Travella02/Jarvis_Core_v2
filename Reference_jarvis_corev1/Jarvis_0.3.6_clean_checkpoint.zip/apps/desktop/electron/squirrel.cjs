'use strict';

const {spawn} = require('node:child_process');
const path = require('node:path');

function runUpdate(arguments_) {
  const updateExe = path.resolve(path.dirname(process.execPath), '..', 'Update.exe');
  try {
    spawn(updateExe, arguments_, {detached: true, windowsHide: true, stdio: 'ignore'}).unref();
  } catch (_) {
    // Squirrel events are best effort; setup should still be allowed to finish.
  }
}

function handleSquirrelEvent(argv = process.argv) {
  if (process.platform !== 'win32') return false;
  const event = argv.find((value) => String(value).startsWith('--squirrel-'));
  if (!event) return false;
  const executableName = path.basename(process.execPath);
  if (event === '--squirrel-install' || event === '--squirrel-updated') {
    runUpdate(['--createShortcut', executableName]);
  } else if (event === '--squirrel-uninstall') {
    runUpdate(['--removeShortcut', executableName]);
  }
  return true;
}

module.exports = {handleSquirrelEvent};
