'use strict';

const path = require('node:path');

const DEFAULT_DESKTOP_SETTINGS = Object.freeze({
  startWithWindows: false,
  notificationsEnabled: true,
  launchHiddenAtStartup: true,
});

function boundedInteger(value, fallback, minimum, maximum) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(Math.max(parsed, minimum), maximum);
}

function computeRestartBackoff(attempt, baseMs = 1000, maximumMs = 30000) {
  const safeAttempt = boundedInteger(attempt, 0, 0, 30);
  const safeBase = boundedInteger(baseMs, 1000, 100, 60000);
  const safeMaximum = boundedInteger(maximumMs, 30000, safeBase, 300000);
  return Math.min(safeMaximum, safeBase * (2 ** safeAttempt));
}

function pruneTimestamps(timestamps, now, windowMs) {
  const current = Number.isFinite(now) ? now : Date.now();
  const span = boundedInteger(windowMs, 600000, 1000, 86400000);
  return (Array.isArray(timestamps) ? timestamps : [])
    .filter((value) => Number.isFinite(value) && value >= current - span && value <= current + 1000)
    .sort((left, right) => left - right);
}

function sanitizeDesktopSettings(value) {
  const source = value && typeof value === 'object' ? value : {};
  return {
    startWithWindows: source.startWithWindows === true,
    notificationsEnabled: source.notificationsEnabled !== false,
    launchHiddenAtStartup: source.launchHiddenAtStartup !== false,
  };
}

function windowsLoginItemOptions({ enabled, isPackaged, defaultApp, execPath, appPath, existsSync }) {
  const args = ['--background'];
  let launchPath = execPath;
  if (defaultApp) {
    args.unshift(appPath);
  } else if (isPackaged) {
    const pathApi = /^[A-Za-z]:[\\/]/.test(execPath) ? path.win32 : path;
    const appFolder = pathApi.dirname(execPath);
    const executableName = pathApi.basename(execPath);
    const squirrelStub = pathApi.resolve(appFolder, '..', executableName);
    if (typeof existsSync === 'function' && existsSync(squirrelStub)) launchPath = squirrelStub;
  }
  return {
    openAtLogin: Boolean(enabled),
    path: launchPath,
    args,
  };
}

function safePresenceSnapshot(value) {
  const source = value && typeof value === 'object' ? value : {};
  return {
    supervisorState: String(source.supervisorState || 'unknown'),
    coreState: String(source.coreState || 'unknown'),
    corePid: Number.isInteger(source.corePid) && source.corePid > 0 ? source.corePid : null,
    coreRestarts: boundedInteger(source.coreRestarts, 0, 0, 1000000),
    rendererRecoveries: boundedInteger(source.rendererRecoveries, 0, 0, 1000000),
    heartbeatFailures: boundedInteger(source.heartbeatFailures, 0, 0, 1000),
    lastHeartbeatAt: Number.isFinite(source.lastHeartbeatAt) ? source.lastHeartbeatAt : null,
    appStartedAt: Number.isFinite(source.appStartedAt) ? source.appStartedAt : null,
    coreStartedAt: Number.isFinite(source.coreStartedAt) ? source.coreStartedAt : null,
    startWithWindows: source.startWithWindows === true,
    notificationsEnabled: source.notificationsEnabled !== false,
    launchedInBackground: source.launchedInBackground === true,
    systemSuspended: source.systemSuspended === true,
  };
}

module.exports = {
  DEFAULT_DESKTOP_SETTINGS,
  computeRestartBackoff,
  pruneTimestamps,
  sanitizeDesktopSettings,
  safePresenceSnapshot,
  windowsLoginItemOptions,
};
