$ErrorActionPreference = "Stop"

function Write-JsonLine {
    param([hashtable]$Payload)
    [Console]::Out.WriteLine(($Payload | ConvertTo-Json -Compress -Depth 5))
    [Console]::Out.Flush()
}

function New-PhraseGrammar {
    param(
        [System.Globalization.CultureInfo]$Culture,
        [string]$Name,
        [string[]]$Phrases,
        [int]$Priority = 100,
        [double]$Weight = 1.0,
        [switch]$AppendDictation
    )

    $choices = New-Object System.Speech.Recognition.Choices
    $choices.Add($Phrases)

    $builder = New-Object System.Speech.Recognition.GrammarBuilder
    $builder.Culture = $Culture
    $builder.Append($choices)
    if ($AppendDictation) {
        $builder.AppendDictation()
    }

    $grammar = New-Object System.Speech.Recognition.Grammar -ArgumentList (,$builder)
    $grammar.Name = $Name
    $grammar.Priority = $Priority
    $grammar.Weight = [single]$Weight
    return $grammar
}

$recognizer = $null
try {
    Add-Type -AssemblyName System.Speech

    $recognizers = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()
    $selected = $recognizers | Where-Object { $_.Culture.Name -eq "en-US" } | Select-Object -First 1
    if ($null -eq $selected) {
        $selected = $recognizers | Where-Object { $_.Culture.TwoLetterISOLanguageName -eq "en" } | Select-Object -First 1
    }
    if ($null -eq $selected) {
        throw "No installed English Windows speech recognizer was found."
    }

    $recognizer = New-Object -TypeName System.Speech.Recognition.SpeechRecognitionEngine -ArgumentList (,$selected)

    # A free-form dictation grammar often treats the proper noun "Jarvis" as an
    # unknown word. Explicit high-priority lifecycle grammars make the wake and
    # sleep phrases deterministic, while the lower-weight dictation grammar
    # still provides ordinary follow-up transcripts.
    $wakePrefixes = @(
        "jarvis",
        "hey jarvis",
        "yo jarvis",
        "okay jarvis",
        "ok jarvis"
    )
    $sleepPhrases = @(
        "that's all jarvis",
        "thats all jarvis",
        "that'll be all jarvis",
        "thatll be all jarvis",
        "go to sleep jarvis",
        "jarvis go to sleep",
        "jarvis sleep",
        "you can go back to sleep",
        "never mind jarvis",
        "nevermind jarvis"
    )

    $wakeOnly = New-PhraseGrammar -Culture $selected.Culture -Name "jarvis_wake" -Phrases $wakePrefixes -Priority 120 -Weight 1.0
    $wakeWithRequest = New-PhraseGrammar -Culture $selected.Culture -Name "jarvis_wake_request" -Phrases $wakePrefixes -Priority 115 -Weight 1.0 -AppendDictation
    $sleepGrammar = New-PhraseGrammar -Culture $selected.Culture -Name "jarvis_sleep" -Phrases $sleepPhrases -Priority 120 -Weight 1.0

    $dictation = New-Object -TypeName System.Speech.Recognition.DictationGrammar
    $dictation.Name = "general_dictation"
    $dictation.Priority = 0
    $dictation.Weight = [single]0.35
    try {
        $dictation.SetDictationContext("Jarvis", "")
    } catch {
        # Some installed recognizers do not support dictation context hints.
    }

    $recognizer.LoadGrammar($wakeOnly)
    $recognizer.LoadGrammar($wakeWithRequest)
    $recognizer.LoadGrammar($sleepGrammar)
    $recognizer.LoadGrammar($dictation)

    $recognizer.InitialSilenceTimeout = [TimeSpan]::FromSeconds(4)
    $recognizer.BabbleTimeout = [TimeSpan]::FromSeconds(5)
    $recognizer.EndSilenceTimeout = [TimeSpan]::FromMilliseconds(500)
    $recognizer.EndSilenceTimeoutAmbiguous = [TimeSpan]::FromMilliseconds(850)
    $recognizer.SetInputToDefaultAudioDevice()

    $script:maxAudioLevel = 0
    $script:emptyCycles = 0
    $recognizer.add_AudioLevelUpdated({
        param($sender, $eventArgs)
        if ($eventArgs.AudioLevel -gt $script:maxAudioLevel) {
            $script:maxAudioLevel = [int]$eventArgs.AudioLevel
        }
    })

    Write-JsonLine @{
        type = "status"
        status = "ready"
        engine = $selected.Description
        culture = $selected.Culture.Name
        input = "default_windows_recording_device"
        grammars = @("jarvis_wake", "jarvis_wake_request", "jarvis_sleep", "general_dictation")
    }

    while ($true) {
        $script:maxAudioLevel = 0
        $result = $recognizer.Recognize()
        if ($null -eq $result) {
            $script:emptyCycles += 1
            if ($script:maxAudioLevel -ge 4) {
                Write-JsonLine @{
                    type = "status"
                    status = "heard_audio_no_match"
                    audio_level = $script:maxAudioLevel
                    message = "Microphone audio was detected, but no phrase matched the loaded grammar."
                }
                $script:emptyCycles = 0
            } elseif ($script:emptyCycles -ge 3) {
                Write-JsonLine @{
                    type = "status"
                    status = "no_audio_signal"
                    audio_level = $script:maxAudioLevel
                    message = "No microphone signal has been detected from the default Windows recording device."
                }
                $script:emptyCycles = 0
            }
            continue
        }

        $script:emptyCycles = 0
        $text = [string]$result.Text
        if ([string]::IsNullOrWhiteSpace($text)) {
            continue
        }

        $alternatives = @()
        foreach ($alternative in $result.Alternates | Select-Object -First 3) {
            if (-not [string]::IsNullOrWhiteSpace([string]$alternative.Text)) {
                $alternatives += @{
                    text = ([string]$alternative.Text).Trim()
                    confidence = [Math]::Round([double]$alternative.Confidence, 4)
                }
            }
        }

        Write-JsonLine @{
            type = "recognized"
            text = $text.Trim()
            confidence = [Math]::Round([double]$result.Confidence, 4)
            grammar = if ($null -ne $result.Grammar) { $result.Grammar.Name } else { "unknown" }
            audio_level = $script:maxAudioLevel
            alternatives = $alternatives
        }
    }
} catch {
    Write-JsonLine @{
        type = "status"
        status = "error"
        message = $_.Exception.Message
    }
    exit 1
} finally {
    if ($null -ne $recognizer) {
        $recognizer.Dispose()
    }
}
