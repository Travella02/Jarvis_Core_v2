'use strict';

const path = require('node:path');

const ALPHA_SCHEMA_VERSION = 2;
const SUPPORTED_VOICES = new Set(['alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse', 'marin', 'cedar']);
const SUPPORTED_WAKE_PROFILES = new Set(['fast', 'balanced', 'strict']);
const SUPPORTED_RESPONSE_MODES = new Set(['test', 'short', 'normal', 'high', 'full']);

const DEFAULT_ALPHA_PREFERENCES = Object.freeze({
  voice: 'cedar',
  wakeProfile: 'fast',
  responseMode: 'normal',
  budgetSessionWarningUsd: 0.10,
  budgetSessionHardUsd: 0.25,
  budgetDailyWarningUsd: 0.50,
  budgetDailyHardUsd: 1.00,
  budgetMonthlyWarningUsd: 5.00,
  budgetMonthlyHardUsd: 10.00,
});

function finiteMoney(value, fallback, {minimum = 0, maximum = 100000} = {}) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < minimum || parsed > maximum) return fallback;
  return Math.round(parsed * 10000) / 10000;
}

function sanitizeAlphaPreferences(input = {}) {
  const source = input && typeof input === 'object' ? input : {};
  const voice = String(source.voice || '').trim().toLowerCase();
  const wakeProfile = String(source.wakeProfile || '').trim().toLowerCase();
  const requestedResponseMode = String(source.responseMode || '').trim().toLowerCase();
  const responseMode = requestedResponseMode === 'medium' ? 'high' : requestedResponseMode;
  const sanitized = {
    voice: SUPPORTED_VOICES.has(voice) ? voice : DEFAULT_ALPHA_PREFERENCES.voice,
    wakeProfile: SUPPORTED_WAKE_PROFILES.has(wakeProfile) ? wakeProfile : DEFAULT_ALPHA_PREFERENCES.wakeProfile,
    responseMode: SUPPORTED_RESPONSE_MODES.has(responseMode) ? responseMode : DEFAULT_ALPHA_PREFERENCES.responseMode,
    budgetSessionWarningUsd: finiteMoney(source.budgetSessionWarningUsd, DEFAULT_ALPHA_PREFERENCES.budgetSessionWarningUsd, {maximum: 1000}),
    budgetSessionHardUsd: finiteMoney(source.budgetSessionHardUsd, DEFAULT_ALPHA_PREFERENCES.budgetSessionHardUsd, {maximum: 1000}),
    budgetDailyWarningUsd: finiteMoney(source.budgetDailyWarningUsd, DEFAULT_ALPHA_PREFERENCES.budgetDailyWarningUsd, {maximum: 10000}),
    budgetDailyHardUsd: finiteMoney(source.budgetDailyHardUsd, DEFAULT_ALPHA_PREFERENCES.budgetDailyHardUsd, {maximum: 10000}),
    budgetMonthlyWarningUsd: finiteMoney(source.budgetMonthlyWarningUsd, DEFAULT_ALPHA_PREFERENCES.budgetMonthlyWarningUsd, {maximum: 100000}),
    budgetMonthlyHardUsd: finiteMoney(source.budgetMonthlyHardUsd, DEFAULT_ALPHA_PREFERENCES.budgetMonthlyHardUsd, {maximum: 100000}),
  };
  const pairs = [
    ['budgetSessionWarningUsd', 'budgetSessionHardUsd'],
    ['budgetDailyWarningUsd', 'budgetDailyHardUsd'],
    ['budgetMonthlyWarningUsd', 'budgetMonthlyHardUsd'],
  ];
  for (const [warningKey, hardKey] of pairs) {
    if (sanitized[warningKey] >= sanitized[hardKey]) {
      sanitized[warningKey] = Math.max(0, Math.round((sanitized[hardKey] * 0.5) * 10000) / 10000);
    }
  }
  return sanitized;
}

function sanitizeSetupPayload(input = {}) {
  const source = input && typeof input === 'object' ? input : {};
  const apiKey = String(source.apiKey || '').trim();
  if (apiKey && (!apiKey.startsWith('sk-') || apiKey.length < 20 || apiKey.length > 512)) {
    throw new Error('The OpenAI API key appears incomplete or invalid.');
  }
  return {
    apiKey,
    preferences: sanitizeAlphaPreferences(source.preferences),
    startWithWindows: Boolean(source.startWithWindows),
    notificationsEnabled: source.notificationsEnabled !== false,
  };
}

function secureSettingsDocument({encryptedApiKeyBase64 = '', preferences = DEFAULT_ALPHA_PREFERENCES, setupComplete = true} = {}) {
  return {
    schemaVersion: ALPHA_SCHEMA_VERSION,
    setupComplete: Boolean(setupComplete),
    encryptedApiKey: String(encryptedApiKeyBase64 || ''),
    preferences: sanitizeAlphaPreferences(preferences),
    updatedAt: new Date().toISOString(),
  };
}

function buildCoreEnvironment({base = {}, apiKey = '', preferences = DEFAULT_ALPHA_PREFERENCES, dataDir = '', logsDir = '', envFile = '', projectRoot = '', hosted = false, desktopConfirmationAuthority = ''} = {}) {
  const pref = sanitizeAlphaPreferences(preferences);
  const env = {
    ...base,
    JARVIS_OPEN_BROWSER: 'false',
    JARVIS_REALTIME_VOICE: pref.voice,
    JARVIS_WAKE_PROFILE: pref.wakeProfile,
    JARVIS_RESPONSE_MODE: pref.responseMode,
    JARVIS_BUDGET_SESSION_WARNING_USD: String(pref.budgetSessionWarningUsd),
    JARVIS_BUDGET_SESSION_HARD_USD: String(pref.budgetSessionHardUsd),
    JARVIS_BUDGET_DAILY_WARNING_USD: String(pref.budgetDailyWarningUsd),
    JARVIS_BUDGET_DAILY_HARD_USD: String(pref.budgetDailyHardUsd),
    JARVIS_BUDGET_MONTHLY_WARNING_USD: String(pref.budgetMonthlyWarningUsd),
    JARVIS_BUDGET_MONTHLY_HARD_USD: String(pref.budgetMonthlyHardUsd),
  };
  if (apiKey) env.OPENAI_API_KEY = apiKey;
  if (hosted) {
    // Official packaged/customer builds fail closed onto Jarvis Cloud. Legacy or
    // user-supplied provider credentials may remain on disk for development
    // compatibility, but they are deliberately removed from the hosted Core
    // process and cannot become a subscription bypass.
    env.JARVIS_PROVIDER_MODE = 'hosted';
    env.JARVIS_SIMULATION_ENABLED = 'false';
    delete env.OPENAI_API_KEY;
    delete env.ELEVENLABS_API_KEY;
    delete env.JARVIS_ELEVENLABS_VOICE_ID;
    delete env.JARVIS_ELEVENLABS_MODEL;
    delete env.JARVIS_ELEVENLABS_OUTPUT_FORMAT;
  }
  if (dataDir) env.JARVIS_DATA_DIR = dataDir;
  if (logsDir) env.JARVIS_LOGS_DIR = logsDir;
  if (envFile) env.JARVIS_ENV_FILE = envFile;
  if (projectRoot) env.JARVIS_PROJECT_ROOT = projectRoot;
  if (desktopConfirmationAuthority) env.JARVIS_DESKTOP_CONFIRMATION_AUTHORITY = String(desktopConfirmationAuthority);
  return env;
}

const DIAGNOSTIC_REDACTED = '[REDACTED]';
const SENSITIVE_DIAGNOSTIC_KEYS = new Set([
  'api_key', 'apikey', 'authorization', 'token', 'id_token', 'oauth_token',
  'auth_token', 'access_token', 'refresh_token', 'session_token', 'poll_token',
  'recovery_token', 'client_secret', 'consumer_secret', 'private_key',
  'password', 'passwd', 'pwd', 'passcode', 'pin', 'otp', 'totp',
  'verification_code', 'recovery_code', 'security_code', 'card_number',
  'credit_card_number', 'debit_card_number', 'cvv', 'cvc', 'cvv2', 'cvc2',
  'bank_account', 'bank_account_number', 'account_number', 'routing_number',
  'routing_transit_number', 'iban', 'swift_code', 'bic', 'secret',
  'encryptedapikey', 'encrypted_api_key',
]);
const SENSITIVE_DIAGNOSTIC_SUFFIXES = [
  '_api_key', '_access_token', '_refresh_token', '_auth_token', '_session_token',
  '_poll_token', '_recovery_token', '_client_secret', '_private_key', '_password',
  '_passcode', '_verification_code', '_recovery_code', '_card_number',
  '_account_number', '_routing_number',
];

function normalizedDiagnosticKey(key) {
  return String(key || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
}

function sensitiveDiagnosticKey(key) {
  const normalized = normalizedDiagnosticKey(key);
  if (!normalized) return false;
  return SENSITIVE_DIAGNOSTIC_KEYS.has(normalized)
    || SENSITIVE_DIAGNOSTIC_SUFFIXES.some((suffix) => normalized.endsWith(suffix));
}

function luhnValid(value) {
  const digits = String(value || '').replace(/\D/g, '');
  if (digits.length < 13 || digits.length > 19 || /^(\d)\1+$/.test(digits)) return false;
  let checksum = 0;
  const parity = digits.length % 2;
  for (let index = 0; index < digits.length; index += 1) {
    let digit = Number(digits[index]);
    if (index % 2 === parity) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    checksum += digit;
  }
  return checksum % 10 === 0;
}

function redactDiagnosticText(input) {
  let text = String(input);
  text = text
    .replace(/-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z0-9 ]*PRIVATE KEY-----/gi, DIAGNOSTIC_REDACTED)
    .replace(/\bBearer\s+[A-Za-z0-9._~+/=-]{8,}/gi, `Bearer ${DIAGNOSTIC_REDACTED}`)
    .replace(/\bsk-(?:proj-|live-|test-)?[A-Za-z0-9_-]{12,}\b/gi, DIAGNOSTIC_REDACTED)
    .replace(/\b(?:rk|pk)_(?:live|test)_[A-Za-z0-9]{16,}\b/gi, DIAGNOSTIC_REDACTED)
    .replace(/\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}\b/g, DIAGNOSTIC_REDACTED)
    .replace(/\bgithub_pat_[A-Za-z0-9_]{20,}\b/gi, DIAGNOSTIC_REDACTED)
    .replace(/\bxox[baprs]-[A-Za-z0-9-]{10,}\b/gi, DIAGNOSTIC_REDACTED)
    .replace(/\bAIza[0-9A-Za-z_-]{20,}\b/g, DIAGNOSTIC_REDACTED)
    .replace(/\bya29\.[0-9A-Za-z._-]{10,}\b/gi, DIAGNOSTIC_REDACTED)
    .replace(/\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g, DIAGNOSTIC_REDACTED);

  // Natural-language phrases run before narrower assignment/CLI forms so a
  // multi-word passphrase cannot leak everything after its first word.
  text = text.replace(
    /(\b(?:my|the|your|our)?\s*(?:password|passcode|pin|otp|totp|verification code|recovery code|security code|api key|access token|refresh token|auth token|session token|client secret|card number|credit card number|debit card number|routing number|bank account number|account number|cvv|cvc|iban)\s+(?:is|was|equals|is set to)\s+)([^\r\n,;.!?]{3,512}?)(?=(?:[,;.!?](?:\s|$)|\r?$|$))/gim,
    (_match, label) => `${label}${DIAGNOSTIC_REDACTED}`,
  );
  // Assignment/CLI forms, including OAuth callback query data.
  text = text.replace(
    /((?:--?)?(?:password|passwd|pwd|passcode|pin|otp|totp|verification[ _-]?code|recovery[ _-]?code|security[ _-]?code|api[ _-]?key|access[ _-]?token|refresh[ _-]?token|auth[ _-]?token|session[ _-]?token|poll[ _-]?token|recovery[ _-]?token|client[ _-]?secret|private[ _-]?key|cvv2?|cvc2?|routing[ _-]?number|routing[ _-]?transit[ _-]?number|bank[ _-]?account(?:[ _-]?number)?|account[ _-]?number|card[ _-]?number|credit[ _-]?card(?:[ _-]?number)?|debit[ _-]?card(?:[ _-]?number)?|iban))(\s*(?:=|:|\bis\b|\bwas\b|\bto\b)\s*)(?:['"][^'"\r\n]{1,512}['"]|[^\s,;\r\n]{3,512})/gi,
    (_match, label, separator) => `${label}${separator}${DIAGNOSTIC_REDACTED}`,
  );
  text = text.replace(
    /(--?(?:password|passwd|pwd|passcode|pin|otp|totp|api[ _-]?key|access[ _-]?token|refresh[ _-]?token|auth[ _-]?token|session[ _-]?token|client[ _-]?secret|cvv2?|cvc2?))(\s+)([^\s,;\r\n]{3,512})/gi,
    (_match, label, separator) => `${label}${separator}${DIAGNOSTIC_REDACTED}`,
  );
  text = text.replace(
    /([?&](?:access_token|refresh_token|token|id_token|code|client_secret|api_key|apikey|key|password|passcode|recovery_token)=)([^&#\s]+)/gi,
    (_match, prefix) => `${prefix}${encodeURIComponent(DIAGNOSTIC_REDACTED)}`,
  );
  text = text.replace(/(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)/g, (candidate) => (luhnValid(candidate) ? DIAGNOSTIC_REDACTED : candidate));
  text = text.replace(/\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b/gi, DIAGNOSTIC_REDACTED);
  text = text.replace(/(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)/g, DIAGNOSTIC_REDACTED);
  return text;
}

function redactDiagnosticValue(value, key = '') {
  if (sensitiveDiagnosticKey(key)) return DIAGNOSTIC_REDACTED;
  if (typeof value === 'string') return redactDiagnosticText(value);
  if (Array.isArray(value)) return value.map((item) => redactDiagnosticValue(item));
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([childKey, childValue]) => [childKey, redactDiagnosticValue(childValue, childKey)]));
  }
  return value;
}

function compareVersions(current, latest) {
  const parse = (value) => String(value || '').replace(/^v/i, '').split('.').map((part) => Number.parseInt(part, 10) || 0);
  const left = parse(current);
  const right = parse(latest);
  const count = Math.max(left.length, right.length);
  for (let index = 0; index < count; index += 1) {
    const a = left[index] || 0;
    const b = right[index] || 0;
    if (a < b) return -1;
    if (a > b) return 1;
  }
  return 0;
}

function runtimeInstallRoot(userDataPath, version) {
  const safeVersion = String(version || 'unknown').replace(/[^A-Za-z0-9._-]/g, '_');
  return path.join(userDataPath, 'runtime', safeVersion);
}

function packagedPythonPath(runtimeBasePath, platform = process.platform) {
  const executable = platform === 'win32' ? 'pythonw.exe' : 'python3';
  return path.join(runtimeBasePath, 'python', executable);
}

module.exports = {
  ALPHA_SCHEMA_VERSION,
  DEFAULT_ALPHA_PREFERENCES,
  buildCoreEnvironment,
  compareVersions,
  packagedPythonPath,
  redactDiagnosticValue,
  runtimeInstallRoot,
  sanitizeAlphaPreferences,
  sanitizeSetupPayload,
  secureSettingsDocument,
};
