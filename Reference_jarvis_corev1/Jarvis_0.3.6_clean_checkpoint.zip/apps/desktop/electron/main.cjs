'use strict';

if (require('./squirrel.cjs').handleSquirrelEvent(process.argv)) process.exit(0);

const {
  app,
  BrowserWindow,
  Menu,
  Tray,
  ipcMain,
  nativeImage,
  screen,
  Notification,
  powerMonitor,
  safeStorage,
  dialog,
  net,
  shell,
} = require('electron');
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const nodeNet = require('node:net');
const crypto = require('node:crypto');
const {
  DEFAULT_DESKTOP_SETTINGS,
  computeRestartBackoff,
  pruneTimestamps,
  sanitizeDesktopSettings,
  safePresenceSnapshot,
  windowsLoginItemOptions,
} = require('./presence.cjs');
const {
  DEFAULT_ALPHA_PREFERENCES,
  buildCoreEnvironment,
  compareVersions,
  packagedPythonPath,
  redactDiagnosticValue,
  runtimeInstallRoot,
  sanitizeAlphaPreferences,
  sanitizeSetupPayload,
  secureSettingsDocument,
} = require('./alpha.cjs');

const CORE_URL = 'http://127.0.0.1:8765';
const HEALTH_URL = `${CORE_URL}/api/health`;
const HEALTH_TIMEOUT_MS = 45000;
const HEALTH_POLL_MS = 400;
const CORE_HEARTBEAT_MS = 5000;
const CORE_HEARTBEAT_TIMEOUT_MS = 1400;
const CORE_FAILURE_THRESHOLD = 3;
const CORE_RESTART_BASE_MS = 1000;
const CORE_RESTART_MAX_MS = 30000;
const CORE_RESTART_WINDOW_MS = 10 * 60 * 1000;
const CORE_MAX_RESTARTS_PER_WINDOW = 5;
const CORE_STABLE_RESET_MS = 2 * 60 * 1000;
const RENDERER_RECOVERY_WINDOW_MS = 5 * 60 * 1000;
const RENDERER_MAX_RECOVERIES = 3;
const RENDERER_UNRESPONSIVE_GRACE_MS = 5000;
const PRESENCE_BROADCAST_MS = 1000;
const PRESENCE_LOG_MAX_BYTES = 2 * 1024 * 1024;
const WINDOW_MARGIN = 24;
const DEFAULT_WINDOW_WIDTH = 1100;
const DEFAULT_WINDOW_HEIGHT = 720;
const MAX_STARTUP_WIDTH_RATIO = 0.82;
const MAX_STARTUP_HEIGHT_RATIO = 0.82;
const MIN_WINDOW_WIDTH = 760;
const MIN_WINDOW_HEIGHT = 560;
const GITHUB_RELEASES_API = 'https://api.github.com/repos/Travella02/Jarvis_Real_Time/releases/latest';
const GITHUB_RELEASES_PAGE = 'https://github.com/Travella02/Jarvis_Real_Time/releases';
const CORE_LOG_MAX_BYTES = 3 * 1024 * 1024;
const DESKTOP_CONFIRMATION_AUTHORITY = crypto.randomBytes(32).toString('base64url');

const launchedInBackground = process.argv.includes('--background') || process.argv.includes('--startup');
const appStartedAt = Date.now();

let mainWindow = null;
let tray = null;
let coreProcess = null;
let coreState = 'stopped';
let supervisorState = 'starting';
let coreStartedAt = null;
let coreHeartbeatTimer = null;
let coreHeartbeatFailures = 0;
let coreRestartTimer = null;
let coreStableTimer = null;
let coreRestartHistory = [];
let coreRestartCount = 0;
let expectedCorePids = new Set();
let rendererRecoveryHistory = [];
let rendererRecoveries = 0;
let rendererRecoveryTimer = null;
let rendererUnresponsiveTimer = null;
let presenceBroadcastTimer = null;
let lastHeartbeatAt = null;
let systemSuspended = false;
let isQuitting = false;
let trayState = 'sleeping';
let desktopSettings = {...DEFAULT_DESKTOP_SETTINGS};
let alphaPreferences = {...DEFAULT_ALPHA_PREFERENCES};
let secureApiKey = '';
let secureSetupConfigured = false;
let developmentPython = null;
let activePermissionConfirmation = null;

function sourceProjectRoot() {
  return path.resolve(__dirname, '..', '..', '..');
}

function packagedRuntimeBase() {
  return runtimeInstallRoot(app.getPath('userData'), app.getVersion());
}

function runtimeRoot() {
  if (process.env.JARVIS_PROJECT_ROOT) return path.resolve(process.env.JARVIS_PROJECT_ROOT);
  if (app.isPackaged) return path.join(packagedRuntimeBase(), 'desktop_runtime');
  return sourceProjectRoot();
}

function privateEnvPath() {
  if (process.env.JARVIS_ENV_FILE) return path.resolve(process.env.JARVIS_ENV_FILE);
  if (!app.isPackaged) return path.join(runtimeRoot(), '.env');
  return path.join(app.getPath('userData'), '.env');
}

function windowStatePath() {
  return path.join(app.getPath('userData'), 'window-state.json');
}

function desktopSettingsPath() {
  return path.join(app.getPath('userData'), 'desktop-settings.json');
}

function presenceLogPath() {
  return path.join(app.getPath('userData'), 'desktop-presence.jsonl');
}

function jarvisDataRoot() {
  return path.join(app.getPath('userData'), 'jarvis-data');
}

function secureSettingsPath() {
  return path.join(jarvisDataRoot(), 'secure-settings.json');
}

function runtimeDataPath() {
  return path.join(jarvisDataRoot(), 'data');
}

function runtimeLogsPath() {
  return path.join(jarvisDataRoot(), 'logs');
}

function coreLogPath() {
  return path.join(runtimeLogsPath(), 'core-process.log');
}

function loadDesktopSettings() {
  try {
    return sanitizeDesktopSettings(JSON.parse(fs.readFileSync(desktopSettingsPath(), 'utf8')));
  } catch (_) {
    return {...DEFAULT_DESKTOP_SETTINGS};
  }
}

function saveDesktopSettings() {
  const target = desktopSettingsPath();
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const temporary = `${target}.new`;
  fs.writeFileSync(temporary, `${JSON.stringify(desktopSettings, null, 2)}\n`, 'utf8');
  fs.renameSync(temporary, target);
}

let legacyDiagnosticScrubComplete = false;

function scrubLegacyDiagnosticFile(target) {
  try {
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return false;
    const raw = fs.readFileSync(target, 'utf8');
    const safe = redactDiagnosticValue(raw);
    if (safe === raw) return false;
    const temporary = `${target}.hygiene.tmp`;
    fs.writeFileSync(temporary, safe, 'utf8');
    fs.renameSync(temporary, target);
    return true;
  } catch (_) {
    return false;
  }
}

function scrubLegacyDesktopDiagnosticsOnce() {
  if (legacyDiagnosticScrubComplete) return;
  legacyDiagnosticScrubComplete = true;
  for (const target of [
    presenceLogPath(), `${presenceLogPath()}.1`, coreLogPath(), `${coreLogPath()}.1`,
  ]) scrubLegacyDiagnosticFile(target);
}

function rotatePresenceLogIfNeeded() {
  const target = presenceLogPath();
  try {
    if (!fs.existsSync(target) || fs.statSync(target).size < PRESENCE_LOG_MAX_BYTES) return;
    const previous = `${target}.1`;
    fs.rmSync(previous, { force: true });
    fs.renameSync(target, previous);
  } catch (_) {
    // Operational diagnostics must not stop Jarvis.
  }
}

function journalPresence(event, detail = {}) {
  try {
    scrubLegacyDesktopDiagnosticsOnce();
    rotatePresenceLogIfNeeded();
    const target = presenceLogPath();
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const safeDetail = redactDiagnosticValue(
      detail && typeof detail === 'object' ? detail : {message: String(detail)},
    );
    fs.appendFileSync(target, `${JSON.stringify({
      timestamp: new Date().toISOString(),
      event: String(event),
      core_state: coreState,
      supervisor_state: supervisorState,
      detail: safeDetail,
    })}\n`, 'utf8');
  } catch (_) {
    // Keep supervision alive even if the diagnostic log cannot be written.
  }
}

function loadWindowState() {
  const fallback = { width: DEFAULT_WINDOW_WIDTH, height: DEFAULT_WINDOW_HEIGHT };
  try {
    const value = JSON.parse(fs.readFileSync(windowStatePath(), 'utf8'));
    if (!Number.isFinite(value.width) || !Number.isFinite(value.height)) return fallback;
    return value;
  } catch (_) {
    return fallback;
  }
}

function saveWindowState() {
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.isMinimized() || mainWindow.isMaximized()) return;
  const bounds = mainWindow.getBounds();
  fs.mkdirSync(path.dirname(windowStatePath()), { recursive: true });
  fs.writeFileSync(windowStatePath(), JSON.stringify(bounds, null, 2));
}

function clamp(value, minimum, maximum) {
  return Math.min(Math.max(value, minimum), maximum);
}

function preferredBounds(display = screen.getPrimaryDisplay()) {
  const area = display.workArea;
  const maximumWidth = Math.max(MIN_WINDOW_WIDTH, Math.floor(area.width * MAX_STARTUP_WIDTH_RATIO));
  const maximumHeight = Math.max(MIN_WINDOW_HEIGHT, Math.floor(area.height * MAX_STARTUP_HEIGHT_RATIO));
  const width = clamp(DEFAULT_WINDOW_WIDTH, Math.min(MIN_WINDOW_WIDTH, maximumWidth), maximumWidth);
  const height = clamp(DEFAULT_WINDOW_HEIGHT, Math.min(MIN_WINDOW_HEIGHT, maximumHeight), maximumHeight);
  return {
    width,
    height,
    x: area.x + Math.floor((area.width - width) / 2),
    y: area.y + Math.floor((area.height - height) / 2),
  };
}

function displayContainingBounds(bounds) {
  return screen.getAllDisplays().find((display) => {
    const area = display.workArea;
    return bounds.x >= area.x
      && bounds.y >= area.y
      && bounds.x + bounds.width <= area.x + area.width
      && bounds.y + bounds.height <= area.y + area.height;
  }) || null;
}

function ensureVisibleBounds(bounds) {
  const primary = screen.getPrimaryDisplay();
  const numeric = {
    x: Number.isFinite(bounds.x) ? bounds.x : NaN,
    y: Number.isFinite(bounds.y) ? bounds.y : NaN,
    width: Number.isFinite(bounds.width) ? bounds.width : NaN,
    height: Number.isFinite(bounds.height) ? bounds.height : NaN,
  };
  const containingDisplay = Number.isFinite(numeric.x)
    && Number.isFinite(numeric.y)
    && Number.isFinite(numeric.width)
    && Number.isFinite(numeric.height)
    ? displayContainingBounds(numeric)
    : null;
  if (!containingDisplay) return preferredBounds(primary);

  const area = containingDisplay.workArea;
  const maximumWidth = Math.max(MIN_WINDOW_WIDTH, Math.floor(area.width * MAX_STARTUP_WIDTH_RATIO));
  const maximumHeight = Math.max(MIN_WINDOW_HEIGHT, Math.floor(area.height * MAX_STARTUP_HEIGHT_RATIO));
  if (numeric.width > maximumWidth || numeric.height > maximumHeight) {
    return preferredBounds(containingDisplay);
  }

  const width = clamp(numeric.width, Math.min(MIN_WINDOW_WIDTH, maximumWidth), maximumWidth);
  const height = clamp(numeric.height, Math.min(MIN_WINDOW_HEIGHT, maximumHeight), maximumHeight);
  const x = clamp(numeric.x, area.x + WINDOW_MARGIN, area.x + area.width - width - WINDOW_MARGIN);
  const y = clamp(numeric.y, area.y + WINDOW_MARGIN, area.y + area.height - height - WINDOW_MARGIN);
  return { width, height, x, y };
}

function resetWindowBounds() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const bounds = preferredBounds(screen.getPrimaryDisplay());
  mainWindow.unmaximize();
  mainWindow.setBounds(bounds, true);
  saveWindowState();
  showWindow();
}

function runtimeBundlePaths() {
  return {
    archive: path.join(process.resourcesPath, 'runtime_bundle.zip'),
    manifest: path.join(process.resourcesPath, 'runtime_bundle-manifest.json'),
  };
}

function sha256File(target) {
  return new Promise((resolve, reject) => {
    const digest = crypto.createHash('sha256');
    const stream = fs.createReadStream(target);
    stream.on('data', (chunk) => digest.update(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(digest.digest('hex')));
  });
}

function runtimeReadyMarker(base) {
  return path.join(base, 'runtime-ready.json');
}

function requiredRuntimeFiles(base) {
  return [
    path.join(base, 'python', 'pythonw.exe'),
    path.join(base, 'python', 'runtime-manifest.json'),
    path.join(base, 'desktop_runtime', 'apps', 'core', 'server.py'),
    path.join(base, 'desktop_runtime', 'apps', 'desktop', 'lab', 'index.html'),
    path.join(base, 'desktop_runtime', 'VERSION'),
  ];
}

function installedRuntimeIsReady(base, bundleSha256) {
  try {
    const marker = JSON.parse(fs.readFileSync(runtimeReadyMarker(base), 'utf8'));
    return marker.bundleSha256 === bundleSha256
      && requiredRuntimeFiles(base).every((target) => fs.existsSync(target))
      && packagedRuntimeCanStart(base);
  } catch (_) {
    return false;
  }
}

function setLoadingStatus(message) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const text = JSON.stringify(String(message));
  mainWindow.webContents.executeJavaScript(`document.getElementById('status').textContent = ${text};`, true).catch(() => {});
}

function runRuntimeProcess(command, args, {cwd, timeoutMs = 180000, allowFailure = false} = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd,
      env: process.env,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      try { child.kill(); } catch (_) {}
      reject(new Error(`Runtime command timed out: ${command} ${args.join(' ')}`));
    }, timeoutMs);
    child.stdout.on('data', (chunk) => { stdout += chunk.toString('utf8'); });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString('utf8'); });
    child.on('error', (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(error);
    });
    child.on('exit', (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      const result = {code: Number(code ?? -1), stdout, stderr};
      if (result.code === 0 || allowFailure) resolve(result);
      else reject(new Error((stderr || stdout || `Runtime command exited with ${result.code}`).trim()));
    });
  });
}

function developmentVenvPython(root) {
  return process.platform === 'win32'
    ? path.join(root, '.venv', 'Scripts', 'python.exe')
    : path.join(root, '.venv', 'bin', 'python');
}

async function ensureDevelopmentRuntime(root) {
  if (app.isPackaged) return null;
  const localPython = developmentVenvPython(root);
  if (!fs.existsSync(localPython)) {
    setLoadingStatus('Preparing Jarvis local development runtime...');
    const bootstrap = process.platform === 'win32'
      ? {command: 'py', args: ['-3.12']}
      : {command: 'python3', args: []};
    await runRuntimeProcess(bootstrap.command, [...bootstrap.args, '-m', 'venv', path.join(root, '.venv')], {cwd: root});
  }
  const ensureScript = path.join(root, 'scripts', 'ensure_environment.py');
  if (!fs.existsSync(ensureScript)) throw new Error(`Runtime bootstrap script is missing: ${ensureScript}`);
  setLoadingStatus('Checking Jarvis runtime dependencies...');
  const checked = await runRuntimeProcess(localPython, [ensureScript, '--check-only'], {cwd: root, allowFailure: true, timeoutMs: 60000});
  if (checked.code !== 0) {
    setLoadingStatus('Repairing missing Jarvis runtime dependencies...');
    const repaired = await runRuntimeProcess(localPython, [ensureScript], {cwd: root, allowFailure: true});
    if (repaired.code !== 0) {
      throw new Error((repaired.stderr || repaired.stdout || 'Jarvis could not repair its local runtime dependencies.').trim());
    }
  }
  developmentPython = {command: localPython, prefix: []};
  return developmentPython;
}

function packagedRuntimeCanStart(base) {
  try {
    const python = packagedPythonPath(base, process.platform);
    if (!fs.existsSync(python)) return false;
    const probe = spawnSync(python, ['-I', '-c', 'import fastapi,httpx,uvicorn,websockets,jarvis,apps'], {
      cwd: path.join(base, 'desktop_runtime'),
      windowsHide: true,
      encoding: 'utf8',
      timeout: 30000,
    });
    return probe.status === 0;
  } catch (_) {
    return false;
  }
}

function extractRuntimeBundle(archive, destination) {
  return new Promise((resolve, reject) => {
    const script = "$ErrorActionPreference='Stop'; Expand-Archive -LiteralPath $env:JARVIS_RUNTIME_ARCHIVE -DestinationPath $env:JARVIS_RUNTIME_DESTINATION -Force";
    const child = spawn('powershell.exe', [
      '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script,
    ], {
      env: {
        ...process.env,
        JARVIS_RUNTIME_ARCHIVE: archive,
        JARVIS_RUNTIME_DESTINATION: destination,
      },
      windowsHide: true,
      stdio: ['ignore', 'ignore', 'pipe'],
    });
    let stderr = '';
    child.stderr.on('data', (chunk) => { stderr += chunk.toString('utf8'); });
    child.on('error', reject);
    child.on('exit', (code) => {
      if (code === 0) resolve();
      else reject(new Error(stderr.trim() || `PowerShell runtime extraction failed with exit code ${code}.`));
    });
  });
}

async function ensurePackagedRuntime() {
  if (!app.isPackaged) return;
  const {archive, manifest: manifestPath} = runtimeBundlePaths();
  if (!fs.existsSync(archive) || !fs.existsSync(manifestPath)) {
    throw new Error('The packaged runtime bundle is missing. Rebuild the Desktop Alpha installer.');
  }
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  const expectedHash = String(manifest.bundle_sha256 || '');
  if (!/^[a-f0-9]{64}$/i.test(expectedHash)) throw new Error('The packaged runtime manifest is invalid.');
  const target = packagedRuntimeBase();
  if (installedRuntimeIsReady(target, expectedHash)) return;

  setLoadingStatus('Verifying the private local runtime package...');
  const actualHash = await sha256File(archive);
  if (actualHash !== expectedHash) throw new Error('The packaged runtime bundle failed its SHA-256 integrity check.');

  const staging = `${target}.staging-${process.pid}`;
  fs.rmSync(staging, {recursive: true, force: true});
  fs.mkdirSync(path.dirname(staging), {recursive: true});
  setLoadingStatus('Preparing the private local runtime for first use. This only happens once per version...');
  try {
    await extractRuntimeBundle(archive, staging);
    const missing = requiredRuntimeFiles(staging).filter((entry) => !fs.existsSync(entry));
    if (missing.length) throw new Error(`The extracted runtime is incomplete: ${missing[0]}`);
    fs.writeFileSync(runtimeReadyMarker(staging), `${JSON.stringify({
      schemaVersion: 1,
      bundleSha256: expectedHash,
      installedAt: new Date().toISOString(),
    }, null, 2)}
`, 'utf8');
    fs.rmSync(target, {recursive: true, force: true});
    fs.renameSync(staging, target);
  } catch (error) {
    fs.rmSync(staging, {recursive: true, force: true});
    throw error;
  }
  setLoadingStatus('Private runtime ready. Starting the Jarvis core...');
}

function pythonCommandForDevelopment(root) {
  if (developmentPython) return developmentPython;
  const local = developmentVenvPython(root);
  if (fs.existsSync(local)) return { command: local, prefix: [] };
  if (process.platform === 'win32') return { command: 'py', prefix: ['-3.12'] };
  return { command: 'python3', prefix: [] };
}

function packagedPython(root) {
  const python = packagedPythonPath(packagedRuntimeBase(), process.platform);
  if (!fs.existsSync(python)) {
    throw new Error(`Bundled Python runtime is missing: ${python}. Rebuild or repair the Desktop Alpha package.`);
  }
  return python;
}

async function loadSecureSetup() {
  alphaPreferences = {...DEFAULT_ALPHA_PREFERENCES};
  secureApiKey = '';
  secureSetupConfigured = false;
  try {
    const target = secureSettingsPath();
    if (!fs.existsSync(target)) return;
    const document = JSON.parse(fs.readFileSync(target, 'utf8'));
    alphaPreferences = sanitizeAlphaPreferences(document.preferences);
    const encrypted = String(document.encryptedApiKey || '');
    // Setup completion is intentionally separate from provider credentials. Hosted
    // customer builds authenticate to Jarvis Cloud and must never require a local
    // OpenAI key just to finish desktop setup. Legacy v1 documents remain complete
    // when they contain the previously required encrypted key.
    secureSetupConfigured = Boolean(document.setupComplete) || Boolean(encrypted);
    if (!encrypted) {
      secureApiKey = '';
      return;
    }
    const available = await safeStorage.isAsyncEncryptionAvailable();
    if (!available) return;
    const result = await safeStorage.decryptStringAsync(Buffer.from(encrypted, 'base64'));
    secureApiKey = result.result || '';
    if (result.shouldReEncrypt && secureApiKey) await persistSecureSetup(secureApiKey, alphaPreferences);
  } catch (error) {
    secureApiKey = '';
    secureSetupConfigured = false;
    journalPresence('secure_setup_load_failed', {message: error.message});
  }
}

async function persistSecureSetup(apiKey, preferences) {
  let encryptedApiKeyBase64 = '';
  if (apiKey) {
    const available = await safeStorage.isAsyncEncryptionAvailable();
    if (!available) throw new Error('Secure operating-system encryption is unavailable.');
    const encrypted = await safeStorage.encryptStringAsync(apiKey);
    encryptedApiKeyBase64 = encrypted.toString('base64');
  }
  const document = secureSettingsDocument({
    encryptedApiKeyBase64,
    preferences,
    setupComplete: true,
  });
  const target = secureSettingsPath();
  fs.mkdirSync(path.dirname(target), {recursive: true});
  const temporary = `${target}.new`;
  fs.writeFileSync(temporary, `${JSON.stringify(document, null, 2)}
`, 'utf8');
  fs.renameSync(temporary, target);
}

function bundledPythonVersion() {
  try {
    const manifest = JSON.parse(fs.readFileSync(path.join(packagedRuntimeBase(), 'python', 'runtime-manifest.json'), 'utf8'));
    return String(manifest.python_version || 'unknown');
  } catch (_) {
    return app.isPackaged ? 'unknown' : process.env.PYTHON_VERSION || 'development';
  }
}

function privateEnvHasApiKey() {
  try {
    const target = privateEnvPath();
    if (!fs.existsSync(target)) return false;
    return fs.readFileSync(target, 'utf8').split(/\r?\n/).some((line) => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) return false;
      const [key, ...rest] = trimmed.split('=');
      return key.trim() === 'OPENAI_API_KEY' && rest.join('=').trim().replace(/^['"]|['"]$/g, '').length >= 20;
    });
  } catch (_) { return false; }
}

function developmentProviderKeyConfigured() {
  return Boolean(secureApiKey) || Boolean(process.env.OPENAI_API_KEY) || privateEnvHasApiKey();
}

function setupStatus() {
  return {
    available: Boolean(windowSafeStorageAvailable()),
    configured: secureSetupConfigured,
    // Packaged customer builds never inspect or report a local provider
    // credential as readiness. Provider authority comes from Jarvis Cloud.
    providerKeyConfigured: app.isPackaged ? false : developmentProviderKeyConfigured(),
    source: secureSetupConfigured ? 'desktop_settings' : 'missing',
    preferences: {...alphaPreferences},
    startWithWindows: desktopSettings.startWithWindows,
    notificationsEnabled: desktopSettings.notificationsEnabled,
    packaged: app.isPackaged,
    appVersion: app.getVersion(),
    electronVersion: process.versions.electron,
    pythonVersion: bundledPythonVersion(),
    installationPath: process.execPath,
    dataPath: runtimeDataPath(),
    logPath: runtimeLogsPath(),
  };
}

function windowSafeStorageAvailable() {
  try { return safeStorage.isEncryptionAvailable(); } catch (_) { return false; }
}

async function saveAlphaSetup(payload) {
  const normalized = sanitizeSetupPayload(payload);
  const nextKey = normalized.apiKey || secureApiKey;
  // Provider credentials are optional desktop-development settings. Hosted mode
  // uses Jarvis Cloud authority and never requires a customer OpenAI key.
  await persistSecureSetup(nextKey, normalized.preferences);
  secureApiKey = nextKey;
  alphaPreferences = normalized.preferences;
  secureSetupConfigured = true;
  configureLoginItem(normalized.startWithWindows);
  setNotificationsEnabled(normalized.notificationsEnabled);
  journalPresence('alpha_setup_saved', {preferences: alphaPreferences});
  await manualRestartCore('alpha_setup_saved');
  return setupStatus();
}

function rotateCoreLogIfNeeded() {
  const target = coreLogPath();
  try {
    if (!fs.existsSync(target) || fs.statSync(target).size < CORE_LOG_MAX_BYTES) return;
    const previous = `${target}.1`;
    fs.rmSync(previous, {force: true});
    fs.renameSync(target, previous);
  } catch (_) {}
}

function writeCoreLog(streamName, chunk) {
  try {
    scrubLegacyDesktopDiagnosticsOnce();
    rotateCoreLogIfNeeded();
    fs.mkdirSync(runtimeLogsPath(), {recursive: true});
    const text = redactDiagnosticValue(chunk.toString('utf8'));
    fs.appendFileSync(coreLogPath(), `[${new Date().toISOString()}] [${streamName}] ${text}`, 'utf8');
    if (!app.isPackaged) {
      const output = streamName === 'stderr' ? process.stderr : process.stdout;
      output.write(`[core] ${text}`);
    }
  } catch (_) {}
}

function tailFile(filePath, maxLines = 200) {
  try {
    if (!fs.existsSync(filePath)) return [];
    return fs.readFileSync(filePath, 'utf8').split(/\r?\n/).filter(Boolean).slice(-maxLines)
      .map((line) => redactDiagnosticValue(line));
  } catch (_) { return []; }
}

async function exportDiagnostics() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Export Jarvis diagnostics',
    defaultPath: path.join(app.getPath('documents'), `Jarvis_Diagnostics_${stamp}.json`),
    buttonLabel: 'Export',
    filters: [{name: 'JSON diagnostics', extensions: ['json']}],
  });
  if (result.canceled || !result.filePath) return {canceled: true};
  const report = redactDiagnosticValue({
    generatedAt: new Date().toISOString(),
    app: {
      name: app.getName(), version: app.getVersion(), packaged: app.isPackaged,
      electron: process.versions.electron, chrome: process.versions.chrome,
      node: process.versions.node, platform: process.platform, arch: process.arch,
    },
    presence: presenceSnapshot(),
    setup: setupStatus(),
    paths: {
      executable: process.execPath,
      resources: process.resourcesPath,
      userData: app.getPath('userData'),
      data: runtimeDataPath(),
      logs: runtimeLogsPath(),
    },
    recentPresenceEvents: tailFile(presenceLogPath(), 200),
    recentCoreLog: tailFile(coreLogPath(), 200),
  });
  fs.writeFileSync(result.filePath, `${JSON.stringify(report, null, 2)}
`, 'utf8');
  journalPresence('diagnostics_exported', {path: result.filePath});
  return {canceled: false, path: result.filePath};
}

async function checkForUpdates() {
  try {
    const response = await net.fetch(GITHUB_RELEASES_API, {
      headers: {'Accept': 'application/vnd.github+json', 'User-Agent': 'Jarvis-Real-Time-Desktop'},
    });
    if (!response.ok) throw new Error(`GitHub returned ${response.status}`);
    const payload = await response.json();
    const latest = String(payload.tag_name || payload.name || '').replace(/^v/i, '');
    const current = app.getVersion();
    return {
      ok: true,
      current,
      latest: latest || current,
      updateAvailable: Boolean(latest) && compareVersions(current, latest) < 0,
      releaseUrl: typeof payload.html_url === 'string' ? payload.html_url : GITHUB_RELEASES_PAGE,
    };
  } catch (error) {
    return {ok: false, current: app.getVersion(), message: error.message};
  }
}

async function openReleasesPage(url = GITHUB_RELEASES_PAGE) {
  let target;
  try { target = new URL(url); } catch (_) { target = new URL(GITHUB_RELEASES_PAGE); }
  if (target.protocol !== 'https:' || target.hostname !== 'github.com') target = new URL(GITHUB_RELEASES_PAGE);
  await shell.openExternal(target.toString());
  return true;
}

async function openExternalWebUrl(url) {
  let target;
  try { target = new URL(String(url || '')); } catch (_) { throw new Error('Invalid web URL'); }
  if (!['https:', 'http:'].includes(target.protocol)) throw new Error('Only http(s) web URLs can be opened');
  await shell.openExternal(target.toString());
  return true;
}

function ensurePackagedEnvExample(root) {
  if (!app.isPackaged) return;
  const exampleSource = path.join(root, '.env.example');
  const exampleTarget = path.join(app.getPath('userData'), '.env.example');
  if (fs.existsSync(exampleSource) && !fs.existsSync(exampleTarget)) {
    fs.copyFileSync(exampleSource, exampleTarget);
  }
}

function presenceSnapshot() {
  return safePresenceSnapshot({
    supervisorState,
    coreState,
    corePid: coreProcess?.pid || null,
    coreRestarts: coreRestartCount,
    rendererRecoveries,
    heartbeatFailures: coreHeartbeatFailures,
    lastHeartbeatAt,
    appStartedAt,
    coreStartedAt,
    startWithWindows: desktopSettings.startWithWindows,
    notificationsEnabled: desktopSettings.notificationsEnabled,
    launchedInBackground,
    systemSuspended,
  });
}

function broadcastPresence() {
  const snapshot = presenceSnapshot();
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('jarvis-presence', snapshot);
  }
  updateTray(trayState);
  return snapshot;
}

function showDesktopNotification(title, body, {silent = true} = {}) {
  if (!desktopSettings.notificationsEnabled || !Notification.isSupported()) return;
  try {
    const notification = new Notification({
      title,
      body,
      silent,
      icon: path.join(__dirname, 'assets', 'icon.png'),
      groupId: 'jarvis-desktop-presence',
    });
    notification.on('click', showWindow);
    notification.show();
  } catch (_) {
    // Notifications are optional and must never affect supervision.
  }
}

function configureLoginItem(enabled) {
  desktopSettings.startWithWindows = Boolean(enabled);
  saveDesktopSettings();
  if (process.platform === 'win32') {
    const options = windowsLoginItemOptions({
      enabled: desktopSettings.startWithWindows,
      isPackaged: app.isPackaged,
      defaultApp: Boolean(process.defaultApp),
      execPath: process.execPath,
      appPath: app.getAppPath(),
      existsSync: fs.existsSync,
    });
    app.setLoginItemSettings(options);
  } else if (process.platform === 'darwin') {
    app.setLoginItemSettings({openAtLogin: desktopSettings.startWithWindows});
  }
  journalPresence('startup_setting_changed', {enabled: desktopSettings.startWithWindows});
  broadcastPresence();
  return desktopSettings.startWithWindows;
}

function setNotificationsEnabled(enabled) {
  desktopSettings.notificationsEnabled = Boolean(enabled);
  saveDesktopSettings();
  journalPresence('notification_setting_changed', {enabled: desktopSettings.notificationsEnabled});
  broadcastPresence();
  return desktopSettings.notificationsEnabled;
}

function startPresenceBroadcast() {
  clearInterval(presenceBroadcastTimer);
  presenceBroadcastTimer = setInterval(broadcastPresence, PRESENCE_BROADCAST_MS);
}

function stopPresenceBroadcast() {
  clearInterval(presenceBroadcastTimer);
  presenceBroadcastTimer = null;
}

function clearCoreTimers() {
  clearInterval(coreHeartbeatTimer);
  clearTimeout(coreRestartTimer);
  clearTimeout(coreStableTimer);
  coreHeartbeatTimer = null;
  coreRestartTimer = null;
  coreStableTimer = null;
}

function coreJsonRequest(pathname, {headers = {}, timeoutMs = 3000} = {}) {
  return new Promise((resolve, reject) => {
    const target = new URL(String(pathname || '/'), CORE_URL);
    const request = http.request(target, {
      method: 'GET',
      timeout: timeoutMs,
      headers: {...headers, 'Accept': 'application/json'},
    }, (response) => {
      const chunks = [];
      response.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
      response.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let payload = {};
        try { payload = text ? JSON.parse(text) : {}; } catch (_) { payload = {}; }
        if ((response.statusCode || 500) < 200 || (response.statusCode || 500) >= 300) {
          const detail = typeof payload?.detail === 'string' ? payload.detail : `Core returned ${response.statusCode || 500}`;
          reject(new Error(detail));
          return;
        }
        resolve(payload);
      });
    });
    request.on('timeout', () => request.destroy(new Error('Jarvis Core confirmation request timed out.')));
    request.on('error', reject);
    request.end();
  });
}

function focusJarvisPermissionSurface() {
  const target = mainWindow && !mainWindow.isDestroyed() ? mainWindow : null;
  if (!target) return null;
  try { if (target.isMinimized()) target.restore(); } catch (_) {}
  try { if (!target.isVisible()) target.show(); } catch (_) {}
  // A voice-triggered permission request can arrive while another Windows app is
  // foreground. Bring the trusted Jarvis owner window forward before showing the
  // native prompt so Explorer/another app cannot become the accidental owner. Keep
  // each focus attempt independent so an unsupported OS hint cannot suppress the
  // BrowserWindow focus fallback.
  try { if (typeof app.focus === 'function') app.focus({steal: true}); } catch (_) {}
  try { if (typeof target.moveTop === 'function') target.moveTop(); } catch (_) {}
  try { target.focus(); } catch (_) {}
  return target;
}

async function confirmPermissionChallenge(challengeId) {
  const id = String(challengeId || '').trim();
  if (!/^pch_[a-f0-9]{64}$/i.test(id)) throw new Error('Invalid permission confirmation challenge.');
  if (activePermissionConfirmation) {
    throw new Error('Another trusted permission confirmation is already active.');
  }
  const summary = await coreJsonRequest(`/api/permissions/challenges/${encodeURIComponent(id)}/native-summary`, {
    headers: {'X-Jarvis-Desktop-Authority': DESKTOP_CONFIRMATION_AUTHORITY},
  });
  const prompt = String(summary?.prompt || '').trim().slice(0, 240);
  const actionDetail = String(summary?.action_detail || '').trim();
  if (!prompt || !actionDetail) {
    throw new Error('The exact trusted confirmation is unavailable; the action was not authorized.');
  }

  const owner = focusJarvisPermissionSurface();
  // Give Windows one event-loop turn to establish Jarvis as foreground owner before
  // creating the native modal dialog. This prevents unrelated Explorer/app focus.
  await new Promise((resolve) => setImmediate(resolve));
  const confirmationState = {challengeId: id};
  activePermissionConfirmation = confirmationState;
  const persistentAllowAvailable = Boolean(summary?.user_can_always_allow);
  const buttons = persistentAllowAvailable
    ? ['Cancel', 'Allow once', 'Always allow']
    : ['Cancel', 'Allow once'];
  let result;
  try {
    result = await dialog.showMessageBox(owner || undefined, {
      type: 'question',
      title: 'Jarvis permission',
      message: `Permission required. ${prompt}`,
      buttons,
      // Permission prompts are intentionally fail-safe: Enter/Escape never widen
      // authority unless the user explicitly selects a positive button.
      defaultId: 0,
      cancelId: 0,
      noLink: true,
    });
  } finally {
    if (activePermissionConfirmation === confirmationState) activePermissionConfirmation = null;
  }
  const choice = result?.response === 2 && persistentAllowAvailable
    ? 'always_allow'
    : (result?.response === 1 ? 'allow_once' : 'cancel');
  const approved = choice !== 'cancel';
  focusJarvisPermissionSurface();

  if (!approved) return {approved: false, challenge_id: id, choice: 'cancel', persist_allow: false};
  // Bind the exact trusted choice into the HMAC. The renderer may relay this
  // value, but it cannot widen Allow once into Always allow without invalidating
  // the main-process attestation.
  const attestation = crypto.createHmac('sha256', DESKTOP_CONFIRMATION_AUTHORITY)
    .update(`jarvis-permission-confirm-v2:${id}:${choice}`, 'utf8')
    .digest('hex');
  return {
    approved: true,
    challenge_id: id,
    choice,
    attestation,
    persist_allow: choice === 'always_allow',
  };
}


function healthReady(timeoutMs = CORE_HEARTBEAT_TIMEOUT_MS) {
  return new Promise((resolve) => {
    const request = http.get(HEALTH_URL, { timeout: timeoutMs }, (response) => {
      response.resume();
      resolve(response.statusCode === 200);
    });
    request.on('timeout', () => { request.destroy(); resolve(false); });
    request.on('error', () => resolve(false));
  });
}

function corePortInUse(timeoutMs = 600) {
  return new Promise((resolve) => {
    const socket = nodeNet.createConnection({host: '127.0.0.1', port: 8765});
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(value);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
  });
}

async function waitForCore() {
  const started = Date.now();
  while (Date.now() - started < HEALTH_TIMEOUT_MS && !isQuitting && !systemSuspended) {
    if (await healthReady()) return true;
    await new Promise((resolve) => setTimeout(resolve, HEALTH_POLL_MS));
  }
  return false;
}

function startCore(reason = 'startup') {
  if (coreProcess && !coreProcess.killed) return coreProcess;
  const root = runtimeRoot();
  ensurePackagedEnvExample(root);
  const env = buildCoreEnvironment({
    base: process.env,
    apiKey: secureApiKey,
    preferences: alphaPreferences,
    dataDir: app.isPackaged ? runtimeDataPath() : '',
    logsDir: app.isPackaged ? runtimeLogsPath() : '',
    envFile: privateEnvPath(),
    projectRoot: root,
    hosted: app.isPackaged,
    desktopConfirmationAuthority: DESKTOP_CONFIRMATION_AUTHORITY,
  });
  let command;
  let args;
  if (app.isPackaged) {
    command = packagedPython(root);
    args = ['-m', 'apps.core', '--no-browser'];
  } else {
    const python = pythonCommandForDevelopment(root);
    command = python.command;
    args = [...python.prefix, '-m', 'apps.core', '--no-browser'];
  }
  coreState = 'starting';
  supervisorState = 'starting';
  coreHeartbeatFailures = 0;
  journalPresence('core_starting', {reason});
  broadcastPresence();
  coreProcess = spawn(command, args, {
    cwd: root,
    env,
    windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  coreStartedAt = Date.now();
  const startedProcess = coreProcess;
  startedProcess.stdout.on('data', (chunk) => writeCoreLog('stdout', chunk));
  startedProcess.stderr.on('data', (chunk) => writeCoreLog('stderr', chunk));
  startedProcess.on('error', (error) => {
    journalPresence('core_spawn_error', {message: error.message});
    if (coreProcess === startedProcess) coreProcess = null;
    coreState = 'failed';
    supervisorState = 'degraded';
    scheduleCoreRestart('spawn_error');
  });
  startedProcess.on('exit', (code, signal) => {
    const pid = startedProcess.pid;
    const expected = expectedCorePids.delete(pid) || isQuitting || systemSuspended;
    if (coreProcess === startedProcess) coreProcess = null;
    coreStartedAt = null;
    clearInterval(coreHeartbeatTimer);
    coreHeartbeatTimer = null;
    journalPresence('core_exit', {code, signal, expected});
    if (expected) {
      coreState = systemSuspended ? 'suspended' : 'stopped';
      broadcastPresence();
      return;
    }
    coreState = 'failed';
    supervisorState = 'degraded';
    broadcastPresence();
    scheduleCoreRestart(`process_exit_${code ?? 'unknown'}`);
  });
  return startedProcess;
}

function stopCore({expected = true, reason = 'shutdown'} = {}) {
  clearInterval(coreHeartbeatTimer);
  coreHeartbeatTimer = null;
  if (!coreProcess || coreProcess.killed) {
    coreProcess = null;
    coreStartedAt = null;
    return;
  }
  const pid = coreProcess.pid;
  if (expected) expectedCorePids.add(pid);
  journalPresence('core_stopping', {reason, pid});
  if (process.platform === 'win32') {
    spawnSync('taskkill', ['/pid', String(pid), '/T', '/F'], { windowsHide: true });
  } else {
    coreProcess.kill('SIGTERM');
  }
  coreProcess = null;
  coreStartedAt = null;
}

function markCoreHealthy(reason = 'heartbeat') {
  const recovered = coreState !== 'healthy';
  coreState = 'healthy';
  supervisorState = 'healthy';
  coreHeartbeatFailures = 0;
  lastHeartbeatAt = Date.now();
  clearTimeout(coreStableTimer);
  coreStableTimer = setTimeout(() => {
    coreRestartHistory = [];
    journalPresence('core_stable_window_complete');
  }, CORE_STABLE_RESET_MS);
  if (recovered) journalPresence('core_healthy', {reason, pid: coreProcess?.pid || null});
  broadcastPresence();
}

function startCoreHeartbeat() {
  clearInterval(coreHeartbeatTimer);
  coreHeartbeatTimer = setInterval(async () => {
    if (isQuitting || systemSuspended || !coreProcess) return;
    const healthy = await healthReady();
    if (healthy) {
      markCoreHealthy('heartbeat');
      return;
    }
    coreHeartbeatFailures += 1;
    coreState = 'unhealthy';
    supervisorState = 'recovering';
    journalPresence('core_heartbeat_failed', {failures: coreHeartbeatFailures});
    broadcastPresence();
    if (coreHeartbeatFailures >= CORE_FAILURE_THRESHOLD) {
      stopCore({expected: true, reason: 'heartbeat_failure'});
      scheduleCoreRestart('heartbeat_failure');
    }
  }, CORE_HEARTBEAT_MS);
}

async function loadCoreInterface() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  try {
    await mainWindow.loadURL(CORE_URL);
  } catch (error) {
    journalPresence('renderer_load_failed', {message: error.message});
    scheduleRendererRecovery('load_url_failed');
  }
}

async function bootCoreAndLoad(reason = 'startup', {notifyOnRecovery = false} = {}) {
  if (!app.isPackaged) {
    try {
      await ensureDevelopmentRuntime(runtimeRoot());
    } catch (error) {
      coreState = 'failed';
      supervisorState = 'degraded';
      journalPresence('development_runtime_prepare_failed', {message: error.message});
      setLoadingStatus(`Runtime preparation failed: ${error.message}`);
      broadcastPresence();
      return false;
    }
  }
  if (!coreProcess && await corePortInUse()) {
    const jarvisCoreResponding = await healthReady(700);
    coreState = 'blocked';
    supervisorState = 'degraded';
    journalPresence('core_port_conflict', {reason, port: 8765, jarvis_core_responding: jarvisCoreResponding});
    setLoadingStatus(
      jarvisCoreResponding
        ? 'Another Jarvis Core is already running on port 8765. Stop the manually started Core, then restart Jarvis.'
        : 'Port 8765 is already in use. Stop the conflicting process, then restart Jarvis.'
    );
    broadcastPresence();
    return false;
  }
  startCore(reason);
  const ready = await waitForCore();
  if (!ready) {
    coreState = 'failed';
    supervisorState = 'degraded';
    journalPresence('core_start_timeout', {reason});
    broadcastPresence();
    scheduleCoreRestart('startup_timeout');
    return false;
  }
  markCoreHealthy(reason);
  startCoreHeartbeat();
  await loadCoreInterface();
  if (notifyOnRecovery) showDesktopNotification('Jarvis recovered', 'The local Jarvis core restarted successfully.');
  return true;
}

function scheduleCoreRestart(reason) {
  if (isQuitting || systemSuspended || coreRestartTimer) return;
  const now = Date.now();
  coreRestartHistory = pruneTimestamps(coreRestartHistory, now, CORE_RESTART_WINDOW_MS);
  if (coreRestartHistory.length >= CORE_MAX_RESTARTS_PER_WINDOW) {
    coreState = 'circuit_open';
    supervisorState = 'degraded';
    journalPresence('core_restart_circuit_open', {reason, attempts: coreRestartHistory.length});
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.loadFile(path.join(__dirname, 'recovery.html'));
    }
    showDesktopNotification('Jarvis needs attention', 'The local core restarted repeatedly and automatic recovery paused.', {silent: false});
    broadcastPresence();
    return;
  }
  const attempt = coreRestartHistory.length;
  const delay = computeRestartBackoff(attempt, CORE_RESTART_BASE_MS, CORE_RESTART_MAX_MS);
  coreRestartHistory.push(now);
  coreRestartCount += 1;
  coreState = 'restarting';
  supervisorState = 'recovering';
  journalPresence('core_restart_scheduled', {reason, attempt: attempt + 1, delay_ms: delay});
  broadcastPresence();
  coreRestartTimer = setTimeout(async () => {
    coreRestartTimer = null;
    const recovered = await bootCoreAndLoad(`automatic_restart:${reason}`, {notifyOnRecovery: true});
    if (!recovered) scheduleCoreRestart('recovery_failed');
  }, delay);
}

async function manualRestartCore(reason = 'manual') {
  clearTimeout(coreRestartTimer);
  coreRestartTimer = null;
  coreRestartHistory = [];
  if (mainWindow && !mainWindow.isDestroyed()) {
    await mainWindow.loadFile(path.join(__dirname, 'loading.html'));
  }
  stopCore({expected: true, reason});
  const recovered = await bootCoreAndLoad(reason, {notifyOnRecovery: false});
  if (!recovered && mainWindow && !mainWindow.isDestroyed()) {
    await mainWindow.loadFile(path.join(__dirname, 'recovery.html'));
  }
  return recovered;
}

function showWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

function hideWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  saveWindowState();
  mainWindow.hide();
}

function quitJarvis() {
  if (isQuitting) return;
  isQuitting = true;
  saveWindowState();
  clearCoreTimers();
  clearTimeout(rendererRecoveryTimer);
  clearTimeout(rendererUnresponsiveTimer);
  stopPresenceBroadcast();
  stopCore({expected: true, reason: 'quit'});
  journalPresence('application_quit');
  app.quit();
}

function sendRendererCommand(command) {
  if (command !== 'sleep' && command !== 'resume-presence') showWindow();
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('jarvis-command', command);
  }
}

function buildTrayMenu() {
  const snapshot = presenceSnapshot();
  return Menu.buildFromTemplate([
    { label: 'Open Jarvis', click: showWindow },
    { label: 'Hide Jarvis', click: hideWindow },
    { label: 'Reset window size', click: resetWindowBounds },
    { type: 'separator' },
    { label: 'Wake Jarvis', enabled: trayState !== 'awake', click: () => sendRendererCommand('wake') },
    { label: 'Sleep Jarvis', enabled: trayState === 'awake', click: () => sendRendererCommand('sleep') },
    { type: 'separator' },
    {
      label: 'Start with Windows',
      type: 'checkbox',
      checked: desktopSettings.startWithWindows,
      click: (item) => configureLoginItem(item.checked),
    },
    {
      label: 'Desktop notifications',
      type: 'checkbox',
      checked: desktopSettings.notificationsEnabled,
      click: (item) => setNotificationsEnabled(item.checked),
    },
    { type: 'separator' },
    { label: `Core: ${snapshot.coreState}`, enabled: false },
    { label: `Restarts: ${snapshot.coreRestarts}`, enabled: false },
    { label: 'Restart core', click: () => manualRestartCore('tray_restart') },
    { label: 'Export diagnostics', click: () => exportDiagnostics() },
    { label: 'Check for updates', click: async () => {
      const result = await checkForUpdates();
      if (result.updateAvailable) await openReleasesPage(result.releaseUrl);
      else showDesktopNotification('Jarvis updates', result.ok ? 'You are running the latest available release.' : `Update check failed: ${result.message}`, {silent: false});
    }},
    { type: 'separator' },
    { label: 'Quit Jarvis', click: quitJarvis },
  ]);
}

function updateTray(state) {
  trayState = state || trayState || 'unknown';
  if (!tray) return;
  tray.setToolTip(`Jarvis_Real_Time — ${trayState} — core ${coreState}`);
  tray.setContextMenu(buildTrayMenu());
}

function createTray() {
  const iconPath = path.join(__dirname, 'assets', 'tray.png');
  const icon = nativeImage.createFromPath(iconPath);
  tray = new Tray(icon);
  tray.on('click', showWindow);
  updateTray('sleeping');
}

function scheduleRendererRecovery(reason) {
  if (isQuitting || systemSuspended || rendererRecoveryTimer || !mainWindow || mainWindow.isDestroyed()) return;
  const now = Date.now();
  rendererRecoveryHistory = pruneTimestamps(rendererRecoveryHistory, now, RENDERER_RECOVERY_WINDOW_MS);
  if (rendererRecoveryHistory.length >= RENDERER_MAX_RECOVERIES) {
    supervisorState = 'degraded';
    journalPresence('renderer_recovery_circuit_open', {reason});
    mainWindow.loadFile(path.join(__dirname, 'recovery.html'));
    showDesktopNotification('Jarvis interface needs attention', 'The desktop renderer failed repeatedly and automatic reload paused.', {silent: false});
    broadcastPresence();
    return;
  }
  rendererRecoveryHistory.push(now);
  rendererRecoveries += 1;
  supervisorState = 'recovering';
  journalPresence('renderer_recovery_scheduled', {reason, attempt: rendererRecoveryHistory.length});
  broadcastPresence();
  rendererRecoveryTimer = setTimeout(async () => {
    rendererRecoveryTimer = null;
    const ready = await healthReady();
    if (ready) {
      await loadCoreInterface();
      supervisorState = 'healthy';
      journalPresence('renderer_recovered', {reason});
      showDesktopNotification('Jarvis interface recovered', 'The desktop interface reloaded successfully.');
      broadcastPresence();
    } else {
      await manualRestartCore(`renderer_recovery:${reason}`);
    }
  }, 1000);
}

function attachRendererSupervision(window) {
  window.on('unresponsive', () => {
    journalPresence('renderer_unresponsive');
    supervisorState = 'recovering';
    broadcastPresence();
    clearTimeout(rendererUnresponsiveTimer);
    rendererUnresponsiveTimer = setTimeout(() => scheduleRendererRecovery('unresponsive'), RENDERER_UNRESPONSIVE_GRACE_MS);
  });
  window.on('responsive', () => {
    clearTimeout(rendererUnresponsiveTimer);
    rendererUnresponsiveTimer = null;
    if (coreState === 'healthy') supervisorState = 'healthy';
    journalPresence('renderer_responsive');
    broadcastPresence();
  });
  window.webContents.on('render-process-gone', (_event, details) => {
    journalPresence('renderer_process_gone', {reason: details.reason, exit_code: details.exitCode});
    scheduleRendererRecovery(`render_process_${details.reason}`);
  });
  window.webContents.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL, isMainFrame) => {
    if (!isMainFrame || errorCode === -3 || isQuitting) return;
    journalPresence('renderer_did_fail_load', {error_code: errorCode, description: errorDescription, url: validatedURL});
    scheduleRendererRecovery('did_fail_load');
  });
}

async function createWindow() {
  const state = ensureVisibleBounds(loadWindowState());
  mainWindow = new BrowserWindow({
    ...state,
    minWidth: Math.min(MIN_WINDOW_WIDTH, state.width),
    minHeight: Math.min(MIN_WINDOW_HEIGHT, state.height),
    show: false,
    backgroundColor: '#07111d',
    title: 'Jarvis_Real_Time',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false,
    },
  });
  attachRendererSupervision(mainWindow);
  mainWindow.once('ready-to-show', () => {
    mainWindow.setBounds(state, false);
    if (!launchedInBackground) mainWindow.show();
  });
  await mainWindow.loadFile(path.join(__dirname, 'loading.html'));
  mainWindow.on('close', saveWindowState);
  mainWindow.on('move', saveWindowState);
  mainWindow.on('resize', saveWindowState);
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));

  try {
    await ensurePackagedRuntime();
  } catch (error) {
    journalPresence('runtime_prepare_failed', {message: error.message});
    setLoadingStatus(`Runtime preparation failed: ${error.message}`);
    await dialog.showMessageBox(mainWindow, {
      type: 'error',
      title: 'Jarvis runtime preparation failed',
      message: 'Jarvis could not prepare its private local runtime.',
      detail: error.message,
    });
    await mainWindow.loadFile(path.join(__dirname, 'recovery.html'));
    return;
  }
  setLoadingStatus('Starting the private local Python core...');
  const ready = await bootCoreAndLoad('application_start');
  if (!ready && mainWindow && !mainWindow.isDestroyed()) {
    await mainWindow.loadFile(path.join(__dirname, 'recovery.html'));
  }
}

function attachPowerSupervision() {
  powerMonitor.on('suspend', () => {
    systemSuspended = true;
    supervisorState = 'suspended';
    journalPresence('system_suspend');
    sendRendererCommand('sleep');
    stopCore({expected: true, reason: 'system_suspend'});
    coreState = 'suspended';
    broadcastPresence();
  });
  powerMonitor.on('resume', () => {
    systemSuspended = false;
    supervisorState = 'recovering';
    journalPresence('system_resume');
    broadcastPresence();
    setTimeout(async () => {
      await manualRestartCore('system_resume');
      sendRendererCommand('resume-presence');
    }, 750);
  });
  powerMonitor.on('lock-screen', () => {
    journalPresence('screen_locked');
    sendRendererCommand('sleep');
  });
  powerMonitor.on('unlock-screen', () => {
    journalPresence('screen_unlocked');
    sendRendererCommand('resume-presence');
  });
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', showWindow);
  app.whenReady().then(async () => {
    fs.mkdirSync(jarvisDataRoot(), {recursive: true});
    fs.mkdirSync(runtimeDataPath(), {recursive: true});
    fs.mkdirSync(runtimeLogsPath(), {recursive: true});
    app.setAppLogsPath(runtimeLogsPath());
    desktopSettings = loadDesktopSettings();
    await loadSecureSetup();
    configureLoginItem(desktopSettings.startWithWindows);
    ipcMain.on('jarvis-state', (_event, state) => updateTray(state));
    ipcMain.on('jarvis-show-window', showWindow);
    ipcMain.handle('jarvis-presence-get', () => presenceSnapshot());
    ipcMain.handle('jarvis-startup-set', (_event, enabled) => configureLoginItem(Boolean(enabled)));
    ipcMain.handle('jarvis-notifications-set', (_event, enabled) => setNotificationsEnabled(Boolean(enabled)));
    ipcMain.handle('jarvis-notify', (_event, payload = {}) => {
      const title = String(payload?.title || 'Jarvis').slice(0, 120);
      const body = String(payload?.body || '').slice(0, 1000);
      showDesktopNotification(title, body, {silent: false});
      return {ok: true};
    });
    ipcMain.handle('jarvis-core-restart', () => manualRestartCore('renderer_request'));
    ipcMain.handle('jarvis-setup-status', () => setupStatus());
    ipcMain.handle('jarvis-setup-save', (_event, payload) => saveAlphaSetup(payload));
    ipcMain.handle('jarvis-diagnostics-export', () => exportDiagnostics());
    ipcMain.handle('jarvis-update-check', () => checkForUpdates());
    ipcMain.handle('jarvis-release-open', (_event, url) => openReleasesPage(url));
    ipcMain.handle('jarvis-external-open', (_event, url) => openExternalWebUrl(url));
    ipcMain.handle('jarvis-permission-confirm', (_event, challengeId) => confirmPermissionChallenge(challengeId));
    createTray();
    attachPowerSupervision();
    startPresenceBroadcast();
    journalPresence('application_ready', {background: launchedInBackground});
    await createWindow();
  });
}

app.on('window-all-closed', () => {
  quitJarvis();
});

app.on('before-quit', () => {
  isQuitting = true;
  saveWindowState();
  clearCoreTimers();
  stopPresenceBroadcast();
  stopCore({expected: true, reason: 'before_quit'});
});

app.on('will-quit', () => stopCore({expected: true, reason: 'will_quit'}));
process.on('exit', () => stopCore({expected: true, reason: 'process_exit'}));
