'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('jarvisDesktop', {
  platform: process.platform,
  isElectron: true,
  onCommand(callback) {
    if (typeof callback !== 'function') return () => {};
    const handler = (_event, command) => callback(command);
    ipcRenderer.on('jarvis-command', handler);
    return () => ipcRenderer.removeListener('jarvis-command', handler);
  },
  onPresence(callback) {
    if (typeof callback !== 'function') return () => {};
    const handler = (_event, snapshot) => callback(snapshot);
    ipcRenderer.on('jarvis-presence', handler);
    return () => ipcRenderer.removeListener('jarvis-presence', handler);
  },
  getPresence() {
    return ipcRenderer.invoke('jarvis-presence-get');
  },
  setStartWithWindows(enabled) {
    return ipcRenderer.invoke('jarvis-startup-set', Boolean(enabled));
  },
  setNotifications(enabled) {
    return ipcRenderer.invoke('jarvis-notifications-set', Boolean(enabled));
  },
  notify(title, body) {
    return ipcRenderer.invoke('jarvis-notify', {title: String(title || 'Jarvis'), body: String(body || '')});
  },
  restartCore() {
    return ipcRenderer.invoke('jarvis-core-restart');
  },
  getSetupStatus() {
    return ipcRenderer.invoke('jarvis-setup-status');
  },
  saveSetup(payload) {
    return ipcRenderer.invoke('jarvis-setup-save', payload);
  },
  exportDiagnostics() {
    return ipcRenderer.invoke('jarvis-diagnostics-export');
  },
  checkForUpdates() {
    return ipcRenderer.invoke('jarvis-update-check');
  },
  openRelease(url) {
    return ipcRenderer.invoke('jarvis-release-open', url);
  },
  openExternal(url) {
    return ipcRenderer.invoke('jarvis-external-open', String(url || ''));
  },
  confirmPermission(challengeId) {
    return ipcRenderer.invoke('jarvis-permission-confirm', String(challengeId || ''));
  },
  setState(state) {
    ipcRenderer.send('jarvis-state', String(state || 'unknown'));
  },
  showWindow() {
    ipcRenderer.send('jarvis-show-window');
  },
});
