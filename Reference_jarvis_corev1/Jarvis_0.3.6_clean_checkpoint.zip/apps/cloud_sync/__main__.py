from __future__ import annotations

import argparse
from pathlib import Path

import uvicorn

from apps.cloud_sync.server import create_cloud_sync_app
from jarvis.sync import build_development_cloud_vault
from jarvis.billing.metering import PricingCatalog
from jarvis.cloud.provider_operations import build_trusted_provider_gateway
from jarvis.cloud.realtime import RealtimeCoordinator
from jarvis.core.config import ProjectSettings


def main() -> int:
    parser = argparse.ArgumentParser(description="Jarvis Cloud Sync development relay")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8770)
    parser.add_argument("--data", default="data/cloud_sync/cloud_vault.sqlite3")
    args = parser.parse_args()
    project_root = Path(__file__).resolve().parents[2]
    vault_path = Path(args.data)
    vault = build_development_cloud_vault(
        path=vault_path, project_root=project_root, billing_data_dir=vault_path.parent
    )
    settings = ProjectSettings.load(project_root)
    pricing = PricingCatalog.from_json(project_root / "config" / "billing" / "development_pricing.json", production=False)
    provider_gateway = build_trusted_provider_gateway(
        settings=settings, authority=vault.billing_authority, pricing=pricing
    )
    realtime = RealtimeCoordinator(
        settings=settings, authority=vault.billing_authority, pricing=pricing
    )
    uvicorn.run(
        create_cloud_sync_app(
            vault=vault, expose_verification_codes=True, provider_gateway=provider_gateway,
            realtime_coordinator=realtime,
        ),
        host=args.host, port=args.port, log_level="info"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
