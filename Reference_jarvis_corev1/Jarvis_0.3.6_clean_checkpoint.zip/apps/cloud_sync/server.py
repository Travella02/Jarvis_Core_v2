from __future__ import annotations

from collections import defaultdict, deque
import asyncio
import hashlib
from pathlib import Path
import threading
import time
from typing import Any, Callable

from fastapi import FastAPI, Header, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict, Field

from jarvis.sync.models import SUPPORTED_SYNC_SCOPES
from jarvis.billing.payments import PaymentConfigurationError, PaymentCoordinator
from jarvis.cloud.realtime import RealtimeCloudError, RealtimeCloudRejected, RealtimeCloudUncertain, RealtimeCoordinator
from jarvis.cloud.provider_gateway import (
    ProviderOperationInProgress, ProviderOperationRejected, ProviderOperationUncertain, TrustedProviderGateway,
)
from jarvis.sync.vault import CloudDeviceLimitError, CloudVaultStore


class _CloudBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

class CloudRegisterBody(_CloudBody):
    email: str = Field(default="", max_length=320)
    phone: str = Field(default="", max_length=40)
    display_name: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=12, max_length=512)
    installation_id: str = Field(min_length=6, max_length=160)
    device_label: str = Field(default="This device", max_length=120)


class CloudVerifyBody(_CloudBody):
    verification_id: str = Field(min_length=8, max_length=200)
    code: str = Field(min_length=4, max_length=16)


class CloudVerificationResendBody(_CloudBody):
    verification_id: str = Field(min_length=8, max_length=200)


class CloudLoginBody(_CloudBody):
    identifier: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=1, max_length=512)
    installation_id: str = Field(min_length=6, max_length=160)
    device_label: str = Field(default="This device", max_length=120)


class CloudReauthenticateBody(_CloudBody):
    identifier: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=1, max_length=512)
    installation_id: str = Field(min_length=6, max_length=160)


class CloudRecoveryStartBody(_CloudBody):
    identifier: str = Field(min_length=3, max_length=320)


class CloudRecoveryVerifyBody(_CloudBody):
    recovery_id: str = Field(min_length=8, max_length=200)
    code: str = Field(min_length=4, max_length=16)


class CloudRecoveryResendBody(_CloudBody):
    recovery_id: str = Field(min_length=8, max_length=200)


class CloudRecoveryResetBody(_CloudBody):
    recovery_token: str = Field(min_length=16, max_length=512)
    new_password: str = Field(min_length=12, max_length=512)


class CloudPushBody(_CloudBody):
    records: list[dict[str, Any]] = Field(default_factory=list, max_length=500)


class CloudReasoningBody(_CloudBody):
    instructions: str = Field(min_length=1, max_length=100_000)
    input_text: str = Field(min_length=1, max_length=200_000)
    max_output_tokens: int = Field(default=4096, ge=256, le=32768)


class CloudWebResearchBody(_CloudBody):
    user_text: str = Field(min_length=1, max_length=30_000)
    response_mode: str = Field(default="normal", max_length=40)


class CloudSpeechBody(_CloudBody):
    text: str = Field(min_length=1, max_length=12_000)
    instructions: str = Field(default="", max_length=12_000)


class CloudCheckoutBody(_CloudBody):
    product_id: str = Field(min_length=1, max_length=120)


class _SlidingWindowLimiter:
    """Small in-process abuse guard for authentication endpoints.

    Production deployments should also enforce rate limits at the edge/load balancer,
    but the relay must not expose completely unbounded login/verification attempts.
    """

    def __init__(self, *, limit: int = 20, window_seconds: float = 60.0) -> None:
        self.limit = max(1, int(limit))
        self.window_seconds = max(1.0, float(window_seconds))
        self._events: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        cutoff = now - self.window_seconds
        clean = str(key or "unknown")[:500]
        with self._lock:
            events = self._events[clean]
            while events and events[0] <= cutoff:
                events.popleft()
            if len(events) >= self.limit:
                return False
            events.append(now)
            return True


def _bearer(request: Request) -> str:
    value = str(request.headers.get("authorization") or "").strip()
    if not value.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="missing cloud session")
    token = value[7:].strip()
    if not token:
        raise HTTPException(status_code=401, detail="missing cloud session")
    return token


def create_cloud_sync_app(
    path: Path | None = None,
    *,
    vault: CloudVaultStore | None = None,
    expose_verification_codes: bool = False,
    verification_sender: Callable[[str, str, str], None] | None = None,
    provider_gateway: TrustedProviderGateway | None = None,
    realtime_coordinator: RealtimeCoordinator | None = None,
    payment_coordinator: PaymentCoordinator | None = None,
    auth_rate_limit: int = 20,
    auth_rate_window_seconds: float = 60.0,
) -> FastAPI:
    store = vault or CloudVaultStore(path or Path("data/cloud_sync/cloud_vault.sqlite3"))
    app = FastAPI(title="Jarvis Cloud Sync Relay", version="1", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.vault = store
    auth_limiter = _SlidingWindowLimiter(limit=auth_rate_limit, window_seconds=auth_rate_window_seconds)

    if realtime_coordinator is not None:
        @app.on_event("startup")
        async def _start_realtime_recovery() -> None:
            await realtime_coordinator.start()

        @app.on_event("shutdown")
        async def _stop_realtime() -> None:
            await realtime_coordinator.aclose()

    def _rate_key(request: Request, lane: str) -> str:
        host = request.client.host if request.client else "unknown"
        return f"{lane}:{host}"

    def _require_auth_budget(request: Request, lane: str) -> None:
        if not auth_limiter.allow(_rate_key(request, lane)):
            raise HTTPException(status_code=429, detail="too many authentication attempts; try again shortly")

    def _identity(request: Request) -> dict[str, Any]:
        try:
            identity = dict(store.authenticate(_bearer(request)))
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="cloud session expired") from exc
        try:
            store.ensure_billing_account(
                account_id=str(identity.get("account_id") or ""),
                tenant_id=str(identity.get("tenant_id") or ""),
            )
        except (KeyError, ValueError, PermissionError) as exc:
            raise HTTPException(status_code=503, detail="billing state is unavailable") from exc
        return identity

    def _provider_identity(request: Request) -> dict[str, Any]:
        if provider_gateway is None:
            raise HTTPException(status_code=503, detail="Jarvis Cloud provider service is not configured")
        return _identity(request)

    def _websocket_identity(websocket: WebSocket) -> dict[str, Any]:
        if realtime_coordinator is None:
            raise PermissionError("Jarvis Cloud Realtime service is not configured")
        value = str(websocket.headers.get("authorization") or "").strip()
        if not value.lower().startswith("bearer "):
            raise PermissionError("missing cloud session")
        try:
            return dict(store.authenticate(value[7:].strip()))
        except PermissionError as exc:
            raise PermissionError("cloud session expired") from exc

    def _idempotency(request: Request) -> str:
        value = str(request.headers.get("x-jarvis-idempotency-key") or "").strip()
        if not value or len(value) > 200:
            raise HTTPException(status_code=400, detail="valid X-Jarvis-Idempotency-Key is required")
        # The caller controls this correlation value. Persist only a digest so a
        # compromised client cannot turn the billing ledger into secret storage.
        return "idem_sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()

    async def _execute_provider(request: Request, *, operation_key: str, payload: dict[str, Any]) -> dict[str, Any]:
        identity = _provider_identity(request)
        try:
            assert provider_gateway is not None
            return await provider_gateway.execute(
                account_id=str(identity.get("account_id") or ""),
                tenant_id=str(identity.get("tenant_id") or ""),
                operation_key=operation_key,
                idempotency_key=_idempotency(request),
                request=payload,
            )
        except ProviderOperationInProgress as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ProviderOperationUncertain as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except ProviderOperationRejected as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        except PermissionError as exc:
            message = str(exc)
            status = 402 if "allowance" in message.lower() or "balance" in message.lower() else 403
            raise HTTPException(status_code=status, detail=message) from exc
        except (ValueError, KeyError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/health")
    async def health() -> dict[str, Any]:
        return {"ok": True, "service": "jarvis-cloud-sync", "protocol": 1}

    @app.post("/v1/account/register")
    async def register(body: CloudRegisterBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "register")
        if not expose_verification_codes and verification_sender is None:
            raise HTTPException(status_code=503, detail="account verification delivery is not configured")
        try:
            result = dict(store.register_account(**body.model_dump()))
            if result.get("verification_required"):
                contact = result.get("contact") if isinstance(result.get("contact"), dict) else {}
                code = str(result.get("verification_code") or "")
                if verification_sender is not None:
                    verification_sender(str(contact.get("kind") or ""), str(contact.get("value") or ""), code)
                if not expose_verification_codes:
                    result.pop("verification_code", None)
            return result
        except CloudDeviceLimitError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="email/phone or password is incorrect") from exc
        except ValueError as exc:
            message = str(exc)
            status = 409 if "already exists" in message else 400
            raise HTTPException(status_code=status, detail=message) from exc

    @app.post("/v1/account/verify")
    async def verify(body: CloudVerifyBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "verify")
        try:
            return store.verify_registration(**body.model_dump())
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/account/verify/resend")
    async def resend_verification(body: CloudVerificationResendBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "verify_resend")
        if not expose_verification_codes and verification_sender is None:
            raise HTTPException(status_code=503, detail="account verification delivery is not configured")
        try:
            result = dict(store.resend_registration(verification_id=body.verification_id))
            contact = result.get("contact") if isinstance(result.get("contact"), dict) else {}
            code = str(result.get("verification_code") or "")
            if verification_sender is not None:
                verification_sender(str(contact.get("kind") or ""), str(contact.get("value") or ""), code)
            if not expose_verification_codes:
                result.pop("verification_code", None)
            return result
        except PermissionError as exc:
            raise HTTPException(status_code=429, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/account/login")
    async def login(body: CloudLoginBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "login")
        try:
            return store.login_account(**body.model_dump())
        except CloudDeviceLimitError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="email/phone or password is incorrect") from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/account/reauthenticate")
    async def reauthenticate(body: CloudReauthenticateBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "reauthenticate")
        try:
            result = dict(store.reauthenticate_account(
                token=_bearer(request),
                identifier=body.identifier,
                password=body.password,
                installation_id=body.installation_id,
            ))
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="email/phone or password is incorrect") from exc
        if result.get("token"):
            raise HTTPException(status_code=500, detail="reauthentication must not issue a reusable cloud session")
        return result

    @app.post("/v1/account/recovery/start")
    async def recovery_start(body: CloudRecoveryStartBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "recovery_start")
        if not expose_verification_codes and verification_sender is None:
            raise HTTPException(status_code=503, detail="account recovery delivery is not configured")
        result = dict(store.begin_account_recovery(identifier=body.identifier))
        contact = result.get("contact") if isinstance(result.get("contact"), dict) else {}
        code = str(result.get("verification_code") or "")
        value = str(contact.get("value") or "")
        kind = str(contact.get("kind") or "")
        if code and value and verification_sender is not None:
            verification_sender(kind, value, code)
        if not expose_verification_codes:
            result.pop("verification_code", None)
        if isinstance(result.get("contact"), dict):
            result["contact"].pop("value", None)
        return result

    @app.post("/v1/account/recovery/verify")
    async def recovery_verify(body: CloudRecoveryVerifyBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "recovery_verify")
        try:
            return store.verify_account_recovery(recovery_id=body.recovery_id, code=body.code)
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/account/recovery/resend")
    async def recovery_resend(body: CloudRecoveryResendBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "recovery_resend")
        if not expose_verification_codes and verification_sender is None:
            raise HTTPException(status_code=503, detail="account recovery delivery is not configured")
        try:
            result = dict(store.resend_account_recovery(recovery_id=body.recovery_id))
            contact = result.get("contact") if isinstance(result.get("contact"), dict) else {}
            code = str(result.get("verification_code") or "")
            value = str(contact.get("value") or "")
            kind = str(contact.get("kind") or "")
            if code and value and verification_sender is not None:
                verification_sender(kind, value, code)
            if not expose_verification_codes:
                result.pop("verification_code", None)
            if isinstance(result.get("contact"), dict):
                result["contact"].pop("value", None)
            return result
        except PermissionError as exc:
            raise HTTPException(status_code=429, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/account/recovery/reset")
    async def recovery_reset(body: CloudRecoveryResetBody, request: Request) -> dict[str, Any]:
        _require_auth_budget(request, "recovery_reset")
        try:
            return store.reset_account_password(recovery_token=body.recovery_token, new_password=body.new_password)
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/account/logout")
    async def logout(request: Request) -> dict[str, Any]:
        token = _bearer(request)
        store.revoke_session(token)
        return {"revoked": True}

    @app.get("/v1/billing/summary")
    async def billing_summary(request: Request) -> dict[str, Any]:
        identity = _identity(request)
        authority = store.billing_authority
        if authority is None:
            raise HTTPException(status_code=503, detail="Jarvis Cloud billing authority is not configured")
        account_id = str(identity.get("account_id") or "")
        tenant_id = str(identity.get("tenant_id") or "")
        try:
            plan = authority.account_plan(account_id, tenant_id=tenant_id)
            devices = store.list_devices(tenant_id=tenant_id, account_id=account_id)
            summary = authority.store.customer_usage_summary(
                account_id=account_id,
                device_limit=plan.device_limit,
                device_count=len(devices),
                plan_display_name=str(plan.metadata.get("display_name") or plan.key),
            )
            # Deliberately no raw allowance units, provider cost, pricing revision,
            # reservation IDs, margin, or provider usage evidence in this response.
            return summary
        except (KeyError, ValueError) as exc:
            raise HTTPException(status_code=503, detail="billing state is unavailable") from exc
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc

    @app.get("/v1/billing/products")
    async def billing_products(request: Request) -> dict[str, Any]:
        _identity(request)
        if payment_coordinator is None:
            return {"products": [], "checkout_available": False}
        products = payment_coordinator.products.public_products()
        return {"products": products, "checkout_available": bool(products)}

    @app.post("/v1/billing/checkout")
    async def billing_checkout(body: CloudCheckoutBody, request: Request) -> dict[str, Any]:
        identity = _identity(request)
        if payment_coordinator is None:
            raise HTTPException(status_code=503, detail="customer checkout is not configured")
        try:
            return await payment_coordinator.create_checkout(
                account_id=str(identity.get("account_id") or ""),
                tenant_id=str(identity.get("tenant_id") or ""),
                product_key=body.product_id,
                customer_request=True,
            )
        except KeyError as exc:
            # Hidden/internal/development products are indistinguishable from unknown IDs.
            raise HTTPException(status_code=404, detail="payment product was not found") from exc
        except PaymentConfigurationError as exc:
            raise HTTPException(status_code=503, detail="customer checkout is unavailable") from exc
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc

    @app.post("/v1/realtime/session")
    async def realtime_session(request: Request) -> Response:
        if realtime_coordinator is None:
            raise HTTPException(status_code=503, detail="Jarvis Cloud Realtime service is not configured")
        content_type = str(request.headers.get("content-type") or "").split(";", 1)[0].strip().lower()
        if content_type != "application/sdp":
            raise HTTPException(status_code=415, detail="Content-Type must be application/sdp")
        identity = _provider_identity(request)
        body = await request.body()
        if not body or len(body) > 1_000_000:
            raise HTTPException(status_code=413 if body else 400, detail="Realtime SDP offer is empty or too large")
        try:
            offer = body.decode("utf-8")
            answer, public_session_id = await realtime_coordinator.create_session(
                account_id=str(identity.get("account_id") or ""),
                tenant_id=str(identity.get("tenant_id") or ""),
                idempotency_key=_idempotency(request),
                sdp_offer=offer,
            )
        except UnicodeDecodeError as exc:
            raise HTTPException(status_code=400, detail="Realtime SDP offer must be UTF-8") from exc
        except RealtimeCloudRejected as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        except RealtimeCloudUncertain as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except PermissionError as exc:
            message = str(exc)
            status = 402 if "allowance" in message.lower() or "balance" in message.lower() else 403
            raise HTTPException(status_code=status, detail=message) from exc
        except (RealtimeCloudError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return Response(
            content=answer.encode("utf-8"),
            media_type="application/sdp",
            headers={
                "Cache-Control": "no-store",
                "X-Jarvis-Realtime-Session": public_session_id,
            },
        )

    @app.websocket("/v1/realtime/sessions/{session_id}/events")
    async def realtime_events(websocket: WebSocket, session_id: str) -> None:
        if realtime_coordinator is None:
            await websocket.close(code=1013, reason="Realtime service unavailable")
            return
        try:
            identity = _websocket_identity(websocket)
            realtime_coordinator.require_owner(
                session_id=session_id,
                account_id=str(identity.get("account_id") or ""),
                tenant_id=str(identity.get("tenant_id") or ""),
            )
        except (PermissionError, KeyError):
            await websocket.close(code=1008, reason="Realtime session unauthorized")
            return
        await websocket.accept()

        async def receive_controls() -> None:
            while True:
                payload = await websocket.receive_json()
                if not isinstance(payload, dict):
                    raise PermissionError("Realtime control must be an object")
                await realtime_coordinator.control(
                    session_id=session_id,
                    account_id=str(identity.get("account_id") or ""),
                    tenant_id=str(identity.get("tenant_id") or ""),
                    message=payload,
                )

        async def send_events() -> None:
            async for event in realtime_coordinator.subscribe(
                session_id=session_id,
                account_id=str(identity.get("account_id") or ""),
                tenant_id=str(identity.get("tenant_id") or ""),
            ):
                await websocket.send_json(event)

        receiver = asyncio.create_task(receive_controls())
        sender = asyncio.create_task(send_events())
        try:
            done, pending = await asyncio.wait({receiver, sender}, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            for task in done:
                task.result()
        except (WebSocketDisconnect, PermissionError, ValueError, KeyError):
            pass
        finally:
            receiver.cancel()
            sender.cancel()
            await realtime_coordinator.control_lost(session_id=session_id)
            try:
                await websocket.close()
            except Exception:
                pass

    @app.post("/v1/provider/reasoning")
    async def provider_reasoning(body: CloudReasoningBody, request: Request) -> dict[str, Any]:
        return await _execute_provider(request, operation_key="reasoning", payload=body.model_dump())

    @app.post("/v1/provider/web-research")
    async def provider_web_research(body: CloudWebResearchBody, request: Request) -> dict[str, Any]:
        return await _execute_provider(request, operation_key="web_research", payload=body.model_dump())

    @app.post("/v1/provider/wake-transcription")
    async def provider_wake_transcription(request: Request) -> dict[str, Any]:
        content_type = str(request.headers.get("content-type") or "").split(";", 1)[0].strip().lower()
        if content_type not in {"audio/wav", "audio/wave", "audio/x-wav"}:
            raise HTTPException(status_code=415, detail="Content-Type must be audio/wav")
        audio = await request.body()
        if not audio or len(audio) > 8_000_000:
            raise HTTPException(status_code=413 if audio else 400, detail="wake audio is empty or too large")
        return await _execute_provider(request, operation_key="wake_transcription", payload={"audio_bytes": audio})

    @app.post("/v1/provider/speech")
    async def provider_speech(body: CloudSpeechBody, request: Request) -> dict[str, Any]:
        return await _execute_provider(request, operation_key="speech", payload=body.model_dump())

    _CONNECTED_LANES = {
        "plan": "connected_actions.plan",
        "compose-new-email": "connected_actions.compose_new_email",
        "compose-reply": "connected_actions.compose_reply",
        "extract-calendar-event": "connected_actions.extract_calendar_event",
        "reason-contextually": "connected_actions.reason_contextually",
        "respond": "connected_actions.respond",
    }

    @app.post("/v1/provider/connected-actions/{lane}")
    async def provider_connected_actions(lane: str, request: Request) -> dict[str, Any]:
        operation_key = _CONNECTED_LANES.get(str(lane or ""))
        if operation_key is None:
            raise HTTPException(status_code=404, detail="connected-action provider lane was not found")
        try:
            payload = await request.json()
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="request body must be JSON") from exc
        if not isinstance(payload, dict):
            raise HTTPException(status_code=400, detail="request body must be an object")
        return await _execute_provider(request, operation_key=operation_key, payload=payload)

    @app.post("/v1/provider/browser-plan")
    async def provider_browser_plan(request: Request) -> dict[str, Any]:
        try:
            payload = await request.json()
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="request body must be JSON") from exc
        if not isinstance(payload, dict):
            raise HTTPException(status_code=400, detail="request body must be an object")
        return await _execute_provider(request, operation_key="browser_planning", payload=payload)

    @app.get("/v1/devices")
    async def devices(request: Request, x_jarvis_tenant: str = Header(default="")) -> dict[str, Any]:
        try:
            identity = store.authenticate(_bearer(request))
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="cloud session expired") from exc
        tenant_id = str(identity.get("tenant_id") or "")
        if x_jarvis_tenant and x_jarvis_tenant != tenant_id:
            raise HTTPException(status_code=403, detail="tenant mismatch")
        current_id = str(identity.get("device_id") or "")
        rows = store.list_devices(tenant_id=tenant_id, account_id=str(identity.get("account_id") or ""))
        return {"devices": [{**dict(row), "current": str(row.get("id") or "") == current_id} for row in rows]}

    @app.post("/v1/devices/{device_id}/revoke")
    async def revoke_device(device_id: str, request: Request, x_jarvis_tenant: str = Header(default="")) -> dict[str, Any]:
        try:
            identity = store.authenticate(_bearer(request))
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="cloud session expired") from exc
        tenant_id = str(identity.get("tenant_id") or "")
        if x_jarvis_tenant and x_jarvis_tenant != tenant_id:
            raise HTTPException(status_code=403, detail="tenant mismatch")
        try:
            return store.revoke_device(
                tenant_id=tenant_id, account_id=str(identity.get("account_id") or ""), device_id=device_id,
                current_device_id=str(identity.get("device_id") or ""),
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/sync/push")
    async def push(body: CloudPushBody, request: Request, x_jarvis_tenant: str = Header(default="")) -> dict[str, Any]:
        try:
            identity = store.authenticate(_bearer(request))
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="cloud session expired") from exc
        tenant_id = str(identity.get("tenant_id") or "")
        if x_jarvis_tenant and x_jarvis_tenant != tenant_id:
            raise HTTPException(status_code=403, detail="tenant mismatch")
        try:
            # The relay, not the client payload, owns device attribution and scope
            # enforcement. A compromised client must not be able to spoof another
            # device or upload a new sensitive scope merely by naming it.
            for record in body.records:
                scope = str(record.get("scope") or "").strip()
                if scope not in SUPPORTED_SYNC_SCOPES:
                    raise ValueError("unsupported cloud sync scope")
            return store.push(
                tenant_id=tenant_id,
                account_id=str(identity.get("account_id") or ""),
                records=body.records,
                authenticated_device_id=str(identity.get("device_id") or ""),
            )
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/v1/sync/pull")
    async def pull(
        request: Request,
        after_revision: int = Query(default=0, ge=0),
        x_jarvis_tenant: str = Header(default=""),
    ) -> dict[str, Any]:
        try:
            identity = store.authenticate(_bearer(request))
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="cloud session expired") from exc
        tenant_id = str(identity.get("tenant_id") or "")
        if x_jarvis_tenant and x_jarvis_tenant != tenant_id:
            raise HTTPException(status_code=403, detail="tenant mismatch")
        try:
            return store.pull(
                tenant_id=tenant_id, account_id=str(identity.get("account_id") or ""), after_revision=after_revision
            )
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc

    return app
