from __future__ import annotations

import argparse
import logging
import os
import sys
import threading
import webbrowser
from pathlib import Path


from jarvis.core.config import ConfigurationError, ProjectSettings
from jarvis.security.hygiene import run_sensitive_data_cleanup
from jarvis.security.redaction import SensitiveDataFormatter, redact_text


def _run_startup_hygiene(settings: ProjectSettings) -> None:
    """Finish one-time legacy cleanup before Core opens any durable log handles.

    Windows does not allow the hygiene migration to atomically replace ``core.log``
    while ``logging.FileHandler`` has that file open. Running the bounded migration
    first preserves the atomic-rewrite guarantee and ensures a failed cleanup simply
    retries on the next Core launch.
    """
    try:
        run_sensitive_data_cleanup(data_dir=settings.data_dir, logs_dir=settings.logs_dir)
    except Exception as exc:
        print(
            f"WARNING: Sensitive-data legacy cleanup will retry on next launch: {redact_text(str(exc))}",
            file=sys.stderr,
        )


def _configure_logging(settings: ProjectSettings) -> None:
    settings.logs_dir.mkdir(parents=True, exist_ok=True)
    formatter = SensitiveDataFormatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    handlers = [
        logging.StreamHandler(),
        logging.FileHandler(settings.logs_dir / "core.log", encoding="utf-8"),
    ]
    for handler in handlers:
        handler.setFormatter(formatter)
    logging.basicConfig(level=logging.INFO, handlers=handlers)


def _diagnostic(settings: ProjectSettings) -> int:
    print(f"{settings.project_name} {settings.version}")
    print("Core state: sleeping")
    print("Realtime transport: WebRTC unified interface")
    print(f"Model: {settings.realtime_model}")
    print(f"Voice: {settings.realtime_voice}")
    print(f"Turn detection: {settings.turn_detection_profile}")
    print(f"Response mode: {settings.response_mode}")
    print(f"Simulation enabled: {'yes' if settings.simulation_enabled else 'no'}")
    print(f"Context token limit: {settings.context_token_limit}")
    print(f"Context retention ratio: {settings.context_retention_ratio}")
    print(f"Wake keyword: {settings.wake_keyword}")
    print(f"Wake profile: {settings.wake_profile}")
    print(f"Spoken sleep acknowledgement: {'enabled' if settings.sleep_acknowledgement_enabled else 'disabled'}")
    print(f"Wake transcription model: {settings.wake_transcription_model}")
    print(f"Wake VAD threshold: {settings.wake_vad_threshold}")
    print(f"Wake VAD silence: {settings.wake_vad_silence_ms} ms")
    print(f"Idle sleep: {settings.idle_sleep_seconds} seconds")
    print(f"Idle warning: {settings.idle_warning_seconds} seconds")
    print(f"Session safety limit: {settings.session_max_minutes} minutes")
    print(f"Session budget: warning ${settings.budget_session_warning_usd:.2f}, hard ${settings.budget_session_hard_usd:.2f}")
    print(f"Daily budget: warning ${settings.budget_daily_warning_usd:.2f}, hard ${settings.budget_daily_hard_usd:.2f}")
    print(f"Monthly budget: warning ${settings.budget_monthly_warning_usd:.2f}, hard ${settings.budget_monthly_hard_usd:.2f}")
    print(f"Provider mode: {settings.provider_mode}")
    if settings.provider_mode == "direct_development":
        print(f"Development provider key configured: {'yes' if settings.key_configured else 'no'}")
    else:
        print("Provider authority: Jarvis Cloud")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Jarvis_Real_Time local Realtime Voice Lab")
    parser.add_argument("--diagnostic", action="store_true", help="print safe configuration and exit")
    parser.add_argument("--no-browser", action="store_true", help="do not open the local voice lab automatically")
    args = parser.parse_args(argv)

    try:
        configured_root = os.environ.get("JARVIS_PROJECT_ROOT", "").strip()
        project_root = Path(configured_root).expanduser().resolve() if configured_root else Path(__file__).resolve().parents[2]
        settings = ProjectSettings.load(project_root)
        if args.diagnostic:
            return _diagnostic(settings)
        if settings.provider_mode == "direct_development" and not settings.key_configured:
            settings.require_openai_api_key()
    except ConfigurationError as exc:
        print(f"CONFIGURATION ERROR: {redact_text(str(exc))}", file=sys.stderr)
        return 2

    # The one-time migration must run before FileHandler opens ``logs/core.log``.
    # create_app keeps its default cleanup path for alternate/embedded entry points,
    # while the normal desktop-owned Core startup disables the redundant second pass.
    _run_startup_hygiene(settings)

    import uvicorn
    from apps.core.server import create_app

    _configure_logging(settings)
    app = create_app(settings, run_legacy_hygiene=False)
    print(f"{settings.project_name} {settings.version}")
    print(f"Realtime Voice Lab: {settings.voice_lab_url}")
    if settings.provider_mode == "direct_development":
        print("Development provider mode: provider credentials remain in the local developer process.")
    else:
        print("Hosted provider mode: paid provider authority and credentials remain on Jarvis Cloud.")

    if settings.open_browser and not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(settings.voice_lab_url)).start()

    uvicorn.run(
        app,
        host=settings.host,
        port=settings.port,
        log_level="info",
        access_log=False,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
