"""Headless Jarvis core application."""
