from __future__ import annotations

import asyncio
import hashlib
import hmac
from datetime import datetime
import io
import logging
import re
from time import perf_counter
import wave
from contextlib import asynccontextmanager
from html import escape
from pathlib import Path
import json
from typing import Any
from uuid import UUID, uuid4
from urllib.parse import parse_qs

from fastapi import FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from jarvis.actions import ActionStore, ConnectedActionService, OpenAIActionPlanner
from jarvis.accounts import (
    AccountAlreadyExists,
    AccountBindingConflict,
    AccountInvalidCredentials,
    AccountNotAuthenticated,
    AccountService,
    AccountValidationError,
)
from jarvis.accounts.web_auth import BrowserAuthCoordinator, BrowserAuthError
from jarvis.accounts.portal import render_auth_portal
from jarvis.browser import BrowserAutomationService, BrowserBridge, OpenAIBrowserPlanner
from jarvis.browser.bridge import BrowserBridgeDisconnected, BrowserBridgeError
from jarvis.computer import ComputerAppService
from jarvis.cloud import (
    HostedActionPlanner, HostedBrowserPlanner, HostedSpeechGateway, HostedTextGateway,
    HostedWakeTranscriptionGateway, HostedWebIntelligenceGateway, HostedRealtimeGateway, JarvisCloudProviderClient,
)
from jarvis.capabilities import CapabilityRegistry
from jarvis.core.config import (
    ConfigurationError,
    ProjectSettings,
    SUPPORTED_REALTIME_VOICES,
    SUPPORTED_SPEECH_PROVIDERS,
    SUPPORTED_TURN_DETECTION_PROFILES,
    SUPPORTED_WAKE_PROFILES,
)
from jarvis.core.events import EventType
from jarvis.core.time_context import client_time_context, effective_user_timezone
from jarvis.core.runtime import RealtimeRuntime
from jarvis.core.state import StateMachine, StateTransitionError
from jarvis.intelligence.web_search import (
    OpenAIWebIntelligenceGateway,
    WebIntelligenceError,
    WebIntelligenceService,
)
from jarvis.intelligence.text import (
    OpenAITextGateway,
    TextProviderError,
    build_detailed_answer_instructions,
)
from jarvis.intelligence.speech import OpenAISpeechGateway, SpeechProviderError, SpeechProviderRouter
from jarvis.intelligence.voice_response import (
    action_locked_speech_facts,
    build_action_naturalization_input,
    build_action_naturalization_instructions,
    build_natural_voice_instructions,
    speech_delivery_instructions,
    validate_naturalized_action_text,
)
from jarvis.intelligence.realtime import (
    OpenAIRealtimeGateway,
    RealtimeProviderError,
    build_session_config,
    validate_turn_detection_profile,
    validate_voice,
)
from jarvis.memory import MemoryKind, MemoryPrivacy, MemoryService, MemorySource
from jarvis.identity import VoiceProfileService, VoiceQualityError
from jarvis.integrations import GoogleIntegrationError, GoogleWorkspaceGateway
from jarvis.intelligence.transcription import (
    OpenAIWakeTranscriptionGateway,
    TranscriptionProviderError,
)
from jarvis.observability.event_journal import EventJournal
from jarvis.observability.usage import (
    SUPPORTED_RESPONSE_MODES,
    public_pricing,
    validate_response_mode,
)
from jarvis.observability.usage_ledger import BudgetLimits, UsageLedger
from jarvis.security.game_mode import GameModeService
from jarvis.permissions import (
    PermissionContext, PermissionGateError, PermissionRequest, PermissionService,
    PreferenceMode, build_permission_service,
)
from jarvis.security.redaction import redact_text
from jarvis.security.hygiene import run_sensitive_data_cleanup
from jarvis.security.secret_store import LocalSecretStore
from jarvis.sync import (
    CloudSyncError,
    CloudSyncNotAuthenticated,
    CloudSyncService,
    CloudVaultStore,
    HttpCloudSyncTransport,
    build_development_cloud_vault,
    LocalVaultTransport,
    SyncStateStore,
)

LOGGER = logging.getLogger("jarvis.realtime")
CLIENT_HEADER = "voice-lab-v1"
MAX_NATIVE_PERMISSION_REVIEW_CHARS = 256_000
_PERMISSION_ATTESTATION_PREFIX = "jarvis-permission-confirm-v2:"
_PERMISSION_NATIVE_ALLOW_ONCE = "allow_once"
_PERMISSION_NATIVE_ALWAYS_ALLOW = "always_allow"
_PERMISSION_NATIVE_CHOICES = {_PERMISSION_NATIVE_ALLOW_ONCE, _PERMISSION_NATIVE_ALWAYS_ALLOW}


def _permission_native_attestation(secret: str, challenge_id: str, choice: str = _PERMISSION_NATIVE_ALLOW_ONCE) -> str:
    normalized_choice = str(choice or "").strip().casefold()
    if normalized_choice not in _PERMISSION_NATIVE_CHOICES:
        raise ValueError("invalid trusted permission choice")
    return hmac.new(
        str(secret or "").encode("utf-8"),
        f"{_PERMISSION_ATTESTATION_PREFIX}{str(challenge_id or '')}:{normalized_choice}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def _valid_permission_native_attestation(secret: str, challenge_id: str, choice: str, supplied: str) -> bool:
    authority = str(secret or "").strip()
    normalized_choice = str(choice or "").strip().casefold()
    candidate = str(supplied or "").strip().casefold()
    if not authority or normalized_choice not in _PERMISSION_NATIVE_CHOICES or len(candidate) != 64:
        return False
    expected = _permission_native_attestation(authority, challenge_id, normalized_choice)
    return hmac.compare_digest(candidate, expected)


class AccountSignupBody(BaseModel):
    email: str = Field(default="", max_length=320)
    phone: str = Field(default="", max_length=40)
    display_name: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=1, max_length=512)
    device_label: str = Field(default="", max_length=120)


class AccountLoginBody(BaseModel):
    identifier: str = Field(default="", max_length=320)
    email: str = Field(default="", max_length=320)
    password: str = Field(min_length=1, max_length=512)
    device_label: str = Field(default="", max_length=120)


class AccountVerifyBody(BaseModel):
    verification_id: str = Field(min_length=8, max_length=200)
    code: str = Field(min_length=4, max_length=16)

class BrowserAuthCompleteBody(BaseModel):
    attempt_id: str = Field(min_length=8, max_length=200)
    poll_token: str = Field(min_length=16, max_length=512)


class AccountProfileBody(BaseModel):
    display_name: str = Field(min_length=1, max_length=120)


class CloudSyncEnableBody(BaseModel):
    enabled: bool


class CloudSyncScopeBody(BaseModel):
    enabled: bool


class CloudSyncConnectBody(BaseModel):
    password: str = Field(min_length=1, max_length=512)


class PermissionPreferenceBody(BaseModel):
    mode: str = Field(pattern="^(default|allow|ask|deny)$")


class ClientEventBody(BaseModel):
    type: str = Field(min_length=1, max_length=100)
    payload: dict[str, Any] = Field(default_factory=dict)
    correlation_id: UUID | None = None


class ComputerAppLaunchBody(BaseModel):
    user_text: str = Field(min_length=1, max_length=1000)
    actor: str | None = Field(default=None, max_length=160)
    actor_scope_id: str | None = Field(default=None, max_length=240)
    session_id: str = Field(min_length=1, max_length=240)


class ComputerAppAliasBody(BaseModel):
    alias: str = Field(min_length=1, max_length=160)
    app_query: str = Field(min_length=1, max_length=260)
    actor: str | None = Field(default=None, max_length=160)


class BrowserTurnBody(BaseModel):
    user_text: str = Field(min_length=1, max_length=12_000)
    actor: str | None = Field(default=None, max_length=160)
    actor_scope_id: str | None = Field(default=None, max_length=240)
    session_id: str = Field(min_length=1, max_length=240)
    usage_session_id: str | None = Field(default=None, max_length=240)
    conversation_context: str = Field(default="", max_length=20_000)
    response_mode: str = Field(default="normal", min_length=1, max_length=32)
    task_id: str = Field(min_length=1, max_length=200)
    contextual: bool = False


class BrowserCancelBody(BaseModel):
    reason: str = Field(default="user_interrupt", max_length=160)


class WebIntelligenceTurnBody(BaseModel):
    user_text: str = Field(min_length=1, max_length=20_000)
    actor: str | None = Field(default=None, max_length=160)
    session_id: str = Field(min_length=1, max_length=240)
    usage_session_id: str | None = Field(default=None, max_length=240)
    response_mode: str = Field(default="normal", min_length=1, max_length=32)
    task_id: str = Field(default="", max_length=200)


class WebSourceOpenBody(BaseModel):
    task_id: str = Field(default="", max_length=200)


class MemoryEventBody(BaseModel):
    content: str = Field(min_length=1, max_length=200_000)
    source: MemorySource
    kind: MemoryKind
    actor: str | None = Field(default=None, max_length=160)
    occurred_at: datetime | None = None
    timezone_name: str | None = Field(default=None, max_length=80)
    session_id: str | None = Field(default=None, max_length=200)
    source_event_id: str | None = Field(default=None, max_length=240)
    idempotency_key: str | None = Field(default=None, max_length=240)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    privacy: MemoryPrivacy = MemoryPrivacy.PRIVATE
    category_path: list[str] | None = Field(default=None, max_length=12)
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemoryConsolidationBody(BaseModel):
    reason: str = Field(default="manual", max_length=200)
    mode: str = Field(default="safe", pattern="^(safe|analyze)$")


class ProactiveRefreshBody(BaseModel):
    reason: str = Field(default="manual", max_length=200)


class ProactiveUpdateBody(BaseModel):
    action: str = Field(pattern="^(complete|dismiss|reopen|snooze)$")
    snooze_minutes: int | None = Field(default=None, ge=15, le=43200)


class MemoryUpdateBody(BaseModel):
    content: str | None = Field(default=None, min_length=1, max_length=200_000)
    actor: str | None = Field(default=None, min_length=1, max_length=160)
    category_path: list[str] | None = Field(default=None, max_length=12)
    privacy: MemoryPrivacy | None = None
    status: str | None = Field(default=None, pattern="^(active|completed|dismissed|superseded|outdated|incorrect|forgotten)$")
    important: bool | None = None


class MemoryLifecycleBody(BaseModel):
    status: str = Field(pattern="^(active|completed|dismissed|superseded|outdated|incorrect|forgotten)$")
    reason: str = Field(default="user_request", max_length=240)
    source_event_id: str | None = Field(default=None, max_length=80)


class MemoryFactLifecycleBody(BaseModel):
    status: str = Field(pattern="^(current|historical|completed|dismissed|superseded|uncertain|incorrect)$")
    reason: str = Field(default="user_request", max_length=240)
    source_event_id: str | None = Field(default=None, max_length=80)


class MemoryRelationshipLifecycleBody(BaseModel):
    status: str = Field(pattern="^(current|historical|completed|dismissed|superseded|uncertain|incorrect)$")
    reason: str = Field(default="user_request", max_length=240)
    source_event_id: str | None = Field(default=None, max_length=80)


class MemoryCommandBody(BaseModel):
    content: str = Field(min_length=1, max_length=20_000)
    command_event_id: str | None = Field(default=None, max_length=80)
    session_id: str | None = Field(default=None, max_length=200)
    actor: str | None = Field(default=None, max_length=160)


class MemoryContextQueryBody(BaseModel):
    query: str = Field(min_length=1, max_length=20_000)
    actor: str | None = Field(default=None, max_length=160)
    session_id: str | None = Field(default=None, max_length=200)
    fact_limit: int = Field(default=14, ge=1, le=50)
    event_limit: int = Field(default=10, ge=1, le=50)
    proactive_limit: int = Field(default=6, ge=1, le=20)
    character_limit: int = Field(default=6200, ge=1000, le=20_000)


class MemoryEntityMergeBody(BaseModel):
    source_id: str = Field(min_length=1, max_length=80)
    target_id: str = Field(min_length=1, max_length=80)


class MemoryUndoBody(BaseModel):
    operation_id: str | None = Field(default=None, max_length=80)


class PersonProfileUpdateBody(BaseModel):
    display_name: str | None = Field(default=None, min_length=1, max_length=160)
    preferred_name: str | None = Field(default=None, max_length=160)
    relationship_to_owner: str | None = Field(default=None, max_length=80)
    role: str | None = Field(default=None, max_length=160)
    access_scope: str | None = Field(default=None, pattern="^(owner|household|business|guest|restricted)$")
    retention_policy: str | None = Field(default=None, pattern="^(permanent|session|ask|none)$")
    trusted: bool | None = None
    notes: str | None = Field(default=None, max_length=4000)
    voice_status: str | None = Field(default=None, pattern="^(not_enrolled|pending|enrolled|disabled|failed)$")
    face_status: str | None = Field(default=None, pattern="^(not_enrolled|pending|enrolled|disabled|failed)$")


class PersonAliasBody(BaseModel):
    alias: str = Field(min_length=1, max_length=160)


class PersonAddressNamesBody(BaseModel):
    action: str = Field(pattern="^(add|remove|replace|clear)$")
    names: list[str] = Field(default_factory=list, max_length=12)
    source_event_id: str | None = Field(default=None, max_length=240)


class PersonPermissionBody(BaseModel):
    memory_scope: str = Field(min_length=1, max_length=80)
    access_level: str = Field(pattern="^(none|read|contribute|manage)$")


class PersonRelationshipBody(BaseModel):
    source_id: str = Field(min_length=1, max_length=80)
    relationship: str = Field(min_length=1, max_length=80)
    target_id: str = Field(min_length=1, max_length=80)
    status: str = Field(default="current", pattern="^(current|historical|uncertain|incorrect)$")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    source_event_id: str | None = Field(default=None, max_length=80)


class EventAttributionBody(BaseModel):
    person_entity_id: str = Field(min_length=1, max_length=80)
    reason: str = Field(default="user_correction", max_length=120)
    source_event_id: str | None = Field(default=None, max_length=80)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)


class VoiceProfileUpdateBody(BaseModel):
    enabled: bool | None = None
    threshold: float | None = Field(default=None, ge=0.50, le=0.99)


class SpeakerSessionBindingBody(BaseModel):
    session_id: str = Field(min_length=1, max_length=200)
    session_speaker_id: str = Field(min_length=1, max_length=120)
    person_name: str = Field(min_length=1, max_length=160)
    address_names: list[str] = Field(default_factory=list, max_length=12)


class UsageRecordBody(BaseModel):
    response_id: str = Field(min_length=1, max_length=200)
    session_id: str = Field(min_length=1, max_length=200)
    model: str = Field(min_length=1, max_length=120)
    response_mode: str = Field(min_length=1, max_length=32)
    usage: dict[str, Any] = Field(default_factory=dict)


class DetailedTextAnswerBody(BaseModel):
    user_text: str = Field(min_length=1, max_length=20_000)
    actor: str | None = Field(default=None, max_length=160)
    conversation_context: str = Field(default="", max_length=30_000)
    response_mode: str = Field(min_length=1, max_length=32)
    session_id: str = Field(min_length=1, max_length=200)


class NaturalVoiceReplyBody(BaseModel):
    user_text: str = Field(min_length=1, max_length=20_000)
    actor: str | None = Field(default=None, max_length=160)
    speaker_name: str | None = Field(default=None, max_length=160)
    speaker_entity_id: str | None = Field(default=None, max_length=80)
    speaker_status: str | None = Field(default=None, max_length=40)
    session_speaker_id: str | None = Field(default=None, max_length=120)
    address_names: list[str] = Field(default_factory=list, max_length=12)
    conversation_context: str = Field(default="", max_length=30_000)
    memory_context: str = Field(default="", max_length=20_000)
    response_mode: str = Field(min_length=1, max_length=32)
    session_id: str = Field(min_length=1, max_length=200)
    timezone_name: str = Field(default="", max_length=80)
    client_local_now: str = Field(default="", max_length=80)
    personality: str | None = Field(default=None, max_length=40)


class SpeechSynthesisBody(BaseModel):
    text: str = Field(min_length=1, max_length=12_000)
    provider: str | None = Field(default=None, max_length=32)
    voice: str | None = Field(default=None, max_length=80)
    response_mode: str = Field(min_length=1, max_length=32)
    session_id: str = Field(min_length=1, max_length=200)
    personality: str | None = Field(default=None, max_length=40)
    user_text: str = Field(default="", max_length=2_000)
    response_purpose: str = Field(default="", max_length=120)
    delivery: str = Field(default="", max_length=4_000)


class ConnectedActionTurnBody(BaseModel):
    user_text: str = Field(min_length=1, max_length=20_000)
    actor: str | None = Field(default=None, max_length=160)
    conversation_context: str = Field(default="", max_length=30_000)
    response_mode: str = Field(min_length=1, max_length=32)
    session_id: str = Field(min_length=1, max_length=200)
    usage_session_id: str | None = Field(default=None, max_length=200)
    timezone_name: str = Field(default="UTC", max_length=100)
    client_local_now: str = Field(default="", max_length=80)
    personality: str | None = Field(default=None, max_length=40)


class ConnectedActionDecisionBody(BaseModel):
    response_mode: str = Field(default="normal", min_length=1, max_length=32)
    user_text: str = Field(default="", max_length=2_000)
    session_id: str = Field(default="", max_length=200)


class ConnectedActionDraftEditBody(BaseModel):
    recipients: list[str] = Field(default_factory=list, max_length=50)
    cc: list[str] = Field(default_factory=list, max_length=50)
    bcc: list[str] = Field(default_factory=list, max_length=50)
    subject: str = Field(default="", max_length=998)
    body: str = Field(default="", max_length=200_000)
    actor: str | None = Field(default=None, max_length=160)
    session_id: str = Field(default="", max_length=200)


class TaskCreateBody(BaseModel):
    title: str = Field(min_length=1, max_length=500)
    notes: str = Field(default="", max_length=20_000)
    actor: str | None = Field(default=None, max_length=160)
    priority: str = Field(default="normal", pattern="^(low|normal|high|urgent)$")
    due_at: str = Field(default="", max_length=80)
    reminder_at: str = Field(default="", max_length=80)
    timezone_name: str = Field(default="UTC", max_length=100)
    client_local_now: str = Field(default="", max_length=80)
    recurrence: str = Field(default="none", pattern="^(none|daily|weekly|monthly|weekdays)$")
    session_id: str = Field(default="", max_length=200)


class TaskUpdateBody(BaseModel):
    title: str | None = Field(default=None, max_length=500)
    notes: str | None = Field(default=None, max_length=20_000)
    priority: str | None = Field(default=None, pattern="^(low|normal|high|urgent)$")
    due_at: str | None = Field(default=None, max_length=80)
    reminder_at: str | None = Field(default=None, max_length=80)
    timezone_name: str = Field(default="UTC", max_length=100)
    client_local_now: str = Field(default="", max_length=80)
    recurrence: str | None = Field(default=None, pattern="^(none|daily|weekly|monthly|weekdays)$")
    actor: str | None = Field(default=None, max_length=160)


def _is_loopback(host: str | None) -> bool:
    return host in {"127.0.0.1", "::1", "localhost", "testclient", None}


def _budget_limits(settings: ProjectSettings) -> BudgetLimits:
    return BudgetLimits(
        session_warning=settings.budget_session_warning_usd,
        session_hard=settings.budget_session_hard_usd,
        daily_warning=settings.budget_daily_warning_usd,
        daily_hard=settings.budget_daily_hard_usd,
        monthly_warning=settings.budget_monthly_warning_usd,
        monthly_hard=settings.budget_monthly_hard_usd,
    )


def _wav_duration_seconds(audio_bytes: bytes) -> float:
    try:
        with wave.open(io.BytesIO(audio_bytes), "rb") as source:
            frames = source.getnframes()
            rate = source.getframerate()
            channels = source.getnchannels()
            width = source.getsampwidth()
    except (wave.Error, EOFError) as exc:
        raise ValueError("wake audio must be a valid WAV file") from exc
    if rate <= 0 or channels != 1 or width != 2:
        raise ValueError("wake audio must be mono 16-bit PCM WAV")
    duration = frames / rate
    if not 0.1 <= duration <= 30.0:
        raise ValueError("wake audio duration must be between 0.1 and 30 seconds")
    return duration


def create_app(
    settings: ProjectSettings | None = None,
    *,
    gateway: OpenAIRealtimeGateway | None = None,
    runtime: RealtimeRuntime | None = None,
    usage_ledger: UsageLedger | None = None,
    transcription_gateway: OpenAIWakeTranscriptionGateway | None = None,
    text_gateway: OpenAITextGateway | None = None,
    speech_gateway: Any | None = None,
    memory_service: MemoryService | None = None,
    account_service: AccountService | None = None,
    cloud_sync_service: CloudSyncService | None = None,
    action_planner: OpenAIActionPlanner | None = None,
    google_gateway: GoogleWorkspaceGateway | None = None,
    action_service: ConnectedActionService | None = None,
    computer_app_service: ComputerAppService | None = None,
    browser_bridge: BrowserBridge | None = None,
    browser_planner: OpenAIBrowserPlanner | None = None,
    browser_service: BrowserAutomationService | None = None,
    web_intelligence_gateway: OpenAIWebIntelligenceGateway | None = None,
    web_intelligence_service: WebIntelligenceService | None = None,
    permission_service: PermissionService | None = None,
    run_legacy_hygiene: bool = True,
) -> FastAPI:
    resolved = settings or ProjectSettings.load()
    if run_legacy_hygiene:
        try:
            run_sensitive_data_cleanup(data_dir=resolved.data_dir, logs_dir=resolved.logs_dir)
        except Exception as exc:
            # Alternate/embedded entry points still get bounded migration protection.
            # Normal desktop startup runs this before opening logs/core.log and passes
            # run_legacy_hygiene=False here to avoid a second pass with an open handle.
            LOGGER.warning("Sensitive-data legacy cleanup will retry: %s", redact_text(str(exc)))
    event_runtime = runtime or RealtimeRuntime(
        state_machine=StateMachine(),
        journal=EventJournal(resolved.logs_dir / "realtime_events.jsonl"),
    )
    provider = gateway
    wake_transcriber = transcription_gateway or OpenAIWakeTranscriptionGateway(resolved)
    text_provider = text_gateway or OpenAITextGateway(resolved)
    speech_provider = speech_gateway or SpeechProviderRouter(resolved)
    planner = action_planner or OpenAIActionPlanner(resolved)
    google = google_gateway or GoogleWorkspaceGateway(resolved)
    ledger = usage_ledger or UsageLedger(resolved.data_dir / "realtime_usage.jsonl")
    accounts = account_service or AccountService(
        resolved.data_dir / "accounts" / "accounts.sqlite3",
        data_namespace=resolved.local_tenant_id,
    )
    memory = memory_service or MemoryService(
        resolved.data_dir / "memory" / "jarvis_memory.sqlite3",
        local_user_name=resolved.local_user_name,
    )
    voice_profiles = VoiceProfileService(
        memory.store,
        resolved.data_dir / "identity" / "voice_profiles",
        tenant_id=resolved.local_tenant_id,
        recognition_threshold=resolved.speaker_recognition_threshold,
        likely_threshold=resolved.speaker_recognition_likely_threshold,
        minimum_samples=resolved.speaker_recognition_minimum_samples,
    )
    actions = action_service or ConnectedActionService(
        resolved,
        planner=planner,
        google=google,
        store=ActionStore(resolved.data_dir / "actions" / "connected_actions.sqlite3"),
        memory_service=memory,
    )
    if cloud_sync_service is not None:
        cloud_sync = cloud_sync_service
    else:
        sync_transport = None
        sync_transport_name = "unconfigured"
        if resolved.cloud_sync_endpoint:
            sync_transport = HttpCloudSyncTransport(
                resolved.cloud_sync_endpoint,
                timeout_seconds=resolved.cloud_sync_timeout_seconds,
            )
            sync_transport_name = "https"
        elif resolved.simulation_enabled:
            # Development-only relay so the sync engine can be exercised locally.
            # Packaged production builds use the hosted endpoint supplied at build/deploy time.
            sync_transport = LocalVaultTransport(
                build_development_cloud_vault(
                    path=resolved.data_dir / "sync" / "development_cloud_vault.sqlite3",
                    project_root=resolved.project_root,
                    billing_data_dir=resolved.data_dir,
                )
            )
            sync_transport_name = "development_local_vault"
        cloud_sync = CloudSyncService(
            accounts=accounts,
            task_store=actions.tasks.store,
            memory=memory,
            state=SyncStateStore(resolved.data_dir / "sync" / "sync_state.sqlite3"),
            secret_store=LocalSecretStore(resolved.data_dir / "connected_accounts"),
            transport=sync_transport,
            service_endpoint=resolved.cloud_sync_endpoint,
            transport_name=sync_transport_name,
        )
    permissions = permission_service or build_permission_service(
        project_root=resolved.project_root,
        data_dir=resolved.data_dir,
    )
    # Ephemeral trusted-desktop review text. PermissionStore intentionally keeps
    # only hashes/fingerprints; this bounded map exists only for the lifetime of
    # Core so a compromised renderer cannot make the native prompt generic or
    # misleading about which exact action the user is approving.
    permission_native_details: dict[str, str] = {}
    # Connected Actions is constructed before account/cloud services so it can be
    # reused by tests and alternate hosts. Attach the central permission authority
    # only after account-scoped permission storage is available.
    actions.permission_service = permissions

    def _hosted_client() -> JarvisCloudProviderClient:
        return JarvisCloudProviderClient(
            resolved.cloud_sync_endpoint, token_getter=cloud_sync.provider_access_token,
            timeout_seconds=max(30, resolved.cloud_sync_timeout_seconds),
        )

    if provider is None:
        provider = HostedRealtimeGateway(_hosted_client()) if resolved.provider_mode == "hosted" else OpenAIRealtimeGateway(resolved)

    if resolved.provider_mode == "hosted":
        # Production/customer mode never falls back to customer provider keys. All
        # paid intelligence uses narrow authenticated Jarvis Cloud operations.
        if transcription_gateway is None:
            wake_transcriber = HostedWakeTranscriptionGateway(_hosted_client())
        if text_gateway is None:
            text_provider = HostedTextGateway(_hosted_client())
        if speech_gateway is None:
            speech_provider = HostedSpeechGateway(_hosted_client())
        if action_planner is None:
            planner = HostedActionPlanner(_hosted_client())
            actions.planner = planner

    computer_apps = computer_app_service or ComputerAppService(resolved, permission_service=permissions)
    if computer_app_service is not None:
        computer_apps.permission_service = permissions
    game_mode = GameModeService(
        enabled=bool(getattr(resolved, "game_mode_enabled", True)),
        catalog_provider=computer_apps.catalog.all,
    )
    computer_apps.game_mode = game_mode
    event_runtime.game_mode_service = game_mode

    def _complete_permission_reauth(purpose: Any, _remote: Any) -> None:
        gm = game_mode.status(refresh=False)
        game_status = "active" if gm.get("active") else ("pending" if gm.get("pending_games") else "inactive")
        context = PermissionContext(
            account_id=str(purpose.get("account_id") or ""),
            tenant_id=str(purpose.get("tenant_id") or ""),
            device_id=str(purpose.get("device_id") or ""),
            actor_id=str(purpose.get("actor_id") or ""),
            session_id=str(purpose.get("session_id") or ""),
            channel="reauth",
            cloud_verified=True,
            game_mode_status=game_status,
        )
        # Password proof establishes only a short-lived identity assurance window.
        # It must not consume the exact permission challenge or mint an action grant;
        # the trusted desktop still reviews and approves each exact sensitive action.
        permissions.validate_authenticated_challenge(str(purpose.get("challenge_id") or ""), context)

    browser_auth = BrowserAuthCoordinator(
        accounts=accounts,
        cloud_sync=cloud_sync,
        reauth_callback=_complete_permission_reauth,
        recent_reauth_ttl_seconds=resolved.security_reauth_window_seconds,
    )
    browser_bridge_service = browser_bridge or BrowserBridge()
    browser_planner_service = browser_planner or (
        HostedBrowserPlanner(_hosted_client()) if resolved.provider_mode == "hosted" else OpenAIBrowserPlanner(resolved)
    )
    browser_actions = browser_service or BrowserAutomationService(
        resolved,
        bridge=browser_bridge_service,
        planner=browser_planner_service,
        game_mode=game_mode,
        max_steps=getattr(resolved, "browser_max_steps", 12),
        permission_service=permissions,
    )
    if browser_service is not None:
        browser_actions.permission_service = permissions
    web_gateway = web_intelligence_gateway or (
        HostedWebIntelligenceGateway(_hosted_client()) if resolved.provider_mode == "hosted" else OpenAIWebIntelligenceGateway(resolved)
    )
    web_intelligence = web_intelligence_service or WebIntelligenceService(
        resolved,
        gateway=web_gateway,
        browser_bridge=browser_bridge_service,
    )
    # Capability providers can inspect live connected-action, computer-action, and browser state through the runtime.
    event_runtime.connected_action_service = actions
    event_runtime.google_workspace_gateway = google
    event_runtime.computer_app_service = computer_apps
    event_runtime.browser_bridge = browser_bridge_service
    event_runtime.browser_automation_service = browser_actions
    event_runtime.web_intelligence_service = web_intelligence
    event_runtime.permission_service = permissions
    capability_registry = CapabilityRegistry(resolved, runtime=event_runtime)
    memory.consolidator.policy.max_events = resolved.memory_consolidation_max_events
    memory.consolidator.policy.auto_apply_safe = resolved.memory_consolidation_auto_apply_safe
    memory.proactive.policy.minimum_priority = resolved.memory_proactive_minimum_priority
    memory.proactive.policy.surface_priority = resolved.memory_proactive_surface_priority
    memory.proactive.policy.relevance_threshold = resolved.memory_proactive_relevance_threshold
    memory.proactive.policy.cooldown_minutes = resolved.memory_proactive_cooldown_minutes
    limits = _budget_limits(resolved)
    static_root = resolved.project_root / "apps" / "desktop" / "lab"
    proactive_refresh_signal = asyncio.Event()

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        consolidation_task: asyncio.Task[None] | None = None
        proactive_task: asyncio.Task[None] | None = None

        async def consolidation_loop() -> None:
            await asyncio.sleep(resolved.memory_consolidation_startup_delay_seconds)
            while True:
                try:
                    should_run = await asyncio.to_thread(
                        memory.should_consolidate,
                        event_threshold=resolved.memory_consolidation_event_threshold,
                        interval_minutes=resolved.memory_consolidation_interval_minutes,
                    )
                    if should_run:
                        result = await asyncio.to_thread(
                            memory.consolidate, reason="scheduled_idle", mode="safe"
                        )
                        LOGGER.info(
                            "Memory consolidation %s completed: %s profiles, %s findings",
                            result.get("run_id"), result.get("profiles_updated"), result.get("findings_created"),
                        )
                except asyncio.CancelledError:
                    raise
                except Exception:
                    LOGGER.exception("Scheduled memory consolidation failed")
                await asyncio.sleep(max(60, resolved.memory_consolidation_interval_minutes * 60))

        async def proactive_loop() -> None:
            interval_seconds = max(60, resolved.memory_proactive_interval_minutes * 60)
            startup_seconds = min(5, resolved.memory_consolidation_startup_delay_seconds + 5)
            timeout_seconds = startup_seconds
            while True:
                reason = "scheduled_proactive"
                try:
                    try:
                        await asyncio.wait_for(proactive_refresh_signal.wait(), timeout=timeout_seconds)
                        proactive_refresh_signal.clear()
                        reason = "automatic_memory_event"
                        debounce = resolved.memory_proactive_event_debounce_ms / 1000
                        await asyncio.sleep(debounce)
                        # Coalesce bursts from one spoken turn while never losing a later correction.
                        while proactive_refresh_signal.is_set():
                            proactive_refresh_signal.clear()
                            await asyncio.sleep(debounce)
                    except TimeoutError:
                        reason = "scheduled_proactive"
                    result = await asyncio.to_thread(memory.refresh_proactive, reason=reason)
                    LOGGER.info(
                        "Proactive memory %s completed (%s): %s created, %s updated, %s corrected, %s completed",
                        result.get("run_id"), reason, result.get("items_created"), result.get("items_updated"),
                        result.get("items_corrected"), result.get("items_completed"),
                    )
                except asyncio.CancelledError:
                    raise
                except Exception:
                    LOGGER.exception("Automatic proactive-memory refresh failed")
                timeout_seconds = interval_seconds

        if resolved.computer_actions_enabled:
            computer_apps.start_background_prewarm()
        game_mode.start()
        if resolved.memory_enabled and resolved.memory_consolidation_enabled:
            consolidation_task = asyncio.create_task(consolidation_loop(), name="jarvis-memory-consolidation")
        if resolved.memory_enabled and resolved.memory_proactive_enabled:
            proactive_task = asyncio.create_task(proactive_loop(), name="jarvis-proactive-memory")
        try:
            yield
        finally:
            game_mode.stop()
            for task in (consolidation_task, proactive_task):
                if task is not None:
                    task.cancel()
            await asyncio.gather(*(task for task in (consolidation_task, proactive_task) if task is not None), return_exceptions=True)
        await browser_bridge_service.close()
        closers = []
        for candidate in (provider, wake_transcriber, text_provider, speech_provider, planner, google, browser_planner_service, web_gateway, cloud_sync):
            closer = getattr(candidate, "aclose", None)
            if callable(closer):
                closers.append(closer())
        if closers:
            await asyncio.gather(*closers, return_exceptions=True)

    app = FastAPI(
        title="Jarvis_Real_Time Core",
        version=resolved.version,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
        lifespan=lifespan,
    )
    app.state.settings = resolved
    app.state.runtime = event_runtime
    app.state.gateway = provider
    app.state.transcription_gateway = wake_transcriber
    app.state.text_gateway = text_provider
    app.state.speech_gateway = speech_provider
    app.state.action_planner = planner
    app.state.google_gateway = google
    app.state.action_service = actions
    app.state.computer_app_service = computer_apps
    app.state.game_mode_service = game_mode
    app.state.browser_bridge = browser_bridge_service
    app.state.browser_planner = browser_planner_service
    app.state.browser_service = browser_actions
    app.state.web_intelligence_gateway = web_gateway
    app.state.web_intelligence_service = web_intelligence
    app.state.usage_ledger = ledger
    app.state.memory = memory
    app.state.cloud_sync = cloud_sync
    app.state.browser_auth = browser_auth
    app.state.voice_profiles = voice_profiles
    app.state.capabilities = capability_registry

    app.mount("/static", StaticFiles(directory=static_root), name="static")

    @app.middleware("http")
    async def local_only(request: Request, call_next):
        if not _is_loopback(request.client.host if request.client else None):
            return JSONResponse(status_code=403, content={"error": "Jarvis voice lab is loopback-only"})
        path = request.url.path
        # Production Jarvis is account-gated and online-only. Development simulation
        # keeps a backend bypass so regression tests and setup diagnostics can run
        # before account enrollment; the desktop UI still enforces the same gate.
        setup_surface = (
            path == "/" or path.startswith("/static/") or path in {"/api/health", "/api/config"}
            or path.startswith("/api/account/") or path.startswith("/api/sync/")
        )
        if not resolved.simulation_enabled and path.startswith("/api/") and not setup_surface:
            token = request.cookies.get(accounts.cookie_name)
            session = accounts.session(token, touch=False)
            verified = bool(session and (session.get("account") or {}).get("verified"))
            connected = bool(session and cloud_sync.status(token).get("connected"))
            if not (session and verified and connected):
                return JSONResponse(
                    status_code=401,
                    content={"detail": "A verified online Jarvis account is required before using assistant features."},
                )
        response = await call_next(request)
        if path == "/" or path.startswith("/static/"):
            response.headers["Cache-Control"] = "no-store, max-age=0"
            response.headers["Pragma"] = "no-cache"
        return response

    async def _google_callback_response(
        *,
        code: str | None,
        state: str | None,
        error: str | None,
    ) -> HTMLResponse:
        if error:
            message = escape(f"Google connection was cancelled: {error}")
            return HTMLResponse(
                f"<html><body style='font-family:sans-serif;background:#07131f;color:#d9f4ff;padding:40px'><h2>Jarvis Google connection</h2><p>{message}</p><p>You can close this tab.</p></body></html>",
                status_code=400,
            )
        if not code or not state:
            return HTMLResponse(
                "<html><body><h2>Jarvis Google connection</h2><p>The authorization response was incomplete.</p></body></html>",
                status_code=400,
            )
        try:
            status = await google.complete_authorization(code=code, state=state)
        except GoogleIntegrationError as exc:
            return HTMLResponse(
                f"<html><body style='font-family:sans-serif;background:#07131f;color:#d9f4ff;padding:40px'><h2>Jarvis Google connection</h2><p>{escape(str(exc))}</p><p>You can close this tab and try again.</p></body></html>",
                status_code=exc.status_code,
            )
        email = escape(status.email or "your Google account")
        return HTMLResponse(
            f"<html><body style='font-family:sans-serif;background:#07131f;color:#d9f4ff;padding:40px'><h2>Google connected</h2><p>Jarvis is connected to {email}.</p><p>You can close this tab and return to Jarvis.</p></body></html>"
        )

    @app.get("/", include_in_schema=False, response_model=None)
    async def index(
        code: str | None = Query(default=None),
        state: str | None = Query(default=None),
        error: str | None = Query(default=None),
    ) -> Response:
        if code is not None or state is not None or error is not None:
            return await _google_callback_response(code=code, state=state, error=error)
        return FileResponse(static_root / "index.html")

    @app.get("/api/health")
    async def health() -> dict[str, Any]:
        return {
            "project": resolved.project_name,
            "version": resolved.version,
            "state": event_runtime.state_machine.current_state.value,
            "key_configured": (resolved.key_configured if resolved.provider_mode == "direct_development" else cloud_sync.connected),
            "provider_mode": resolved.provider_mode,
            "model": (resolved.realtime_model if resolved.provider_mode == "direct_development" else "jarvis-cloud"),
            "voice": resolved.realtime_voice,
            "turn_detection_profile": resolved.turn_detection_profile,
            "response_mode": resolved.response_mode,
            "wake_keyword": resolved.wake_keyword,
            "wake_profile": resolved.wake_profile,
            "sleep_acknowledgement_enabled": resolved.sleep_acknowledgement_enabled,
            "wake_transcription_model": resolved.wake_transcription_model,
            "idle_sleep_seconds": resolved.idle_sleep_seconds,
            "idle_warning_seconds": resolved.idle_warning_seconds,
            "session_max_minutes": resolved.session_max_minutes,
            "memory_enabled": resolved.memory_enabled,
            "memory_transcription_enabled": resolved.memory_transcription_enabled,
            "memory_transcription_model": resolved.memory_transcription_model,
            "memory_consolidation_enabled": resolved.memory_consolidation_enabled,
            "memory_consolidation_interval_minutes": resolved.memory_consolidation_interval_minutes,
            "memory_consolidation_event_threshold": resolved.memory_consolidation_event_threshold,
            "memory_proactive_enabled": resolved.memory_proactive_enabled,
            "memory_proactive_interval_minutes": resolved.memory_proactive_interval_minutes,
            "memory_proactive_event_debounce_ms": resolved.memory_proactive_event_debounce_ms,
            "memory_stats": memory.stats() if resolved.memory_enabled else None,
            "capability_counts": capability_registry.snapshot()["counts"],
            "dual_channel_answers_enabled": resolved.dual_channel_answers_enabled,
            "text_model": (resolved.text_model if resolved.provider_mode == "direct_development" else "jarvis-cloud"),
            "speech_enabled": resolved.speech_enabled,
            "speech_provider": (resolved.speech_provider if resolved.provider_mode == "direct_development" else "jarvis-cloud"),
            "speech_model": (resolved.speech_model if resolved.provider_mode == "direct_development" else "jarvis-cloud"),
            "speech_voice": (resolved.speech_voice if resolved.provider_mode == "direct_development" else "server-default"),
            "elevenlabs_configured": (resolved.elevenlabs_configured if resolved.provider_mode == "direct_development" else False),
            "elevenlabs_model": (resolved.elevenlabs_model if resolved.provider_mode == "direct_development" else ""),
            "voice_personality": resolved.voice_personality,
            "connected_actions_enabled": resolved.connected_actions_enabled,
            "computer_actions_enabled": resolved.computer_actions_enabled,
            "browser_actions_enabled": bool(getattr(resolved, "browser_actions_enabled", True)),
            "browser_max_steps": int(getattr(resolved, "browser_max_steps", 12)),
            "browser_status": browser_actions.status(),
            "web_intelligence_enabled": bool(resolved.key_configured) if resolved.provider_mode == "direct_development" else cloud_sync.connected,
            "web_intelligence_model": resolved.action_model if resolved.provider_mode == "direct_development" else "jarvis-cloud",
            "web_intelligence_status": web_intelligence.status(),
            "computer_app_status": computer_apps.status(),
            "action_model": resolved.action_model,
            "google_oauth_configured": resolved.google_oauth_configured,
        }

    def _account_status_payload(token: str | None, *, touch: bool = True) -> dict[str, Any]:
        payload = accounts.status(token, touch=touch)
        sync_status = cloud_sync.status(token)
        payload["cloud_sync"] = {
            "enabled": bool(sync_status.get("enabled")),
            "available": bool(sync_status.get("available")),
            "connected": bool(sync_status.get("connected")),
            "verification": sync_status.get("verification"),
            "status": (sync_status.get("last_run") or {}).get("status") or ("ready" if sync_status.get("available") else "service_unavailable"),
            "portable_scopes": list(sync_status.get("portable_scopes") or []),
            "local_only_scopes": list(sync_status.get("local_only_scopes") or []),
            "open_conflicts": int(sync_status.get("open_conflicts") or 0),
            "transport": str((sync_status.get("service") or {}).get("transport") or ""),
            "message": str(sync_status.get("message") or ""),
        }
        return payload

    @app.get("/api/config")
    async def safe_config(request: Request) -> dict[str, Any]:
        local_person = memory.local_person() if resolved.memory_enabled else None
        account_status = _account_status_payload(request.cookies.get(accounts.cookie_name), touch=False)
        return {
            "project": resolved.project_name,
            "version": resolved.version,
            "key_configured": (resolved.key_configured if resolved.provider_mode == "direct_development" else cloud_sync.connected),
            "provider_mode": resolved.provider_mode,
            "model": (resolved.realtime_model if resolved.provider_mode == "direct_development" else "jarvis-cloud"),
            "default_voice": resolved.realtime_voice,
            "voices": list(SUPPORTED_REALTIME_VOICES),
            "default_turn_detection_profile": resolved.turn_detection_profile,
            "turn_detection_profiles": list(SUPPORTED_TURN_DETECTION_PROFILES),
            "default_response_mode": resolved.response_mode,
            "response_modes": list(SUPPORTED_RESPONSE_MODES),
            "response_mode_profiles": {
                mode: {
                    "max_words": resolved.response_mode_max_words[mode],
                    "max_sentences": resolved.response_mode_max_sentences[mode],
                    "max_output_tokens": resolved.response_mode_max_output_tokens[mode],
                }
                for mode in SUPPORTED_RESPONSE_MODES
            },
            "simulation_enabled": resolved.simulation_enabled,
            "test_auto_sleep": resolved.test_auto_sleep,
            "context_token_limit": resolved.context_token_limit,
            "context_retention_ratio": resolved.context_retention_ratio,
            "wake_keyword": resolved.wake_keyword,
            "default_wake_profile": resolved.wake_profile,
            "wake_profiles": list(SUPPORTED_WAKE_PROFILES),
            "sleep_acknowledgement_enabled": resolved.sleep_acknowledgement_enabled,
            "wake_transcription_model": resolved.wake_transcription_model,
            "wake_vad_threshold": resolved.wake_vad_threshold,
            "wake_vad_silence_ms": resolved.wake_vad_silence_ms,
            "wake_vad_min_speech_ms": resolved.wake_vad_min_speech_ms,
            "wake_vad_max_speech_ms": resolved.wake_vad_max_speech_ms,
            "wake_vad_preroll_ms": resolved.wake_vad_preroll_ms,
            "idle_sleep_seconds": resolved.idle_sleep_seconds,
            "idle_warning_seconds": resolved.idle_warning_seconds,
            "session_max_minutes": resolved.session_max_minutes,
            "pricing_usd_per_million": public_pricing() if resolved.provider_mode == "direct_development" else {},
            "budgets": limits.to_dict() if resolved.provider_mode == "direct_development" else {},
            "transport": "WebRTC unified interface",
            "memory_enabled": resolved.memory_enabled,
            "memory_transcription_enabled": resolved.memory_transcription_enabled,
            "memory_transcription_model": resolved.memory_transcription_model,
            "memory_proactive_enabled": resolved.memory_proactive_enabled,
            "memory_proactive_interval_minutes": resolved.memory_proactive_interval_minutes,
            "memory_proactive_event_debounce_ms": resolved.memory_proactive_event_debounce_ms,
            "memory_proactive_minimum_priority": resolved.memory_proactive_minimum_priority,
            "memory_proactive_surface_priority": resolved.memory_proactive_surface_priority,
            "memory_proactive_cooldown_minutes": resolved.memory_proactive_cooldown_minutes,
            "local_user_name": resolved.local_user_name,
            "local_user_entity_id": str(local_person.get("id") or "") if local_person else "",
            "local_user_display_name": str(local_person.get("name") or resolved.local_user_name) if local_person else resolved.local_user_name,
            "local_user_address_names": list(local_person.get("active_address_names") or []) if local_person else [],
            "local_user_primary_address_name": str(local_person.get("primary_address_name") or "") if local_person else "",
            "local_tenant_id": resolved.local_tenant_id,
            "account_foundation_enabled": True,
            "account_required": True,
            "online_required": True,
            "account_signed_in": bool(account_status["signed_in"]),
            "account_verified": bool(account_status.get("verified")),
            "account_ready": bool(account_status.get("signed_in") and account_status.get("verified") and (account_status.get("cloud_sync") or {}).get("connected")),
            "account_tenant_id": str((account_status.get("tenant") or {}).get("id") or ""),
            "cloud_sync_available": bool((account_status.get("cloud_sync") or {}).get("available")),
            "cloud_sync_enabled": bool((account_status.get("cloud_sync") or {}).get("enabled")),
            "cloud_sync_transport": str((account_status.get("cloud_sync") or {}).get("transport") or ""),
            "speaker_recognition_enabled": resolved.speaker_recognition_enabled,
            "speaker_recognition_threshold": resolved.speaker_recognition_threshold,
            "speaker_recognition_likely_threshold": resolved.speaker_recognition_likely_threshold,
            "speaker_recognition_minimum_samples": resolved.speaker_recognition_minimum_samples,
            "speaker_recognition_local_only": True,
            "capability_registry_enabled": True,
            "dual_channel_answers_enabled": resolved.dual_channel_answers_enabled,
            "text_model": resolved.text_model if resolved.provider_mode == "direct_development" else "jarvis-cloud",
            "text_reasoning_effort": resolved.text_reasoning_effort if resolved.provider_mode == "direct_development" else "cloud-owned",
            "detailed_text_max_output_tokens": resolved.detailed_text_max_output_tokens,
            "speech_enabled": resolved.speech_enabled,
            "speech_provider": resolved.speech_provider if resolved.provider_mode == "direct_development" else "jarvis-cloud",
            "speech_providers": list(SUPPORTED_SPEECH_PROVIDERS) if resolved.provider_mode == "direct_development" else ["jarvis-cloud"],
            "speech_provider_ready": ({
                "openai": resolved.key_configured,
                "elevenlabs": resolved.elevenlabs_configured,
            } if resolved.provider_mode == "direct_development" else {"jarvis-cloud": cloud_sync.connected}),
            "speech_model": resolved.speech_model if resolved.provider_mode == "direct_development" else "jarvis-cloud",
            "speech_voice": resolved.speech_voice if resolved.provider_mode == "direct_development" else "server-default",
            "elevenlabs_model": resolved.elevenlabs_model if resolved.provider_mode == "direct_development" else "",
            "elevenlabs_voice_id": resolved.elevenlabs_voice_id if (resolved.provider_mode == "direct_development" and resolved.elevenlabs_configured) else "",
            "voice_personality": resolved.voice_personality,
            "voice_personalities": ["classic", "casual", "warm", "direct", "witty"],
            "connected_actions_enabled": resolved.connected_actions_enabled,
            "computer_actions_enabled": resolved.computer_actions_enabled,
            "game_mode_enabled": bool(getattr(resolved, "game_mode_enabled", True)),
            "game_mode_status": game_mode.status(refresh=False),
            "browser_actions_enabled": bool(getattr(resolved, "browser_actions_enabled", True)),
            "browser_max_steps": int(getattr(resolved, "browser_max_steps", 12)),
            "browser_status": browser_actions.status(),
            "web_intelligence_enabled": bool(resolved.key_configured) if resolved.provider_mode == "direct_development" else cloud_sync.connected,
            "web_intelligence_model": resolved.action_model,
            "web_intelligence_status": web_intelligence.status(),
            "computer_deep_search_enabled": resolved.computer_deep_search_enabled,
            "computer_deep_search_timeout_seconds": resolved.computer_deep_search_timeout_seconds,
            "computer_app_status": computer_apps.status(),
            "action_model": resolved.action_model,
            "action_reasoning_effort": resolved.action_reasoning_effort,
            "action_confirmation_ttl_minutes": resolved.action_confirmation_ttl_minutes,
            "google_oauth_configured": resolved.google_oauth_configured,
        }

    @app.get("/api/account/status")
    async def account_status(request: Request) -> dict[str, Any]:
        return _account_status_payload(request.cookies.get(accounts.cookie_name))

    def _permission_context(
        request: Request,
        *,
        channel: str = "desktop",
        actor_id: str = "",
        session_id: str = "",
        allow_development_fallback: bool = False,
    ) -> PermissionContext:
        status = _account_status_payload(request.cookies.get(accounts.cookie_name), touch=False)
        if not status.get("signed_in") or not status.get("verified"):
            if allow_development_fallback and bool(getattr(resolved, "simulation_enabled", False)):
                gm = game_mode.status(refresh=False)
                game_status = "active" if gm.get("active") else ("pending" if gm.get("pending_games") else "inactive")
                return PermissionContext(
                    account_id=str(resolved.local_user_id),
                    tenant_id=str(resolved.local_tenant_id),
                    device_id=str(accounts.installation_id),
                    actor_id=str(actor_id or resolved.local_user_id),
                    session_id=str(session_id or "development_executor"),
                    channel=channel,
                    cloud_verified=True,
                    game_mode_status=game_status,
                )
            raise HTTPException(status_code=401, detail="verified Jarvis account is required")
        account = dict(status.get("account") or {})
        tenant = dict(status.get("tenant") or {})
        device = dict(status.get("device") or {})
        account_id = str(account.get("id") or "").strip()
        tenant_id = str(tenant.get("id") or "").strip()
        device_id = str(device.get("id") or (status.get("installation") or {}).get("id") or "").strip()
        if not account_id or not tenant_id or not device_id:
            raise HTTPException(status_code=409, detail="account/device permission scope is incomplete")
        gm = game_mode.status(refresh=False)
        game_status = "active" if gm.get("active") else ("pending" if gm.get("pending_games") else "inactive")
        return PermissionContext(
            account_id=account_id,
            tenant_id=tenant_id,
            device_id=device_id,
            actor_id=str(actor_id or account.get("id") or ""),
            session_id=str(session_id or "desktop_settings"),
            channel=channel,
            cloud_verified=bool((status.get("cloud_sync") or {}).get("connected")),
            game_mode_status=game_status,
        )

    def _trusted_permission_native_choice(
        request: Request,
        *,
        challenge: Any,
        definition: Any,
        message: str = "This confirmation must be approved through Jarvis's trusted desktop prompt.",
    ) -> str:
        """Verify the exact native permission choice and return its trusted meaning.

        The renderer may relay the choice string, but the Electron main process binds
        that choice into the HMAC. Changing Allow once into Always allow therefore
        invalidates the attestation instead of widening authority.
        """
        authority = str(getattr(resolved, "desktop_confirmation_authority", "") or "").strip()
        if not authority:
            if bool(getattr(resolved, "simulation_enabled", False)):
                return _PERMISSION_NATIVE_ALLOW_ONCE
            raise HTTPException(
                status_code=503,
                detail="Trusted desktop permission confirmation is unavailable; the action was not authorized.",
            )
        choice = str(request.headers.get("x-permission-native-choice") or _PERMISSION_NATIVE_ALLOW_ONCE).strip().casefold()
        attestation = str(request.headers.get("x-permission-native-attestation") or "").strip()
        if choice == _PERMISSION_NATIVE_ALWAYS_ALLOW and not bool(definition.user_can_always_allow):
            raise HTTPException(status_code=409, detail={
                "code": "permission_persistent_allow_unavailable",
                "message": "This permission can only be approved for the current action.",
                "challenge_id": challenge.challenge_id,
                "permission_key": challenge.permission_key,
                "expires_at": challenge.expires_at,
                "requires_authentication": bool(challenge.requires_authentication),
            })
        if not _valid_permission_native_attestation(authority, challenge.challenge_id, choice, attestation):
            raise HTTPException(status_code=409, detail={
                "code": "permission_native_confirmation_required",
                "message": message,
                "challenge_id": challenge.challenge_id,
                "permission_key": challenge.permission_key,
                "expires_at": challenge.expires_at,
                "requires_authentication": bool(challenge.requires_authentication),
            })
        return choice

    def _require_permission(
        request: Request,
        *,
        permission_key: str,
        operation: str,
        resource_kind: str = "",
        resource_id: str = "",
        channel: str = "desktop",
        actor_id: str = "",
        session_id: str = "",
        allow_development_fallback: bool = True,
    ) -> None:
        context = _permission_context(
            request, channel=channel, actor_id=actor_id, session_id=session_id,
            allow_development_fallback=allow_development_fallback,
        )
        permission_request = PermissionRequest(
            permission_key=permission_key, operation=operation,
            resource_kind=resource_kind, resource_id=resource_id,
        )
        supplied_challenge = str(request.headers.get("x-permission-challenge") or "").strip()
        persist_allow_key = ""
        if supplied_challenge:
            try:
                live = permissions.challenge_for_context(supplied_challenge, context)
            except PermissionError:
                live = None
            if live is not None:
                if live.requires_authentication:
                    raise HTTPException(
                        status_code=409,
                        detail={
                            "code": "permission_authentication_required",
                            "message": "Authenticated confirmation is required for this exact action.",
                            "challenge_id": live.challenge_id,
                            "permission_key": live.permission_key,
                            "expires_at": live.expires_at,
                            "requires_authentication": True,
                        },
                    )
                definition = permissions.catalog.get(live.permission_key)
                trusted_choice = _trusted_permission_native_choice(
                    request, challenge=live, definition=definition,
                )
                # Permission persistence is an explicit trusted user choice. A
                # persistable permission may still be approved only once; the Core
                # persists only a choice cryptographically bound as Always allow.
                if trusted_choice == _PERMISSION_NATIVE_ALWAYS_ALLOW:
                    persist_allow_key = live.permission_key
                try:
                    # Exact challenge -> one-use grant. The executor-facing require
                    # below is intentionally the component that consumes that grant.
                    permissions.confirm_challenge(supplied_challenge, permission_request, context)
                except PermissionError as exc:
                    raise HTTPException(
                        status_code=409,
                        detail={
                            "code": "permission_challenge_invalid",
                            "message": str(exc),
                        },
                    ) from exc
        try:
            permissions.require(permission_request, context)
            if persist_allow_key:
                _persist_trusted_permission_allow(persist_allow_key, context)
        except PermissionGateError as exc:
            if exc.decision.kind.value not in {"confirm", "authenticate"}:
                raise HTTPException(status_code=403, detail=str(exc)) from exc
            if supplied_challenge:
                # A stale/replayed/wrong-context supplied challenge must fail closed;
                # do not silently mint a fresh replacement from the same request.
                raise HTTPException(
                    status_code=409,
                    detail={
                        "code": "permission_challenge_invalid",
                        "message": "That permission confirmation is expired, already used, or does not match this exact action.",
                    },
                ) from exc
            try:
                challenge = permissions.create_challenge(permission_request, context)
                detail_source = f"{operation}\n{resource_kind}: {str(resource_id or '')}"
                safe_native_detail = redact_text(detail_source).strip()
                # Never silently truncate a trusted human-review surface. If the
                # exact action cannot fit the bounded in-memory review channel,
                # leave no generic preview; native-summary will fail closed and
                # require the action to be requested again through a reviewable path.
                permission_native_details[challenge.challenge_id] = (
                    safe_native_detail if len(safe_native_detail) <= MAX_NATIVE_PERMISSION_REVIEW_CHARS else ""
                )
                while len(permission_native_details) > 512:
                    permission_native_details.pop(next(iter(permission_native_details)), None)
            except PermissionGateError as challenge_exc:
                raise HTTPException(status_code=403, detail=str(challenge_exc)) from challenge_exc
            except PermissionError as challenge_exc:
                raise HTTPException(status_code=409, detail=str(challenge_exc)) from challenge_exc
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "permission_authentication_required" if challenge.requires_authentication else "permission_confirmation_required",
                    "message": str(exc),
                    "challenge_id": challenge.challenge_id,
                    "permission_key": challenge.permission_key,
                    "expires_at": challenge.expires_at,
                    "requires_authentication": challenge.requires_authentication,
                },
            ) from exc

    def _require_trusted_desktop_confirmation(
        request: Request,
        *,
        challenge_id: str,
        permission_context: PermissionContext,
    ) -> str:
        """Require native desktop approval for a pre-existing exact challenge.

        Connected Actions own their transaction-bound challenge and deliberately
        consume it inside the service immediately before the executor permission
        check.  This helper therefore verifies only the trusted user-presence
        attestation; it never consumes the challenge or materializes a grant.
        """
        exact_id = str(challenge_id or "").strip()
        if not exact_id:
            raise HTTPException(status_code=409, detail={
                "code": "permission_challenge_invalid",
                "message": "This action is missing its exact permission confirmation challenge.",
            })
        try:
            live = permissions.challenge_for_context(exact_id, permission_context)
        except PermissionError as exc:
            raise HTTPException(status_code=409, detail={
                "code": "permission_challenge_invalid",
                "message": "That permission confirmation is expired, already used, or does not match this exact action.",
            }) from exc

        supplied_challenge = str(request.headers.get("x-permission-challenge") or "").strip()
        if not supplied_challenge:
            raise HTTPException(status_code=409, detail={
                "code": "permission_authentication_required" if live.requires_authentication else "permission_confirmation_required",
                "message": "Authenticated confirmation is required for this exact action." if live.requires_authentication
                    else "Jarvis needs your confirmation before performing this exact action.",
                "challenge_id": live.challenge_id,
                "permission_key": live.permission_key,
                "expires_at": live.expires_at,
                "requires_authentication": live.requires_authentication,
            })
        if not hmac.compare_digest(supplied_challenge, exact_id):
            raise HTTPException(status_code=409, detail={
                "code": "permission_challenge_invalid",
                "message": "That permission confirmation does not belong to this exact pending action.",
            })

        # Connected Actions currently use ordinary confirmation permissions.  Keep
        # the authenticated branch fail-closed rather than allowing an authenticated
        # challenge to fall through to ordinary service confirmation.
        if live.requires_authentication:
            raise HTTPException(status_code=409, detail={
                "code": "permission_authentication_required",
                "message": "Authenticated confirmation is required for this exact action.",
                "challenge_id": live.challenge_id,
                "permission_key": live.permission_key,
                "expires_at": live.expires_at,
                "requires_authentication": True,
            })

        definition = permissions.catalog.get(live.permission_key)
        return _trusted_permission_native_choice(
            request, challenge=live, definition=definition,
        )

    def _persist_trusted_permission_allow(permission_key: str, context: PermissionContext) -> None:
        key = str(permission_key or "").strip()
        if not key:
            return
        try:
            definition = permissions.catalog.get(key)
        except KeyError as exc:
            raise HTTPException(status_code=409, detail="The permission setting is no longer available.") from exc
        if not definition.user_can_always_allow:
            raise HTTPException(status_code=409, detail="This permission can only be approved for the current action.")
        permissions.set_preference(permission_key=key, context=context, mode=PreferenceMode.ALLOW)

    def _connected_action_can_use_conversational_confirmation(
        challenge_id: str,
        context: PermissionContext,
    ) -> bool:
        exact_id = str(challenge_id or "").strip()
        if not exact_id:
            # No challenge means the permission policy already allows the executor.
            return True
        try:
            live = permissions.challenge_for_context(exact_id, context)
            definition = permissions.catalog.get(live.permission_key)
        except (PermissionError, KeyError):
            return False
        if live.requires_authentication:
            return False
        preference = permissions.store.preference(
            account_id=context.account_id, tenant_id=context.tenant_id,
            device_id=context.device_id, permission_key=definition.key,
        )
        return bool(definition.metadata.get("conversation_confirmation_allowed")) and preference == PreferenceMode.DEFAULT

    @app.get("/api/permissions")
    async def permission_catalog(request: Request) -> dict[str, Any]:
        context = _permission_context(request)
        rows = []
        for definition in permissions.catalog.all():
            preference = permissions.store.preference(
                account_id=context.account_id,
                tenant_id=context.tenant_id,
                device_id=context.device_id,
                permission_key=definition.key,
            )
            rows.append({
                "key": definition.key,
                "title": definition.title,
                "description": definition.description,
                "level": definition.level.value,
                "authority": definition.authority.value,
                "data_sensitivity": definition.data_sensitivity.value,
                "user_can_disable": definition.user_can_disable,
                "user_can_always_allow": definition.user_can_always_allow,
                "autonomous_allowed": definition.autonomous_allowed,
                "requires_game_mode_clear": definition.requires_game_mode_clear,
                "preference": preference.value,
            })
        return {
            "schema_version": 1,
            "device_scoped": True,
            "cloud_connected": context.cloud_verified,
            "permissions": rows,
        }

    @app.put("/api/permissions/{permission_key}")
    async def permission_preference(permission_key: str, request: Request, body: PermissionPreferenceBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        context = _permission_context(request)
        try:
            mode = PreferenceMode(body.mode)
            definition = permissions.catalog.get(permission_key)
            # Validate impossible preference modes before asking the user to
            # reauthenticate for a change that can never be accepted.
            if mode == PreferenceMode.ALLOW and not definition.user_can_always_allow:
                raise PermissionError("this permission cannot be configured as always allow")
            if mode == PreferenceMode.DENY and not definition.user_can_disable:
                raise PermissionError("this safety permission cannot be disabled")
            if permissions.preference_change_lowers_protection(
                permission_key=permission_key, context=context, mode=mode
            ):
                current_mode = permissions.store.preference(
                    account_id=context.account_id, tenant_id=context.tenant_id,
                    device_id=context.device_id, permission_key=permission_key,
                )
                _require_permission(
                    request,
                    permission_key="security.change_protection",
                    operation="permission.preference.lower_protection",
                    resource_kind="permission_preference",
                    resource_id=json.dumps({
                        "permission_key": permission_key,
                        "from": current_mode.value,
                        "to": mode.value,
                    }, sort_keys=True, separators=(",", ":")),
                    channel="security_settings",
                    actor_id=context.actor_id,
                    session_id=context.session_id or "permission_settings",
                    allow_development_fallback=False,
                )
            permissions.set_preference(permission_key=permission_key, context=context, mode=mode)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except PermissionError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {
            "saved": True,
            "permission_key": definition.key,
            "preference": mode.value,
            "device_scoped": True,
        }

    @app.get("/api/permissions/audit")
    async def permission_audit(request: Request, limit: int = Query(default=40, ge=1, le=200)) -> dict[str, Any]:
        context = _permission_context(request)
        return {
            "decisions": permissions.store.list_audit(
                account_id=context.account_id, tenant_id=context.tenant_id, device_id=context.device_id, limit=limit
            )
        }

    @app.get("/api/permissions/challenges/{challenge_id}/native-summary")
    async def permission_native_summary(challenge_id: str, request: Request) -> dict[str, Any]:
        authority = str(getattr(resolved, "desktop_confirmation_authority", "") or "").strip()
        supplied = str(request.headers.get("x-jarvis-desktop-authority") or "").strip()
        if not authority or not hmac.compare_digest(supplied, authority):
            raise HTTPException(status_code=403, detail="trusted desktop authority is required")
        row = permissions.store.challenge(challenge_id)
        if row is None or row.get("consumed_at") or row.get("invalidated_at"):
            raise HTTPException(status_code=409, detail="permission confirmation challenge is no longer valid")
        try:
            expires_at = datetime.fromisoformat(str(row.get("expires_at") or ""))
            now = datetime.now(expires_at.tzinfo) if expires_at.tzinfo is not None else datetime.now()
            if expires_at <= now:
                raise HTTPException(status_code=409, detail="permission confirmation challenge expired")
        except ValueError as exc:
            raise HTTPException(status_code=409, detail="permission confirmation challenge has an invalid expiry") from exc
        try:
            definition = permissions.catalog.get(str(row.get("permission_key") or ""))
        except KeyError as exc:
            raise HTTPException(status_code=409, detail="permission confirmation policy is unavailable") from exc
        prompt = ""
        action_detail = str(permission_native_details.get(challenge_id) or "").strip()
        if not action_detail:
            action_detail = str(actions.native_confirmation_detail(challenge_id) or "").strip()
            prompt_fn = getattr(actions, "native_confirmation_prompt", None)
            if action_detail and callable(prompt_fn):
                prompt = str(prompt_fn(challenge_id) or "").strip()
        if not action_detail:
            action_detail = str(browser_actions.native_confirmation_detail(challenge_id) or "").strip()
            prompt_fn = getattr(browser_actions, "native_confirmation_prompt", None)
            if action_detail and callable(prompt_fn):
                prompt = str(prompt_fn(challenge_id) or "").strip()
        if not action_detail:
            action_detail = str(computer_apps.native_confirmation_detail(challenge_id) or "").strip()
            prompt_fn = getattr(computer_apps, "native_confirmation_prompt", None)
            if action_detail and callable(prompt_fn):
                prompt = str(prompt_fn(challenge_id) or "").strip()
        if not action_detail:
            # Native confirmation must show enough trusted, Core-derived detail for
            # the user to review the exact pending action. Challenge fingerprints
            # intentionally cannot be reversed after a Core restart; a challenge
            # whose ephemeral review detail is gone must therefore fail closed and
            # be requested again rather than presenting a misleading generic prompt.
            permissions.store.invalidate_challenge(challenge_id)
            raise HTTPException(
                status_code=409,
                detail="The exact action review is no longer available. Please request the action again.",
            )
        if len(action_detail) > MAX_NATIVE_PERMISSION_REVIEW_CHARS:
            permissions.store.invalidate_challenge(challenge_id)
            raise HTTPException(
                status_code=409,
                detail="The exact action is too large to review safely in the trusted confirmation window. Please reduce the action and try again.",
            )
        if not prompt:
            first_line = action_detail.splitlines()[0].strip() if action_detail else ""
            # Generic HTTP permission details can begin with internal operation tokens.
            # Never leak those tokens into the consumer confirmation copy.
            if first_line and not re.search(r"[_.:{}\[\]]", first_line):
                summary = first_line.rstrip(".?!")
                prompt = f"Allow Jarvis to {summary[:1].lower() + summary[1:]}?"
            else:
                title = str(definition.title or "perform this action").strip().rstrip(".?!")
                lowered = title[:1].lower() + title[1:] if title else "perform this action"
                prompt = f"Allow Jarvis to {lowered}?"
        prompt = prompt[:240].strip()
        if not prompt:
            permissions.store.invalidate_challenge(challenge_id)
            raise HTTPException(status_code=409, detail="The trusted confirmation prompt is unavailable. Please request the action again.")
        return {
            "challenge_id": str(row.get("challenge_id") or ""),
            "permission_key": definition.key,
            "title": definition.title,
            "description": definition.description,
            "prompt": prompt,
            # Retain exact Core-only review detail for diagnostics/security tests; the
            # desktop confirmation UI intentionally renders only the natural prompt.
            "action_detail": action_detail,
            "expires_at": str(row.get("expires_at") or ""),
            "requires_authentication": bool(int(row.get("requires_authentication") or 0)),
            "user_can_always_allow": bool(definition.user_can_always_allow),
        }

    def _permission_reauth_purpose(challenge: Any, context: PermissionContext) -> dict[str, str]:
        return {
            "challenge_id": str(challenge.challenge_id),
            "permission_key": str(challenge.permission_key),
            "account_id": context.account_id,
            "tenant_id": context.tenant_id,
            "device_id": context.device_id,
            # Permission scope uses the desktop's local device ID, while cloud
            # reauthentication proves the same physical install via installation ID.
            "installation_id": accounts.installation_id,
            "actor_id": str(challenge.actor_id),
            "session_id": str(challenge.session_id),
        }

    @app.post("/api/permissions/challenges/{challenge_id}/reauth/start")
    async def permission_reauth_start(challenge_id: str, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        device_context = _permission_context(request)
        try:
            challenge = permissions.challenge_for_device(challenge_id, device_context)
        except PermissionError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        if not challenge.requires_authentication:
            raise HTTPException(status_code=409, detail="This permission challenge does not require account reauthentication.")
        purpose = _permission_reauth_purpose(challenge, device_context)
        recent = browser_auth.recent_reauth_status(purpose)
        if recent.get("valid"):
            return {
                "mode": "reauth",
                "recent_auth": True,
                "challenge_id": challenge.challenge_id,
                "expires_at": str(recent.get("expires_at") or ""),
            }
        portal_url = str(request.base_url).rstrip("/") + "/api/account/web-auth/portal"
        try:
            payload = browser_auth.begin(
                mode="reauth",
                portal_base_url=portal_url,
                purpose=purpose,
            )
            payload["recent_auth"] = False
            return payload
        except BrowserAuthError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/permissions/challenges/{challenge_id}/reauth/confirm")
    async def permission_reauth_confirm(challenge_id: str, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        context = _permission_context(request)
        try:
            challenge = permissions.validate_authenticated_challenge(challenge_id, context)
        except PermissionError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        purpose = _permission_reauth_purpose(challenge, context)
        recent = browser_auth.recent_reauth_status(purpose)
        if not recent.get("valid"):
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "permission_reauthentication_required",
                    "message": "Your recent identity verification expired. Verify your account again.",
                    "challenge_id": challenge.challenge_id,
                    "permission_key": challenge.permission_key,
                    "requires_authentication": True,
                },
            )
        definition = permissions.catalog.get(challenge.permission_key)
        _trusted_permission_native_choice(
            request,
            challenge=challenge,
            definition=definition,
            message="This exact security-sensitive action must be approved through Jarvis's trusted desktop prompt.",
        )
        try:
            result = permissions.authenticate_challenge(challenge.challenge_id, context)
        except PermissionError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        permission_native_details.pop(challenge.challenge_id, None)
        return {
            "authenticated": True,
            "challenge_id": challenge.challenge_id,
            "grant_id": result.grant_id,
            "scope": result.scope.value,
            "recent_auth_expires_at": str(recent.get("expires_at") or ""),
        }

    async def _browser_form(request: Request) -> dict[str, str]:
        raw = (await request.body()).decode("utf-8", errors="replace")
        parsed = parse_qs(raw, keep_blank_values=True)
        return {key: str(values[-1] if values else "") for key, values in parsed.items()}

    def _portal_html(attempt_id: str, state: str, *, view: str = "", error: str = "", notice: str = "") -> HTMLResponse:
        try:
            attempt = browser_auth.portal_attempt(attempt_id=attempt_id, state=state)
            return HTMLResponse(render_auth_portal(
                attempt=attempt,
                attempt_id=attempt_id,
                state=state,
                view=view,
                error=error,
                notice=notice,
            ))
        except BrowserAuthError as exc:
            return HTMLResponse(
                render_auth_portal(
                    attempt={"mode": "signin", "status": "expired"},
                    attempt_id=attempt_id,
                    state=state,
                    view="signin",
                    error=str(exc),
                ),
                status_code=400,
            )

    @app.post("/api/account/web-auth/start")
    async def account_web_auth_start(request: Request, mode: str = Query(default="signin")) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        if str(mode or "").strip().casefold() == "reauth":
            raise HTTPException(status_code=400, detail="Permission reauthentication must start from an exact permission challenge.")
        try:
            portal_url = str(request.base_url).rstrip("/") + "/api/account/web-auth/portal"
            return browser_auth.begin(mode=mode, portal_base_url=portal_url)
        except BrowserAuthError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/api/account/web-auth/portal", response_class=HTMLResponse)
    async def account_web_auth_portal(
        attempt: str = Query(default=""),
        state: str = Query(default=""),
        view: str = Query(default=""),
    ) -> HTMLResponse:
        return _portal_html(attempt, state, view=view)

    @app.post("/api/account/web-auth/portal/signup", response_class=HTMLResponse)
    async def account_web_auth_portal_signup(request: Request) -> HTMLResponse:
        form = await _browser_form(request)
        attempt_id, state = form.get("attempt", ""), form.get("state", "")
        try:
            await browser_auth.signup(
                attempt_id=attempt_id,
                state=state,
                display_name=form.get("display_name", ""),
                email=form.get("email", ""),
                phone=form.get("phone", ""),
                password=form.get("password", ""),
                confirm_password=form.get("confirm_password", ""),
            )
            return _portal_html(attempt_id, state, view="signup")
        except BrowserAuthError as exc:
            return _portal_html(attempt_id, state, view="signup", error=str(exc))

    @app.post("/api/account/web-auth/portal/signin", response_class=HTMLResponse)
    async def account_web_auth_portal_signin(request: Request) -> HTMLResponse:
        form = await _browser_form(request)
        attempt_id, state = form.get("attempt", ""), form.get("state", "")
        try:
            await browser_auth.signin(
                attempt_id=attempt_id,
                state=state,
                identifier=form.get("identifier", ""),
                password=form.get("password", ""),
            )
            return _portal_html(attempt_id, state, view="signin")
        except BrowserAuthError as exc:
            return _portal_html(attempt_id, state, view="signin", error=str(exc))

    @app.post("/api/account/web-auth/portal/verify", response_class=HTMLResponse)
    async def account_web_auth_portal_verify(request: Request) -> HTMLResponse:
        form = await _browser_form(request)
        attempt_id, state = form.get("attempt", ""), form.get("state", "")
        try:
            await browser_auth.verify_signup(attempt_id=attempt_id, state=state, code=form.get("code", ""))
            return _portal_html(attempt_id, state, view="signup")
        except BrowserAuthError as exc:
            return _portal_html(attempt_id, state, view="signup", error=str(exc))

    @app.post("/api/account/web-auth/portal/verify/resend", response_class=HTMLResponse)
    async def account_web_auth_portal_verify_resend(request: Request) -> HTMLResponse:
        form = await _browser_form(request)
        attempt_id, state = form.get("attempt", ""), form.get("state", "")
        try:
            await browser_auth.resend_signup_verification(attempt_id=attempt_id, state=state)
            return _portal_html(attempt_id, state, view="signup", notice="A new verification code was sent.")
        except BrowserAuthError as exc:
            return _portal_html(attempt_id, state, view="signup", error=str(exc))

    @app.post("/api/account/web-auth/portal/recovery/start", response_class=HTMLResponse)
    async def account_web_auth_portal_recovery_start(request: Request) -> HTMLResponse:
        form = await _browser_form(request)
        attempt_id, state = form.get("attempt", ""), form.get("state", "")
        try:
            result = await browser_auth.begin_recovery(
                attempt_id=attempt_id, state=state, identifier=form.get("identifier", "")
            )
            notice = "If that verified contact belongs to a Jarvis account, a recovery code has been sent."
            if not result.get("recovery_id"):
                # Keep the web response deliberately non-enumerating.
                notice = "If that verified contact belongs to a Jarvis account, a recovery code has been sent."
            return _portal_html(attempt_id, state, view="recovery", notice=notice)
        except BrowserAuthError as exc:
            return _portal_html(attempt_id, state, view="recovery", error=str(exc))

    @app.post("/api/account/web-auth/portal/recovery/resend", response_class=HTMLResponse)
    async def account_web_auth_portal_recovery_resend(request: Request) -> HTMLResponse:
        form = await _browser_form(request)
        attempt_id, state = form.get("attempt", ""), form.get("state", "")
        try:
            await browser_auth.resend_recovery(attempt_id=attempt_id, state=state)
            return _portal_html(attempt_id, state, view="recovery", notice="A new recovery code was sent.")
        except BrowserAuthError as exc:
            return _portal_html(attempt_id, state, view="recovery", error=str(exc))

    @app.post("/api/account/web-auth/portal/recovery/verify", response_class=HTMLResponse)
    async def account_web_auth_portal_recovery_verify(request: Request) -> HTMLResponse:
        form = await _browser_form(request)
        attempt_id, state = form.get("attempt", ""), form.get("state", "")
        try:
            await browser_auth.verify_recovery(attempt_id=attempt_id, state=state, code=form.get("code", ""))
            return _portal_html(attempt_id, state, view="recovery")
        except BrowserAuthError as exc:
            return _portal_html(attempt_id, state, view="recovery", error=str(exc))

    @app.post("/api/account/web-auth/portal/recovery/reset", response_class=HTMLResponse)
    async def account_web_auth_portal_recovery_reset(request: Request) -> HTMLResponse:
        form = await _browser_form(request)
        attempt_id, state = form.get("attempt", ""), form.get("state", "")
        try:
            await browser_auth.reset_password(
                attempt_id=attempt_id,
                state=state,
                new_password=form.get("new_password", ""),
                confirm_password=form.get("confirm_password", ""),
            )
            return _portal_html(
                attempt_id, state, view="signin", notice="Password reset complete. Sign in with your new password."
            )
        except BrowserAuthError as exc:
            return _portal_html(attempt_id, state, view="recovery", error=str(exc))

    @app.get("/api/account/web-auth/status")
    async def account_web_auth_status(
        request: Request,
        attempt_id: str = Query(min_length=8, max_length=200),
        poll_token: str = Query(min_length=16, max_length=512),
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return browser_auth.poll(attempt_id=attempt_id, poll_token=poll_token)
        except BrowserAuthError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/account/web-auth/complete")
    async def account_web_auth_complete(body: BrowserAuthCompleteBody, request: Request) -> Response:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            token = browser_auth.consume(attempt_id=body.attempt_id, poll_token=body.poll_token)
        except BrowserAuthError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        response = JSONResponse(_account_status_payload(token, touch=False))
        response.set_cookie(
            key=accounts.cookie_name,
            value=token,
            max_age=accounts.session_ttl_days * 24 * 60 * 60,
            httponly=True,
            samesite="strict",
            secure=False,
            path="/",
        )
        return response

    @app.post("/api/account/signup")
    async def account_signup(body: AccountSignupBody, request: Request) -> Response:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            created = accounts.signup(
                email=body.email,
                phone=body.phone,
                display_name=body.display_name,
                password=body.password,
                device_label=body.device_label,
            )
        except AccountValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except (AccountAlreadyExists, AccountBindingConflict) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        token = str(created.pop("token"))
        try:
            await cloud_sync.connect(token, password=body.password)
        except CloudSyncError:
            # Preserve the pending local identity so the user can retry verification,
            # but normal Jarvis use remains gated until cloud verification succeeds.
            pass
        response = JSONResponse(_account_status_payload(token, touch=False), status_code=201)
        response.set_cookie(
            key=accounts.cookie_name,
            value=token,
            max_age=accounts.session_ttl_days * 24 * 60 * 60,
            httponly=True,
            samesite="strict",
            secure=False,
            path="/",
        )
        return response

    @app.post("/api/account/login")
    async def account_login(body: AccountLoginBody, request: Request) -> Response:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        browser_auth.clear_recent_reauth()
        try:
            authenticated = accounts.login(
                identifier=body.identifier or body.email,
                password=body.password,
                device_label=body.device_label,
            )
        except AccountValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except AccountInvalidCredentials as local_exc:
            # A fresh device can recover the same stable account/tenant identity
            # from Jarvis Cloud after the user proves the account password.
            if not cloud_sync.service_configured:
                raise HTTPException(status_code=401, detail=str(local_exc)) from local_exc
            try:
                remote_identity = await cloud_sync.remote_login(
                    identifier=body.identifier or body.email,
                    password=body.password,
                    installation_id=accounts.installation_id,
                    device_label=body.device_label or accounts.device_label,
                )
                authenticated = accounts.adopt_cloud_identity(
                    identity=remote_identity,
                    password=body.password,
                    device_label=body.device_label,
                )
            except CloudSyncError as exc:
                raise HTTPException(status_code=401, detail="Email or password is incorrect.") from exc
            except AccountBindingConflict as exc:
                raise HTTPException(status_code=409, detail=str(exc)) from exc
        except AccountBindingConflict as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        token = str(authenticated.pop("token"))
        if not bool((authenticated.get("account") or {}).get("verified")) or not cloud_sync.status(token).get("connected"):
            try:
                await cloud_sync.connect(token, password=body.password)
            except CloudSyncError:
                pass
        response = JSONResponse(_account_status_payload(token, touch=False))
        response.set_cookie(
            key=accounts.cookie_name,
            value=token,
            max_age=accounts.session_ttl_days * 24 * 60 * 60,
            httponly=True,
            samesite="strict",
            secure=False,
            path="/",
        )
        return response

    @app.post("/api/account/verify")
    async def account_verify(body: AccountVerifyBody, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        token = request.cookies.get(accounts.cookie_name)
        try:
            await cloud_sync.verify_connection(token, verification_id=body.verification_id, code=body.code)
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except CloudSyncError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _account_status_payload(token, touch=False)

    @app.patch("/api/account/profile")
    async def account_profile(body: AccountProfileBody, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        token = request.cookies.get(accounts.cookie_name)
        try:
            accounts.update_profile(token, display_name=body.display_name)
        except AccountValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except AccountNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        return _account_status_payload(token, touch=False)

    @app.post("/api/account/logout")
    async def account_logout(request: Request) -> Response:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        token = request.cookies.get(accounts.cookie_name)
        if token and accounts.session(token, touch=False) is not None:
            try:
                await cloud_sync.disconnect(token)
            except CloudSyncError:
                # Local sign-out must still succeed if the network is unavailable.
                cloud_sync.state.set_enabled(False)
                cloud_sync.secret_store.delete("cloud_sync_session")
                cloud_sync.secret_store.delete("cloud_sync_verification")
                if cloud_sync.transport is not None:
                    cloud_sync.transport.set_access_token("")
        accounts.logout(token)
        browser_auth.clear_recent_reauth()
        response = JSONResponse(_account_status_payload(None, touch=False))
        response.delete_cookie(key=accounts.cookie_name, path="/", samesite="strict")
        return response


    @app.get("/api/sync/status")
    async def cloud_sync_status(request: Request) -> dict[str, Any]:
        return cloud_sync.status(request.cookies.get(accounts.cookie_name))

    @app.post("/api/sync/connect")
    async def cloud_sync_connect(body: CloudSyncConnectBody, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return await cloud_sync.connect(request.cookies.get(accounts.cookie_name), password=body.password)
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except CloudSyncError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/sync/disconnect")
    async def cloud_sync_disconnect(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return await cloud_sync.disconnect(request.cookies.get(accounts.cookie_name))
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc

    @app.patch("/api/sync/enabled")
    async def cloud_sync_enabled(body: CloudSyncEnableBody, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return cloud_sync.set_enabled(request.cookies.get(accounts.cookie_name), body.enabled)
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except CloudSyncError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.patch("/api/sync/scopes/{scope}")
    async def cloud_sync_scope(scope: str, body: CloudSyncScopeBody, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return cloud_sync.set_scope(request.cookies.get(accounts.cookie_name), scope=scope, enabled=body.enabled)
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/sync/run")
    async def cloud_sync_run(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return await cloud_sync.sync_now(request.cookies.get(accounts.cookie_name))
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except CloudSyncError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/sync/conflicts")
    async def cloud_sync_conflicts(request: Request) -> dict[str, Any]:
        try:
            return {"conflicts": cloud_sync.conflicts(request.cookies.get(accounts.cookie_name))}
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc


    @app.get("/api/account/devices")
    async def account_devices(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            devices = await cloud_sync.devices(request.cookies.get(accounts.cookie_name))
            return {"devices": devices}
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except CloudSyncError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/account/billing")
    async def account_billing(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return await cloud_sync.billing_summary(request.cookies.get(accounts.cookie_name))
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except CloudSyncError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc


    @app.post("/api/account/devices/{device_id}/revoke")
    async def account_device_revoke(device_id: str, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            result = await cloud_sync.revoke_device(request.cookies.get(accounts.cookie_name), target_device_id=device_id)
            return {"result": result, "devices": await cloud_sync.devices(request.cookies.get(accounts.cookie_name))}
        except CloudSyncNotAuthenticated as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except CloudSyncError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc


    @app.get("/api/capabilities")
    async def capabilities() -> dict[str, Any]:
        return capability_registry.snapshot()

    @app.post("/api/providers/prewarm")
    async def prewarm_providers(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        tasks = []
        labels = []
        for label, candidate in (("realtime", provider), ("transcription", wake_transcriber), ("text", text_provider), ("speech", speech_provider)):
            prewarm = getattr(candidate, "prewarm", None)
            if callable(prewarm):
                labels.append(label)
                tasks.append(prewarm())
        if not tasks:
            return {"ready": False, "providers": {}}
        results = await asyncio.gather(*tasks, return_exceptions=True)
        provider_status = {
            label: bool(result) if not isinstance(result, Exception) else False
            for label, result in zip(labels, results, strict=True)
        }
        return {"ready": all(provider_status.values()), "providers": provider_status}

    @app.get("/api/game-mode/status")
    async def game_mode_status() -> dict[str, Any]:
        return game_mode.status(refresh=False)

    @app.get("/api/game-mode/safety-probe")
    async def game_mode_safety_probe(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        return game_mode.safety_probe()

    @app.post("/api/web/turn")
    async def web_intelligence_turn(request: Request, body: WebIntelligenceTurnBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        mode = validate_response_mode(body.response_mode)
        started_at = perf_counter()
        try:
            result = await web_intelligence.handle_turn(
                user_text=body.user_text,
                response_mode=mode,
                task_id=body.task_id,
            )
        except WebIntelligenceError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        usage_session_id = (body.usage_session_id or body.session_id).strip()
        record = ledger.record_text(
            response_id=result.response_id,
            session_id=usage_session_id,
            model=result.model,
            response_mode=mode,
            usage=result.usage,
            purpose="web_intelligence",
        )
        return {
            "handled": True,
            "status": "completed",
            "spoken_text": result.spoken_text,
            "display_text": result.spoken_text,
            "presentation": result.presentation(),
            "result_id": result.result_id,
            "response_id": result.response_id,
            "planner_model": result.model,
            "records": [record],
            "summary": ledger.summary(session_id=usage_session_id),
            "budget": ledger.budget_status(limits, session_id=usage_session_id),
            "search_actions": result.search_actions,
            "browser_handoff": dict(result.browser_handoff),
            "realtime_role": "ears_only",
            "web_role": "grounded_responses_web_search",
            "action_latency_ms": int((perf_counter() - started_at) * 1000),
        }

    @app.post("/api/web/results/{result_id}/sources/{source_id}/open")
    async def web_intelligence_open_source(
        result_id: str,
        source_id: str,
        request: Request,
        body: WebSourceOpenBody,
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return await web_intelligence.open_source(
                result_id=result_id,
                source_id=source_id,
                task_id=body.task_id,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except BrowserBridgeDisconnected as exc:
            raise HTTPException(status_code=409, detail="Jarvis Browser Bridge is not connected") from exc
        except BrowserBridgeError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    @app.websocket("/api/browser/ws")
    async def browser_bridge_socket(websocket: WebSocket) -> None:
        client = str(websocket.query_params.get("client") or "")
        origin = str(websocket.headers.get("origin") or "")
        if client != "jarvis-browser-bridge-v1" or not origin.startswith("chrome-extension://"):
            await websocket.close(code=1008)
            return
        await websocket.accept()
        attached = False
        try:
            hello = await asyncio.wait_for(websocket.receive_json(), timeout=8.0)
            if not isinstance(hello, dict) or str(hello.get("type") or "").lower() != "hello":
                await websocket.close(code=1008)
                return
            await browser_bridge_service.attach(websocket, hello)
            attached = True
            await websocket.send_json({"type": "ready", "browser_access": True, "max_steps": browser_actions.max_steps})
            while True:
                message = await websocket.receive_json()
                if isinstance(message, dict):
                    await browser_bridge_service.handle_message(websocket, message)
        except (WebSocketDisconnect, TimeoutError):
            pass
        except Exception as exc:
            LOGGER.warning("Browser Bridge socket closed after error: %s", redact_text(str(exc), (resolved.openai_api_key,)))
        finally:
            if attached:
                await browser_bridge_service.detach(websocket, reason="extension_disconnected")

    @app.get("/api/browser/status")
    async def browser_status(session_id: str = Query(default="", max_length=240)) -> dict[str, Any]:
        return browser_actions.status(session_id=session_id)

    @app.post("/api/browser/tasks/{task_id}/cancel")
    async def browser_cancel_task(task_id: str, request: Request, body: BrowserCancelBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        cancelled = await browser_actions.cancel(task_id, reason=body.reason)
        return {"cancelled": cancelled, "task_id": task_id}

    @app.post("/api/browser/turn")
    async def browser_turn(request: Request, body: BrowserTurnBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        mode = validate_response_mode(body.response_mode)
        started_at = perf_counter()
        usage_session_id = (body.usage_session_id or body.session_id).strip()
        browser_actor = (body.actor or "").strip() or "Unknown speaker"
        permission_actor_scope = (body.actor_scope_id or "").strip() or f"browser-unattributed:{body.session_id}"
        permission_context = _permission_context(
            request, channel="browser", actor_id=permission_actor_scope, session_id=body.session_id,
            allow_development_fallback=True,
        )
        permission_confirmation_authorized = False
        persist_allow_key = ""
        supplied_permission_challenge = str(request.headers.get("x-permission-challenge") or "").strip()
        try:
            prepared = browser_actions.prepare_confirmation_for_turn(
                user_text=body.user_text, session_id=body.session_id,
                permission_context=permission_context,
            )
        except PermissionError as exc:
            raise HTTPException(status_code=409, detail={
                "code": "permission_challenge_invalid", "message": str(exc),
            }) from exc
        if prepared is not None:
            prepared_challenge_id = str(prepared.get("permission_challenge_id") or "")
            trusted_choice = _require_trusted_desktop_confirmation(
                request,
                challenge_id=prepared_challenge_id,
                permission_context=permission_context,
            )
            permission_confirmation_authorized = True
            live = permissions.challenge_for_context(prepared_challenge_id, permission_context)
            if trusted_choice == _PERMISSION_NATIVE_ALWAYS_ALLOW:
                persist_allow_key = live.permission_key
        elif supplied_permission_challenge:
            # Device-policy confirmations are initiated by the executor and retried
            # internally after the trusted native prompt. Validate a still-live
            # ordinary challenge here; an authenticated challenge is consumed by
            # the purpose-bound reauth endpoint and therefore reaches the executor
            # as a grant with no live challenge left to attest.
            try:
                live = permissions.challenge_for_context(supplied_permission_challenge, permission_context)
            except PermissionError:
                live = None
            if live is not None:
                trusted_choice = _require_trusted_desktop_confirmation(
                    request, challenge_id=supplied_permission_challenge, permission_context=permission_context,
                )
                permission_confirmation_authorized = True
                if trusted_choice == _PERMISSION_NATIVE_ALWAYS_ALLOW:
                    persist_allow_key = live.permission_key
        result = await browser_actions.handle_turn(
            user_text=body.user_text,
            actor=browser_actor,
            session_id=body.session_id,
            conversation_context=body.conversation_context,
            response_mode=mode,
            task_id=body.task_id,
            contextual=body.contextual,
            permission_context=permission_context,
            permission_confirmation_authorized=permission_confirmation_authorized,
            permission_challenge_id=supplied_permission_challenge,
        )
        if persist_allow_key and result.status not in {"permission_confirmation_invalid", "permission_denied", "blocked"}:
            _persist_trusted_permission_allow(persist_allow_key, permission_context)
        records = []
        for generated in result.usage:
            if generated.response_id:
                records.append(ledger.record_text(
                    response_id=generated.response_id,
                    session_id=usage_session_id,
                    model=generated.model,
                    response_mode=mode,
                    usage=generated.usage,
                    purpose="browser_planner",
                ))
        payload = result.to_dict()
        payload.update({
            "records": records,
            "summary": ledger.summary(session_id=usage_session_id),
            "budget": ledger.budget_status(limits, session_id=usage_session_id),
            "planner_model": resolved.action_model,
            "realtime_role": "ears_only",
            "browser_role": "luna_iterative_dom_agent",
            "action_latency_ms": int((perf_counter() - started_at) * 1000),
        })
        return payload

    @app.get("/api/computer/apps/status")
    async def computer_app_status() -> dict[str, Any]:
        return computer_apps.status()

    @app.get("/api/computer/apps")
    async def computer_app_catalog(limit: int = Query(default=250, ge=1, le=1000)) -> dict[str, Any]:
        return {"status": computer_apps.status(), "apps": computer_apps.list_apps(limit=limit)}

    @app.get("/api/computer/apps/diagnostics")
    async def computer_app_diagnostics(
        app_query: str = Query(default="", max_length=260),
        limit: int = Query(default=25, ge=1, le=100),
    ) -> dict[str, Any]:
        return {"diagnostics": computer_apps.recent_diagnostics(app_query=app_query, limit=limit)}

    @app.post("/api/computer/apps/launch")
    async def computer_app_launch(request: Request, body: ComputerAppLaunchBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        started_at = perf_counter()
        permission_actor_scope = (body.actor_scope_id or "").strip() or f"computer-unattributed:{body.session_id}"
        permission_context = _permission_context(
            request, channel="computer", actor_id=permission_actor_scope, session_id=body.session_id,
            allow_development_fallback=True,
        )
        supplied_permission_challenge = str(request.headers.get("x-permission-challenge") or "").strip()
        permission_confirmation_authorized = False
        persist_allow_key = ""
        if supplied_permission_challenge:
            try:
                live = permissions.challenge_for_context(supplied_permission_challenge, permission_context)
            except PermissionError:
                live = None
            if live is not None:
                trusted_choice = _require_trusted_desktop_confirmation(
                    request, challenge_id=supplied_permission_challenge, permission_context=permission_context,
                )
                permission_confirmation_authorized = True
                if trusted_choice == _PERMISSION_NATIVE_ALWAYS_ALLOW:
                    persist_allow_key = live.permission_key
        result = await asyncio.to_thread(
            computer_apps.handle_turn,
            user_text=body.user_text,
            actor=body.actor,
            session_id=body.session_id,
            permission_context=permission_context,
            permission_challenge_id=supplied_permission_challenge,
            permission_confirmation_authorized=permission_confirmation_authorized,
        )
        if persist_allow_key and result is not None and result.status not in {"permission_confirmation_invalid", "permission_denied", "blocked"}:
            _persist_trusted_permission_allow(persist_allow_key, permission_context)
        if result is None:
            return {"handled": False, "status": "not_handled", "elapsed_ms": int((perf_counter() - started_at) * 1000)}
        payload = result.to_dict()
        payload["elapsed_ms"] = int((perf_counter() - started_at) * 1000)
        payload["local_action"] = True
        payload["reasoning_model"] = "none"
        return payload

    @app.post("/api/computer/apps/aliases")
    async def computer_app_alias(request: Request, body: ComputerAppAliasBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(
            request, permission_key="computer.apps.alias", operation="remember_app_alias",
            resource_kind="application_alias", resource_id=f"{body.app_query}|{body.alias}",
            channel="computer", actor_id=body.actor or resolved.local_user_name,
        )
        candidate = await asyncio.to_thread(
            computer_apps.teach_alias,
            alias=body.alias,
            app_query=body.app_query,
            actor=body.actor,
        )
        if candidate is None:
            raise HTTPException(status_code=404, detail="No matching installed application was found for that alias.")
        return {"saved": True, "app": candidate.to_dict(), "alias": body.alias}

    @app.delete("/api/computer/apps/aliases")
    async def computer_app_alias_delete(request: Request, body: ComputerAppAliasBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(
            request, permission_key="computer.apps.alias", operation="forget_app_alias",
            resource_kind="application_alias", resource_id=f"{body.app_query}|{body.alias}",
            channel="computer", actor_id=body.actor or resolved.local_user_name,
        )
        candidate = await asyncio.to_thread(
            computer_apps.unteach_alias,
            alias=body.alias,
            app_query=body.app_query,
            actor=body.actor,
        )
        if candidate is None:
            raise HTTPException(status_code=404, detail="No matching installed application was found for that alias.")
        return {"removed": True, "app": candidate.to_dict(), "alias": body.alias}

    @app.get("/api/integrations/google/status")
    async def google_status(validate: bool = Query(default=False)) -> dict[str, Any]:
        status = await google.status(validate=validate)
        return {"google": status.to_dict(), "action_model": resolved.action_model}

    @app.post("/api/integrations/google/connect")
    async def google_connect(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            return google.begin_authorization(open_browser=True)
        except GoogleIntegrationError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc

    @app.get("/api/integrations/google/callback", response_class=HTMLResponse)
    async def google_callback(
        code: str | None = Query(default=None),
        state: str | None = Query(default=None),
        error: str | None = Query(default=None),
    ) -> HTMLResponse:
        # Backward-compatible route for an authorization attempt started before repair1.
        return await _google_callback_response(code=code, state=state, error=error)

    @app.post("/api/integrations/google/disconnect")
    async def google_disconnect(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        removed = await google.disconnect()
        return {"disconnected": True, "token_removed": removed}

    @app.get("/api/actions/audit")
    async def connected_action_audit(limit: int = Query(default=50, ge=1, le=200)) -> dict[str, Any]:
        return {"actions": actions.store.list_recent(tenant_id=resolved.local_tenant_id, limit=limit)}

    @app.get("/api/actions/pending")
    async def connected_action_pending() -> dict[str, Any]:
        return {"actions": actions.pending_actions()}

    @app.post("/api/actions/{action_id}/confirm")
    async def connected_action_confirm(action_id: str, request: Request, body: ConnectedActionDecisionBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        mode = validate_response_mode(body.response_mode)
        started_at = perf_counter()
        pending = actions.store.get_for_tenant(action_id, tenant_id=resolved.local_tenant_id)
        pending_actor = str((pending or {}).get("actor") or resolved.local_user_name)
        pending_session = str((pending or {}).get("session_id") or body.session_id or action_id)
        permission_context = _permission_context(
            request, channel="connected_action", actor_id=pending_actor, session_id=pending_session,
            allow_development_fallback=True,
        )
        prepared = actions.prepare_confirmation_for_action(
            action_id=action_id, permission_context=permission_context
        )
        permission_confirmation_authorized = False
        persist_allow_key = ""
        if prepared is not None:
            challenge_id = str(prepared.get("permission_challenge_id") or "")
            if _connected_action_can_use_conversational_confirmation(challenge_id, permission_context):
                permission_confirmation_authorized = True
            else:
                trusted_choice = _require_trusted_desktop_confirmation(
                    request,
                    challenge_id=challenge_id,
                    permission_context=permission_context,
                )
                permission_confirmation_authorized = True
                live = permissions.challenge_for_context(challenge_id, permission_context)
                if trusted_choice == _PERMISSION_NATIVE_ALWAYS_ALLOW:
                    persist_allow_key = live.permission_key
        result = await actions.confirm_action(
            action_id=action_id, user_text=body.user_text or "Confirm this action.", response_mode=mode,
            permission_context=permission_context,
            permission_confirmation_authorized=permission_confirmation_authorized,
        )
        if persist_allow_key and result.status != "pending_confirmation":
            _persist_trusted_permission_allow(persist_allow_key, permission_context)
        action_latency_ms = int((perf_counter() - started_at) * 1000)
        records = []
        for generated in result.usage:
            if generated.response_id:
                records.append(ledger.record_text(response_id=generated.response_id, session_id=body.session_id or action_id, model=generated.model, response_mode=mode, usage=generated.usage, purpose="connected_action"))
        payload = result.to_dict()
        payload.update({"records": records, "summary": ledger.summary(session_id=body.session_id or action_id), "budget": ledger.budget_status(limits, session_id=body.session_id or action_id), "planner_model": resolved.action_model, "realtime_role": "ears_only", "action_latency_ms": action_latency_ms})
        return payload

    @app.post("/api/actions/{action_id}/cancel")
    async def connected_action_cancel(action_id: str, request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        return actions.cancel_action(action_id=action_id).to_dict()

    @app.post("/api/actions/{action_id}/draft")
    async def connected_action_edit_draft(action_id: str, request: Request, body: ConnectedActionDraftEditBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            started_at = perf_counter()
            _require_permission(
                request, permission_key="gmail.draft.write", operation="edit_gmail_draft",
                resource_kind="gmail_draft", resource_id=action_id,
                channel="connected_action", actor_id=body.actor or resolved.local_user_name, session_id=body.session_id or action_id,
            )
            result = await actions.edit_pending_gmail_draft(
                action_id=action_id,
                recipients=body.recipients,
                cc=body.cc,
                bcc=body.bcc,
                subject=body.subject,
                body=body.body,
                actor=body.actor,
                session_id=body.session_id,
                permission_context=_permission_context(
                    request, channel="connected_action", actor_id=body.actor or resolved.local_user_name,
                    session_id=body.session_id or action_id, allow_development_fallback=True,
                ),
            )
        except GoogleIntegrationError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        payload = result.to_dict()
        payload.update({"planner_model": resolved.action_model, "realtime_role": "ears_only", "action_latency_ms": int((perf_counter() - started_at) * 1000)})
        return payload

    @app.post("/api/actions/turn")
    async def connected_action_turn(request: Request, body: ConnectedActionTurnBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            mode = validate_response_mode(body.response_mode)
            started_at = perf_counter()
            usage_session_id = (body.usage_session_id or body.session_id).strip()
            action_actor = body.actor or resolved.local_user_name
            permission_context = _permission_context(
                request, channel="connected_action", actor_id=action_actor, session_id=body.session_id,
                allow_development_fallback=True,
            )
            prepared = actions.prepare_confirmation_for_turn(
                user_text=body.user_text, actor=action_actor, session_id=body.session_id,
                permission_context=permission_context,
            )
            permission_confirmation_authorized = False
            persist_allow_key = ""
            if prepared is not None:
                challenge_id = str(prepared.get("permission_challenge_id") or "")
                if _connected_action_can_use_conversational_confirmation(challenge_id, permission_context):
                    # The user already answered Jarvis's exact natural review question.
                    # That is the one confirmation for routine Connected Actions.
                    permission_confirmation_authorized = True
                else:
                    trusted_choice = _require_trusted_desktop_confirmation(
                        request,
                        challenge_id=challenge_id,
                        permission_context=permission_context,
                    )
                    permission_confirmation_authorized = True
                    live = permissions.challenge_for_context(challenge_id, permission_context)
                    if trusted_choice == _PERMISSION_NATIVE_ALWAYS_ALLOW:
                        persist_allow_key = live.permission_key
            result = await actions.handle_turn(
                user_text=body.user_text,
                actor=action_actor,
                session_id=body.session_id,
                conversation_context=body.conversation_context,
                response_mode=mode,
                timezone_name=body.timezone_name,
                client_local_now=body.client_local_now,
                permission_context=permission_context,
                permission_confirmation_authorized=permission_confirmation_authorized,
            )
            if persist_allow_key and result.status != "pending_confirmation":
                _persist_trusted_permission_allow(persist_allow_key, permission_context)
        except TextProviderError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        except GoogleIntegrationError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        records = []
        for generated in result.usage:
            if generated.response_id:
                records.append(ledger.record_text(
                    response_id=generated.response_id,
                    session_id=usage_session_id,
                    model=generated.model,
                    response_mode=mode,
                    usage=generated.usage,
                    purpose="connected_action",
                ))
        payload = result.to_dict()
        original_spoken = str(payload.get("spoken_text") or "").strip()
        original_display = str(payload.get("display_text") or "").strip()
        if payload.get("handled") and payload.get("status") == "completed" and original_spoken:
            locked = action_locked_speech_facts(
                action=payload.get("action") if isinstance(payload.get("action"), dict) else {},
                user_text=body.user_text,
                fallback_spoken_text=original_spoken,
                timezone_name=body.timezone_name,
                client_local_now=body.client_local_now,
            )
            actor_name = (body.actor or "").strip()
            address_names: list[str] = []
            if resolved.memory_enabled and actor_name:
                for person in memory.people(actor_name, limit=8):
                    candidate = str(person.get("name") or "").strip()
                    if candidate.casefold() == actor_name.strip().casefold():
                        address_names = [str(value) for value in person.get("active_address_names") or [] if str(value).strip()]
                        break
            # Exact schedule follow-ups do not need another model pass at all. A
            # deterministic "2 PM" is both more human and more reliable than asking
            # any language model to restate a clock value it could mutate. Broader
            # action answers still go through Luna for natural conversational wording.
            if locked.preferred_short_answer:
                chosen_spoken = locked.preferred_short_answer
                truth_guard = "deterministic_short_answer"
            else:
                try:
                    naturalized = await text_provider.generate(
                        instructions=build_action_naturalization_instructions(
                            resolved,
                            response_mode=mode,
                            locked_facts=locked,
                            speaker_name=actor_name,
                            address_names=address_names,
                            personality=(body.personality or resolved.voice_personality).strip().lower() or resolved.voice_personality,
                        ),
                        input_text=build_action_naturalization_input(
                            operation=str((payload.get("action") or {}).get("operation") or "connected_action")
                            if isinstance(payload.get("action"), dict)
                            else "connected_action",
                            grounded_spoken_text=original_spoken,
                        ),
                        max_output_tokens=max(48, min(768, int(resolved.response_mode_max_words.get(mode, 120) or 120) * 4)),
                    )
                    records.append(ledger.record_text(
                        response_id=naturalized.response_id,
                        session_id=usage_session_id,
                        model=naturalized.model,
                        response_mode=mode,
                        usage=naturalized.usage,
                        purpose="action_naturalization",
                    ))
                    if validate_naturalized_action_text(naturalized.text, locked):
                        chosen_spoken = naturalized.text.strip()
                        truth_guard = "passed"
                    else:
                        chosen_spoken = original_spoken
                        truth_guard = "fallback"
                except (TextProviderError, ConfigurationError, ValueError) as exc:
                    LOGGER.warning("Action speech naturalization fell back to grounded wording: %s", redact_text(str(exc), (resolved.openai_api_key,)))
                    chosen_spoken = original_spoken
                    truth_guard = "provider_fallback"
            payload["spoken_text"] = chosen_spoken
            if not original_display or original_display == original_spoken:
                payload["display_text"] = chosen_spoken
            payload["speech_truth"] = {
                "guard": truth_guard,
                "locked_facts": locked.rendered,
                "required_literals": list(locked.required_literals),
                "realtime_can_rewrite": False,
            }
        payload.update({
            "records": records,
            "summary": ledger.summary(session_id=usage_session_id),
            "budget": ledger.budget_status(limits, session_id=usage_session_id),
            "planner_model": resolved.action_model,
            "realtime_role": "ears_only",
            "speech_role": "luna_script_then_tts",
            "action_latency_ms": int((perf_counter() - started_at) * 1000),
        })
        return payload

    @app.get("/api/usage/summary")
    async def usage_summary(session_id: str | None = Query(default=None, max_length=200)) -> dict[str, Any]:
        return {
            "summary": ledger.summary(session_id=session_id),
            "budget": ledger.budget_status(limits, session_id=session_id),
        }

    @app.post("/api/usage/record")
    async def record_usage(request: Request, body: UsageRecordBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            mode = validate_response_mode(body.response_mode)
            record = ledger.record(
                response_id=body.response_id,
                session_id=body.session_id,
                model=body.model,
                response_mode=mode,
                usage=body.usage,
                purpose="realtime_session",
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {
            "record": record,
            "summary": ledger.summary(session_id=body.session_id),
            "budget": ledger.budget_status(limits, session_id=body.session_id),
        }

    @app.post("/api/voice/reply")
    async def create_natural_voice_reply(request: Request, body: NaturalVoiceReplyBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            mode = validate_response_mode(body.response_mode)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        budget = ledger.budget_status(limits, session_id=body.session_id)
        if budget["hard_stops"]:
            raise HTTPException(status_code=402, detail=f"Jarvis API budget hard limit reached for: {', '.join(budget['hard_stops'])}.")
        # Unknown speakers stay identity-neutral. The desktop supplies actor only
        # after a confident voice-profile match; never silently borrow the local
        # owner's identity or forms of address for an unrecognized voice.
        actor_name = (body.actor or "").strip() or None
        memory_context = body.memory_context.strip()
        if not memory_context and resolved.memory_enabled:
            memory_context = memory.build_turn_context(
                body.user_text,
                actor=actor_name,
                session_id=body.session_id,
                character_limit=6200,
            )
        personality = (body.personality or resolved.voice_personality).strip().lower() or resolved.voice_personality
        instructions = build_natural_voice_instructions(
            resolved,
            response_mode=mode,
            speaker_name=(body.speaker_name or body.actor or "").strip(),
            address_names=body.address_names,
            personality=personality,
            memory_context=memory_context,
            capability_context=capability_registry.model_context(),
            client_time_context=client_time_context(body.client_local_now, body.timezone_name),
        )
        current_speaker_label = (body.speaker_name or "").strip() or "Unknown speaker"
        current_speaker_state = (body.speaker_status or "unknown").strip() or "unknown"
        current_session_speaker = (body.session_speaker_id or "").strip() or "unassigned"
        input_text = "\n".join((
            "CURRENT SPEAKER ATTRIBUTION — PRIVATE CONTEXT:",
            f"Speaker: {current_speaker_label}",
            f"Attribution status: {current_speaker_state}",
            f"Live session speaker id: {current_session_speaker}",
            "Treat speaker labels in recent conversation as distinct people. Never transfer one person's first-person statements, preferences, tasks, or forms of address to another speaker.",
            "",
            "CURRENT USER TURN — ANSWER THIS TURN:", body.user_text.strip(), "",
            "RECENT CONVERSATION — REFERENCE ONLY; DO NOT ANSWER OLD TURNS:",
            body.conversation_context.strip() or "No additional recent conversation is required.",
        ))
        try:
            generated = await text_provider.generate(
                instructions=instructions,
                input_text=input_text,
                max_output_tokens=max(64, min(2048, int(resolved.response_mode_max_words.get(mode, 120) or 120) * 4)),
            )
            record = ledger.record_text(
                response_id=generated.response_id,
                session_id=body.session_id,
                model=generated.model,
                response_mode=mode,
                usage=generated.usage,
                purpose="voice_reply",
            )
        except ConfigurationError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except TextProviderError as exc:
            safe = redact_text(str(exc), (resolved.openai_api_key,))
            LOGGER.error("Natural voice response generation failed: %s", safe)
            raise HTTPException(status_code=502, detail=safe) from exc
        return {
            "spoken_text": generated.text,
            "response_id": generated.response_id,
            "request_id": generated.request_id,
            "model": generated.model,
            "record": record,
            "summary": ledger.summary(session_id=body.session_id),
            "budget": ledger.budget_status(limits, session_id=body.session_id),
            "personality": personality,
            "speech_role": "luna_script",
        }

    @app.post("/api/speech/synthesize")
    async def synthesize_speech(request: Request, body: SpeechSynthesisBody) -> Response:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        if not resolved.speech_enabled:
            raise HTTPException(status_code=409, detail="Dedicated Jarvis speech is disabled.")
        try:
            mode = validate_response_mode(body.response_mode)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        personality = (body.personality or resolved.voice_personality).strip().lower() or resolved.voice_personality
        delivery = body.delivery.strip() or speech_delivery_instructions(
            personality=personality,
            response_mode=mode,
            text=body.text,
            user_text=body.user_text,
            response_purpose=body.response_purpose,
        )
        if resolved.provider_mode == "hosted":
            requested_provider = "jarvis-cloud"
            requested_voice = "server-default"
        else:
            requested_provider = (body.provider or resolved.speech_provider).strip().lower() or resolved.speech_provider
            if requested_provider not in SUPPORTED_SPEECH_PROVIDERS:
                raise HTTPException(status_code=400, detail="Unsupported speech provider.")
            if requested_provider == "elevenlabs" and not resolved.elevenlabs_configured:
                raise HTTPException(
                    status_code=409,
                    detail="ElevenLabs is not configured for direct development mode.",
                )
            requested_voice = resolved.elevenlabs_voice_id if requested_provider == "elevenlabs" else (body.voice or resolved.speech_voice)
            if requested_provider == "openai":
                try:
                    requested_voice = validate_voice(str(requested_voice or resolved.speech_voice))
                except ValueError as exc:
                    raise HTTPException(status_code=400, detail=str(exc)) from exc
        try:
            try:
                speech = await speech_provider.synthesize(
                    text=body.text,
                    instructions=delivery,
                    provider=requested_provider,
                    voice=requested_voice,
                    response_format="wav",
                )
            except TypeError as exc:
                if "provider" not in str(exc):
                    raise
                speech = await speech_provider.synthesize(
                    text=body.text,
                    instructions=delivery,
                    voice=resolved.speech_voice,
                    response_format="wav",
                )
        except ConfigurationError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except SpeechProviderError as exc:
            safe = redact_text(str(exc), (resolved.openai_api_key, resolved.elevenlabs_api_key))
            LOGGER.error("Speech generation failed: %s", safe)
            raise HTTPException(status_code=exc.status_code, detail=safe) from exc
        headers = {
            "Cache-Control": "no-store",
            "X-Jarvis-Speech-Provider": getattr(speech, "provider", requested_provider),
            "X-Jarvis-Speech-Model": speech.model,
            "X-Jarvis-Speech-Voice": speech.voice,
        }
        if speech.request_id:
            headers["X-Request-ID"] = speech.request_id
        return Response(content=speech.audio, media_type=speech.content_type, headers=headers)

    @app.post("/api/text/detailed-answer")
    async def create_detailed_text_answer(
        request: Request,
        body: DetailedTextAnswerBody,
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        if not resolved.dual_channel_answers_enabled:
            raise HTTPException(status_code=409, detail="Detailed written answers are disabled.")
        try:
            response_mode = validate_response_mode(body.response_mode)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        budget = ledger.budget_status(limits, session_id=body.session_id)
        if resolved.provider_mode == "direct_development" and budget["hard_stops"]:
            raise HTTPException(
                status_code=402,
                detail=f"Jarvis API budget hard limit reached for: {', '.join(budget['hard_stops'])}.",
            )
        try:
            if resolved.provider_mode == "direct_development":
                resolved.require_openai_api_key()
            answer_actor = body.actor or resolved.local_user_name
            memory_context = (
                memory.build_turn_context(
                    body.user_text,
                    actor=answer_actor,
                    session_id=body.session_id,
                    character_limit=6200,
                )
                if resolved.memory_enabled
                else ""
            )
            working_context = actions.render_task_working_context_for_actor(actor=answer_actor, query=body.user_text)
            if working_context:
                memory_context = f"{memory_context.strip()}\n\n{working_context}".strip()
            instructions = build_detailed_answer_instructions(
                capability_context=capability_registry.model_context(),
                memory_context=memory_context or "",
            )
            input_text = "\n".join((
                "ORIGINAL USER REQUEST:",
                body.user_text.strip(),
                "",
                "RECENT CONVERSATION CONTEXT:",
                body.conversation_context.strip() or "No additional recent context is required.",
            ))
            result = await text_provider.generate(
                instructions=instructions,
                input_text=input_text,
                max_output_tokens=resolved.detailed_text_max_output_tokens,
            )
            record = ledger.record_text(
                response_id=result.response_id,
                session_id=body.session_id,
                model=result.model,
                response_mode=response_mode,
                usage=result.usage,
                purpose="detailed_answer",
            )
        except ConfigurationError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except TextProviderError as exc:
            safe = redact_text(str(exc), (resolved.openai_api_key,))
            LOGGER.error("Detailed text generation failed: %s", safe)
            raise HTTPException(status_code=502, detail=safe) from exc
        return {
            "answer": result.text,
            "response_id": result.response_id,
            "request_id": result.request_id,
            "model": result.model,
            "record": record,
            "summary": ledger.summary(session_id=body.session_id),
            "budget": ledger.budget_status(limits, session_id=body.session_id),
        }

    @app.post("/api/wake/transcribe")
    async def transcribe_wake(
        request: Request,
        session_id: str = Query(min_length=1, max_length=200),
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        content_type = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        if content_type not in {"audio/wav", "audio/wave", "audio/x-wav"}:
            raise HTTPException(status_code=415, detail="Content-Type must be audio/wav")
        budget = ledger.budget_status(limits, session_id=session_id)
        hard_stops = [scope for scope in budget["hard_stops"] if scope in {"daily", "monthly"}]
        if resolved.provider_mode == "direct_development" and hard_stops:
            raise HTTPException(
                status_code=402,
                detail=f"Jarvis API budget hard limit reached for: {', '.join(hard_stops)}.",
            )
        try:
            if resolved.provider_mode == "direct_development":
                resolved.require_openai_api_key()
            audio_bytes = await request.body()
            if len(audio_bytes) > 8_000_000:
                raise HTTPException(status_code=413, detail="wake audio is too large")
            duration = _wav_duration_seconds(audio_bytes)
            result = await wake_transcriber.transcribe(audio_bytes)
            response_id = f"wake_{result.request_id or uuid4()}"
            record = ledger.record_transcription(
                response_id=response_id,
                session_id=session_id,
                model=resolved.wake_transcription_model,
                duration_seconds=duration,
                usage=result.usage,
            )
        except ConfigurationError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except TranscriptionProviderError as exc:
            safe = redact_text(str(exc), (resolved.openai_api_key,))
            LOGGER.error("Wake transcription failed: %s", safe)
            raise HTTPException(status_code=502, detail=safe) from exc
        return {
            "transcript": result.text,
            "duration_seconds": round(duration, 3),
            "record": record,
            "summary": ledger.summary(session_id=session_id),
            "budget": ledger.budget_status(limits, session_id=session_id),
        }

    @app.get("/api/realtime/session-profile")
    async def realtime_session_profile(
        request: Request,
        response_mode: str = Query(default=resolved.response_mode),
        timezone_name: str = Query(default="", max_length=100),
        client_local_now: str = Query(default="", max_length=80),
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            response_mode = validate_response_mode(response_mode)
            memory_context = (
                memory.build_realtime_context(
                    fact_limit=resolved.memory_context_fact_limit,
                    recent_event_limit=resolved.memory_context_event_limit,
                )
                if resolved.memory_enabled
                else None
            )
            session = build_session_config(
                resolved,
                voice=resolved.realtime_voice,
                turn_detection_profile=resolved.turn_detection_profile,
                response_mode=response_mode,
                memory_context=memory_context,
                capability_context=capability_registry.model_context(),
                client_local_now=client_local_now,
                timezone_name=timezone_name,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {
            "profile": {
                "type": "realtime",
                "response_mode": response_mode,
                "instructions": session["instructions"],
                "max_output_tokens": session["max_output_tokens"],
            }
        }

    @app.post("/api/realtime/session")
    async def create_realtime_session(
        request: Request,
        voice: str = Query(default=resolved.realtime_voice),
        turn_detection_profile: str = Query(default=resolved.turn_detection_profile),
        response_mode: str = Query(default=resolved.response_mode),
        timezone_name: str = Query(default="", max_length=100),
        client_local_now: str = Query(default="", max_length=80),
    ) -> Response:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        if request.headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/sdp":
            raise HTTPException(status_code=415, detail="Content-Type must be application/sdp")
        try:
            voice = validate_voice(voice)
            turn_detection_profile = validate_turn_detection_profile(turn_detection_profile)
            response_mode = validate_response_mode(response_mode)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        if resolved.provider_mode != "hosted":
            budget = ledger.budget_status(limits)
            account_hard_stops = [scope for scope in budget["hard_stops"] if scope in {"daily", "monthly"}]
            if account_hard_stops:
                scopes = ", ".join(account_hard_stops)
                raise HTTPException(
                    status_code=402,
                    detail=f"Jarvis API budget hard limit reached for: {scopes}. Adjust the local budget settings to continue.",
                )

        correlation_id = uuid4()
        event_runtime.publish_internal(
            EventType.PROVIDER_SESSION_CONNECTING,
            {
                "model": resolved.realtime_model,
                "voice": voice,
                "turn_detection_profile": turn_detection_profile,
                "response_mode": response_mode,
            },
            correlation_id=correlation_id,
        )
        try:
            if resolved.provider_mode != "hosted":
                resolved.require_openai_api_key()
            body = await request.body()
            if len(body) > 1_000_000:
                raise HTTPException(status_code=413, detail="SDP offer is too large")
            offer = body.decode("utf-8")
            memory_context = (
                memory.build_realtime_context(
                    fact_limit=resolved.memory_context_fact_limit,
                    recent_event_limit=resolved.memory_context_event_limit,
                )
                if resolved.memory_enabled
                else None
            )
            result = await provider.create_call(
                offer,
                voice=voice,
                turn_detection_profile=turn_detection_profile,
                response_mode=response_mode,
                memory_context=memory_context,
                capability_context=capability_registry.model_context(),
                client_local_now=client_local_now,
                timezone_name=timezone_name,
            )
        except ConfigurationError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except UnicodeDecodeError as exc:
            raise HTTPException(status_code=400, detail="SDP offer must be UTF-8 text") from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except RealtimeProviderError as exc:
            safe = redact_text(str(exc), (resolved.openai_api_key,))
            LOGGER.error("Realtime session creation failed: %s", safe)
            event_runtime.publish_internal(
                EventType.PROVIDER_DEGRADED,
                {"message": safe, "request_id": exc.request_id},
                correlation_id=correlation_id,
            )
            return JSONResponse(
                status_code=502,
                content={
                    "error": "Jarvis Realtime session creation failed",
                    "detail": safe,
                    **({"request_id": exc.request_id} if resolved.provider_mode != "hosted" and exc.request_id else {}),
                },
            )
        event_runtime.publish_internal(
            EventType.PROVIDER_SESSION_CONNECTED,
            {
                "request_id": result.request_id,
                "model": resolved.realtime_model,
                "voice": voice,
                "turn_detection_profile": turn_detection_profile,
                "response_mode": response_mode,
            },
            correlation_id=correlation_id,
        )
        headers = {"Cache-Control": "no-store"}
        if resolved.provider_mode == "hosted" and result.public_session_id:
            headers["X-Jarvis-Realtime-Session"] = result.public_session_id
        elif result.request_id:
            headers["X-Jarvis-Upstream-Request-Id"] = result.request_id
        return Response(
            content=result.sdp_answer.encode("utf-8"),
            media_type="application/sdp",
            headers=headers,
        )

    @app.websocket("/api/realtime/events")
    async def local_realtime_events(websocket: WebSocket, session_id: str = Query(default="")) -> None:
        if resolved.provider_mode != "hosted" or not isinstance(provider, HostedRealtimeGateway):
            await websocket.close(code=1008, reason="Hosted Realtime is not active")
            return
        clean_session = str(session_id or "").strip()
        if not clean_session.startswith("rts_") or len(clean_session) > 100:
            await websocket.close(code=1008, reason="Invalid Realtime session")
            return
        try:
            cloud_socket = await provider.connect_events(clean_session)
        except RealtimeProviderError:
            await websocket.close(code=1013, reason="Jarvis Cloud Realtime unavailable")
            return
        await websocket.accept()

        async def browser_to_cloud() -> None:
            while True:
                message = await websocket.receive_text()
                try:
                    payload = json.loads(message)
                except ValueError as exc:
                    raise PermissionError("Realtime control must be valid JSON") from exc
                if not isinstance(payload, dict):
                    raise PermissionError("Realtime control must be an object")
                # Core prefilters for diagnostics/least privilege, but Cloud repeats
                # this validation because the entire desktop is assumed hostile.
                allowed = {"input_audio_buffer.clear", "jarvis.control.ping", "jarvis.session.hangup"}
                if str(payload.get("type") or "") not in allowed:
                    raise PermissionError("Realtime control is not allowed")
                await cloud_socket.send(json.dumps(payload, separators=(",", ":")))

        async def cloud_to_browser() -> None:
            async for message in cloud_socket:
                await websocket.send_text(message if isinstance(message, str) else message.decode("utf-8"))

        browser_task = asyncio.create_task(browser_to_cloud())
        cloud_task = asyncio.create_task(cloud_to_browser())
        try:
            done, pending = await asyncio.wait({browser_task, cloud_task}, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            for task in done:
                task.result()
        except (WebSocketDisconnect, PermissionError, ValueError, UnicodeDecodeError):
            pass
        finally:
            try:
                await cloud_socket.send(json.dumps({"type": "jarvis.session.hangup"}))
            except Exception:
                pass
            await cloud_socket.close()
            try:
                await websocket.close()
            except Exception:
                pass

    @app.get("/api/tasks")
    async def list_tasks(
        actor: str | None = None,
        status: str = Query(default="open", pattern="^(open|completed|cancelled)$"),
        limit: int = Query(default=100, ge=1, le=500),
    ) -> dict[str, Any]:
        task_actor = str(actor or resolved.local_user_name or "User").strip() or "User"
        return {
            "tasks": actions.task_list_for_actor(actor=task_actor, status=status, limit=limit),
            "stats": actions.task_stats_for_actor(actor=task_actor),
            "actor": task_actor,
            "working_context": actions.task_working_context_for_actor(actor=task_actor),
        }

    @app.get("/api/tasks/stats")
    async def task_stats(actor: str | None = None) -> dict[str, Any]:
        task_actor = str(actor or resolved.local_user_name or "User").strip() or "User"
        return {"stats": actions.task_stats_for_actor(actor=task_actor), "actor": task_actor}

    @app.post("/api/tasks")
    async def create_task(request: Request, body: TaskCreateBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        task_actor = str(body.actor or resolved.local_user_name or "User").strip() or "User"
        task_timezone = effective_user_timezone(body.timezone_name, body.client_local_now)
        try:
            result = actions.tasks.create(
                actor=task_actor,
                session_id=body.session_id or None,
                timezone_name=task_timezone,
                arguments={
                    "task_title": body.title, "task_notes": body.notes, "task_priority": body.priority,
                    "task_due_at": body.due_at, "task_reminder_at": body.reminder_at, "task_recurrence": body.recurrence,
                },
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"task": result, "stats": actions.task_stats_for_actor(actor=task_actor)}

    @app.patch("/api/tasks/{task_id}")
    async def update_task(task_id: str, request: Request, body: TaskUpdateBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        task_actor = str(body.actor or resolved.local_user_name or "User").strip() or "User"
        arguments: dict[str, Any] = {"task_id": task_id}
        if body.title is not None: arguments["task_title"] = body.title
        if body.notes is not None: arguments["task_notes"] = body.notes
        if body.priority is not None: arguments["task_priority"] = body.priority
        if body.due_at is not None: arguments["task_due_at"] = body.due_at
        if body.reminder_at is not None: arguments["task_reminder_at"] = body.reminder_at
        if body.recurrence is not None: arguments["task_recurrence"] = body.recurrence
        task_timezone = effective_user_timezone(body.timezone_name, body.client_local_now)
        task, error = actions.tasks.update(actor=task_actor, arguments=arguments, timezone_name=task_timezone)
        if error or task is None:
            status_code = 400 if error and error.startswith("For security, Jarvis won’t store") else 404
            raise HTTPException(status_code=status_code, detail=error or "task not found")
        return {"task": task, "stats": actions.task_stats_for_actor(actor=task_actor)}

    @app.post("/api/tasks/{task_id}/complete")
    async def complete_task(
        task_id: str,
        request: Request,
        actor: str | None = None,
        timezone_name: str = Query(default="UTC", max_length=100),
        client_local_now: str = Query(default="", max_length=80),
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        task_actor = str(actor or resolved.local_user_name or "User").strip() or "User"
        task_timezone = effective_user_timezone(timezone_name, client_local_now)
        task, error = actions.tasks.complete(actor=task_actor, arguments={"task_id": task_id}, timezone_name=task_timezone)
        if error or task is None:
            raise HTTPException(status_code=404, detail=error or "task not found")
        return {"task": task, "stats": actions.task_stats_for_actor(actor=task_actor)}

    @app.post("/api/tasks/{task_id}/reopen")
    async def reopen_task(task_id: str, request: Request, actor: str | None = None) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        task_actor = str(actor or resolved.local_user_name or "User").strip() or "User"
        task, error = actions.tasks.reopen(actor=task_actor, arguments={"task_id": task_id})
        if error or task is None:
            raise HTTPException(status_code=404, detail=error or "task not found")
        return {"task": task, "stats": actions.task_stats_for_actor(actor=task_actor)}

    @app.delete("/api/tasks/{task_id}")
    async def cancel_task(task_id: str, request: Request, actor: str | None = None) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        task_actor = str(actor or resolved.local_user_name or "User").strip() or "User"
        task, error = actions.tasks.delete(actor=task_actor, arguments={"task_id": task_id})
        if error or task is None:
            raise HTTPException(status_code=404, detail=error or "task not found")
        return {"task": task, "stats": actions.task_stats_for_actor(actor=task_actor)}

    @app.post("/api/tasks/reminders/claim")
    async def claim_task_reminders(
        request: Request,
        actor: str | None = None,
        limit: int = Query(default=25, ge=1, le=100),
        timezone_name: str = Query(default="UTC", max_length=100),
        client_local_now: str = Query(default="", max_length=80),
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        task_actor = str(actor or resolved.local_user_name or "User").strip() or "User"
        task_timezone = effective_user_timezone(timezone_name, client_local_now)
        return {
            "reminders": actions.task_reminders_due(actor=task_actor, limit=limit, timezone_name=task_timezone),
            "actor": task_actor,
        }

    @app.post("/api/memory/events")
    async def remember_event(request: Request, body: MemoryEventBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        if not resolved.memory_enabled:
            raise HTTPException(status_code=503, detail="Jarvis durable memory is disabled")
        _require_permission(
            request, permission_key="memory.write", operation="memory.remember",
            resource_kind="memory_event", resource_id=body.idempotency_key or body.source_event_id or "new",
            actor_id=body.actor or resolved.local_user_name, session_id=body.session_id or "memory_write",
        )
        try:
            stored = memory.remember(
                content=body.content,
                source=body.source,
                kind=body.kind,
                actor=body.actor or resolved.local_user_name,
                occurred_at=body.occurred_at,
                timezone_name=body.timezone_name,
                session_id=body.session_id,
                source_event_id=body.source_event_id,
                idempotency_key=body.idempotency_key,
                confidence=body.confidence,
                privacy=body.privacy,
                category_path=body.category_path,
                metadata=body.metadata,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        if (
            resolved.memory_proactive_enabled
            and str(body.source) != "assistant"
            and str(body.kind) != "response"
        ):
            proactive_refresh_signal.set()
        return {"accepted": True, "memory": stored.to_dict(), "stats": memory.stats()}

    @app.get("/api/memory/search")
    async def search_memory(
        request: Request,
        q: str = Query(default="", max_length=500),
        limit: int = Query(default=50, ge=1, le=250),
        category: str | None = Query(default=None, max_length=160),
        source: str | None = Query(default=None, max_length=80),
        actor: str | None = Query(default=None, max_length=160),
        date_from: str | None = Query(default=None, max_length=10),
        date_to: str | None = Query(default=None, max_length=10),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.search", resource_kind="memory")
        return {
            "memories": memory.search(
                q,
                limit=limit,
                category=category,
                source=source,
                actor=actor,
                date_from=date_from,
                date_to=date_to,
            ),
            "stats": memory.stats(),
        }

    @app.get("/api/memory/explore")
    async def explore_memory(
        request: Request,
        q: str = Query(default="", max_length=500),
        limit: int = Query(default=100, ge=1, le=250),
        category: str | None = Query(default=None, max_length=160),
        source: str | None = Query(default=None, max_length=80),
        actor: str | None = Query(default=None, max_length=160),
        date_from: str | None = Query(default=None, max_length=10),
        date_to: str | None = Query(default=None, max_length=10),
        status: str | None = Query(default=None, max_length=20),
        important: bool | None = Query(default=None),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.explore", resource_kind="memory")
        return memory.explore(
            q, limit=limit, category=category, source=source, actor=actor,
            date_from=date_from, date_to=date_to, status=status, important=important,
        )

    @app.get("/api/memory/events/{event_id}")
    async def memory_event_detail(event_id: str, request: Request) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.event_detail", resource_kind="memory_event", resource_id=event_id)
        result = memory.event(event_id)
        if result is None:
            raise HTTPException(status_code=404, detail="memory event not found")
        return {"memory": result}

    @app.post("/api/memory/context/resolve")
    async def resolve_memory_context(request: Request, body: MemoryContextQueryBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        actor_name = body.actor or resolved.local_user_name
        _require_permission(
            request, permission_key="memory.read", operation="memory.resolve_context", resource_kind="memory",
            actor_id=actor_name, session_id=body.session_id or "memory_context",
        )
        result = memory.resolve_context(
            body.query,
            actor=actor_name,
            session_id=body.session_id,
            fact_limit=body.fact_limit,
            event_limit=body.event_limit,
            proactive_limit=body.proactive_limit,
            character_limit=body.character_limit,
        )
        working = actions.render_task_working_context_for_actor(actor=actor_name, query=body.query)
        if working:
            rendered = str(result.get("rendered") or "").strip()
            result["rendered"] = f"{rendered}\n\n{working}".strip()
            result["working_context"] = {"type": "task_focus", "active": True}
        return result


    @app.post("/api/memory/commands")
    async def apply_memory_command(request: Request, body: MemoryCommandBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(
            request, permission_key="memory.write", operation="memory.command", resource_kind="memory",
            resource_id=body.command_event_id or "command", actor_id=body.actor or resolved.local_user_name,
        )
        try:
            result = memory.apply_memory_command(
                body.content,
                command_event_id=body.command_event_id,
                session_id=body.session_id,
                actor=body.actor or resolved.local_user_name,
            )
        except (ValueError, KeyError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        result["stats"] = memory.stats()
        return result

    @app.post("/api/memory/events/{event_id}/lifecycle")
    async def set_memory_event_lifecycle(
        request: Request, event_id: str, body: MemoryLifecycleBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.event_lifecycle", resource_kind="memory_event", resource_id=event_id)
        try:
            result = memory.set_event_lifecycle(
                event_id, body.status, reason=body.reason, source_event_id=body.source_event_id
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        result["stats"] = memory.stats()
        return result

    @app.get("/api/memory/events/{event_id}/history")
    async def memory_event_lifecycle_history(
        request: Request,
        event_id: str, limit: int = Query(default=100, ge=1, le=250)
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.event_history", resource_kind="memory_event", resource_id=event_id)
        return {"history": memory.lifecycle_history("event", event_id, limit=limit)}

    @app.get("/api/memory/facts/{fact_id}")
    async def memory_fact_detail(request: Request, fact_id: str) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.fact_detail", resource_kind="memory_fact", resource_id=fact_id)
        result = memory.fact(fact_id)
        if result is None:
            raise HTTPException(status_code=404, detail="memory fact not found")
        return {"fact": result}

    @app.post("/api/memory/facts/{fact_id}/lifecycle")
    async def set_memory_fact_lifecycle(
        request: Request, fact_id: str, body: MemoryFactLifecycleBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.fact_lifecycle", resource_kind="memory_fact", resource_id=fact_id)
        try:
            fact = memory.set_fact_lifecycle(
                fact_id, body.status, reason=body.reason, source_event_id=body.source_event_id
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"fact": fact, "stats": memory.stats()}

    @app.post("/api/memory/relationships/{relationship_id}/lifecycle")
    async def set_memory_relationship_lifecycle(
        request: Request, relationship_id: str, body: MemoryRelationshipLifecycleBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.relationship_lifecycle", resource_kind="memory_relationship", resource_id=relationship_id)
        try:
            result = memory.set_relationship_lifecycle(
                relationship_id, body.status, reason=body.reason, source_event_id=body.source_event_id
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        result["stats"] = memory.stats()
        return result

    @app.patch("/api/memory/events/{event_id}")
    async def update_memory_event(request: Request, event_id: str, body: MemoryUpdateBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.event_update", resource_kind="memory_event", resource_id=event_id)
        changes = body.model_dump(exclude_none=True)
        if not changes:
            raise HTTPException(status_code=400, detail="no memory changes were provided")
        if "privacy" in changes:
            changes["privacy"] = str(changes["privacy"])
        try:
            result = memory.update_event(event_id, **changes)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"memory": result, "stats": memory.stats()}

    @app.delete("/api/memory/events/{event_id}")
    async def delete_memory_event(request: Request, event_id: str) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.delete", operation="memory.event_delete", resource_kind="memory_event", resource_id=event_id)
        try:
            result = memory.delete_event(event_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        result["stats"] = memory.stats()
        return result

    @app.get("/api/memory/timeline")
    async def memory_timeline(
        request: Request,
        date: str | None = Query(default=None, max_length=10),
        limit: int = Query(default=100, ge=1, le=250),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.timeline", resource_kind="memory", resource_id="timeline")
        return {"memories": memory.timeline(local_date=date, limit=limit), "stats": memory.stats()}

    @app.get("/api/memory/categories")
    async def memory_categories(request: Request, ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.categories", resource_kind="memory", resource_id="categories")
        return {"categories": memory.categories()}

    @app.get("/api/memory/entities")
    async def memory_entities(
        request: Request,
        q: str = Query(default="", max_length=300),
        limit: int = Query(default=100, ge=1, le=250),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.entities", resource_kind="memory", resource_id="entities")
        return {"entities": memory.entities(q, limit=limit)}

    @app.get("/api/memory/entities/{entity_id}")
    async def memory_entity_detail(
        request: Request,
        entity_id: str,
        event_limit: int = Query(default=100, ge=1, le=250),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.entity_detail", resource_kind="memory_entity", resource_id=entity_id)
        result = memory.entity(entity_id, event_limit=event_limit)
        if result is None:
            raise HTTPException(status_code=404, detail="memory entity not found")
        return {"entity": result}

    @app.post("/api/memory/entities/merge")
    async def merge_memory_entities(request: Request, body: MemoryEntityMergeBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.entity_merge", resource_kind="memory_entity", resource_id=f"{body.source_id}:{body.target_id}")
        try:
            result = memory.merge_entities(body.source_id, body.target_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        result["stats"] = memory.stats()
        return result

    @app.post("/api/memory/entities/{entity_id}/split")
    async def split_memory_entity(request: Request, entity_id: str) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.entity_split", resource_kind="memory_entity", resource_id=entity_id)
        try:
            result = memory.split_entity(entity_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        result["stats"] = memory.stats()
        return result

    @app.get("/api/memory/people")
    async def memory_people(
        request: Request,
        q: str = Query(default="", max_length=300),
        limit: int = Query(default=100, ge=1, le=250),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.people", resource_kind="memory", resource_id="people")
        return {"people": memory.people(q, limit=limit), "stats": memory.stats()}

    @app.get("/api/memory/people/{entity_id}")
    async def memory_person_detail(
        request: Request,
        entity_id: str,
        event_limit: int = Query(default=100, ge=1, le=250),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.person_detail", resource_kind="memory_person", resource_id=entity_id)
        result = memory.person(entity_id, event_limit=event_limit)
        if result is None:
            raise HTTPException(status_code=404, detail="person profile not found")
        return {"person": result}

    @app.patch("/api/memory/people/{entity_id}")
    async def update_memory_person(
        request: Request, entity_id: str, body: PersonProfileUpdateBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.person_update", resource_kind="memory_person", resource_id=entity_id)
        changes = body.model_dump(exclude_none=True)
        if not changes:
            raise HTTPException(status_code=400, detail="no person-profile changes were provided")
        try:
            person = memory.update_person(entity_id, **changes)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"person": person, "stats": memory.stats()}

    @app.post("/api/memory/people/{entity_id}/aliases")
    async def add_memory_person_alias(
        request: Request, entity_id: str, body: PersonAliasBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.person_alias", resource_kind="memory_person", resource_id=entity_id)
        try:
            person = memory.add_person_alias(entity_id, body.alias)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"person": person, "stats": memory.stats()}


    @app.post("/api/memory/people/{entity_id}/address-names")
    async def set_memory_person_address_names(
        request: Request, entity_id: str, body: PersonAddressNamesBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.person_address_names", resource_kind="memory_person", resource_id=entity_id)
        try:
            person = memory.set_person_address_names(
                entity_id,
                body.names,
                action=body.action,
                source_event_id=body.source_event_id,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"person": person, "stats": memory.stats()}

    @app.put("/api/memory/people/{entity_id}/permissions")
    async def set_memory_person_permission(
        request: Request, entity_id: str, body: PersonPermissionBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        # Bind authenticated confirmation to the exact protection mutation, not
        # merely the person record. Raw values are used only as transient
        # fingerprint input; PermissionStore persists the resulting hash.
        protection_action = json.dumps(
            {"entity_id": entity_id, "memory_scope": body.memory_scope, "access_level": body.access_level},
            sort_keys=True, separators=(",", ":"),
        )
        _require_permission(
            request, permission_key="security.change_protection", operation="memory.person_permission",
            resource_kind="memory_person", resource_id=protection_action,
        )
        try:
            person = memory.set_person_permission(entity_id, body.memory_scope, body.access_level)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"person": person, "stats": memory.stats()}

    @app.post("/api/memory/people/relationships")
    async def set_memory_person_relationship(
        request: Request, body: PersonRelationshipBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.person_relationship", resource_kind="memory_person", resource_id=f"{body.source_id}:{body.target_id}")
        try:
            result = memory.set_person_relationship(
                body.source_id,
                body.relationship,
                body.target_id,
                status=body.status,
                confidence=body.confidence,
                source_event_id=body.source_event_id,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        result["stats"] = memory.stats()
        return result

    @app.post("/api/memory/events/{event_id}/attribute")
    async def attribute_memory_event(
        request: Request, event_id: str, body: EventAttributionBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.event_attribution", resource_kind="memory_event", resource_id=event_id)
        try:
            result = memory.attribute_event(
                event_id,
                body.person_entity_id,
                reason=body.reason,
                source_event_id=body.source_event_id,
                confidence=body.confidence,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"memory": result, "stats": memory.stats()}

    @app.get("/api/voice-profiles")
    async def list_voice_profiles(request: Request) -> dict[str, Any]:
        _require_permission(request, permission_key="voice_profile.use", operation="voice_profile.list", resource_kind="voice_profile")
        return {
            "profiles": voice_profiles.profiles(),
            "people": memory.people(limit=250),
            "enabled": resolved.speaker_recognition_enabled,
            "tenant_id": resolved.local_tenant_id,
            "local_only": True,
            "recommended_samples": 3,
            "enrollment_prompts": voice_profiles.enrollment_prompts(),
        }

    @app.get("/api/voice-profiles/{person_entity_id}")
    async def voice_profile_detail(person_entity_id: str, request: Request) -> dict[str, Any]:
        _require_permission(request, permission_key="voice_profile.use", operation="voice_profile.detail", resource_kind="voice_profile", resource_id=person_entity_id)
        profile = voice_profiles.profile(person_entity_id)
        if profile is None:
            person = memory.person(person_entity_id, event_limit=10)
            if person is None:
                raise HTTPException(status_code=404, detail="person profile not found")
            return {"profile": None, "person": person}
        return {"profile": profile}

    @app.post("/api/voice-profiles/{person_entity_id}/samples")
    async def enroll_voice_sample(request: Request, person_entity_id: str) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        if request.headers.get("x-voice-consent", "").lower() not in {"true", "1", "yes"}:
            raise HTTPException(status_code=400, detail="voice enrollment requires confirmed consent")
        # Read and hash the opaque bytes before the permission gate so the exact
        # enrollment sample participates in the confirmation fingerprint.  This
        # is not biometric processing: no decoding, embedding, recognition, or
        # profile mutation occurs until after the executor permission check.
        audio = await request.body()
        enrollment_fingerprint = json.dumps({
            "person_entity_id": person_entity_id,
            "audio_sha256": hashlib.sha256(audio).hexdigest(),
            "filename": request.headers.get("x-file-name", "voice-sample.wav"),
            "enrollment_prompt_id": request.headers.get("x-enrollment-prompt", ""),
        }, sort_keys=True, separators=(",", ":"))
        _require_permission(
            request, permission_key="voice_profile.enroll", operation="voice_profile.enroll",
            resource_kind="voice_profile_enrollment", resource_id=enrollment_fingerprint,
            session_id=request.headers.get("x-session-id") or "voice_enrollment",
        )
        if not audio or len(audio) > 32 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="voice sample is empty or too large")
        try:
            profile = await asyncio.to_thread(
                voice_profiles.enroll,
                person_entity_id,
                audio,
                filename=request.headers.get("x-file-name", "voice-sample.wav"),
                consent_confirmed=True,
                enrollment_prompt_id=request.headers.get("x-enrollment-prompt", ""),
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except (ValueError, VoiceQualityError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"profile": profile, "stats": memory.stats()}

    @app.delete("/api/voice-profiles/{person_entity_id}/samples/{sample_id}")
    async def delete_voice_sample(request: Request, person_entity_id: str, sample_id: str) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="voice_profile.delete", operation="voice_profile.sample_delete", resource_kind="voice_profile", resource_id=f"{person_entity_id}:{sample_id}")
        try:
            profile = await asyncio.to_thread(voice_profiles.delete_sample, person_entity_id, sample_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return {"profile": profile, "stats": memory.stats()}

    @app.patch("/api/voice-profiles/{person_entity_id}")
    async def configure_voice_profile(request: Request, person_entity_id: str, body: VoiceProfileUpdateBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="voice_profile.manage", operation="voice_profile.configure", resource_kind="voice_profile", resource_id=person_entity_id)
        if body.enabled is None and body.threshold is None:
            raise HTTPException(status_code=400, detail="no voice-profile changes were provided")
        try:
            profile = voice_profiles.configure(person_entity_id, enabled=body.enabled, threshold=body.threshold)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return {"profile": profile, "stats": memory.stats()}

    @app.delete("/api/voice-profiles/{person_entity_id}")
    async def delete_voice_profile(request: Request, person_entity_id: str) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="voice_profile.delete", operation="voice_profile.delete", resource_kind="voice_profile", resource_id=person_entity_id)
        try:
            result = await asyncio.to_thread(voice_profiles.delete_profile, person_entity_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return {"result": result, "stats": memory.stats()}

    @app.post("/api/voice-profiles/session-bind")
    async def bind_live_session_speaker(request: Request, body: SpeakerSessionBindingBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="voice_profile.manage", operation="voice_profile.session_bind", resource_kind="voice_profile", resource_id=body.session_id)
        _require_permission(request, permission_key="memory.write", operation="memory.speaker_binding", resource_kind="memory_person", resource_id=body.person_name)
        clean_name = " ".join(body.person_name.split()).strip()
        if not clean_name:
            raise HTTPException(status_code=400, detail="speaker name cannot be blank")
        try:
            person = memory.canonicalize_person_identity(clean_name)
            if body.address_names:
                person = memory.set_person_address_names(person["id"], body.address_names, action="replace")
            binding = voice_profiles.bind_session_speaker(
                body.session_id,
                body.session_speaker_id,
                person_entity_id=str(person["id"]),
                person_name=str(person.get("preferred_name") or person.get("display_name") or person.get("name") or clean_name),
                address_names=person.get("active_address_names") or body.address_names,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"binding": binding, "person": person, "stats": memory.stats()}

    @app.post("/api/voice-profiles/recognize")
    async def recognize_voice(request: Request) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="voice_profile.use", operation="voice_profile.recognize", resource_kind="voice_profile", session_id=request.headers.get("x-session-id") or "voice_recognition")
        if not resolved.speaker_recognition_enabled:
            return {"recognition": {"status": "disabled", "confidence": 0.0}}
        audio = await request.body()
        if not audio or len(audio) > 16 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="voice clip is empty or too large")
        try:
            result = await asyncio.to_thread(
                voice_profiles.recognize,
                audio,
                source_event_id=request.headers.get("x-source-event-id") or None,
                session_id=request.headers.get("x-session-id") or None,
            )
        except VoiceQualityError as exc:
            return {"recognition": {"status": "insufficient_audio", "confidence": 0.0, "detail": str(exc)}}
        return {"recognition": result}

    @app.get("/api/memory/summary")
    async def memory_summary(request: Request, date: str | None = Query(default=None, max_length=10)) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.summary", resource_kind="memory", resource_id=date or "summary")
        return memory.daily_summary(date)

    @app.get("/api/memory/operations")
    async def memory_operations(request: Request, limit: int = Query(default=50, ge=1, le=250)) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.operations", resource_kind="memory", resource_id="operations")
        return {"operations": memory.operations(limit=limit), "stats": memory.stats()}

    @app.post("/api/memory/undo")
    async def undo_memory_operation(request: Request, body: MemoryUndoBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.undo", resource_kind="memory_operation", resource_id=body.operation_id)
        try:
            result = memory.undo(body.operation_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        result["stats"] = memory.stats()
        return result

    @app.get("/api/memory/export")
    async def export_memory(
        request: Request,
        format: str = Query(default="json", pattern="^(json|markdown)$"),
        q: str = Query(default="", max_length=500),
        category: str | None = Query(default=None, max_length=160),
        source: str | None = Query(default=None, max_length=80),
        actor: str | None = Query(default=None, max_length=160),
        date_from: str | None = Query(default=None, max_length=10),
        date_to: str | None = Query(default=None, max_length=10),
        status: str | None = Query(default=None, max_length=20),
        important: bool | None = Query(default=None),
    ) -> Response:
        _require_permission(request, permission_key="memory.read", operation="memory.export", resource_kind="memory", resource_id=format)
        content, media_type, filename = memory.export(
            format=format, query=q, category=category, source=source, actor=actor,
            date_from=date_from, date_to=date_to, status=status, important=important,
        )
        return Response(
            content=content.encode("utf-8"), media_type=media_type,
            headers={"Content-Disposition": f'attachment; filename="{filename}"', "Cache-Control": "no-store"},
        )

    @app.get("/api/memory/stats")
    async def memory_stats(request: Request, ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.stats", resource_kind="memory", resource_id="stats")
        return memory.stats()

    @app.post("/api/memory/consolidate")
    async def consolidate_memory(request: Request, body: MemoryConsolidationBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.consolidate", resource_kind="memory", resource_id=body.reason or body.mode)
        result = await asyncio.to_thread(memory.consolidate, reason=body.reason, mode=body.mode)
        result["stats"] = memory.stats()
        return result

    @app.get("/api/memory/consolidation/runs")
    async def memory_consolidation_runs(
        request: Request,
        limit: int = Query(default=25, ge=1, le=100),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.consolidation_runs", resource_kind="memory", resource_id="consolidation")
        return {"runs": memory.consolidation_runs(limit=limit), "stats": memory.stats()}

    @app.get("/api/memory/consolidation/findings")
    async def memory_consolidation_findings(
        request: Request,
        status: str = Query(default="open", pattern="^(open|stale|resolved|)$"),
        limit: int = Query(default=100, ge=1, le=250),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.consolidation_findings", resource_kind="memory", resource_id="consolidation")
        return {"findings": memory.consolidation_findings(status=status, limit=limit)}

    @app.get("/api/memory/proactive/inbox")
    async def proactive_memory_inbox(
        request: Request,
        status: str = Query(default="open", pattern="^(open|completed|dismissed|)$"),
        limit: int = Query(default=100, ge=1, le=250),
        minimum_priority: float = Query(default=0.0, ge=0.0, le=1.0),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.proactive_inbox", resource_kind="memory", resource_id="proactive")
        return {
            "items": memory.proactive_inbox(status=status, limit=limit, minimum_priority=minimum_priority),
            "runs": memory.proactive_runs(limit=5),
            "stats": memory.stats(),
        }

    @app.get("/api/memory/proactive/relevant")
    async def proactive_memory_relevant(
        request: Request,
        q: str = Query(min_length=1, max_length=500),
        limit: int = Query(default=5, ge=1, le=20),
        mark_surfaced: bool = Query(default=False),
    ) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.proactive_relevant", resource_kind="memory", resource_id=q)
        return {"items": memory.proactive_relevant(q, limit=limit, mark_surfaced=mark_surfaced)}

    @app.get("/api/memory/proactive/items/{item_id}")
    async def proactive_memory_item(request: Request, item_id: str) -> dict[str, Any]:
        _require_permission(request, permission_key="memory.read", operation="memory.proactive_item", resource_kind="memory_proactive_item", resource_id=item_id)
        item = memory.proactive_item(item_id)
        if item is None:
            raise HTTPException(status_code=404, detail="proactive memory item not found")
        return {"item": item}

    @app.post("/api/memory/proactive/refresh")
    async def refresh_proactive_memory(request: Request, body: ProactiveRefreshBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.proactive_refresh", resource_kind="memory", resource_id=body.reason)
        result = await asyncio.to_thread(memory.refresh_proactive, reason=body.reason)
        result["stats"] = memory.stats()
        return result

    @app.patch("/api/memory/proactive/items/{item_id}")
    async def update_proactive_memory_item(
        request: Request, item_id: str, body: ProactiveUpdateBody
    ) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        _require_permission(request, permission_key="memory.write", operation="memory.proactive_update", resource_kind="memory_proactive_item", resource_id=item_id)
        try:
            item = memory.update_proactive_item(
                item_id, action=body.action, snooze_minutes=body.snooze_minutes
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"item": item, "stats": memory.stats()}

    @app.post("/api/events")
    async def receive_client_event(request: Request, body: ClientEventBody) -> dict[str, Any]:
        if request.headers.get("x-jarvis-client") != CLIENT_HEADER:
            raise HTTPException(status_code=403, detail="missing trusted local client header")
        try:
            event = event_runtime.publish_client_event(
                body.type, body.payload, correlation_id=body.correlation_id
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except StateTransitionError as exc:
            LOGGER.warning("Rejected out-of-order client lifecycle event %s: %s", body.type, exc)
            raise HTTPException(status_code=409, detail="out-of-order Jarvis lifecycle event") from exc
        return {
            "accepted": True,
            "event_id": str(event.event_id),
            "state": event_runtime.state_machine.current_state.value,
        }

    @app.get("/api/events/recent")
    async def recent_events() -> dict[str, Any]:
        return {"events": [event.to_dict() for event in event_runtime.journal.recent()]}

    return app
